# NivareQ Step 2 Pathfinder — S2-B R8 Internal WebView2 Lifecycle Checkpoint

Date: 2026-10-10. **INTERNAL DEVELOPMENT SOURCE ONLY — NOT AN OWNER-TEST CANDIDATE OR ACCEPTED RELEASE.**

## Authority
- Windows **v1.2.1 Stable** remains sole owner-accepted and rollback baseline.
- This source is a direct extension of **S2-B R7 R2**; all earlier checkpoints retained.
- Notes architecture is **Notebook → Note → Page** in one unified Notes workspace; Scratchpad is the editor, not a duplicate document library.
- Lower-left six actions remain My Study, Search, Browse Notes, New Note, Settings, **Backups**.
- S1 Scratchpad JSON bridge, Journal, My Study, Search, active SQLite generations, backup providers, medical content and PWA are not activated, replaced or mutated.

## S2-B R8 implementation
1. `src/NivareQ.Step2Pathfinder/Services/NotesWebDocumentLifecycleV1.cs`: independent, inactive document lifecycle policy. Only explicitly armed first navigation is permitted. Unexpected refreshes, redirects, frame sources and post-crash operations fail closed. Native writer ownership and document-bound editor drain are both required before an explicitly armed reload.
2. `src/NivareQ.Step2Pathfinder/Services/NotesWebView2LifecycleAdapterV1.cs`: typed WinUI3 CoreWebView2 event adapter for NavigationStarting, NavigationCompleted, SourceChanged, WebMessageReceived, ProcessFailed, NewWindowRequested and FrameNavigationStarting. It is **not instantiated, configured with assets or called from MainWindow**. Runtime event coverage is not asserted by compilation.
3. `src/NivareQ.Step2Pathfinder/Services/NotesWebMessageBridgeV1.cs`: read-only `HasOwnedSessions` guard for lifecycle decisions, with existing R7 save/ACK semantics retained.
4. `src/NivareQ.Step2Pathfinder/NotesProtocol/notes-web-transport.js`: staging-only `drainAfterCoordinatorClose`, pagehide teardown, sealed request barrier; no S1 integration.
5. Native isolated policy harness `tests/NotesLifecycleHarness` and JS `tests/NotesLifecycleJsHarness`.

## Mandatory safety gates before activation
- This **does not** prove live WebView2 page lifecycle operation. There is no dedicated Notes asset host, no actual user-facing control opened in CI, no on-device crash test, no live app storage authority, and no cross-provider writer/restore lock.
- **Do not** hook the adapter into the live S1 view, cockpit, Journal or current backup provider.
- S2-D Backup VNext ZIP64 verified full archival restore and atomic active-generation writer gate must be implemented and fault-tested before any live generation activation.
- A crash can lose unsaved renderer memory. R8 quarantines ambiguity; it does not claim miraculous recovery. Incomplete native writer sessions must be handled by later explicit recovery/quarantine procedures.
- Release source must still undergo native owner QA after full S2→U1 integration. S2-C is not started.

## Reproduce local portable checks
- `node tests/NotesLifecycleJsHarness/run.cjs`
- `node tests/NotesWebTransportHarness/run.cjs`
- `node tests/NotesProtocolHarness/run.cjs`
- `python tools/s2b_contract_smoke.py`

## CI
Dedicated branch: `dev/pathfinder-scratchpad-s2-r1-20261009` in temporary CI repository `paglaaacoc/-_-fehu-H-_-` (public). R8 lifecycle workflow `.github/workflows/pathfinder-s2b-r8-lifecycle-ci.yml` validates the SHA-pinned original R5 source plus explicit SHA-verified R8 native overlay, compiles a native R7+R8 policy harness, and compiles WinUI x64 and ARM64. **Run 38042533775 completed SUCCESS: 33 native R7+R8 wire/lifecycle assertions and WinUI x64 + ARM64 compilation.** It is not a build of this complete R8 ZIP as a unit and no installers are produced.

## Next internal gate
S2-B R9: bounded isolated WebView2 *actual UI-event* smoke with a dedicated local HTML document, verified reload/process fault behavior, plus lifecycle failure notification/recovery UX; or transition into Backup VNext design/fault injection if native UI test cannot be executed unattended. No live U1 activation without S2-D.
