# NivareQ Step 2 Pathfinder — S2-D Backup VNext B1

Date: 2026-10-10. **INTERNAL SOURCE CHECKPOINT ONLY — NATIVE CI PENDING, NOT OWNER-ACCEPTED.**

## Authority
- Sole owner-accepted rollback: Windows **v1.2.1 Stable** (embedded historical source untouched).
- Inherited internal validation: S2-B R10 exact crash-test GitHub CI PASS (run `38045461924`); R8 isolated staging source baseline.
- This checkpoint adds a **separate, inactive S2-D B1 backup archive/security primitive and tests**. It changes no existing Pathfinder runtime source files, no installed backup engine, no user data, no restored provider, and no active Notes generation pointer.

## Implemented staging primitive
- `src/NivareQ.Step2Pathfinder/Services/NotesBackupVNextV1.cs`: a new, isolated `.nqpfbackup` ZIP64-capable writer, streaming SHA-256 verifier and inactive-generation extractor. Uses SQLite online backup from a verified sealed staging generation rather than copying a hot SQLite file. Exports the caller-supplied canonical Pathfinder JSON, the SQLite snapshot, referenced PNG/JPEG attachments by SHA-256 (if any), and S1 migration recovery source if present. Writes to a temporary ZIP and verifies the completed archive before non-overwriting final publication.
- Strict ZIP entry-name allowlist, no traversal, case-insensitive duplicate rejection, symlink denial, capped provider/manifest/image entries, decompression-ratio sanity checks, exact length/hash verification. Extracts to a new randomized *inactive* generation and reopens with `NotesStoreV1.OpenStagedGeneration` for SQLite/foreign-key/attachment integrity verification. Never flips active pointer.
- `NotesVNextMutationGate`: separate test-only in-process writer/exclusive lease, explicitly NOT yet installed in the actual app's editors or global restore transactions.
- **Mandatory strict canonical validator callback:** no default and no permissive fallback. Harness callback tests required shape only. Product activation requires binding the existing `BackupContractService` full strict state parser with provider inventory/version checks; no such binding exists yet.
- No total ~100MB library ceiling, but legacy canonical JSON remains capped at 100MB by the trusted provider contract. ZIP64 large-archive acceptance and billion-byte stress/fault testing have NOT been run.

## Validation evidence and limitations
- Portable inherited R10 tests: 52 JS ACK + 11 Web transport + 10 lifecycle + 8 SQLite + 22 SQLite contract and static checks PASS, including original medical payload count 132.
- New `tools/s2d_b1_static_gate.py` structural/negative-wiring contract PASS. It is **NOT a .NET compiler, native execution, nor proof of safe restore**.
- Native .NET backup harness source exists at `tests/NotesBackupVNextHarness/`, including negative cases. **No native Windows CI for these new source bytes yet**. Earlier R10 Windows CI does not validate this new B1 code.
- R10 full source files remain byte-identical; new artifacts are additive only.

## Hard gates still open
1. Native .NET 10 compilation/execution for this exact B1 snapshot and security harness; Windows x64/ARM64 app compile after any actual inclusion.
2. Full Pathfinder provider inventory + **actual** `BackupContractService` strict validator and complete coherent provider/Notes snapshot under ONE global writer gate. Current B1 gate is isolated, not bound to live S1/Journal/My Study.
3. True SQLite/attachment restoration with proven cross-provider consistency, disk-space preflight, cancellation/crash recovery and fault-injection; transactional pointer activation via existing `RestoreTransactionService.Commit()` and clean-restart writer invalidation.
4. ZIP64 >4GB, 1GB and 5GB streaming tests, asset-decode checks, malicious archive expansion attacks, interrupted snapshot/rename/power loss, and safe garbage collection.
5. Actual isolated WinUI Notes screen and Backup UI integration, then owner-test installers and explicit acceptance. None started.

## Next checkpoint
Run Windows native B1 harness, fix any compiler or runtime defects, then bind a unified provider snapshot and generation-pointer transaction adapter in *inactive* tests. DO NOT enable notes, rewrite existing backup, reset, or delete/collect generations.
