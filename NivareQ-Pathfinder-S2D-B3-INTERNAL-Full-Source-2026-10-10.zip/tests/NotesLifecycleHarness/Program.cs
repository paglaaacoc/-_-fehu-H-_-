using System.Text.Json;
using NivareQ.Step2Pathfinder.Services;

var checks = 0;
void Check(bool ok, string detail)
{
    if (!ok) throw new Exception("FAIL R8 lifecycle: " + detail);
    ++checks;
}
void Deny(Action action, string detail)
{
    try { action(); }
    catch (InvalidOperationException) { ++checks; return; }
    throw new Exception("FAIL: " + detail);
}
var directory = Path.Combine(Path.GetTempPath(), "pathfinder-r8-inactive-" + Guid.NewGuid().ToString("N"));
try
{
    using var store = NotesStoreV1.CreateStaging(directory);
    var notebook = store.CreateNotebook("R8 isolated notes");
    var note = store.CreateNote(notebook, "Lifecycle tests");
    var page = store.ListPages(note)[0].Id;
    var router = new NotesStagingPageRouterV1(store);
    const string trusted = NotesWebMessageBridgeV1.TrustedPage;
    var policy = new NotesWebDocumentLifecycleV1(router);
    Check(policy.State == NotesWebDocumentLifecycleV1.Phase.New, "first document starts unloaded");
    Check(!policy.NavigationStarting(trusted, 10), "unarmed top-level navigation is refused");
    policy.ArmInitialNavigation();
    Check(!policy.NavigationStarting("https://scratchpad.pathfinder.invalid/index.html", 11),
        "S1 Scratchpad navigation cannot consume initial permit");
    Check(policy.NavigationStarting(trusted, 12), "explicit initial Notes navigation starts");
    Check(!policy.NavigationStarting(trusted, 13), "overlapping redirect or reload refused");
    Check(policy.NavigationCompleted(trusted, 13, false) is null && policy.State == NotesWebDocumentLifecycleV1.Phase.Loading,
        "canceled navigation completion cannot revoke in-flight legitimate navigation");
    var bootstrap = policy.NavigationCompleted(trusted, 12, true)!;
    using var boot = JsonDocument.Parse(bootstrap);
    var token = boot.RootElement.GetProperty("documentToken").GetString()!;
    Check(token.Length == 48 && policy.State == NotesWebDocumentLifecycleV1.Phase.Ready,
        "navigation completion mints a new document authority");
    Deny(policy.ArmReloadAfterDrain, "raw reload without native release is denied");
    Check(!policy.NavigationStarting(trusted, 14), "reload Ctrl+R denied without arm");
    string Packet(string type, object payload, string requestId, string? nonce=null)
        => JsonSerializer.Serialize(new { channel=NotesWebMessageBridgeV1.Channel,
            documentToken=nonce??token, type, requestId, payload });
    JsonDocument Send(string type, object payload, string id)
        => JsonDocument.Parse(policy.WebMessageReceived(trusted,trusted,Packet(type,payload,id))
            ?? throw new Exception("Missing native message response: " + type));
    Check(policy.WebMessageReceived("https://evil.invalid/index.html",trusted,
        Packet("notes-open",new { noteId=note, pageId=page },"reject")) is null,
        "foreign frame/source never receives a response");
    Check(policy.WebMessageReceived(trusted,trusted,
        Packet("notes-drained",new {editorFrozen=true},"forged",new string('0',48))) is null,
        "forged document token cannot drain");
    using var open = Send("notes-open",new {noteId=note,pageId=page},"open_1");
    Check(open.RootElement.GetProperty("ok").GetBoolean(), "staging page opened");
    var session = open.RootElement.GetProperty("result").GetProperty("sessionId").GetString()!;
    Check(policy.HasNativeWriter && !policy.TryClose(), "active native page writer prevents close");
    Check(policy.WebMessageReceived(trusted,trusted,
        Packet("notes-drained",new {editorFrozen=true},"unreleased")) is null,
        "renderer cannot claim drain with an owned native writer session");
    var draft = new {guide="ruled",spacing=32,cells=new[]{new {text="saved before reload",strokesJson="[]"}},images=Array.Empty<object>()};
    using var write = Send("notes-write",new {protocol=NotesStagingPageRouterV1.Protocol,sessionId=session,
        sequence=1,noteId=note,pageId=page,expectedRevision=0,page=draft},"write_1");
    Check(write.RootElement.GetProperty("ok").GetBoolean() &&
        write.RootElement.GetProperty("result").GetProperty("persistedRevision").GetInt64() == 1,
        "only native committed revision produces success");
    using var release = Send("notes-release",new {sessionId=session,lastAcknowledgedSequence=1,
        lastAcknowledgedRevision=1},"release_1");
    Check(release.RootElement.GetProperty("ok").GetBoolean() && !policy.HasNativeWriter,
        "native writer is released by matching ACK");
    Check(!policy.TryClose(),"idle document still needs editor freeze/drain attestation");
    using var drained = Send("notes-drained",new {editorFrozen=true},"drain_1");
    Check(drained.RootElement.GetProperty("ok").GetBoolean() &&
        policy.State == NotesWebDocumentLifecycleV1.Phase.Sealed,
        "verified drain revokes prior document lease");
    Check(policy.WebMessageReceived(trusted,trusted,Packet("notes-open",new{noteId=note,pageId=page},"late")) is null,
        "sealed document cannot restart a writer");
    policy.ArmReloadAfterDrain();
    Check(policy.NavigationStarting(trusted, 15), "reloading sealed and released page is permitted");
    var fresh = policy.NavigationCompleted(trusted,15,true)!;
    using var freshBoot = JsonDocument.Parse(fresh);
    var token2 = freshBoot.RootElement.GetProperty("documentToken").GetString()!;
    Check(token2 != token && policy.State == NotesWebDocumentLifecycleV1.Phase.Ready,
        "reloaded page gets distinct document capability");
    Check(policy.WebMessageReceived(trusted,trusted,Packet("notes-open",new {noteId=note,pageId=page},"old_lease")) is null,
        "stale pre-reload messages never receive a response");
    using var readBack = JsonDocument.Parse(policy.WebMessageReceived(trusted,trusted,
        JsonSerializer.Serialize(new {channel=NotesWebMessageBridgeV1.Channel,documentToken=token2,
            requestId="open_after",type="notes-open",payload=new {noteId=note,pageId=page}}))!);
    Check(readBack.RootElement.GetProperty("ok").GetBoolean() &&
        readBack.RootElement.GetProperty("result").GetProperty("persistedRevision").GetInt64() == 1,
        "reloaded document reads durable committed page only");
    policy.ProcessFailed("RenderProcessExited");
    Check(policy.State == NotesWebDocumentLifecycleV1.Phase.Quarantined && !policy.CanCloseSafely &&
        policy.HasNativeWriter,"renderer failure quarantines a still-owned native session");
    Check(!policy.NavigationStarting(trusted,16) && policy.NavigationCompleted(trusted,16,true) is null,
        "quarantined page cannot silently reload");
    Check(store.ReadPage(note,page).Cells[0].Text == "saved before reload",
        "stale document and process failure do not rewrite committed page");

    var newPolicy = new NotesWebDocumentLifecycleV1(router);
    newPolicy.ArmInitialNavigation();
    Check(newPolicy.NavigationStarting(trusted,20),"new independent document can start without hijacking old session");
    Check(newPolicy.NavigationCompleted("https://bad.invalid",20,true) is null &&
        newPolicy.State == NotesWebDocumentLifecycleV1.Phase.Quarantined,
        "unexpected completion URL quarantines");
    Console.WriteLine($"PASS S2-B R8 native isolated WebView lifecycle policy: {checks} checks");
}
finally
{
    if (Directory.Exists(directory)) Directory.Delete(directory,true);
}
