using System.IO.Compression;
using System.Text;
using System.Text.Json;
using NivareQ.Step2Pathfinder.Services;

// S2-D B1: Isolated archive security and mutation-gate harness ONLY.
// Canonical state test validator is a fixture, NOT Pathfinder's production
// strict BackupContractService.ParseImport(...) and NEVER authorizes activation.
int count=0;
void Check(bool ok,string tag)
{ if(!ok) throw new Exception("FAIL " + tag); count++; Console.WriteLine("PASS B1 " + tag); }
void Refuse(Action f,string tag)
{
    try { f(); }
    catch(Exception e) when(e is InvalidDataException or IOException or InvalidOperationException or JsonException or ArgumentOutOfRangeException or Microsoft.Data.Sqlite.SqliteException)
    { Check(true,tag);return; }
    throw new Exception("Expected failure: "+tag);
}
void CanonicalFixture(JsonElement obj)
{
    if (obj.ValueKind != JsonValueKind.Object ||
        obj.GetProperty("BackupSchemaVersion").GetInt32()!=7 ||
        obj.GetProperty("FormatId").GetString()!="nivareq.step2pathfinder.backup" ||
        obj.GetProperty("ContractAuthority").GetString()!="windows-canonical" ||
        !obj.TryGetProperty("PersonalStudy",out _) || !obj.TryGetProperty("ShellSettings",out _) ||
        !obj.TryGetProperty("Journal",out _) || !obj.TryGetProperty("UWorldSelector",out _) ||
        !obj.TryGetProperty("CockpitState",out _) || !obj.TryGetProperty("Coverage",out _) ||
        !obj.TryGetProperty("PreservedExtensions",out _))
        throw new InvalidDataException("Fake canonical provider shape.");
}
var temp=Path.Combine(Path.GetTempPath(),"nqpf-vnext-b1-"+Guid.NewGuid().ToString("N"));
Directory.CreateDirectory(temp);
try
{
    var notesRoot=Path.Combine(temp,"notes");
    string genId;
    var gate=new NotesVNextMutationGate();
    var data=Encoding.UTF8.GetBytes("""
        {"BackupSchemaVersion":7,"FormatId":"nivareq.step2pathfinder.backup","ContractAuthority":"windows-canonical",
        "ShellSettings":{},"PersonalStudy":{},"CockpitState":{},"Journal":{},"UWorldSelector":{},"Coverage":{},"PreservedExtensions":{}}
        """);
    var archive=Path.Combine(temp,"complete.nqpfbackup");
    using(var store=NotesStoreV1.CreateStaging(notesRoot))
    {
        genId=store.GenerationId;
        var notebook=store.CreateNotebook("Safety notebook");
        var note=store.CreateNote(notebook,"Persistent note");
        var page=store.ListPages(note)[0];
        store.SavePage(note,page.Id,0,"ruled",32,[new NotesInkCell("Source-backed durable note", "[]")]);
        Refuse(()=>NotesBackupVNextV1.ExportStaging(archive,data,notesRoot,genId,gate,CanonicalFixture),
            "unsealed generation cannot be archived");
        store.SealStaging();
    }
    using(var writer=gate.Writer())
    {
        Refuse(()=>NotesBackupVNextV1.ExportStaging(archive,data,notesRoot,genId,gate,CanonicalFixture),
            "archive refused while a writer holds the gate");
        Refuse(()=>gate.Exclusive(),"exclusive gate cannot bypass an active writer");
    }
    using(var guard=gate.Exclusive())
    {
        Refuse(()=>gate.Writer(),"writer cannot enter during full backup/restore gate");
        Refuse(()=>gate.Exclusive(),"second backup/restore excluded");
    }
    // B2: coherent state capture is performed with the exclusive gate held.
    long epoch=7;
    var coherentArchive=Path.Combine(temp,"coherent.nqpfbackup");
    NotesBackupVNextV1.ExportStagingCoherent(coherentArchive,
        ()=> { Refuse(()=>gate.Writer(),"coherent capture excludes simultaneous provider mutation");return data; },
        ()=>epoch,notesRoot,genId,gate,CanonicalFixture);
    Check(File.Exists(coherentArchive),"coherent snapshot archived after exclusive provider capture");
    Check(NotesBackupVNextV1.Verify(coherentArchive,CanonicalFixture).Entries.Count==2,
        "coherent export yields independently verifiable archive");
    var changedDuring=Path.Combine(temp,"epoch-unstable.nqpfbackup");
    Refuse(()=>NotesBackupVNextV1.ExportStagingCoherent(changedDuring,
            ()=>{epoch++;return data;},()=>epoch,notesRoot,genId,gate,CanonicalFixture),
        "epoch changed during provider capture rejected");
    Check(!File.Exists(changedDuring),"unstable capture never publishes a ZIP");
    var changedAtPublish=Path.Combine(temp,"epoch-publish.nqpfbackup");
    long poll=0;
    Refuse(()=>NotesBackupVNextV1.ExportStagingCoherent(changedAtPublish,
            ()=>data,()=> ++poll < 3 ? 7L : 9L,notesRoot,genId,gate,CanonicalFixture),
        "epoch changed before publication refused");
    Check(!File.Exists(changedAtPublish),"changed-epoch archive never published");
    NotesBackupVNextV1.ExportStaging(archive,data,notesRoot,genId,gate,CanonicalFixture);
    Check(File.Exists(archive),"staging archive published only after verification");
    var verified=NotesBackupVNextV1.Verify(archive,CanonicalFixture);
    Check(verified.Format==NotesBackupVNextV1.Format && verified.Entries.Count==2,
        "manifest includes canonical provider + consistent SQLite snapshot");
    Check(verified.Entries.All(e=>e.Sha256.Length==64),"all payloads SHA-256 verified");
    // B3: a valid checksum does not override the resource budget, and a
    // refused budget must never even allocate a partial Notes generation.
    var beforeBudget = Directory.GetDirectories(Path.Combine(notesRoot,"generations")).Length;
    var oversizedBudget = new NotesVNextResourceBudget(256, 0);
    Refuse(()=>NotesBackupVNextV1.Verify(archive,CanonicalFixture,oversizedBudget),
        "refuse fully hashed ZIP when selected extraction budget is too small");
    Refuse(()=>NotesBackupVNextV1.ExtractToInactiveGeneration(archive,notesRoot,gate,
        CanonicalFixture,oversizedBudget),
        "refuse extraction pre-allocation when uncompressed archive exceeds budget");
    Check(Directory.GetDirectories(Path.Combine(notesRoot,"generations")).Length==beforeBudget,
        "rejected resource-budget archive allocated no new generation");
    var invalidBudget = new NotesVNextResourceBudget(-1);
    Refuse(()=>NotesBackupVNextV1.Verify(archive,CanonicalFixture,invalidBudget),
        "invalid negative resource budget rejected");
    var restoredId=NotesBackupVNextV1.ExtractToInactiveGeneration(archive,notesRoot,gate,CanonicalFixture);
    Check(restoredId!=genId && NotesStoreV1.IsValidGenerationId(restoredId),
        "restore extraction stages fresh, inactive generation ID only");
    using(var verifiedStage=NotesStoreV1.OpenStagedGeneration(notesRoot,restoredId))
    {
        var notebooks=verifiedStage.ListNotebooks();
        Check(notebooks.Count==1 && notebooks[0].Title=="Safety notebook",
            "verified staged extraction reopens Notes database without active pointer");
    }
    var altered=Path.Combine(temp,"tampered.nqpfbackup");
    File.Copy(archive,altered);
    using(var zip=ZipFile.Open(altered,ZipArchiveMode.Update))
    {
        var entry=zip.GetEntry("pathfinder-state.json")!;
        entry.Delete();
        var fake=zip.CreateEntry("pathfinder-state.json");
        using var stream=fake.Open();stream.Write(Encoding.UTF8.GetBytes("{\"forged\":true}"));
    }
    Refuse(()=>NotesBackupVNextV1.Verify(altered,CanonicalFixture),
        "reject payload that no longer matches manifest after ZIP rewrite");
    // An attacker can rehash a corrupt database and forge an internally
    // self-consistent manifest. Inactive staging must still reject it using
    // NotesStore's real SQLite integrity/schema/FK checks.
    var malicious=Path.Combine(temp,"internally-rehashed-corrupt-db.nqpfbackup");
    var invalidDatabase=Encoding.UTF8.GetBytes("This is not a SQLite database");
    var forgedManifest=new NotesVNextManifest(NotesBackupVNextV1.Format,1,[
        new NotesVNextEntry("pathfinder-state.json",data.LongLength,
            Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(data)).ToLowerInvariant()),
        new NotesVNextEntry("scratchpad.sqlite",invalidDatabase.LongLength,
            Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(invalidDatabase)).ToLowerInvariant())
    ]);
    using(var zip=ZipFile.Open(malicious,ZipArchiveMode.Create))
    {
        foreach(var item in new (string path,byte[] payload)[]{
            ("pathfinder-state.json",data),("scratchpad.sqlite",invalidDatabase),
            ("manifest.json",JsonSerializer.SerializeToUtf8Bytes(forgedManifest))})
        { var e=zip.CreateEntry(item.path);using var output=e.Open();output.Write(item.payload); }
    }
    Check(NotesBackupVNextV1.Verify(malicious,CanonicalFixture).Entries.Count==2,
        "cryptographic hashes alone do not claim a sound SQLite database");
    Refuse(()=>NotesBackupVNextV1.ExtractToInactiveGeneration(malicious,notesRoot,gate,CanonicalFixture),
        "rehashed but corrupt SQLite rejected by inactive generation verification");

    Refuse(()=>NotesBackupVNextV1.ExportStaging(archive,data,notesRoot,genId,gate,CanonicalFixture),
        "existing user backup never silently overwritten");
    using(var store=NotesStoreV1.OpenStagedGeneration(notesRoot,genId))
        Check(store.ListNotebooks().Count==1,"export left source generation intact");

    string Make(string name,params (string path,byte[] bytes)[] items)
    {
        var path=Path.Combine(temp,name);
        using var zip=ZipFile.Open(path,ZipArchiveMode.Create);
        foreach(var e in items)
        {
            var entry=zip.CreateEntry(e.path);
            using var stream=entry.Open();stream.Write(e.bytes);
        }
        return path;
    }
    var payload=Encoding.UTF8.GetBytes("test");
    Refuse(()=>NotesBackupVNextV1.Verify(Make("traversal.zip",("../manifest.json",payload),("pathfinder-state.json",data),("scratchpad.sqlite",payload)),CanonicalFixture),
        "reject traversal before extraction");
    Refuse(()=>NotesBackupVNextV1.Verify(Make("duplicate.zip",("manifest.json",payload),("MANIFEST.JSON",payload),("pathfinder-state.json",data),("scratchpad.sqlite",payload)),CanonicalFixture),
        "reject case-insensitive duplicate archive names");
    Refuse(()=>NotesBackupVNextV1.Verify(Make("arbitrary.zip",("evil.exe",payload),("manifest.json",payload),("pathfinder-state.json",data),("scratchpad.sqlite",payload)),CanonicalFixture),
        "reject extra executable entry");
    Refuse(()=>NotesBackupVNextV1.Verify(Make("malformed.zip",("manifest.json",payload),("pathfinder-state.json",data),("scratchpad.sqlite",payload)),CanonicalFixture),
        "reject malformed or forged manifest");
    using(var invalid=new MemoryStream())
    {
        var invalidProvider=Encoding.UTF8.GetBytes("{\"PersonalStudy\":{}}");
        Refuse(()=>NotesBackupVNextV1.ExportStaging(Path.Combine(temp,"bad.nqpfbackup"), invalidProvider,notesRoot,genId,gate,CanonicalFixture),
            "strict canonical callback rejects incomplete provider graph");
        Check(!File.Exists(Path.Combine(temp,"bad.nqpfbackup")),"provider rejection never publishes backup");
    }
    Console.WriteLine($"PASS S2-D B1 BACKUP ARCHIVE: {count} isolated security/gate checks; no live provider or restore activation");
}
finally { try { Directory.Delete(temp,true); } catch(IOException) { } }
