using System.Text;
using System.Text.Json;
using NivareQ.Step2Pathfinder.Services;

// Standalone non-Windows smoke suite: dotnet run --project tests/NotesStoreHarness
static void Check(bool value, string message) { if (!value) throw new Exception("FAIL: " + message); }
static void ExpectFailure(Action test, string message)
{
    try { test(); throw new Exception("FAIL: accepted " + message); }
    catch (Exception ex) when (ex is InvalidOperationException or InvalidDataException or Microsoft.Data.Sqlite.SqliteException or FileNotFoundException or KeyNotFoundException)
    { /* expected fail-closed */ }
}
var root = Path.Combine(Path.GetTempPath(), "pathfinder-s2b-tests-" + Guid.NewGuid().ToString("N"));
try
{
    var gen = "";
    var note = ""; var page = "";
    using (var store = NotesStoreV1.CreateStaging(root))
    {
        gen = store.GenerationId;
        Check(NotesStoreV1.IsValidGenerationId(gen), "generation ID validation");
        var book = store.CreateNotebook("General");
        note = store.CreateNote(book,"Test clinical note");
        Check(store.SearchNoteIds("clinical").Contains(note), "FTS title");
        // Native bootstrap page ID is retrieved from test DB without relying on UI.
        using (var db = new Microsoft.Data.Sqlite.SqliteConnection($"Data Source={store.DatabasePath}"))
        {
            db.Open(); using var cmd = db.CreateCommand();
            cmd.CommandText = "SELECT id FROM pages WHERE note_id=@n";
            cmd.Parameters.AddWithValue("@n", note);
            page = (string)(cmd.ExecuteScalar() ?? throw new Exception("missing page"));
        }
        var ink = "[{\"color\":\"#142235\",\"width\":2,\"points\":[[0.1,0.2],[0.5,0.5]]}]";
        var rev = store.SavePage(note,page,0,"ruled",44,[new NotesInkCell("Saved cardiology test",ink)]);
        Check(rev==1, "first revision");
        Check(store.SearchNoteIds("cardiology").Contains(note), "FTS page content");
        Check(store.ListNotebooks().Count == 1, "notebook library");
        Check(store.ListNotes().Count == 1 && store.ListNotes()[0].Id == note, "library note listing");
        Check(store.ListPages(note).Count == 1, "page summaries");
        var clinicalNotebook = store.CreateNotebook("Clinical");
        var noteRevision = store.ReadNote(note).Revision;
        var movedRev = store.UpdateNoteMetadata(note, noteRevision, clinicalNotebook,
            "Revised clinical note", "cardiology", true);
        Check(movedRev == noteRevision + 1, "metadata CAS increment");
        Check(store.ListNotes(clinicalNotebook).Count == 1 && store.ReadNote(note).Pinned, "notebook move and pin");
        ExpectFailure(() => store.UpdateNoteMetadata(note, noteRevision, clinicalNotebook,
            "Stale overwrite", "cardiology", false), "stale note metadata");
        Check(store.SearchNoteIds("Revised").Contains(note), "metadata FTS refresh");
        var otherNote = store.CreateNote(clinicalNotebook, "Unrelated case");
        var otherPage = store.ListPages(otherNote)[0].Id;
        ExpectFailure(() => store.SetActivePage(note, otherPage, movedRev), "cross-note page navigation");
        Check(store.ReadNote(note).Revision == movedRev, "rejected navigation retained note revision");
        var switchedRevision = store.SetActivePage(note, page, movedRev);
        Check(switchedRevision == movedRev + 1, "same-note revisioned page navigation");
        var secondPage = store.AddPage(note, 1, "triple", 60);
        Check(store.ListPages(note).Count == 2, "add page kept first page");
        Check(store.ReadNote(note).Revision == switchedRevision + 1, "add page increments note revision");
        Check(store.ReadPage(note, page).Cells[0].Text == "Saved cardiology test", "page switch preserved draft");
        var activeRevision = store.ReadNote(note).Revision;
        Check(store.SetActivePage(note, secondPage, activeRevision) == activeRevision + 1,
            "second page activates under CAS");
        // The final browser will offer a reversible per-space Trash experience.
        // Until then the backend must refuse removing nonempty writing spaces.
        var twoCells = new[] { new NotesInkCell("Keep cell one", "[]"), new NotesInkCell("Keep cell two", "[]") };
        var twoRevision = store.SavePage(note, secondPage, 0, "triple", 60, twoCells);
        ExpectFailure(() => store.SavePage(note, secondPage, twoRevision, "triple", 60,
            [new NotesInkCell("Keep cell one", "[]")]), "destructive writing-space reduction");
        Check(store.ReadPage(note, secondPage).Revision == twoRevision &&
              store.ReadPage(note, secondPage).Cells.Count == 2, "rejected reduction preserved both cells");
        // Subject-only and invalid alleged positions must never become exact sources.
        ExpectFailure(() => store.CreateNote(clinicalNotebook, "False exact reference", references:
            [new NotesReference("resource", "v1", "{}", true)]), "unverified exact source");
        var subjectNote = store.CreateNote(clinicalNotebook, "Subject only", "cardiology",
            [new NotesReference("resource", "v1", null, false)]);
        Check(store.ReadNoteSources(subjectNote).Count == 1 &&
              !store.ReadNoteSources(subjectNote)[0].Verified, "subject-only source stays unverified");
        var trustedNote = store.CreateNote(clinicalNotebook, "Trusted source", "cardiology",
            [new NotesReference("resource", "v1", "{\"paragraph\":8}", true)],
            verifyExactSource: r => r.ResourceId == "resource" && r.SourceLocationJson == "{\"paragraph\":8}");
        Check(store.ReadNoteSources(trustedNote)[0].Verified, "trusted exact source retained");
        ExpectFailure(()=>store.SavePage(note,page,0,"ruled",44,[new NotesInkCell("bad stale write","[]")]),"stale save");
        Check(store.ReadPage(note,page).Cells[0].Text=="Saved cardiology test", "stale write rolled back");
        ExpectFailure(()=>store.SavePage(note,page,1,"ruled",32,[new NotesInkCell("invalid", "[{\"color\":\"bad\",\"width\":2,\"points\":[[0.2,0.3]]}]")]),"invalid ink");
        // Transparent 1x1 PNG has valid chunk CRCs and is saved content-addressed.
        var png = Convert.FromBase64String("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAADElEQVR4nGP4z8AAAAMBAQDJ/pLvAAAAAElFTkSuQmCC");
        try
        {
            using var image = new MemoryStream(png);
            var blob = store.PutAttachment(image,"image/png");
            Check(blob.Sha256.Length==64 && blob.Width==1 && blob.Height==1,"PNG attachment");
            var obj = new NotesImageObject("img1",0,blob.Sha256,0.1,0.2,0.4,0.3,0);
            store.SavePage(note,page,1,"ruled",44,[new NotesInkCell("Saved cardiology test",ink)],[obj]);
            store.VerifyIntegrity();
            Check(store.ReadPage(note,page).Images.Count==1,"image reference persisted");
        }
        catch (InvalidDataException) { Console.WriteLine("PNG fixture rejected; image-positive path requires a validated fixture."); throw; }
        using (var badImage = new MemoryStream(new byte[] { 0, 1, 2, 3, 4, 5 }))
            ExpectFailure(() => store.PutAttachment(badImage, "image/png"), "malformed image upload");
        var missingImage = new NotesImageObject("missing", 0, new string('0', 64), 0.1, 0.1, 0.2, 0.2, 0);
        ExpectFailure(() => store.SavePage(note, page, 2, "ruled", 44,
            [new NotesInkCell("Saved cardiology test", ink)], [missingImage]), "missing image blob FK");
        Check(store.ReadPage(note, page).Revision == 2 &&
              store.ReadPage(note, page).Images.Count == 1, "missing attachment rollback kept previous page and image");
        using var s1 = JsonDocument.Parse("""
          {"schemaVersion":1,"activePadId":"old-pad","pads":[{"id":"old-pad","title":"Old test S1 note",
          "activePageId":"old-page","pages":[{"id":"old-page","guide":"ruled","spacing":60,
          "cells":[{"text":"Legacy text intact","strokes":[{"color":"#142235","width":2,"points":[[0.5,0.5]]}]}]}]}]}
          """);
        var summary = store.ImportS1(s1.RootElement);
        Check(summary.PadCount==1 && summary.PageCount==1 && summary.CellCount==1 && summary.InkStrokeCount==1,
            "S1 import record counts");
        Check(store.SearchNoteIds("Legacy").Count==1,"S1 imported body searchable");
        Check(File.Exists(Path.Combine(root,"generations",gen,"s1-import-source.json")),"S1 source retained");
        store.VerifyIntegrity();
        var beforeTrashRevision = store.ReadNote(note).Revision;
        var trashRevision = store.SetTrashed(note, beforeTrashRevision, true);
        Check(store.ListNotes(clinicalNotebook).All(n => n.Id != note), "Trash omitted from active library");
        Check(store.ListNotes(clinicalNotebook, trash: true).Any(n => n.Id == note), "Trash has note");
        Check(!store.SearchNoteIds("cardiology").Contains(note), "Trash removed from FTS");
        ExpectFailure(() => store.SavePage(note, page, 2, "ruled", 32,
            [new NotesInkCell("Must not save to Trash", "[]")]), "save to Trash");
        ExpectFailure(() => store.AddPage(note, 2), "append to Trash");
        ExpectFailure(() => store.SetTrashed(note, beforeTrashRevision, false), "stale Trash restore");
        Check(store.SetTrashed(note, trashRevision, false) == trashRevision + 1, "Trash restore CAS");
        Check(store.ReadPage(note, secondPage).Cells[1].Text == "Keep cell two", "Trash retained page contents");
        Check(store.SearchNoteIds("cardiology").Contains(note), "restored note reindexed");
        // R3: staging-only session matching, duplicate ACK idempotence and CAS.
        var pageRouter = new NotesStagingPageRouterV1(store);
        var draftNote = store.CreateNote(clinicalNotebook, "Protocol trial");
        var draftPage = store.ListPages(draftNote)[0].Id;
        var session = pageRouter.OpenStagingPage(draftNote, draftPage);
        var proposed = new NotesPageDraft("ruled", 48,
            [new NotesInkCell("Save via staging router", "[]")], []);
        var packet = new NotesPageWritePacket(NotesStagingPageRouterV1.Protocol,
            session.SessionId, 5, session.NoteId, session.PageId, session.PersistedRevision, proposed);
        var firstAck = pageRouter.Write(packet);
        ExpectFailure(() => pageRouter.OpenStagingPage(draftNote, draftPage),
            "competing writer session for same page blocked");
        Check(firstAck.PersistedRevision == 1, "staging router returns committed ACK");
        var probeRequest = new NotesPageProbeRequest(NotesStagingPageRouterV1.Protocol,
            session.SessionId, draftNote, draftPage);
        var nativeProbe = pageRouter.Probe(probeRequest);
        Check(nativeProbe.PersistedRevision == firstAck.PersistedRevision &&
              nativeProbe.Page.Cells[0].Text == proposed.Cells[0].Text &&
              nativeProbe.SessionId == session.SessionId, "native read-based lost-ACK reconciliation");
        ExpectFailure(() => pageRouter.Probe(probeRequest with { PageId = page }),
            "recovery read requires exact session/page ownership");
        // Regression: actual JavaScript wire cells transmit strokesJson STRING,
        // not the renderer's strokes array. A camelCase JSON object must bind
        // to the same immutable native packet type used by the write router.
        var actualJsPacket = $$$"""
            {"protocol":"{{{NotesStagingPageRouterV1.Protocol}}}","sessionId":"{{{session.SessionId}}}",
             "sequence":5,"noteId":"{{{draftNote}}}","pageId":"{{{draftPage}}}",
             "expectedRevision":0,"page":{"guide":"ruled","spacing":48,
               "cells":[{"text":"Save via staging router","strokesJson":"[]"}],"images":[]}}
            """;
        var jsDto = JsonSerializer.Deserialize<NotesPageWritePacket>(actualJsPacket,
            new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        Check(jsDto is not null && jsDto.Page.Cells.Count == 1 &&
              jsDto.Page.Cells[0].StrokesJson == "[]" &&
              jsDto.Page.Cells[0].Text == "Save via staging router", "real JS camelCase strokesJson DTO binds");

        Check(pageRouter.Write(packet) == firstAck, "duplicate retransmission returns same ACK without another write");
        Check(store.ReadPage(draftNote, draftPage).Revision == 1, "duplicate ACK did not increment revision");
        ExpectFailure(() => pageRouter.Write(packet with { Page = proposed with { Spacing = 60 } }),
            "altered retransmission cannot reuse ACK");
        ExpectFailure(() => pageRouter.Write(packet with { Sequence = 4 }), "older save request blocked");
        ExpectFailure(() => pageRouter.Write(packet with { Sequence = 6, PageId = page }),
            "cross-page injection blocked");
        ExpectFailure(() => pageRouter.Write(packet with { Sequence = 6, ExpectedRevision = 0 }),
            "stale revision blocked");
        Check(store.ReadPage(draftNote, draftPage).Cells[0].Text == "Save via staging router",
            "rejected packets never removed saved text");
        var nextAck = pageRouter.Write(packet with { Sequence = 7, ExpectedRevision = 1,
            Page = proposed with { Cells = [new NotesInkCell("Latest page draft", "[]")] } });
        Check(nextAck.PersistedRevision == 2 &&
            store.ReadPage(draftNote, draftPage).Cells[0].Text == "Latest page draft",
            "monotonic page revisions preserve final draft");
        ExpectFailure(() => pageRouter.OpenStagingPage(draftNote, page), "foreign page session blocked");
        // Check the actual JSON casing that the future WebView2 envelope uses.
        var wire = JsonSerializer.Serialize(packet,
            new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase });
        var roundtrip = JsonSerializer.Deserialize<NotesPageWritePacket>(wire,
            new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        Check(roundtrip is not null && roundtrip.Page.Cells[0].Text == proposed.Cells[0].Text &&
              roundtrip.SessionId == session.SessionId, "camelCase renderer/native envelope round-trip");
        ExpectFailure(() => pageRouter.ReleaseStagingPage(session.SessionId, 5, 1),
            "release without last acknowledged revision blocked");
        pageRouter.ReleaseStagingPage(session.SessionId, 7, 2);
        ExpectFailure(() => pageRouter.Write(packet), "released session cannot be replayed");
        var reopenedPage = pageRouter.OpenStagingPage(draftNote, draftPage);
        Check(reopenedPage.PersistedRevision == 2, "released page reopens at durable revision");
        store.SealStaging();
        ExpectFailure(()=>store.CreateNotebook("Should not write after seal"),"sealed write");
    }
    using (var opened = NotesStoreV1.OpenStagedGeneration(root,gen))
    {
        Check(opened.ReadPage(note,page).Revision==2,"reopen persisted revision");
        opened.VerifyIntegrity();
    }
    ExpectFailure(()=>NotesStoreV1.OpenStagedGeneration(root,"../bad"),"path traversal");
    // Tampered S1 recovery evidence must refuse read-only reopening.
    var sourceEvidence = Path.Combine(root, "generations", gen, "s1-import-source.json");
    File.AppendAllText(sourceEvidence, "CORRUPT", Encoding.UTF8);
    ExpectFailure(() => NotesStoreV1.OpenStagedGeneration(root, gen), "modified S1 recovery source");
    ExpectFailure(()=>NotesStoreV1.OpenStagedGeneration(root,new string('a',32)),"missing generation");
    // Partial S1 import must never be sealed or activated. New generation is the
    // only safe retry; source in failed stage remains available for forensics.
    using (var broken = NotesStoreV1.CreateStaging(root))
    {
        var brokenDir = Path.GetDirectoryName(broken.DatabasePath)!;
        using var legacy = JsonDocument.Parse("""
          {"schemaVersion":1,"activePadId":"old", "pads":[
          {"id":"old","title":"Saved source","activePageId":"p1","pages":[
          {"id":"p1","guide":"ruled","spacing":32,"cells":[{"text":"Retain original","strokes":[]}]},
          {"id":"p1","guide":"ruled","spacing":32,"cells":[{"text":"Duplicate page ID","strokes":[]}]}
          ]}]}
          """);
        ExpectFailure(() => broken.ImportS1(legacy.RootElement), "partially failed legacy import");
        Check(File.Exists(Path.Combine(brokenDir, "s1-import-source.json")), "failed S1 input evidence retained");
        ExpectFailure(() => broken.SealStaging(), "sealing a partly imported S1 generation");
    }
    using (var cleanRetry = NotesStoreV1.CreateStaging(root))
    {
        var book = cleanRetry.CreateNotebook("Clean after failed import");
        var n = cleanRetry.CreateNote(book, "Fresh trial");
        Check(cleanRetry.ListPages(n).Count == 1, "fresh generation usable after failed sibling");
        cleanRetry.SealStaging();
    }
    Console.WriteLine("PASS S2-B native store: library, metadata/page CAS, Trash/restore, S1 quarantine, FTS, ink, attachment, read-only reopen");
}
finally
{
    try { Directory.Delete(root,true); } catch { /* test evidence may be in use */ }
}
