'use strict';
const assert=require('node:assert/strict');
const Transport=require('../../src/NivareQ.Step2Pathfinder/NotesProtocol/notes-web-transport.js');
const token='a'.repeat(48); const channel=Transport.channel;
let checks=0;
function check(test,msg){assert.ok(test,msg);checks++;}
class Web {
 constructor(){this.listeners={message:new Set()};this.sent=[];this.native=null;}
 addEventListener(n,cb){this.listeners[n].add(cb);}
 removeEventListener(n,cb){this.listeners[n].delete(cb);}
 postMessage(x){this.sent.push(x);this.native?.(x);}
 emit(x){for(const cb of this.listeners.message)cb({data:x});}
 bootstrap(){this.emit({channel,type:'notes-bootstrap',documentToken:token});}
 reply(x,result,ok=true){this.emit({channel,type:'notes-response',documentToken:token,requestId:x.requestId,
 action:x.type,ok,result});}
}
class WindowFake {
 constructor(){this.handlers=new Map();}
 addEventListener(n,cb){this.handlers.set(n,cb);}
 removeEventListener(n,cb){if(this.handlers.get(n)===cb)this.handlers.delete(n);}
 fire(n){this.handlers.get(n)?.();}
}
async function test(){
 const web=new Web(),hostWindow=new WindowFake(),wire=new Transport(web,{timeoutMs:250});
 wire.bindPageLifecycle(hostWindow); check(hostWindow.handlers.has('pagehide'),'pagehide handler registered');
 web.bootstrap(); check(wire.ready,'document bootstrapped');
 await assert.rejects(wire.drainAfterCoordinatorClose({status:{pending:true}}),/release/);checks++;
 const onClose={status:null};
 web.native=req=>setImmediate(()=>web.reply(req,{drained:true}));
 const result=await wire.drainAfterCoordinatorClose(onClose);
 check(result && !wire.ready && wire.pendingCount===0,'drain ACK seals the transport');
 await assert.rejects(wire.open('note','page'),/sealed/);checks++;
 hostWindow.fire('pagehide');
 check(hostWindow.handlers.size===0 && web.listeners.message.size===0,'pagehide tears down listeners');
 const web2=new Web(),wire2=new Transport(web2,{timeoutMs:250});web2.bootstrap();
 web2.native=()=>{};const outstanding=wire2.open('n','p');
 wire2.dispose();await assert.rejects(outstanding,/disposed/);checks++;
 check(wire2.pendingCount===0,'unacknowledged native write is not declared saved');
 const web3=new Web(),wire3=new Transport(web3,{timeoutMs:100});web3.bootstrap();
 web3.native=()=>{};
 const unacked=wire3.drainAfterCoordinatorClose(onClose);
 await assert.rejects(unacked,/timed out/);checks++;
 await assert.rejects(wire3.probe({}),/sealed/);checks++;
 wire3.dispose();
 console.log(JSON.stringify({result:'PASS',checks,suite:'R8 isolated JS pagehide/drain/navigation transport'}));
}
test().catch(e=>{console.error(e);process.exitCode=1;});
