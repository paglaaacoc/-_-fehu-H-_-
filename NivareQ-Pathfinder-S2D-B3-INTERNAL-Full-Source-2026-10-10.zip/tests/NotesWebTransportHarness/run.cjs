'use strict';
const assert=require('node:assert/strict');
const Transport=require('../../src/NivareQ.Step2Pathfinder/NotesProtocol/notes-web-transport.js');
const Coordinator=require('../../src/NivareQ.Step2Pathfinder/NotesProtocol/notes-draft-coordinator.js');
let checks=0;
function ok(value,label){assert.ok(value,label);checks++;}
const channel=Transport.channel;
const token='a'.repeat(48);
function page(text='initial'){return {guide:'ruled',spacing:32,cells:[{text,strokes:[]}],images:[]};}
class FakeWebView {
  constructor(){this.handlers=new Set();this.sent=[];this.native=null;}
  addEventListener(kind,listener){if(kind==='message')this.handlers.add(listener);}
  removeEventListener(kind,listener){if(kind==='message')this.handlers.delete(listener);}
  postMessage(msg){this.sent.push(msg);if(this.native)this.native(msg);}
  emit(data){for(const listener of this.handlers)listener({data});}
  respond(req,result,okFlag=true,overrides={}){
    this.emit({channel,type:'notes-response',documentToken:token,requestId:req.requestId,
      action:req.type,ok:okFlag,result,...overrides});
  }
  bootstrap(){this.emit({channel,type:'notes-bootstrap',documentToken:token});}
}
async function test(){
  const web=new FakeWebView(),wire=new Transport(web,{timeoutMs:250});
  await assert.rejects(wire.open('n','p'),/not bootstrapped/);checks++;
  web.emit({channel,type:'notes-bootstrap',documentToken:'forged'});
  ok(!wire.ready,'invalid native token ignored');
  web.bootstrap();ok(wire.ready,'one-way isolated bootstrap succeeds');
  // Simulate replies from a native router with durable CAS state.
  const current=new Map([['p',{page:page(),revision:0}]]);
  let writes=0;let released=0;
  web.native=req=>setImmediate(()=>{
    if(req.type==='notes-open'){
      web.respond(req,{sessionId:'session-1',noteId:req.payload.noteId,pageId:req.payload.pageId,
          persistedRevision:0,page:page()}); return;
    }
    if(req.type==='notes-write'){
      writes++;
      const p=req.payload,cur=current.get(p.pageId);
      if(p.expectedRevision!==cur.revision){web.respond(req,null,false);return;}
      current.set(p.pageId,{page:p.page,revision:cur.revision+1});
      // Drop first committed ACK to test read-and-reconcile without duplicate write.
      if(writes===1)return;
      web.respond(req,{protocol:Coordinator.protocol,sessionId:p.sessionId,
        noteId:p.noteId,pageId:p.pageId,sequence:p.sequence,persistedRevision:cur.revision+1});return;
    }
    if(req.type==='notes-probe'){
      const cur=current.get(req.payload.pageId);
      web.respond(req,{protocol:Coordinator.protocol,sessionId:req.payload.sessionId,
        noteId:req.payload.noteId,pageId:req.payload.pageId,
        persistedRevision:cur.revision,page:cur.page});return;
    }
    if(req.type==='notes-release'){released++;web.respond(req,{released:true});return;}
  });
  const session=await wire.open('n','p');
  ok(session.sessionId==='session-1','native open transport');
  const coordinator=new Coordinator({write:p=>wire.write(p),probe:p=>wire.probe(p),release:p=>wire.release(p)});
  coordinator.open(session);coordinator.edit(page('committed though ACK lost'));
  await assert.rejects(coordinator.flush(),/timed out/);checks++;
  ok(coordinator.status.pending && coordinator.status.needsReconciliation,'lost native ACK retains unsaved status');
  await coordinator.flush({retry:true});
  ok(!coordinator.status.pending && coordinator.status.revision===1 && writes===1,
     'read-and-reconcile avoids duplicate native save');
  await coordinator.close();
  ok(released===1 && coordinator.status===null,'native release required for closing');
  // A response with wrong action or nonce never completes a pending request.
  web.native=req=>setImmediate(()=>{
    web.respond(req,{released:true},true,{action:'notes-open'});
    web.respond(req,{released:true},true,{documentToken:'b'.repeat(48)});
  });
  await assert.rejects(wire.release({sessionId:'session-2',lastAcknowledgedSequence:0,lastAcknowledgedRevision:0}),
    /timed out/);checks++;
  // Disposing during native IO fails closed, never synthesizes success.
  const pending=wire.open('n','p');wire.dispose();
  await assert.rejects(pending,/disposed/);checks++;
  ok(!wire.ready && web.handlers.size===0,'document lease torn down');
  console.log(JSON.stringify({result:'PASS',suite:'isolated Notes WebView2 wire protocol (no live activation)',checks}));
}
test().catch(e=>{console.error(e);process.exitCode=1;});
