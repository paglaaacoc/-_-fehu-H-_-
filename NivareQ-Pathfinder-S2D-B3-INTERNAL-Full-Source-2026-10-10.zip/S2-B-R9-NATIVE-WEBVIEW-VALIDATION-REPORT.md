# S2-B R9 Windows WebView2 native evidence

Internal only. GitHub Actions https://github.com/paglaaacoc/-_-fehu-H-_-/actions/runs/38043234568 — **SUCCESS** — head commit `950b29d854451aecddfd3f8747cd9b62e966d074`.

## Windows runtime smoke, exact job evidence
- Actual WebView2 runtime `153.0.4234.48` launched on `windows-latest`.
- 14 real browser assertions PASS: engine available, isolated document unloaded, navigation + bootstrap, unsafe refresh canceled, JS page open ACK, native session ownership, committed SQLite revision ACK, incorrect-release refusal, correct release, real drain ACK, safe reload token rotation, durable reopened text, synthetic quarantine after process-failure notification, real event counters.
- Event counters: NavigationStarting=3, NavigationCompleted=3, denied=1, WebMessageReceived=14.
- Existing R8 policy/wire native harness: **33 PASS**.
- WinUI x64: compile **PASS**. WinUI ARM64: compile **PASS**.
- Source ZIP signature and medical files 132/132: **PASS**.

## Portable inherited verification
- R8 JS lifecycle: 10 PASS.
- R7 WebView transport: 11 PASS.
- R5 ACK/navigation: 52 PASS.
- Python SQLite smoke: 8 PASS.

## What is NOT proven
- Real Pathfinder WinUI Notes screen has NOT been opened; adapter event signatures previously compiled, not attached in a running app.
- No forced real Chromium renderer/process crash; synthetic `ProcessFailed` verifies policy reaction only.
- No live study storage, generation activation, ZIP64 backup or transactional restore.
- No hardware/on-device owner acceptance.
- Inherited nullable reference compiler warnings still exist; no unrelated modifications authorized.

## Reproducibility
CI branch files: `ci/s2b-r9/Program.cs`, `ci/s2b-r9/NotesRealWebView2Smoke.csproj`, `ci/s2b-r9/index.html`, `.github/workflows/pathfinder-s2b-r9-real-webview-ci.yml`; CI reconstitutes the SHA-pinned original R5 archive and R8 overlays before compiling and launching the real browser.

The local Full Source ZIP contains a semantically equivalent but non-byte-identical `Program.cs` harness; GitHub branch commit is authoritative for the exact browser test evidence.
