from pathlib import Path
p=Path(__file__).resolve().parents[1]
s=(p/'src/NivareQ.Step2Pathfinder/Services/NotesBackupVNextV1.cs').read_text()
t=(p/'tests/NotesBackupVNextHarness/Program.cs').read_text()
checks={
 'archive-wide byte budget and accounting':'NotesVNextResourceBudget' in s and 'totalUncompressed = checked(totalUncompressed + e.Length)' in s,
 'quota checked before streaming':'totalUncompressed > budget.MaxUncompressedBytes' in s and s.index('totalUncompressed > budget.MaxUncompressedBytes') < s.index('HashStream(input, e.Length)'),
 'disk check before generation allocation':s.index('drive.AvailableFreeSpace')<s.index('Directory.CreateDirectory(target)'),
 'restore preserves quarantine on failure':'A failed staged extraction remains quarantined' in s,
 'S1 recovery capped':'e.FullName == RecoveryEntry && e.Length > MaxProviderBytes' in s,
 'large libraries not limited to 100MB':'64L * 1024 * 1024 * 1024' in s,
 'native tests include negative budgeting': all(x in t for x in ['selected extraction budget is too small','allocated no new generation','invalid negative resource budget rejected']),
 'no live activation':'RestoreTransactionService.Commit(' not in s and 'GenerationPointerKey' not in s,
}
for name,ok in checks.items(): print(('PASS' if ok else 'FAIL')+' B3 '+name)
assert all(checks.values())
