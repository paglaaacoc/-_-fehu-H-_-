from pathlib import Path
s=(Path(__file__).resolve().parents[1]/'src/NivareQ.Step2Pathfinder/Services/NotesBackupVNextV1.cs').read_text()
t=(Path(__file__).resolve().parents[1]/'tests/NotesBackupVNextHarness/Program.cs').read_text()
checks={
 'separate coherent capture entry':'public static void ExportStagingCoherent' in s,
 'exclusive gate before provider capture':s.index('using var exclusive = gate.Exclusive();',s.index('ExportStagingCoherent')) < s.index('var snapshot = captureCanonicalProvider()',s.index('ExportStagingCoherent')),
 'epoch before and after capture':'readProviderEpoch() != initialEpoch' in s and s.count('readProviderEpoch() != initialEpoch')==2,
 'publication fence within core':'beforePublication(); // epoch fence BEFORE' in s and s.index('beforePublication(); // epoch fence BEFORE') < s.index('File.Move(partial, target, overwrite: false)'),
 'no active generation pointer or restore transaction':'RestoreTransactionService.Commit(' not in s and 'GenerationPointerKey' not in s,
 'native tests source scenarios':all(x in t for x in ['epoch changed during provider capture rejected','epoch changed before publication refused','coherent snapshot archived']),
}
for k,v in checks.items():print(('PASS' if v else 'FAIL')+' B2 '+k)
assert all(checks.values())
