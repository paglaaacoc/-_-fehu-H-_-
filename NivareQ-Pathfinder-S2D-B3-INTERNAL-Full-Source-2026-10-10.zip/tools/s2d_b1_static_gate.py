#!/usr/bin/env python3
"""S2-D B1 preservation + static boundary checks. NOT C# compiler or native CI."""
from pathlib import Path
import hashlib,zipfile,re,json
root=Path(__file__).resolve().parents[1]
source=root/'src/NivareQ.Step2Pathfinder/Services/NotesBackupVNextV1.cs'
text=source.read_text()
checks={
  'new sealed-independent archive component': 'public static class NotesBackupVNextV1' in text,
  'no active mutation or restore commit': all(x not in text for x in ('RestoreTransactionService.Commit(', 'ReplaceInMemory(', 'GenerationPointerKey +', 'AtomicFileStore.WriteText(')),
  'exclusive gate required at export/staging': text.count('using var exclusive = gate.Exclusive();') == 3,
  'canonical provider validator required':text.count('ArgumentNullException.ThrowIfNull(strictCanonicalValidator)')>=2,
  'read only staging before export':'NotesStoreV1.OpenStagedGeneration(notesRoot, generationId)' in text,
  'SQLite consistent backup API':'conn.BackupDatabase(snapshotDb);' in text,
  'manifest includes SHA-256':'public sealed record NotesVNextEntry' in text and 'HashStream(input, e.Length)' in text,
  'streamed attachments':'while ((count = input.Read(buffer)) != 0)' in text,
  'active pointer never set': not re.search(r'\.GenerationPointerKey\b',text),
  'read-only verification + inactive restore':'public static string ExtractToInactiveGeneration' in text and 'using var reopened = NotesStoreV1.OpenStagedGeneration' in text,
  'no user backup overwrite':'File.Move(partial, target, overwrite: false)' in text,
  'no path traversal':'AllowedPath(e.FullName)' in text and 'StringComparer.OrdinalIgnoreCase' in text,
}
medical=[p for p in (root/'src/NivareQ.Step2Pathfinder/MedicalPayload/R2').rglob('*') if p.is_file()]
checks['medical payload count unchanged']=len(medical)==132
for key,ok in checks.items():
 print(('PASS' if ok else 'FAIL')+' — '+key)
if not all(checks.values()):raise SystemExit(1)
print(json.dumps({'result':'PASS','scope':'static B1 safety and preservation, NOT native compiler or restore activation','checks':len(checks),'medical_files':len(medical)}))
