# S2-D B2 — Coherent Capture and Publication Fence (INTERNAL)

Parent: S2-D B1. Owner-accepted rollback: Windows v1.2.1 Stable.

**New staging-only `ExportStagingCoherent`** obtains a shared in-process
exclusive gate before invoking the provider snapshot callback, checks the
provider graph epoch after capture, then checks it again immediately before
the archive is atomically published. Null capture, changed epochs, overlapping
writers or invalid canonical JSON reject publication. A callback is still
mandatory for full canonical JSON validation. No live provider is wired into
the gate yet; hence this is NOT a coherent *production* backup until S2-D
provider integration closes every writer and restores using one authority.

B2 unit scenarios added to `tests/NotesBackupVNextHarness/Program.cs`.
These are source-level tests awaiting Windows .NET CI; portable contract tests
and preservation checks are separate and do not establish native execution.

Never promote this archive writer to live backup or restore while the shared
provider fence and trusted BackupContractService adapter are not connected.
