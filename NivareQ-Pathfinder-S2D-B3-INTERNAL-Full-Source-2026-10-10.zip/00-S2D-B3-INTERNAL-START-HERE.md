# S2-D B3 — Archive resource budgeting and inactive extraction preflight

Parent: S2-D B2. This is **internal staging only** and **native .NET CI pending**.

A configurable `NotesVNextResourceBudget` defaults to 64 GiB of
uncompressed archive data, separately from the legacy 100 MiB JSON provider
limit. `Verify` adds bounded aggregate checks before hashing expensive ZIP
members; extracted Notes bytes require filesystem capacity plus a reserve
before creating a random new generation. Oversized/negative budgets and
adversarial pre-allocation scenarios are added to the native harness source.

This is not a guarantee against sudden disk exhaustion, crashes, ZIP64
resource exhaustion, filesystem races, or a forged but syntactically valid
canonical provider. Product restore remains BLOCKED on the strict provider
parser, full source authority, shared writer gate and one transactional
restore commit. No live path or pointer was modified.
