# NivareQ Step 2 Pathfinder — S2-B R7 / Isolated Notes WebView2 Transport

**INTERNAL CHECKPOINT. NOT AN APP BUILD, NOT AN OWNER-TEST CANDIDATE.** Windows **v1.2.1 Stable** is the sole accepted rollback. Continue S2+B/U1 development as a coordinated line. Do not activate NotesStore or retire the S1 Scratchpad/Journal paths until Backup VNext and transactional generation-pointer safety pass.

## What changed

- Added `Services/NotesWebMessageBridgeV1.cs`: staging-only native JSON message interpreter around `NotesStagingPageRouterV1` with exact isolated-document origin, random per-document capability, request IDs, session ownership, persist-then-ACK responses, read-only recovery probes, guarded release, and revoke-on-navigation contract. No `MainWindow` hookup or backup pointer.
- Added `NotesProtocol/notes-web-transport.js`: asynchronous WebView2 postMessage/reply transport wrapping `open`, `write`, `probe`, and `release`. Unknown ACK outcomes time out and are rejected, allowing the existing R5 draft coordinator to fail closed and reconcile by read.
- Added `tests/NotesWireHarness` (.NET 10) and `tests/NotesWebTransportHarness` (Node) to validate the cross-language wire contract independently. The tests do not load the actual WebView2 control or activate real study data.

## Tested locally

- Node NotesWebTransport harness (11 checks) PASS
- Node NotesDraftCoordinator harness (52 assertions) PASS
- SQLite schema harness (8) and R2 storage contracts (22) PASS
- R3/R4/R5 isolation/static safety checks PASS
- 132 medical payloads unchanged, S1 live bridge untouched, Stable rollback source preserved inside original nested authority ZIP

## Native CI

An isolated GitHub workflow `pathfinder-s2b-r7-wire-ci.yml` is installed on `dev/pathfinder-scratchpad-s2-r1-20261009`. It checks the immutable S2-B R5 source ZIP, overlays only the unactivated R7 C# message interpreter and native test harness, then runs .NET 10 tests and WinUI x64/ARM64 compile. Before declaring full native PASS, check the latest Actions run's final conclusion and logs. The current R7 full ZIP itself is a new internal checkpoint, NOT separately built in CI.

## Next gate

Implement a genuine isolated WebView2 control adapter and stress-test lifecycle/process failure, navigation/closing barriers, main-window persistence/restore transaction interactions, and durable full Windows Backup VNext before any activation. S2-C remains unopened. No changes to cockpit, 132 medical files, or PWA.
