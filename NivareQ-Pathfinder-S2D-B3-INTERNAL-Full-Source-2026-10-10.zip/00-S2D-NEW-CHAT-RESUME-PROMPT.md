# Portable Safe Resume — Pathfinder Windows Notes/Backup VNext

Attach the latest full source ZIP. Verify the newest manifest and source
continuity, validate SHA-256 and cross-check latest branch/Actions results.
Source of truth for accepted rollback is Windows v1.2.1 Stable until owner
explicitly accepts another build. Never modify Stable, main, medical data,
Journal, S1 live Scratchpad or existing personal study storage during inactive
S2-D development. Follow Notebook→Note→Page, strict provenance, durable ACK,
no data loss, global writer/restore fence and verified transactional rollback.
Current isolated GitHub branch (verify before touching):
`paglaaacoc/-_-fehu-H-_-` / `dev/pathfinder-scratchpad-s2-r1-20261009`.
R10 last PASS real renderer crash: GitHub Actions 38045461924. B1-B3 new
backup archive code is NOT native CI validated until a new passing native run
is recorded. Do not conflate R10 PASS with Backup VNext PASS.

Perform bounded implementation and batch 2–3 meaningful checkpoints, stopping
at ~15–20 minutes for a genuine long/problematic stage. Preserve full and
incremental source ZIPs, manifests, exact CI refs, tests and pending gaps. Ask
owner only for permissions, essential decisions, or real-device testing.
The next major gate is Windows native S2-D B1→B3 archive harness validation,
then binding real BackupContractService.ParseImport, provider writer exclusion,
restore journal/transaction pointer and crash-safety tests. No live activation.
