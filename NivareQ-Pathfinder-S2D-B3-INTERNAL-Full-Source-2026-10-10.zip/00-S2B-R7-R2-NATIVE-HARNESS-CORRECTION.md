# S2-B R7 R2 — Native test harness correction

Source of truth: R6 R2 -> R7 wire implementation, plus exactly one test-helper correction from R7. The accepted Windows v1.2.1 Stable rollback is unchanged.

Corrections: `tests/NotesWireHarness/Program.cs` calls `Packet(..., lease: new string('0',48))` using C# named-argument syntax `:` (not assignment `=`). The initial R7 harness's `CS0103` was a **test syntax error**; it was not in production/runtime code or in `NotesWebMessageBridgeV1.cs`. The corresponding test-file SHA-256 in `tools/s2b_r7_ci_contract.json` is also updated.

Native CI: isolated branch `dev/pathfinder-scratchpad-s2-r1-20261009`, workflow `.github/workflows/pathfinder-s2b-r7-wire-ci.yml`. Verify the final GitHub run before asserting that R7 R2 passes. The workflow runs native harness and cross-compiles x64 and ARM64 after validating original R5 ZIP and exact R7 overlay files. No S1/Journal or medical payload modification. No active generation pointer or Backup VNext activation.

Next S2-B gate: only after native success, introduce an isolated WebView2 control lifecycle adapter; safely handle navigation/reload/close with pending saves, and design/verify Backup VNext + writer gate before any live data activation. S2-C remains unopened.

Validated on the isolated GitHub branch: Actions run 38027700950 completed SUCCESS (17 native wire checks, WinUI x64 and ARM64 compilation). The CI combines the unchanged immutable R5 source with the SHA-verified R7 C# bridge and corrected test harness; the R7 R2 ZIP itself was not separately uploaded.
