using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;

namespace NivareQ.Step2Pathfinder.Services;

// S2-D B1. No MainWindow hookup, active generation pointer, restore transaction
// call, reset hookup, or authority to unlock the current application's writers.
// Each caller MUST supply the existing full canonical-provider parser as a
// validation delegate; there is intentionally no permissive fallback.
public sealed class NotesVNextMutationGate
{
    private readonly object _sync = new();
    private int _writers;
    private bool _exclusive;
    public IDisposable Writer()
    {
        lock (_sync)
        {
            if (_exclusive) throw new InvalidOperationException("A Notes archive/restore owns the exclusive mutation gate.");
            _writers++;
            return new Lease(() => { lock (_sync) _writers--; });
        }
    }
    public IDisposable Exclusive()
    {
        lock (_sync)
        {
            if (_writers != 0 || _exclusive)
                throw new InvalidOperationException("A Notes writer or archive operation is still active.");
            _exclusive = true;
            return new Lease(() => { lock (_sync) _exclusive = false; });
        }
    }
    private sealed class Lease(Action release) : IDisposable
    {
        private Action? _release = release;
        public void Dispose() => Interlocked.Exchange(ref _release, null)?.Invoke();
    }
}

public sealed record NotesVNextEntry(string Path, long Bytes, string Sha256);
public sealed record NotesVNextManifest(string Format, int Version, List<NotesVNextEntry> Entries);

// B3: resource limits apply to an entire archive rather than constraining
// every generation to the old 100 MB canonical-JSON-only ceiling. This limit
// may be increased deliberately for larger libraries after disk preflight.
// No value of this record is a product restore authorization.
public sealed record NotesVNextResourceBudget(long MaxUncompressedBytes,
    long MinFreeSpaceReserveBytes = 128L * 1024 * 1024)
{
    public static NotesVNextResourceBudget Default { get; } =
        new(64L * 1024 * 1024 * 1024);

    public void Validate()
    {
        if (MaxUncompressedBytes < 1 || MinFreeSpaceReserveBytes < 0)
            throw new ArgumentOutOfRangeException(nameof(MaxUncompressedBytes),
                "Notes backup resource budget is invalid.");
    }
}

public static class NotesBackupVNextV1
{
    public const string Format = "nivareq.step2pathfinder.nqpfbackup";
    private const string ProviderEntry = "pathfinder-state.json";
    private const string DatabaseEntry = "scratchpad.sqlite";
    private const string RecoveryEntry = "migration/s1-import-source.json";
    private const string ManifestEntry = "manifest.json";
    private const long MaxProviderBytes = 100L * 1024 * 1024;
    private const long MaxManifestBytes = 8L * 1024 * 1024;
    private const long MaxAssetBytes = 25L * 1024 * 1024;
    private const int MaxEntries = 100_000;
    private static readonly JsonSerializerOptions StrictJson = new() { PropertyNameCaseInsensitive = false };

    // B1 archive primitive: source must be a sealed, offline generation. The
    // global Windows provider graph / Save coordinator is NOT bound here yet.
    // Caller must acquire the same process gate from all Notes editors; B2 will
    // require a single shared authority before any product runtime connection.
    public static void ExportStaging(string destination, byte[] canonicalProviderUtf8,
        string notesRoot, string generationId, NotesVNextMutationGate gate,
        Action<JsonElement> strictCanonicalValidator)
    {
        ArgumentNullException.ThrowIfNull(strictCanonicalValidator);
        ArgumentNullException.ThrowIfNull(gate);
        using var exclusive = gate.Exclusive();
        ExportStagingCore(destination, canonicalProviderUtf8, notesRoot, generationId,
            strictCanonicalValidator, static () => { });
    }

    // B2 staging-only coherent capture. All participating provider writers MUST
    // acquire the same gate; an epoch mismatch fails before ZIP publication.
    // This has NOT been wired to the Windows live provider graph.
    public static void ExportStagingCoherent(string destination,
        Func<byte[]> captureCanonicalProvider, Func<long> readProviderEpoch,
        string notesRoot, string generationId, NotesVNextMutationGate gate,
        Action<JsonElement> strictCanonicalValidator)
    {
        ArgumentNullException.ThrowIfNull(captureCanonicalProvider);
        ArgumentNullException.ThrowIfNull(readProviderEpoch);
        ArgumentNullException.ThrowIfNull(strictCanonicalValidator);
        ArgumentNullException.ThrowIfNull(gate);
        using var exclusive = gate.Exclusive();
        var initialEpoch = readProviderEpoch();
        if (initialEpoch < 0) throw new InvalidDataException("Provider epoch is invalid.");
        var snapshot = captureCanonicalProvider() ?? throw new InvalidDataException("Provider capture returned null.");
        if (readProviderEpoch() != initialEpoch)
            throw new InvalidOperationException("Provider graph changed during canonical snapshot capture.");
        ExportStagingCore(destination, snapshot, notesRoot, generationId,
            strictCanonicalValidator, () =>
            {
                if (readProviderEpoch() != initialEpoch)
                    throw new InvalidOperationException("Provider graph changed before backup publication.");
            });
    }

    private static void ExportStagingCore(string destination, byte[] canonicalProviderUtf8,
        string notesRoot, string generationId, Action<JsonElement> strictCanonicalValidator,
        Action beforePublication)
    {
        ValidateProvider(canonicalProviderUtf8, strictCanonicalValidator);
        using var store = NotesStoreV1.OpenStagedGeneration(notesRoot, generationId);
        var gen = Path.Combine(notesRoot, "generations", generationId);
        using var conn = new SqliteConnection(new SqliteConnectionStringBuilder
        {
            DataSource = store.DatabasePath, Mode = SqliteOpenMode.ReadOnly, Pooling = false
        }.ToString());
        conn.Open();
        using (var cmd = conn.CreateCommand())
        {
            cmd.CommandText = "SELECT value FROM meta WHERE key='stage_state'";
            if ((string?)cmd.ExecuteScalar() != "sealed")
                throw new InvalidOperationException("Only sealed and verified offline generations may be exported.");
        }
        // SQLite's online backup API creates a transactional snapshot, including
        // committed WAL rows, rather than copying a hot SQLite file.
        var tempDir = Path.Combine(Path.GetTempPath(), "nqpf-b1-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(tempDir);
        var snapshot = Path.Combine(tempDir, "snapshot.sqlite");
        var target = Path.GetFullPath(destination);
        var partial = target + ".pending-" + Guid.NewGuid().ToString("N");
        try
        {
            using (var snapshotDb = new SqliteConnection(new SqliteConnectionStringBuilder
            { DataSource = snapshot, Mode = SqliteOpenMode.ReadWriteCreate, Pooling = false }.ToString()))
            {
                snapshotDb.Open();
                conn.BackupDatabase(snapshotDb);
            }
            var entries = new List<NotesVNextEntry>();
            using (var writer = new FileStream(partial, FileMode.CreateNew, FileAccess.Write,
                FileShare.None, 128 * 1024, FileOptions.WriteThrough))
            {
                using (var zip = new ZipArchive(writer, ZipArchiveMode.Create, leaveOpen: true, Encoding.UTF8))
                {
                    WriteBytes(zip, ProviderEntry, canonicalProviderUtf8, entries);
                    WriteFile(zip, DatabaseEntry, snapshot, entries);
                    var s1Source = Path.Combine(gen, "s1-import-source.json");
                    if (File.Exists(s1Source)) WriteFile(zip, RecoveryEntry, s1Source, entries);
                    using var command = conn.CreateCommand();
                    command.CommandText = "SELECT DISTINCT a.sha256,a.mime,a.bytes FROM attachments a JOIN image_objects i ON i.sha256=a.sha256 ORDER BY a.sha256";
                    using var reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        var hash = reader.GetString(0);
                        var mime = reader.GetString(1);
                        var bytes = reader.GetInt64(2);
                        var ext = mime == "image/png" ? ".png" : mime == "image/jpeg" ? ".jpg" : throw new InvalidDataException("Invalid image MIME in Notes database.");
                        if (!ValidHash(hash) || bytes is < 1 or > MaxAssetBytes)
                            throw new InvalidDataException("Invalid referenced image metadata.");
                        var file = Path.Combine(store.AttachmentsRoot, hash + ext);
                        if (new FileInfo(file).Length != bytes) throw new InvalidDataException("Referenced image bytes changed.");
                        WriteFile(zip, "attachments/" + hash + ext, file, entries);
                    }
                    var manifest = new NotesVNextManifest(Format, 1, entries);
                    WriteBytes(zip, ManifestEntry, JsonSerializer.SerializeToUtf8Bytes(manifest, StrictJson), null);
                }
                writer.Flush(flushToDisk: true);
            }
            Verify(partial, strictCanonicalValidator);
            beforePublication(); // epoch fence BEFORE the atomic no-overwrite publication
            // No replacement of an existing user backup. This is intentionally
            // fail-closed until an audited explicit replace policy exists.
            File.Move(partial, target, overwrite: false);
        }
        finally
        {
            if (File.Exists(partial)) File.Delete(partial);
            try { Directory.Delete(tempDir, recursive: true); }
            catch (IOException) { /* do not disguise successful committed archive */ }
        }
    }

    // Read-only inspection; never trusts ZIP headers, manifest claims, filenames,
    // or bytes without full streaming hashes and a strict caller's provider plan.
    public static NotesVNextManifest Verify(string archive, Action<JsonElement> strictCanonicalValidator,
        NotesVNextResourceBudget? budget = null)
    {
        ArgumentNullException.ThrowIfNull(strictCanonicalValidator);
        budget ??= NotesVNextResourceBudget.Default;
        budget.Validate();
        using var file = File.OpenRead(archive);
        using var zip = new ZipArchive(file, ZipArchiveMode.Read, leaveOpen: false, Encoding.UTF8);
        if (zip.Entries.Count is < 3 or > MaxEntries)
            throw new InvalidDataException("Invalid Notes backup entry count.");
        var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        ZipArchiveEntry? manifestEntry = null;
        ZipArchiveEntry? providerEntry = null;
        long totalUncompressed = 0;
        foreach (var e in zip.Entries)
        {
            totalUncompressed = checked(totalUncompressed + e.Length);
            if (totalUncompressed > budget.MaxUncompressedBytes)
                throw new InvalidDataException("Notes archive exceeds the selected uncompressed-byte safety budget.");
            if (e.FullName == DatabaseEntry && e.Length == 0)
                throw new InvalidDataException("Empty Notes SQLite archive member.");
            if (e.FullName == RecoveryEntry && e.Length > MaxProviderBytes)
                throw new InvalidDataException("S1 recovery evidence exceeds the bounded JSON evidence budget.");
            if (!AllowedPath(e.FullName) || !names.Add(e.FullName))
                throw new InvalidDataException("Duplicate, unsafe, or unsupported Notes backup entry.");
            if ((e.ExternalAttributes >> 16 & 0xF000) == 0xA000)
                throw new InvalidDataException("Symbolic-link archive entry refused.");
            if (e.Length < 0 || e.CompressedLength < 0 ||
                (e.Length > 4096 && e.CompressedLength < e.Length / 10_000))
                throw new InvalidDataException("Suspicious archive expansion ratio.");
            if (e.FullName == ProviderEntry)
            { if (e.Length > MaxProviderBytes) throw new InvalidDataException("Provider exceeds established JSON contract limit."); providerEntry = e; }
            if (e.FullName == ManifestEntry)
            { if (e.Length > MaxManifestBytes) throw new InvalidDataException("Oversized backup manifest."); manifestEntry = e; }
            if (e.FullName.StartsWith("attachments/", StringComparison.Ordinal) && e.Length > MaxAssetBytes)
                throw new InvalidDataException("Oversized attachment.");
        }
        if (manifestEntry is null || providerEntry is null || !names.Contains(DatabaseEntry))
            throw new InvalidDataException("Mandatory backup entries missing.");
        NotesVNextManifest? manifest;
        using (var stream = manifestEntry.Open())
        using (var doc = JsonDocument.Parse(stream, new JsonDocumentOptions { MaxDepth = 16 }))
        {
            manifest = doc.Deserialize<NotesVNextManifest>(StrictJson);
        }
        if (manifest is null || manifest.Format != Format || manifest.Version != 1 || manifest.Entries is null ||
            manifest.Entries.Count != zip.Entries.Count - 1)
            throw new InvalidDataException("Unsupported or incomplete Notes backup manifest.");
        var expected = new Dictionary<string, NotesVNextEntry>(StringComparer.Ordinal);
        foreach (var entry in manifest.Entries)
            if (!AllowedPath(entry.Path) || entry.Path == ManifestEntry || !ValidHash(entry.Sha256) ||
                entry.Bytes < 0 || !expected.TryAdd(entry.Path, entry))
                throw new InvalidDataException("Malformed or duplicate manifest item.");
        foreach (var e in zip.Entries)
        {
            if (e.FullName == ManifestEntry) continue;
            if (!expected.TryGetValue(e.FullName, out var item) || item.Bytes != e.Length)
                throw new InvalidDataException("Manifest entry size/name disagreement.");
            using var input = e.Open();
            var hash = HashStream(input, e.Length);
            if (!hash.Equals(item.Sha256, StringComparison.Ordinal))
                throw new InvalidDataException("Backup content hash mismatch: " + e.FullName);
            if (e.FullName.StartsWith("attachments/", StringComparison.Ordinal))
            {
                var name = e.FullName["attachments/".Length..];
                if (!name.StartsWith(hash, StringComparison.Ordinal))
                    throw new InvalidDataException("Referenced asset name/bytes hash disagreement.");
            }
        }
        using (var provider = providerEntry.Open())
        using (var document = JsonDocument.Parse(provider, new JsonDocumentOptions { MaxDepth = 128 }))
            strictCanonicalValidator(document.RootElement);
        return manifest;
    }

    // PRE-ACTIVATION ONLY: extracts to a NEW generation identifier, then opens
    // it read-only and verifies SQLite relational structure and every referenced
    // blob. Does not change the active-generation pointer or any study provider.
    // A failed staged extraction remains quarantined for recovery diagnostics.
    public static string ExtractToInactiveGeneration(string archive, string notesRoot,
        NotesVNextMutationGate gate, Action<JsonElement> strictCanonicalValidator,
        NotesVNextResourceBudget? budget = null)
    {
        ArgumentNullException.ThrowIfNull(gate);
        budget ??= NotesVNextResourceBudget.Default;
        budget.Validate();
        using var exclusive = gate.Exclusive();
        var manifest = Verify(archive, strictCanonicalValidator, budget);
        var map = manifest.Entries.ToDictionary(e => e.Path, StringComparer.Ordinal);
        // Before allocating a new generation, prove there is space for all
        // extracted Notes payloads plus a safety margin. This never affects
        // the existing active generation; out-of-space after preflight still
        // leaves a quarantined, never-activated partial generation.
        long required = 0;
        foreach (var item in manifest.Entries)
            if (item.Path != ProviderEntry)
                required = checked(required + item.Bytes);
        var driveRoot = Path.GetPathRoot(Path.GetFullPath(notesRoot))
            ?? throw new InvalidDataException("Notes restoration volume is unknown.");
        var drive = new DriveInfo(driveRoot);
        if (!drive.IsReady || (ulong)drive.AvailableFreeSpace < (ulong)required + (ulong)budget.MinFreeSpaceReserveBytes)
            throw new IOException("Not enough disk space to stage the Notes generation safely.");
        var generationId = Guid.NewGuid().ToString("N");
        var target = Path.Combine(notesRoot, "generations", generationId);
        Directory.CreateDirectory(target); // never resolves an untrusted name
        try
        {
            using var fs = File.OpenRead(archive);
            using var zip = new ZipArchive(fs, ZipArchiveMode.Read, leaveOpen: false, Encoding.UTF8);
            foreach (var entry in zip.Entries)
            {
                if (entry.FullName is ManifestEntry or ProviderEntry) continue;
                var outputName = entry.FullName switch
                {
                    DatabaseEntry => "notes.sqlite",
                    RecoveryEntry => "s1-import-source.json",
                    _ when entry.FullName.StartsWith("attachments/", StringComparison.Ordinal) => entry.FullName,
                    _ => throw new InvalidDataException("Unexpected stage extraction entry.")
                };
                var outputPath = Path.Combine(target, outputName.Replace('/', Path.DirectorySeparatorChar));
                Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);
                using var source = entry.Open();
                using var dest = new FileStream(outputPath, FileMode.CreateNew, FileAccess.Write,
                    FileShare.None, 128 * 1024, FileOptions.WriteThrough);
                using var hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
                var buffer = new byte[128 * 1024];
                long copied = 0;
                int count;
                while ((count = source.Read(buffer)) != 0)
                {
                    copied = checked(copied + count);
                    if (copied > map[entry.FullName].Bytes)
                        throw new InvalidDataException("Stage extraction exceeded verified entry size.");
                    dest.Write(buffer, 0, count);
                    hash.AppendData(buffer, 0, count);
                }
                dest.Flush(flushToDisk: true);
                if (copied != map[entry.FullName].Bytes ||
                    !Convert.ToHexString(hash.GetHashAndReset()).ToLowerInvariant()
                        .Equals(map[entry.FullName].Sha256, StringComparison.Ordinal))
                    throw new InvalidDataException("Archive changed during stage extraction.");
            }
            using var reopened = NotesStoreV1.OpenStagedGeneration(notesRoot, generationId);
            // Fail closed: staged database must carry sealed/read-only status.
            using var conn = new SqliteConnection(new SqliteConnectionStringBuilder
            { DataSource = reopened.DatabasePath, Mode = SqliteOpenMode.ReadOnly, Pooling = false }.ToString());
            conn.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT value FROM meta WHERE key='stage_state'";
            if ((string?)cmd.ExecuteScalar() != "sealed")
                throw new InvalidDataException("Archive Notes database is not sealed.");
            return generationId;
        }
        catch
        {
            // Preserve invalid partial evidence; NEVER flip an active pointer.
            throw;
        }
    }

    // Strict path grammar: no ZIP traversal, no arbitrary extra material.
    private static bool AllowedPath(string name)
    {
        if (name is ManifestEntry or ProviderEntry or DatabaseEntry or RecoveryEntry) return true;
        if (!name.StartsWith("attachments/", StringComparison.Ordinal)) return false;
        var tail = name["attachments/".Length..];
        if (tail.Length != 68) return false;
        var extension = tail[64..];
        return ValidHash(tail[..64]) && (extension is ".png" or ".jpg");
    }
    private static bool ValidHash(string? hash)
        => hash is { Length: 64 } && hash.All(c => c is >= '0' and <= '9' or >= 'a' and <= 'f');
    private static void ValidateProvider(byte[] data, Action<JsonElement> strict)
    {
        if (data.Length == 0 || data.LongLength > MaxProviderBytes)
            throw new InvalidDataException("Invalid provider JSON length.");
        using var doc = JsonDocument.Parse(data, new JsonDocumentOptions { MaxDepth = 128 });
        strict(doc.RootElement);
    }
    private static void WriteBytes(ZipArchive zip, string path, byte[] bytes, List<NotesVNextEntry>? entries)
    {
        var item = zip.CreateEntry(path, CompressionLevel.Optimal);
        item.LastWriteTime = new DateTimeOffset(2020, 1, 1, 0, 0, 0, TimeSpan.Zero);
        using (var stream = item.Open()) stream.Write(bytes);
        entries?.Add(new NotesVNextEntry(path, bytes.LongLength,
            Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant()));
    }
    private static void WriteFile(ZipArchive zip, string path, string source, List<NotesVNextEntry> entries)
    {
        var item = zip.CreateEntry(path, CompressionLevel.Optimal);
        item.LastWriteTime = new DateTimeOffset(2020, 1, 1, 0, 0, 0, TimeSpan.Zero);
        using var input = new FileStream(source, FileMode.Open, FileAccess.Read, FileShare.Read,
            128 * 1024, FileOptions.SequentialScan);
        using var output = item.Open();
        using var hasher = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
        var buffer = new byte[128 * 1024];
        long total = 0;
        int count;
        while ((count = input.Read(buffer)) != 0)
        { output.Write(buffer, 0, count); hasher.AppendData(buffer, 0, count); total = checked(total + count); }
        entries.Add(new NotesVNextEntry(path, total, Convert.ToHexString(hasher.GetHashAndReset()).ToLowerInvariant()));
    }
    private static string HashStream(Stream input, long expectedBytes)
    {
        using var hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
        var buffer = new byte[128 * 1024];
        long total = 0; int n;
        while ((n = input.Read(buffer)) != 0)
        {
            total = checked(total + n);
            if (total > expectedBytes) throw new InvalidDataException("Decompressed entry exceeds advertised size.");
            hash.AppendData(buffer, 0, n);
        }
        if (total != expectedBytes) throw new InvalidDataException("Truncated archive entry.");
        return Convert.ToHexString(hash.GetHashAndReset()).ToLowerInvariant();
    }
}
