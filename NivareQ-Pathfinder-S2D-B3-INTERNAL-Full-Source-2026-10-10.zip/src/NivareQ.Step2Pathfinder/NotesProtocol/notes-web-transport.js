/* S2-B R7: STAGING ONLY. Not loaded by the S1 Scratchpad or cockpit. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.NivareQNotesWebTransportV1 = factory();
})(typeof globalThis === 'object' ? globalThis : this, function () {
  'use strict';
  const channel = 'nivareq.notes.web.v1';
  const actions = new Set(['notes-open','notes-write','notes-probe','notes-release','notes-drained']);
  class NotesWebTransportV1 {
    constructor(webview, {timeoutMs = 15000, onError = () => {}} = {}) {
      if (!webview || typeof webview.postMessage !== 'function' ||
          typeof webview.addEventListener !== 'function' ||
          typeof webview.removeEventListener !== 'function' ||
          !Number.isInteger(timeoutMs) || timeoutMs < 100 || timeoutMs > 120000)
        throw new TypeError('A valid isolated WebView2 message transport is required.');
      this._webview=webview; this._timeoutMs=timeoutMs; this._onError=onError;
      this._token=null; this._pending=new Map(); this._disposed=false; this._sealed=false;
      this._pageHost=null; this._pageHide=null;
      this._counter=0;
      this._prefix=(globalThis.crypto?.randomUUID?.() ||
        String(Math.random()).slice(2)).replace(/[^a-zA-Z0-9_-]/g, '_');
      this._receive=e=>this._onMessage(e?.data);
      webview.addEventListener('message',this._receive);
    }
    get ready() { return !this._disposed && !this._sealed && !!this._token; }
    get pendingCount() { return this._pending.size; }
    _onMessage(data) {
      if (this._disposed || !data || data.channel !== channel) return;
      if (data.type === 'notes-bootstrap') {
        if (this._token || typeof data.documentToken !== 'string' ||
            !/^[0-9a-f]{48}$/.test(data.documentToken)) return;
        this._token=data.documentToken; return;
      }
      if (data.type !== 'notes-response' || data.documentToken !== this._token ||
          typeof data.requestId !== 'string') return;
      const pending=this._pending.get(data.requestId);
      if (!pending || data.action !== pending.action) return;
      this._pending.delete(data.requestId); clearTimeout(pending.timer);
      if (data.ok === true && data.result != null) pending.resolve(data.result);
      else pending.reject(Error('Notes native operation not acknowledged; local draft retained.'));
    }
    _request(action,payload) {
      if (this._disposed || this._sealed && action !== 'notes-drained')
        return Promise.reject(Error('Isolated Notes document is disposed or sealed.'));
      if (!this._token) return Promise.reject(Error('Isolated Notes document is not bootstrapped.'));
      if (!actions.has(action)) return Promise.reject(Error('Unsupported Notes action.'));
      const requestId=`${this._prefix}_${++this._counter}`;
      return new Promise((resolve,reject)=>{
        const timer=setTimeout(()=>{
          this._pending.delete(requestId);
          reject(Error('Notes native ACK timed out; outcome uncertain, preserve local draft.'));
        },this._timeoutMs);
        this._pending.set(requestId,{action,resolve,reject,timer});
        try { this._webview.postMessage({channel,type:action,documentToken:this._token,requestId,payload}); }
        catch(error) { clearTimeout(timer); this._pending.delete(requestId); reject(error); }
      });
    }
    open(noteId,pageId) { return this._request('notes-open',{noteId,pageId}); }
    write(packet) { return this._request('notes-write',packet); }
    probe(packet) { return this._request('notes-probe',packet); }
    release(packet) { return this._request('notes-release',packet).then(result=>{
      if (result.released !== true) throw Error('Native Notes release not confirmed.');
    }); }
    // Allowed ONLY after coordinator.close(): a durable flush/reconciliation and
    // native release have completed. If ACK is lost, the document stays sealed.
    async drainAfterCoordinatorClose(coordinator) {
      if (this._disposed || this._sealed || !this._token || !coordinator ||
          coordinator.status !== null || this._pending.size !== 0)
        throw Error('Native release and zero outstanding Notes requests required before reload.');
      this._sealed=true; // atomic client barrier before posting request
      const result=await this._request('notes-drained',{editorFrozen:true});
      if (!result || result.drained !== true)
        throw Error('Notes native drain was not acknowledged; do not reload.');
      return true;
    }
    // A browser crash cannot run pagehide. The native ProcessFailed policy is
    // authoritative; pagehide is only a best-effort JS pending-promise teardown.
    bindPageLifecycle(pageWindow) {
      if (!pageWindow || typeof pageWindow.addEventListener !== 'function' ||
          typeof pageWindow.removeEventListener !== 'function' || this._pageHost)
        throw TypeError('Notes page lifecycle already bound or unavailable.');
      this._pageHost=pageWindow;
      this._pageHide=()=>this.dispose();
      pageWindow.addEventListener('pagehide',this._pageHide);
      return ()=>this.dispose();
    }
    dispose() {
      if (this._disposed) return;
      this._disposed=true; this._token=null; this._sealed=true;
      if(this._pageHost){
        this._pageHost.removeEventListener('pagehide',this._pageHide);
        this._pageHost=null; this._pageHide=null;
      }
      this._webview.removeEventListener('message',this._receive);
      for(const entry of this._pending.values()){
        clearTimeout(entry.timer);
        entry.reject(Error('Notes document was disposed before native ACK; save is uncertain.'));
      }
      this._pending.clear();
    }
  }
  NotesWebTransportV1.channel=channel;
  return NotesWebTransportV1;
});
