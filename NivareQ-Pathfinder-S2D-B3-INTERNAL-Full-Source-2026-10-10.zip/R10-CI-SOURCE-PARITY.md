# R10 GitHub native test source parity

**Exact passing CI run:** https://github.com/paglaaacoc/-_-fehu-H-_-/actions/runs/38045461924

**GitHub source of record:**
- `ci/s2b-r10/Program.cs` — Git blob `03cd1783f262c4ef564a143c675193512b4e6fdc`
- `.github/workflows/pathfinder-s2b-r10-renderer-crash-ci.yml` — Git blob `4cc67bf530f027f4886f1558f759f8d5eb9c9c83`
- Derived on the runner from immutable R5 ZIP plus R8 bridge/lifecycle overlays and R9 smoke project and local test HTML, replacing only the R9 smoke `Program.cs` with the R10 fault-injection test.

**Full Source ZIP representation:** `tests/NotesRealRendererCrashSmoke/Program.cs` preserves a locally reconstructed, functionally equivalent R10 scenario but is **not** identical in bytes to the CI-authoritative GitHub Program.cs. The WinUI app source in the inherited R9 ZIP is byte-for-byte unchanged. When strict reproduction is needed, use the GitHub source, rather than claiming this entire packaged snapshot was directly compiled and run.
