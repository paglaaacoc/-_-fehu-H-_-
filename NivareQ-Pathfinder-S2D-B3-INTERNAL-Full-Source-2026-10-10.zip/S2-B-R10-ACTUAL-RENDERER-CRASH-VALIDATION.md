# S2-B R10 — Actual Chromium Renderer Crash Evidence / Audit Boundary

CI: https://github.com/paglaaacoc/-_-fehu-H-_-/actions/runs/38045461924 — completed **SUCCESS**.

## Positive native Windows evidence
- R10 host compiled and opened Edge WebView2 with a virtual-host, trusted, local HTML document and **ephemeral** SQLite NotesStore generation.
- Prior R9 real-browser steps passed (bootstrap, unauthorized refresh rejection, opening page, committed revision ACK, failed release, approved release, safe drain/reload and reopened persisted text).
- While the reloaded page had an outstanding native writer, the test invoked actual Chromium DevTools `Page.crash`. The runner emitted: `R10 ACTUAL ProcessFailed: kind=RenderProcessExited reason=Crashed`.
- The test **did not** count the CDP command's interrupted task as proof; it awaited a real `CoreWebView2.ProcessFailed` event.
- Native policy quarantined the Notes document, preserved the writer session, disallowed close/navigation, declined late release ACK and left the committed SQLite page intact.
- Native R10 test **21 checks PASS**, real crash events **1**. Legacy R7+R8 native wire/lifecycle **33 checks PASS**. WinUI x64 and ARM64 compile **PASS**.
- Medical source files **132/132 unmodified**.

## Portable inherited regressions executed locally
- JS save/ACK/navigation: **52 PASS**.
- JS R7 wire transport: **11 PASS**.
- JS R8 lifecycle: **10 PASS**.
- Python SQLite DDL/static smoke: **8 PASS**.
- Python R2 contract: **22 PASS**. R3–R5 static contract gates PASS.

## Limitations and risk accounting
- This does **not** exercise actual production WinUI graphical Notes controls or live user data; the typed adapter remains uninstantiated in Pathfinder.
- The browser-process crash (as opposed to renderer only), process unresponsiveness, disk crash timing and full backup/restore rollover remain out of scope.
- Synthetic 'ProcessFailed' tests are still valid inherited regression tests but are distinct from R10's genuine failure.
- R10 test host source in this ZIP is semantically equivalent but not byte-identical to GitHub's passing Program.cs; the exact authoritative CI file blob is in `00-S2B-R10-INTERNAL-START-HERE.md`.
- Inherited nullable compiler warnings remain; no unrelated changes made.

**Result:** R10 real renderer-crash gate **PASS**; this is an isolated validation-only checkpoint, **NOT** owner acceptance or permission to activate Notes.
