# NivareQ Step 2 Pathfinder — S2-B R4 INTERNAL SOURCE CHECKPOINT

**2026-10-09 — NOT OWNER ACCEPTED; NOT NATIVE-COMPILED; NO WINDOWS BUILD OR INSTALLER.**

## Source authority and completed work

This checkpoint is an incremental continuation of the R3 full source. The accepted rollback is Windows **v1.2.1 Stable** (preserved verbatim in `AUTHORITY/`). It does not turn S1 or S2 into a user-data authority. S2-A remains preserved; S2-B R1/R2/R3 work is included without unnecessary rewrites. All 132 medical payload files remain byte-for-byte identical to R3.

## R4 changes

1. **Corrected actual JavaScript/native ink wire.** The S1-like renderer may supply `strokes: [...]`, but the pending native DTO requires `strokesJson: "[...]"`. The isolated JS coordinator now canonicalizes this before writing; the C# harness includes a representative camelCase JSON DTO fixture to catch mismatch.
2. **Lost-ACK recovery via verified native read.** Adds `NotesStagingPageRouterV1.Probe` (read-only, session-bound) and JS compare-before-retry. A committed write becomes ACK-equivalent only when exact expected revision and canonical content match. If no commit occurred, the latest draft can retry. If read fails, revision advances unexpectedly, or page content differs, the draft remains blocked for manual reconciliation. No read probe means **no blind retry**.
3. **Native release barrier.** A direct `open` cannot bypass session cleanup. `switchTo`/`close` flush, require native session-release callback/ACK, and preserve the current page on failure. The future WebView2 adapter must map this to `ReleaseStagingPage`.
4. **Expanded portable race tests:** 40 assertions pass (up from 27 R3). Added cross-language static guard and native harness assertions (C# assertions **not executed**).
5. **CI transfer readiness:** A complete isolated-branch workflow is included at `.github/workflows/pathfinder-s2b-native.yml` and a guarded Windows owner-device transfer helper at `tools/PUBLISH-S2B-R4-TO-CI.ps1`. This CI workflow is **in this ZIP only**, not committed to GitHub. A push is blocked if the repository branch HEAD differs from the recorded `6face5b0...` baseline. `main` must never be touched; no release/artifact publishing is authorized.

## Remaining blocking work — do not falsely close S2-B

- Full source has not been transferred to GitHub; `paglaaacoc/-_-fehu-H-_-` dev branch presently contains only the S2 scope gate document.
- .NET 10 NotesStoreHarness **not compiled or run**; WinUI x64/ARM64 **not built**. This sandbox has no .NET SDK or direct GitHub network access, and the connected GitHub tool does not accept a mounted source tree upload. The one-time guarded transfer helper allows the source to be published from an authenticated Windows environment without manually copying 550 files.
- Not tested on WebView2, real Windows, real user-data migration/restore, or device runtime. No live Notes writer activated, no study providers modified, no installer generated.
- S2-D holistic backup/restore and mutation-gate design are required before any live Notes activation. S2-C/U1 navigator and Scratchpad replacement remain future checkpoints.

## Owner scope remains frozen

**Notes → Notebook → Note → Page**, single Notes workspace. Lower-left six actions: **My Study, Search, Browse Notes, New Note, Settings, Backups**. The Backups button opens the same canonical backup manager as Settings. Journal retirement only after parity verification. Historical disposable Journal notes migration is waived, but live personal study data is not disposable.
