# NivareQ Step 2 Pathfinder — Scratchpad S2 R1 Owner-Authorized Development Gate

**Date:** 2026-10-09
**Status:** Gate OPENED by owner (proposal accepted), NOT an accepted release and NOT yet a native Windows test candidate.
**Source authority:** Accepted Pathfinder v1.2.1 Stable frozen. Immediate feature basis is Scratchpad S1 CI-Corrected R2 TEST, GitHub run 37996254406, CI commit 0e783499f8a0b398df363d215eab2de9cb0ea080. S1 remains owner-unaccepted and may be superseded by S2 owner-testing, never automatically promoted.
**Working CI repository:** temporary public `paglaaacoc/-_-fehu-H-_-`, *new S2 branch* `dev/pathfinder-scratchpad-s2-r1-20261009`, never default branch and never source of authoritative app truth.

## Accepted S2 scope

1. Screenshot insertion from Ctrl+V, touch-accessible Paste Image command, optionally native Windows clipboard fallback, and file picker if clipboard API unavailable; visible error feedback, not silent failure.
2. Images are independently positioned and resized in an Arrange mode, retaining aspect ratio, with keyboard/pointer/touch support, selection handles and minimal actions. In Type and Draw modes, image objects should not intercept editing and ink. Preserve text-only paste.
3. Native durable storage: transactional SQLite for document/page metadata and ink, independent binary image files referenced by content hash; avoid serializing images within each autosave. No arbitrary overall 12MB/1GB/5GB quota. Enforce sane per-paste bounds, quotas for pathological inputs, disk-space checks, atomic per-image commit, and visible error status. Prefer deduplication; avoid deleting attachments while any saved page references them.
4. Versioned self-contained `.nqpfbackup` archive: whole accepted Windows study-state provider graph and all Scratchpad records/images, manifest, checksums, streaming ZIP64 support; verified before declaring success. Atomic recovery must encompass data providers and entire Scratchpad store, including crash/restart recovery. Suitable for multi-GB synthetic datasets without requiring RAM proportional to archive size. Both export and restore need disk-space, zip-bomb, symlink/traversal, duplicate-path, and archive corruption defenses.
5. S1 live notes migrated without destructive overwrite; old JSON backup import may be discontinued by explicit owner choice. Keep rollback evidence and do not silently delete S1 notes; protect downgrade boundary.
6. Preserve all 132 medical payload files byte-for-byte, registry identity, 23 cockpit IDs/medical pedagogy, Search, Journal, session, tabs, left library scrolling, themes and split view. Windows alone authoritative; PWA unchanged.
7. Windows x64/ARM64 CI on an isolated branch and real-device acceptance checklist; never auto-release, merge, deploy, delete historical backups, or proclaim owner acceptance.

## S1 owner-test feedback folded into S2

### Theme disparity — FIX, modest solution
Scratchpad toolbar/page containers should receive the selected native Pathfinder theme via a validated palette message to its isolated WebView2. Do NOT inject cockpit theme CSS into Scratchpad, and NEVER dark-theme the writing paper automatically. The writing/paper area remains off-white with dark readable text and crisp lines across shell themes. Obey forced-colors accessibility; maintain contrast and focus indicators. Test theme changes while tool is open and after restart.

### Rich format pasted from HTML/Word — DEFER
S1 correctly pastes full clinical blocks as plain text. True rich text needs a `contenteditable`/editor model, HTML allowlist sanitization, selection/undo, formatting persistence and image/rich-content conflict resolution, a significant regression/security burden. S2 retains plain text selection, normal copy/paste and native keyboard undo. The owner explicitly permits deferral. Storage increase alone does not solve editor complexity. Reopen later only after S2 stability, not in S2 R1.

### Ruled guides drift relative to typed text — FIX
S1 textarea internally scrolls while CSS guide background belongs to an independent sheet. Baseline also varies with 24/32/44/60 px line-height. Synchronize guide offset with editor scroll and position baseline ~3px above the line in all four presets; retain writing-space scroll positions when toggling guides/mode/spaces. Test long pasted blocks while scrolling to bottom and changing spacing, one/two/four spaces, Split View resize, zoom and focus; do not alter medical WebViews.

### Word screenshot — reference only
Microsoft Word is a feature-reference for drag/resize and image/text co-existence, not a commitment to paragraph-anchored inline images, arbitrary rich text or complex line wrapping. S2 uses floating images on an arrangement layer.

## Implementation checkpoints — acceptance must be independent

A. **Theme and guide defect repair:** native theme event bridge plus guide scroll/baseline alignment, medical hash unaffected, browser smoke + Windows CI.
B. **Persisted Scratchpad V2:** storage service, S1 migration, transactional save, image file protections, handling of cold restart and storage failures. Never create first owner-test artifact while storage is unresolved.
C. **Image UX:** Paste Image, Ctrl+V, input types, Arrange, touch/stylus pointer controls and rollback of unsuccessful paste. Visual tests for narrow Split View and 125% scaling.
D. **Unified backup vNext:** canonical provider snapshot, streaming self-contained zip, image integrity, crash-safe restore spanning all stores and attachments, verified before reset. Old backups optional; current live Windows study data must remain safe.
E. **CI/closure:** x64+ARM64 binaries, compiler warnings audited, traceable full-source ZIP and hashes, source invariant tests, detailed owner acceptance checklist; no Stable promotion before explicit acceptance.

## Development constraints

* Future work should be on a dedicated S2 source branch, NOT public-impact G0. Do not touch default branch.
* Use full-source master as reproducible source input and verify its hash; a CI-staged patch is not a replacement for corrected full source.
* No bulk CSS injection into cockpit content. Keep writing paper white/off-white for legibility.
* Maintain no loss of S1 user-created pads, typed text and ink; test migration in disposable Windows data directories.
* No unverified global backup change. If atomic full restore cannot be proven, STOP and continue only within internal implementation checkpoints; do not ship a superficially successful installer.
* Owner's screenshots are diagnostic input and should not be copied into the public GitHub repository.

## Progress from current context

Owner accepted this scope and authorized development. S2-A *working-copy implementation* has been applied locally but not compiled as a native Windows build: Scratchpad palette dispatch, isolated palette CSS variables, text/guide scroll coupling, text baseline offsets, and scroll-position retention. Headless Chromium browser smoke confirmed validated palette reception and ruled-guide offset synchronization at 500 px scroll (`-17px` -> `-517px` for 60px line spacing). No screenshots or clinical source files were altered. This is NOT S2 R1 complete and must not be owner-tested or installed as a release.

## Stop/go criteria

S2 R1 cannot be considered a candidate until SQLite/schema, image UX, ZIP64 archive restore crash-consistency and CI passes are complete and auditable. S1 CI-Corrected R2 remains the only currently built Scratchpad TEST candidate; v1.2.1 Stable remains the only accepted Windows baseline.
