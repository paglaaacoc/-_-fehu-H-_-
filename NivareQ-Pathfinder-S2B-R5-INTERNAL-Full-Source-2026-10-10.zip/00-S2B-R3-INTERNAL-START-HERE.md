# NivareQ Step 2 Pathfinder — S2-B R3 INTERNAL SOURCE CHECKPOINT

**2026-10-09 · Not owner-accepted · Not compiled · Not a Windows build or installer.**

## Source chain and precedence

Windows v1.2.1 Stable is the immutable accepted rollback authority. This package is the
complete S2-B R2 source, incrementally extended to **S2-B R3**. Its archived original
S2-A/S1 source and all 132 medical payload files remain unchanged. No PWA work.

The temporary development repository is `paglaaacoc/-_-fehu-H-_-`, branch
`dev/pathfinder-scratchpad-s2-r1-20261009`. This R3 source has **NOT** been committed:
the isolated repository branch only carries the earlier S2 scope record. Avoid
installing CI until the full source is transferred and verified on that branch.

## R3 scope: stage-only save/ACK protocol

- `NotesProtocol/notes-draft-coordinator.js`: a pure, unmounted future U1 client
  draft controller. Per-page save ACKs, monotonic revisions, renderer snapshot
  isolation, retry-after-failure without claiming durability, pending-draft
  navigation fence and serialized edits arriving during an in-flight write.
- `Services/NotesStagingPageRouterV1.cs`: typed C# in-process staging router,
  session/page ownership, one writer session per page, durable revision ACK,
  identical-payload retransmission idempotence, stale packet rejection, explicit
  session release after acknowledged revision. **Not registered in MainWindow.**
- Native NotesStoreHarness extended with staged-route and camelCase JSON contract
  assertions, awaiting compilation.
- Portable JavaScript race harness: `node tests/NotesProtocolHarness/run.cjs`.
- Inactive CI template extended with JS/static tests; remains under `ci/`, NOT
  `.github/workflows/`.

## Verification observed (not extrapolated)

- Node simulated native transport/ACK test: **27 assertions PASS**.
- Python SQLite schema smoke: **8 tests PASS**.
- Python SQLite SQL/static R2 validation: **22 checks PASS**.
- Python R3 cross-language static check: **PASS**.
- Inherited 132 medical files: **byte-identical**.
- **Not executed:** C#/.NET harness, Windows WinUI x64/ARM64 compilation, actual
  WebView2 IPC, storage activation, real user-data migrations, backup, installer.

## Safety / recovery gates still open

1. Transfer verified full source to the isolated dev branch and run Windows CI
   (.NET 10 harness + x64/ARM64 WinUI). Correct native compile or runtime defects.
2. Design and validate S2-D unified backup snapshot, durable pointer activation,
   complete ZIP64 restore and cross-provider rollback BEFORE connecting this
   staging Notes writer to live Pathfinder personal data.
3. Perform real WebView2 integration tests for save failure, closed/switching
   pages, lost ACK, exact source links and restart. A lost ACK after a commit
   must resolve by verified read/reconcile, NOT blind overwrite.
4. Complete S2-C images + U1 navigator/Quick Capture + parity, keeping one
   Notes workspace (Notebook → Note → Page).

Final lower-left actions: **My Study / Search / Browse Notes / New Note / Settings /
Backups**. Backups navigates to the existing single authoritative backup manager.
Historical Journal note migration remains waived; other existing study data may
never be silently erased. No public release, owner-test EXE or CI success is claimed.
