using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using NivareQ.Step2Pathfinder.Models;

namespace NivareQ.Step2Pathfinder;

public sealed partial class MainWindow
{
    private const double SplitMinRatio = 0.28;
    private const double SplitMaxRatio = 0.72;
    private const double SplitAdaptiveMinimumWidth = 860;

    private bool _splitWorkspaceActive;
    private bool _splitWorkspaceSuspended;
    private bool _splitDividerDragging;
    private uint _splitDividerPointerId;
    private bool _suppressSplitSelectionHandling;
    private bool _splitSwapInProgress;
    private TabViewItem? _splitPrimaryTab;
    private TabViewItem? _splitSecondaryTab;
    private UIElement? _splitSecondaryOriginalContent;
    private double _splitRatio = 0.50;

    private async void SplitWorkspaceButton_Click(object sender, RoutedEventArgs e)
    {
        if (_splitWorkspaceActive)
        {
            ShowSplitWorkspaceMenu();
            return;
        }
        await OpenSplitWorkspaceAsync();
    }

    private async void SplitWorkspaceAccelerator_Invoked(KeyboardAccelerator sender, KeyboardAcceleratorInvokedEventArgs args)
    {
        if (_splitWorkspaceActive) await CloseSplitWorkspaceAsync();
        else await OpenSplitWorkspaceAsync();
        args.Handled = true;
    }

    // W5 preflight contract: Split View may be intentionally empty. Opening Split by itself
    // never chooses or creates a second view. A view enters the secondary slot only through
    // an explicit Show beside action or session restoration.
    private async Task OpenSplitWorkspaceAsync(TabViewItem? requestedSecondary = null)
    {
        CloseAppSurface(restorePreviousTab: false);
        var primary = Tabs.SelectedItem as TabViewItem;
        if (primary is null || primary == _homeTab || primary == _splitSecondaryTab)
        {
            primary = Tabs.TabItems.OfType<TabViewItem>().FirstOrDefault(IsEligibleMainSplitTab);
            if (primary is null)
            {
                await ShowPersonalMessageAsync("Split View needs a workspace", "Open a study cockpit or tool workspace first, then use Split View.");
                return;
            }
            Tabs.SelectedItem = primary;
        }

        _splitWorkspaceActive = true;
        _splitPrimaryTab = primary;
        _splitRatio = Math.Clamp(_settings.LastWorkspaceSplitRatio, SplitMinRatio, SplitMaxRatio);
        ApplySplitWorkspaceLayout();

        if (requestedSecondary is not null)
        {
            if (!await ShowTabBesideCoreAsync(requestedSecondary, showFailureMessage: true))
            {
                // The split workspace itself remains open and intentionally empty.
                UpdateSecondaryWorkspaceChrome();
            }
        }

        SplitWorkspaceButton.Content = "◫ Split •";
        ToolTipService.SetToolTip(SplitWorkspaceButton, "Split View options");
        QueuePersistenceFailureNotice(SaveCurrentSession(), "Split workspace state");
    }

    private UIElement CreateEmptySplitContent()
    {
        var stack = new StackPanel
        {
            Spacing = 8,
            Padding = new Thickness(28),
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center,
            MaxWidth = 500
        };
        stack.Children.Add(new TextBlock
        {
            Text = "Second pane is empty",
            FontSize = 18,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            TextWrapping = TextWrapping.Wrap,
            TextAlignment = TextAlignment.Center
        });
        stack.Children.Add(new TextBlock
        {
            Text = "Use Show beside on a tab, source preview, or the Split menu to place a view here. Main-tab navigation will not replace it automatically.",
            Opacity = .72,
            TextWrapping = TextWrapping.Wrap,
            TextAlignment = TextAlignment.Center
        });
        return stack;
    }

    private async Task<bool> AttachSecondaryWorkspaceTabAsync(TabViewItem tab)
    {
        if (!_splitWorkspaceActive || !Tabs.TabItems.Contains(tab) || tab == _homeTab) return false;
        if (_splitSecondaryTab == tab && _splitSecondaryOriginalContent is not null) return true;
        if (tab == _splitPrimaryTab || ReferenceEquals(Tabs.SelectedItem, tab)) return false;

        if (tab.Content is not UIElement content) return false;
        await ReturnSecondaryWorkspaceTabAsync(selectReturned: false, save: false);
        if (_splitSecondaryTab is not null) return false; // previous beside view could not detach safely

        // TabView may still have the unselected content root in its presenter for a dispatcher
        // turn. Never attach the same XAML element to the secondary ContentControl until its
        // previous parent has actually released it.
        if (!await WaitForSplitElementDetachAsync(content)) return false;

        _splitSecondaryTab = tab;
        _splitSecondaryOriginalContent = content;
        tab.Content = null;
        tab.Visibility = Visibility.Collapsed;
        SecondaryWorkspaceContent.Content = content;
        VerifySplitWorkspaceInvariant();
        UpdateSecondaryWorkspaceChrome();
        return true;
    }

    private async Task ReturnSecondaryWorkspaceTabAsync(bool selectReturned, bool save = true)
    {
        var tab = _splitSecondaryTab;
        var content = _splitSecondaryOriginalContent;
        if (tab is null)
        {
            SecondaryWorkspaceContent.Content = CreateEmptySplitContent();
            UpdateSecondaryWorkspaceChrome();
            if (save) QueuePersistenceFailureNotice(SaveCurrentSession(), "Split workspace state");
            return;
        }

        SecondaryWorkspaceContent.Content = null;
        if (content is not null && !await WaitForSplitElementDetachAsync(content))
        {
            // Never reparent a live XAML root while WinUI still reports a visual parent. Keep the
            // logical beside ownership intact so the user can retry instead of risking the W4 R1
            // double-parent crash class.
            UpdateSecondaryWorkspaceChrome();
            await ShowPersonalMessageAsync("Beside view is still settling", "Pathfinder did not move the beside view because WinUI had not safely detached it yet. Nothing was discarded; try Return to tabs again.");
            return;
        }
        if (Tabs.TabItems.Contains(tab))
        {
            if (content is not null) tab.Content = content;
            tab.Visibility = Visibility.Visible;
        }

        _splitSecondaryTab = null;
        _splitSecondaryOriginalContent = null;
        SecondaryWorkspaceContent.Content = CreateEmptySplitContent();
        UpdateSecondaryWorkspaceChrome();

        if (selectReturned && Tabs.TabItems.Contains(tab))
        {
            _suppressSplitSelectionHandling = true;
            try { Tabs.SelectedItem = tab; }
            finally { _suppressSplitSelectionHandling = false; }
            _splitPrimaryTab = tab;
        }

        if (save) QueuePersistenceFailureNotice(SaveCurrentSession(), "Split workspace state");
    }

    private async void ReturnSecondaryWorkspaceButton_Click(object sender, RoutedEventArgs e)
        => await ReturnSecondaryWorkspaceTabAsync(selectReturned: false);

    private async void CloseSplitWorkspaceButton_Click(object sender, RoutedEventArgs e)
        => await CloseSplitWorkspaceAsync();

    private async Task CloseSplitWorkspaceAsync(bool save = true)
    {
        await ReturnSecondaryWorkspaceTabAsync(selectReturned: false, save: false);
        if (_splitSecondaryTab is not null) return; // detach safety kept the beside view parked
        _splitWorkspaceActive = false;
        _splitWorkspaceSuspended = false;
        _splitPrimaryTab = null;
        PrimaryWorkspaceColumn.Width = new GridLength(1, GridUnitType.Star);
        WorkspaceDividerColumn.Width = new GridLength(0);
        SecondaryWorkspaceColumn.Width = new GridLength(0);
        WorkspaceDivider.Visibility = Visibility.Collapsed;
        SecondaryWorkspaceFrame.Visibility = Visibility.Collapsed;
        SplitWorkspaceButton.Content = _compactChrome ? "◫" : "◫ Split";
        ToolTipService.SetToolTip(SplitWorkspaceButton, "Split workspace");
        if (save) QueuePersistenceFailureNotice(SaveCurrentSession(), "Split workspace state");
    }

    private void ApplySplitWorkspaceLayout()
    {
        if (!_splitWorkspaceActive) return;

        var width = MainContentHost.ActualWidth > 0 ? MainContentHost.ActualWidth : RootGrid.ActualWidth;
        _splitWorkspaceSuspended = width > 0 && width < SplitAdaptiveMinimumWidth;
        if (_splitWorkspaceSuspended)
        {
            PrimaryWorkspaceColumn.Width = new GridLength(1, GridUnitType.Star);
            WorkspaceDividerColumn.Width = new GridLength(0);
            SecondaryWorkspaceColumn.Width = new GridLength(0);
            WorkspaceDivider.Visibility = Visibility.Collapsed;
            SecondaryWorkspaceFrame.Visibility = Visibility.Collapsed;
            SplitWorkspaceButton.Content = "◫ Split ↕";
            ToolTipService.SetToolTip(SplitWorkspaceButton, "Split View is preserved and will return when the window is wider");
            return;
        }

        _splitRatio = Math.Clamp(_splitRatio, SplitMinRatio, SplitMaxRatio);
        PrimaryWorkspaceColumn.Width = new GridLength(_splitRatio, GridUnitType.Star);
        WorkspaceDividerColumn.Width = new GridLength(10);
        SecondaryWorkspaceColumn.Width = new GridLength(1 - _splitRatio, GridUnitType.Star);
        WorkspaceDivider.Visibility = Visibility.Visible;
        SecondaryWorkspaceFrame.Visibility = Visibility.Visible;
        SplitWorkspaceButton.Content = "◫ Split •";
        ToolTipService.SetToolTip(SplitWorkspaceButton, "Split View options");
        if (_splitSecondaryTab is null && SecondaryWorkspaceContent.Content is null)
            SecondaryWorkspaceContent.Content = CreateEmptySplitContent();
        UpdateSecondaryWorkspaceChrome();
    }

    private void UpdateSecondaryWorkspaceChrome()
    {
        var tab = _splitSecondaryTab;
        var hasSecondary = tab is not null;
        ReturnSecondaryWorkspaceButton.IsEnabled = hasSecondary;
        SwapSplitPanesButton.IsEnabled = hasSecondary && !_splitSwapInProgress;
        if (tab is null)
        {
            SecondaryWorkspaceTitle.Text = "Split View";
            SecondaryWorkspaceRoleText.Text = "Empty secondary workspace · choose Show beside deliberately";
            SecondaryBackButton.IsEnabled = false;
            SecondaryForwardButton.IsEnabled = false;
            return;
        }

        SecondaryWorkspaceTitle.Text = TabHeaderText(tab);
        if (_studyTabs.TryGetValue(tab, out var context))
        {
            SecondaryWorkspaceRoleText.Text = context.ViewRole == CockpitViewRole.Primary
                ? "Interactive primary cockpit · parked beside"
                : "State-read-only source/reference view · parked beside";
            SecondaryBackButton.IsEnabled = context.WebView.CoreWebView2?.CanGoBack == true;
            SecondaryForwardButton.IsEnabled = context.WebView.CoreWebView2?.CanGoForward == true;
        }
        else
        {
            SecondaryWorkspaceRoleText.Text = "Tool workspace · parked beside";
            SecondaryBackButton.IsEnabled = false;
            SecondaryForwardButton.IsEnabled = false;
        }
    }

    private static string TabHeaderText(TabViewItem tab)
        => tab.Header?.ToString() ?? "Workspace";

    private bool IsEligibleMainSplitTab(TabViewItem tab)
        => tab != _homeTab && tab != _splitSecondaryTab && Tabs.TabItems.Contains(tab) && tab.Visibility == Visibility.Visible;

    private void ConfigureShellTabWorkspaceFeatures(TabViewItem tab)
    {
        tab.RightTapped += (_, e) =>
        {
            var flyout = new MenuFlyout();
            var showBeside = new MenuFlyoutItem { Text = "Show beside in Split View" };
            showBeside.Click += async (_, _) => await ShowTabBesideAsync(tab);
            flyout.Items.Add(showBeside);
            flyout.Items.Add(new MenuFlyoutSeparator());
            var close = new MenuFlyoutItem { Text = "Close tab" };
            close.Click += async (_, _) => await CloseTabItemAsync(tab, true);
            flyout.Items.Add(close);
            flyout.ShowAt(tab);
            e.Handled = true;
        };
    }

    private void ShowSplitWorkspaceMenu()
    {
        var flyout = new MenuFlyout();
        foreach (var tab in Tabs.TabItems.OfType<TabViewItem>().Where(IsEligibleMainSplitTab))
        {
            if (tab == _splitPrimaryTab) continue;
            var item = new MenuFlyoutItem { Text = "Show beside: " + TabHeaderText(tab) };
            var localTab = tab;
            item.Click += async (_, _) => await ShowTabBesideAsync(localTab);
            flyout.Items.Add(item);
        }
        if (flyout.Items.Count > 0) flyout.Items.Add(new MenuFlyoutSeparator());

        var returnToTabs = new MenuFlyoutItem { Text = "Return beside view to tabs", IsEnabled = _splitSecondaryTab is not null };
        returnToTabs.Click += async (_, _) => await ReturnSecondaryWorkspaceTabAsync(selectReturned: false);
        flyout.Items.Add(returnToTabs);
        var swap = new MenuFlyoutItem { Text = "Swap panes", IsEnabled = _splitSecondaryTab is not null && !_splitSwapInProgress };
        swap.Click += async (_, _) => await SwapSplitPanesAsync();
        flyout.Items.Add(swap);
        var close = new MenuFlyoutItem { Text = "Close Split View" };
        close.Click += async (_, _) => await CloseSplitWorkspaceAsync();
        flyout.Items.Add(close);
        flyout.ShowAt(SplitWorkspaceButton);
    }

    private void HandleSplitPrimarySelectionChanged()
    {
        if (!_splitWorkspaceActive || _suppressSplitSelectionHandling || _splitSwapInProgress) return;
        if (Tabs.SelectedItem is not TabViewItem selected) return;

        // A parked secondary tab is intentionally hidden and ordinary navigation never swaps
        // it. If an internal caller nevertheless tries to select it, keep the current primary.
        if (selected == _splitSecondaryTab)
        {
            if (_splitPrimaryTab is not null && Tabs.TabItems.Contains(_splitPrimaryTab))
            {
                _suppressSplitSelectionHandling = true;
                try { Tabs.SelectedItem = _splitPrimaryTab; }
                finally { _suppressSplitSelectionHandling = false; }
            }
            PulseSecondaryWorkspaceAlreadyOpen();
            return;
        }

        if (selected != _homeTab && selected.Visibility == Visibility.Visible)
            _splitPrimaryTab = selected;
        UpdateSecondaryWorkspaceChrome();
    }

    private void PulseSecondaryWorkspaceAlreadyOpen()
    {
        if (_splitSecondaryTab is null) return;
        SecondaryWorkspaceRoleText.Text = "Already open beside · use Swap panes to move it to main";
        _ = RestoreSecondaryRoleTextLaterAsync(_splitSecondaryTab);
    }

    private async Task RestoreSecondaryRoleTextLaterAsync(TabViewItem expected)
    {
        await Task.Delay(1700);
        if (_splitWorkspaceActive && _splitSecondaryTab == expected) UpdateSecondaryWorkspaceChrome();
    }

    private bool IsTabParkedBeside(TabViewItem tab)
        => _splitWorkspaceActive && ReferenceEquals(tab, _splitSecondaryTab);

    private bool IsResourceParkedBeside(string resourceId)
        => _splitSecondaryTab is not null
           && _studyTabs.TryGetValue(_splitSecondaryTab, out var context)
           && context.Subject.ResourceId.Equals(resourceId, StringComparison.OrdinalIgnoreCase);

    private bool TryHandleAlreadyParkedBeside(TabViewItem tab)
    {
        if (!IsTabParkedBeside(tab)) return false;
        PulseSecondaryWorkspaceAlreadyOpen();
        return true;
    }

    private Task YieldSplitWorkspaceAsync()
    {
        var completion = new TaskCompletionSource<bool>();
        if (!DispatcherQueue.TryEnqueue(Microsoft.UI.Dispatching.DispatcherQueuePriority.Low, () => completion.TrySetResult(true)))
            completion.TrySetResult(true);
        return completion.Task;
    }

    private async Task<bool> WaitForSplitElementDetachAsync(UIElement element)
    {
        for (var attempt = 0; attempt < 10; attempt++)
        {
            if (VisualTreeHelper.GetParent(element) is null) return true;
            await YieldSplitWorkspaceAsync();
        }
        return VisualTreeHelper.GetParent(element) is null;
    }

    private async Task<bool> WaitForSplitElementAttachAsync(UIElement element)
    {
        for (var attempt = 0; attempt < 10; attempt++)
        {
            if (VisualTreeHelper.GetParent(element) is not null) return true;
            await YieldSplitWorkspaceAsync();
        }
        return VisualTreeHelper.GetParent(element) is not null;
    }

    private void VerifySplitWorkspaceInvariant()
    {
        if (!_splitWorkspaceActive) return;
        if (_splitPrimaryTab is null || !Tabs.TabItems.Contains(_splitPrimaryTab) || _splitPrimaryTab == _homeTab)
            throw new InvalidOperationException("Split View primary ownership is incomplete.");
        if (!ReferenceEquals(Tabs.SelectedItem, _splitPrimaryTab))
            throw new InvalidOperationException("Split View selected-tab ownership did not settle on the primary pane.");

        if (_splitSecondaryTab is null)
        {
            if (_splitSecondaryOriginalContent is not null)
                throw new InvalidOperationException("Split View has secondary content without a parked secondary tab.");
            return;
        }

        if (_splitSecondaryOriginalContent is null)
            throw new InvalidOperationException("Split View parked tab is missing its live content.");
        if (_splitPrimaryTab == _splitSecondaryTab)
            throw new InvalidOperationException("Split View primary and secondary cannot be the same tab.");
        if (!Tabs.TabItems.Contains(_splitSecondaryTab))
            throw new InvalidOperationException("Split View references a tab that is no longer open.");
        if (_splitSecondaryTab.Visibility != Visibility.Collapsed)
            throw new InvalidOperationException("Split View secondary tab must be hidden from the main tab strip while parked beside.");
        if (_splitSecondaryTab.Content is not null)
            throw new InvalidOperationException("Split View secondary tab must not retain live content while parked beside.");
        if (!ReferenceEquals(SecondaryWorkspaceContent.Content, _splitSecondaryOriginalContent))
            throw new InvalidOperationException("Split View secondary host does not own the recorded live content.");
    }

    private async Task<bool> SwapSplitPanesAsync()
    {
        if (_splitSwapInProgress || !_splitWorkspaceActive || _splitPrimaryTab is null || _splitSecondaryTab is null || _splitSecondaryOriginalContent is null) return false;
        if (_splitPrimaryTab.Content is not UIElement primaryContent) return false;

        var oldPrimary = _splitPrimaryTab;
        var oldSecondary = _splitSecondaryTab;
        var oldSecondaryContent = _splitSecondaryOriginalContent;
        _splitSwapInProgress = true;
        _suppressSplitSelectionHandling = true;
        try
        {
            // Release the parked view first, restore its tab while unselected, then promote it.
            SecondaryWorkspaceContent.Content = null;
            if (!await WaitForSplitElementDetachAsync(oldSecondaryContent))
                throw new InvalidOperationException("The beside view had not detached from its host before the Split View swap.");
            oldSecondary.Content = oldSecondaryContent;
            oldSecondary.Visibility = Visibility.Visible;
            Tabs.SelectedItem = oldSecondary;
            await YieldSplitWorkspaceAsync();
            if (!await WaitForSplitElementAttachAsync(oldSecondaryContent))
                throw new InvalidOperationException("The former beside view did not attach as the new main view.");

            if (!await WaitForSplitElementDetachAsync(primaryContent))
                throw new InvalidOperationException("The previous main view had not detached before being parked beside.");

            oldPrimary.Content = null;
            oldPrimary.Visibility = Visibility.Collapsed;
            _splitPrimaryTab = oldSecondary;
            _splitSecondaryTab = oldPrimary;
            _splitSecondaryOriginalContent = primaryContent;
            SecondaryWorkspaceContent.Content = primaryContent;

            VerifySplitWorkspaceInvariant();
            UpdateSecondaryWorkspaceChrome();
            QueuePersistenceFailureNotice(SaveCurrentSession(), "Split workspace state");
            return true;
        }
        catch (Exception ex)
        {
            // Fail safe: restore ordinary visible tabs without ever assigning a UIElement that
            // WinUI still reports as parented elsewhere. This preserves the W4 crash repair even
            // when the explicit W5 swap transaction itself cannot settle.
            SecondaryWorkspaceContent.Content = null;
            if (Tabs.TabItems.Contains(oldSecondary))
            {
                oldSecondary.Visibility = Visibility.Visible;
                if (oldSecondary.Content is null && await WaitForSplitElementDetachAsync(oldSecondaryContent))
                    oldSecondary.Content = oldSecondaryContent;
            }
            if (Tabs.TabItems.Contains(oldPrimary))
            {
                oldPrimary.Visibility = Visibility.Visible;
                if (oldPrimary.Content is null && await WaitForSplitElementDetachAsync(primaryContent))
                    oldPrimary.Content = primaryContent;
            }

            if (Tabs.TabItems.Contains(oldPrimary) && oldPrimary.Content is not null)
                Tabs.SelectedItem = oldPrimary;
            else if (Tabs.TabItems.Contains(oldSecondary) && oldSecondary.Content is not null)
                Tabs.SelectedItem = oldSecondary;

            _splitSecondaryOriginalContent = null;
            _splitSecondaryTab = null;
            _splitPrimaryTab = Tabs.SelectedItem as TabViewItem;
            _splitWorkspaceActive = false;
            _splitWorkspaceSuspended = false;
            PrimaryWorkspaceColumn.Width = new GridLength(1, GridUnitType.Star);
            WorkspaceDividerColumn.Width = new GridLength(0);
            SecondaryWorkspaceColumn.Width = new GridLength(0);
            WorkspaceDivider.Visibility = Visibility.Collapsed;
            SecondaryWorkspaceFrame.Visibility = Visibility.Collapsed;
            SplitWorkspaceButton.Content = _compactChrome ? "◫" : "◫ Split";
            ToolTipService.SetToolTip(SplitWorkspaceButton, "Split workspace");
            await ShowPersonalMessageAsync("Split View swap could not complete", "Pathfinder avoided an unsafe reparent, restored every view WinUI had safely released, and closed Split View. " + ex.Message);
            return false;
        }
        finally
        {
            _suppressSplitSelectionHandling = false;
            _splitSwapInProgress = false;
            if (_splitWorkspaceActive) UpdateSecondaryWorkspaceChrome();
        }
    }

    private async void SwapSplitPanesButton_Click(object sender, RoutedEventArgs e) => await SwapSplitPanesAsync();

    private void SecondaryBackButton_Click(object sender, RoutedEventArgs e)
    {
        if (_splitSecondaryTab is not null && _studyTabs.TryGetValue(_splitSecondaryTab, out var context) && context.WebView.CoreWebView2?.CanGoBack == true)
            context.WebView.CoreWebView2.GoBack();
    }

    private void SecondaryForwardButton_Click(object sender, RoutedEventArgs e)
    {
        if (_splitSecondaryTab is not null && _studyTabs.TryGetValue(_splitSecondaryTab, out var context) && context.WebView.CoreWebView2?.CanGoForward == true)
            context.WebView.CoreWebView2.GoForward();
    }

    private void SecondaryWorkspaceFrame_PointerPressed(object sender, PointerRoutedEventArgs e)
        => UpdateSecondaryWorkspaceChrome();

    private void WorkspaceDivider_PointerPressed(object sender, PointerRoutedEventArgs e)
    {
        if (!_splitWorkspaceActive || _splitWorkspaceSuspended) return;
        _splitDividerDragging = true;
        _splitDividerPointerId = e.Pointer.PointerId;
        WorkspaceDivider.CapturePointer(e.Pointer);
        e.Handled = true;
    }

    private void WorkspaceDivider_PointerMoved(object sender, PointerRoutedEventArgs e)
    {
        if (!_splitDividerDragging || e.Pointer.PointerId != _splitDividerPointerId) return;
        var width = MainContentHost.ActualWidth;
        if (width <= 40) return;
        var x = e.GetCurrentPoint(MainContentHost).Position.X;
        _splitRatio = Math.Clamp(x / width, SplitMinRatio, SplitMaxRatio);
        ApplySplitWorkspaceLayout();
        e.Handled = true;
    }

    private void WorkspaceDivider_PointerReleased(object sender, PointerRoutedEventArgs e)
        => EndSplitDividerDrag(e);

    private void WorkspaceDivider_PointerCanceled(object sender, PointerRoutedEventArgs e)
        => EndSplitDividerDrag(e);

    private void WorkspaceDivider_DoubleTapped(object sender, DoubleTappedRoutedEventArgs e)
    {
        if (!_splitWorkspaceActive || _splitWorkspaceSuspended) return;
        _splitRatio = 0.50;
        _settings.LastWorkspaceSplitRatio = _splitRatio;
        ApplySplitWorkspaceLayout();
        QueuePersistenceFailureNotice(SaveCurrentSession(), "Split workspace ratio");
        e.Handled = true;
    }

    private void EndSplitDividerDrag(PointerRoutedEventArgs e)
    {
        if (!_splitDividerDragging || e.Pointer.PointerId != _splitDividerPointerId) return;
        _splitDividerDragging = false;
        WorkspaceDivider.ReleasePointerCapture(e.Pointer);
        QueuePersistenceFailureNotice(SaveCurrentSession(), "Split workspace ratio");
        e.Handled = true;
    }

    private async Task ShowTabBesideAsync(TabViewItem tab)
    {
        if (!_splitWorkspaceActive)
        {
            await OpenSplitWorkspaceAsync(tab);
            return;
        }
        await ShowTabBesideCoreAsync(tab, showFailureMessage: true);
    }

    private async Task<bool> ShowTabBesideCoreAsync(TabViewItem tab, bool showFailureMessage)
    {
        if (!Tabs.TabItems.Contains(tab) || tab == _homeTab) return false;
        if (tab == _splitSecondaryTab)
        {
            PulseSecondaryWorkspaceAlreadyOpen();
            return true;
        }

        if (ReferenceEquals(Tabs.SelectedItem, tab) || tab == _splitPrimaryTab)
        {
            // A beside view cannot also be the active main view. Move main selection to an
            // already-open visible workspace first; never invent an implicit duplicate.
            var replacementMain = Tabs.TabItems.OfType<TabViewItem>()
                .Where(x => x != tab && IsEligibleMainSplitTab(x))
                .LastOrDefault();
            if (replacementMain is null)
            {
                if (showFailureMessage)
                    await ShowPersonalMessageAsync("Keep one view in the main pane", "Open another study/tool tab first, then use Show beside on this view. Split View itself can remain empty until you choose what belongs beside.");
                return false;
            }
            Tabs.SelectedItem = replacementMain;
            _splitPrimaryTab = replacementMain;
            await YieldSplitWorkspaceAsync();
        }

        if (!await AttachSecondaryWorkspaceTabAsync(tab))
        {
            if (showFailureMessage)
                await ShowPersonalMessageAsync("Could not show this view beside", "Pathfinder could not move this view into the secondary workspace safely. Both tabs were left available in the main workspace.");
            return false;
        }
        ApplySplitWorkspaceLayout();
        QueuePersistenceFailureNotice(SaveCurrentSession(), "Split workspace state");
        return true;
    }

    private void PrepareTabForCloseInSplitWorkspace(TabViewItem tab)
    {
        if (!_splitWorkspaceActive) return;
        if (tab == _splitSecondaryTab)
        {
            // The tab is about to be removed. Detach its live root from the beside host but do
            // not reparent it into the soon-to-be-removed TabViewItem; that would recreate the
            // visual-parent race W4 deliberately eliminated.
            SecondaryWorkspaceContent.Content = null;
            tab.Content = null;
            tab.Visibility = Visibility.Visible;
            _splitSecondaryOriginalContent = null;
            _splitSecondaryTab = null;
            SecondaryWorkspaceContent.Content = CreateEmptySplitContent();
            UpdateSecondaryWorkspaceChrome();
            return;
        }
        if (tab == _splitPrimaryTab)
        {
            _splitPrimaryTab = Tabs.TabItems.OfType<TabViewItem>().FirstOrDefault(x => x != tab && IsEligibleMainSplitTab(x));
        }
    }

    private void CaptureSplitWorkspaceSessionState()
    {
        _settings.LastWorkspaceSplitEnabled = _splitWorkspaceActive;
        _settings.LastWorkspaceSplitRatio = Math.Clamp(_splitRatio, SplitMinRatio, SplitMaxRatio);
        _settings.LastWorkspaceSecondaryKind = "";
        _settings.LastWorkspaceSecondaryId = "";
        if (!_splitWorkspaceActive || _splitSecondaryTab is null) return;

        if (_studyTabs.TryGetValue(_splitSecondaryTab, out var study))
        {
            // Strict read-only source/reference tabs can carry an exact Location v2 target that
            // the legacy Split session fields cannot represent. Never guess that target on
            // restart. Keep Split View enabled, but restore its secondary slot empty instead.
            if (study.ViewRole == CockpitViewRole.ReadOnlySecondary) return;
            _settings.LastWorkspaceSecondaryKind = "study";
            _settings.LastWorkspaceSecondaryId = study.Subject.Slug;
            return;
        }
        if (_splitSecondaryTab.Tag is string tag && tag.StartsWith("shell:", StringComparison.Ordinal))
        {
            _settings.LastWorkspaceSecondaryKind = "shell";
            _settings.LastWorkspaceSecondaryId = tag[6..];
        }
    }

    private async Task RestoreSplitWorkspaceSessionAsync()
    {
        if (!_settings.RestoreSplitWorkspace || !_settings.LastWorkspaceSplitEnabled) return;
        _splitRatio = Math.Clamp(_settings.LastWorkspaceSplitRatio, SplitMinRatio, SplitMaxRatio);
        var primary = Tabs.SelectedItem as TabViewItem;
        if (primary is null || primary == _homeTab) return;

        _splitWorkspaceActive = true;
        _splitPrimaryTab = primary;
        ApplySplitWorkspaceLayout();

        if (string.IsNullOrWhiteSpace(_settings.LastWorkspaceSecondaryId))
        {
            UpdateSecondaryWorkspaceChrome();
            return;
        }

        TabViewItem? secondary = null;
        if (_settings.LastWorkspaceSecondaryKind.Equals("study", StringComparison.OrdinalIgnoreCase))
        {
            var subject = _catalog.Resolve(_settings.LastWorkspaceSecondaryId);
            if (subject is not null) secondary = FindPrimaryStudyContext(subject.ResourceId)?.Tab;
        }
        else if (_settings.LastWorkspaceSecondaryKind.Equals("shell", StringComparison.OrdinalIgnoreCase))
        {
            secondary = Tabs.TabItems.OfType<TabViewItem>().FirstOrDefault(x => Equals(x.Tag, "shell:" + _settings.LastWorkspaceSecondaryId));
        }
        else if (_settings.LastWorkspaceSecondaryKind.Equals("readonly-study", StringComparison.OrdinalIgnoreCase))
        {
            // W4 may have persisted only the read-only resource identity, not its strict exact
            // source target. W5 deliberately restores this as an empty secondary slot rather
            // than fabricate a location. The user can reopen the verified source explicitly.
            secondary = null;
        }

        if (secondary is null || secondary == primary) return;
        if (!await AttachSecondaryWorkspaceTabAsync(secondary))
        {
            await ReturnSecondaryWorkspaceTabAsync(selectReturned: false, save: false);
            return;
        }
        ApplySplitWorkspaceLayout();
    }

    private void ValidateSplitWorkspaceAfterTabChange()
    {
        if (!_splitWorkspaceActive) return;
        if (_splitSecondaryTab is not null && !Tabs.TabItems.Contains(_splitSecondaryTab))
        {
            _splitSecondaryTab = null;
            _splitSecondaryOriginalContent = null;
            SecondaryWorkspaceContent.Content = CreateEmptySplitContent();
        }
        if (_splitPrimaryTab is null || !Tabs.TabItems.Contains(_splitPrimaryTab) || _splitPrimaryTab == _splitSecondaryTab || _splitPrimaryTab.Visibility != Visibility.Visible)
        {
            _splitPrimaryTab = Tabs.SelectedItem as TabViewItem;
            if (_splitPrimaryTab is null || _splitPrimaryTab == _homeTab || _splitPrimaryTab == _splitSecondaryTab || _splitPrimaryTab.Visibility != Visibility.Visible)
            {
                _splitPrimaryTab = Tabs.TabItems.OfType<TabViewItem>().FirstOrDefault(IsEligibleMainSplitTab);
                if (_splitPrimaryTab is not null)
                {
                    _suppressSplitSelectionHandling = true;
                    try { Tabs.SelectedItem = _splitPrimaryTab; }
                    finally { _suppressSplitSelectionHandling = false; }
                }
            }
        }
        if (_splitPrimaryTab is null)
        {
            _ = CloseSplitWorkspaceAsync(save: false);
            return;
        }
        ApplySplitWorkspaceLayout();
    }

    private async Task<TabViewItem?> CreateReadOnlySourceTabForSplitAsync(SubjectEntry subject, UniversalSearchResult result)
    {
        var before = new HashSet<TabViewItem>(_studyTabs.Keys);
        await CreateStudyTabAsync(subject, false, null, result, CockpitViewRole.ReadOnlySecondary);
        return _studyTabs.Values
            .Where(x => x.ViewRole == CockpitViewRole.ReadOnlySecondary
                        && x.Subject.ResourceId.Equals(subject.ResourceId, StringComparison.OrdinalIgnoreCase)
                        && !before.Contains(x.Tab))
            .Select(x => x.Tab)
            .FirstOrDefault();
    }


    private async Task<TabViewItem?> CreateReadOnlySourceTabForLocationAsync(SubjectEntry subject, StudyLocationState location)
    {
        if (!location.IsStrictSource
            || !location.ResourceId.Equals(subject.ResourceId, StringComparison.OrdinalIgnoreCase)
            || !location.SourceVersion.Equals(subject.ExpectedSha256, StringComparison.OrdinalIgnoreCase))
            return null;

        var before = new HashSet<TabViewItem>(_studyTabs.Keys);
        await CreateStudyTabAsync(subject, false, CloneLocation(location), null, CockpitViewRole.ReadOnlySecondary);
        return _studyTabs.Values
            .Where(x => x.ViewRole == CockpitViewRole.ReadOnlySecondary
                        && x.Subject.ResourceId.Equals(subject.ResourceId, StringComparison.OrdinalIgnoreCase)
                        && !before.Contains(x.Tab))
            .Select(x => x.Tab)
            .FirstOrDefault();
    }
}
