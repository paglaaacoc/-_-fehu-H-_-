using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.Web.WebView2.Core;
using NivareQ.Step2Pathfinder.Models;
using NivareQ.Step2Pathfinder.Services;

namespace NivareQ.Step2Pathfinder;

public sealed partial class MainWindow
{
    private async Task PreviewUniversalSearchResultAsync(UniversalSearchResult result)
    {
        var subject = _catalog.Entries.FirstOrDefault(x => x.ResourceId.Equals(result.SubjectSlug, StringComparison.OrdinalIgnoreCase));
        if (subject is null) return;
        if (string.IsNullOrWhiteSpace(result.SourceVersion)
            || !result.SourceVersion.Equals(subject.ExpectedSha256, StringComparison.OrdinalIgnoreCase))
        {
            await ShowPersonalMessageAsync(
                "Source preview is stale",
                "This search result does not match the verified bytes of the current cockpit. Pathfinder will not guess a replacement source. Run the search again against the current library.");
            return;
        }

        var availableWidth = RootGrid.ActualWidth > 0 ? RootGrid.ActualWidth : 1200;
        var availableHeight = RootGrid.ActualHeight > 0 ? RootGrid.ActualHeight : 800;
        // ContentDialog's stock width is too narrow for desktop cockpit layouts. Keep
        // this modal presentation adaptive now; W4 may host the same SourcePreview in
        // Split View or a detachable window without changing its source contract.
        var previewWidth = Math.Min(1280, Math.Max(360, availableWidth - (availableWidth >= 1000 ? 120 : 32)));
        var previewHeight = Math.Min(900, Math.Max(360, availableHeight - (availableHeight >= 720 ? 120 : 32)));

        var status = new TextBlock
        {
            Text = "Loading verified read-only source…",
            FontSize = 12,
            Opacity = .76,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true,
            Margin = new Thickness(0, 0, 0, 8)
        };
        var web = new WebView2
        {
            HorizontalAlignment = HorizontalAlignment.Stretch,
            VerticalAlignment = VerticalAlignment.Stretch
        };
        Microsoft.UI.Xaml.Automation.AutomationProperties.SetName(web, $"Read-only source preview for {subject.Title}");
        Microsoft.UI.Xaml.Automation.AutomationProperties.SetHelpText(web, "Verified source preview. Scrolling, touch zoom and text selection are available; study-state-changing controls are blocked and this view has no cockpit-state authority.");

        var content = new Grid { Width = Math.Max(320, previewWidth - 48), Height = previewHeight };
        content.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        content.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        Grid.SetRow(status, 0);
        Grid.SetRow(web, 1);
        content.Children.Add(status);
        content.Children.Add(web);

        var dialog = new ContentDialog
        {
            XamlRoot = RootGrid.XamlRoot,
            Title = $"Read-only source preview · {subject.Title}",
            Content = content,
            PrimaryButtonText = "Go to cockpit",
            SecondaryButtonText = "Show beside",
            CloseButtonText = "Close",
            DefaultButton = ContentDialogButton.Close,
            IsPrimaryButtonEnabled = false,
            IsSecondaryButtonEnabled = false,
            Width = previewWidth,
            MaxWidth = previewWidth,
            MaxHeight = Math.Min(availableHeight - 16, previewHeight + 150)
        };
        // Override the stock ContentDialog presenter envelope where the platform theme
        // supplies a narrow default max width. Unknown resource keys are harmless.
        dialog.Resources["ContentDialogMaxWidth"] = previewWidth;

        StudyLocationState? strictSource = null;
        string? previewHost = null;
        using var previewLifetime = new CancellationTokenSource();
        dialog.Closed += (_, _) => previewLifetime.Cancel();
        dialog.Opened += async (_, _) =>
        {
            try
            {
                var initialized = await InitializeSourcePreviewAsync(web, subject, result, status, previewLifetime.Token);
                previewHost = initialized.Host;
                strictSource = initialized.Location;
                dialog.IsPrimaryButtonEnabled = strictSource is not null;
                dialog.IsSecondaryButtonEnabled = strictSource is not null;
                if (strictSource is null && string.IsNullOrWhiteSpace(status.Text))
                    status.Text = "Pathfinder could not resolve an exact verified source for this result.";
            }
            catch (OperationCanceledException)
            {
                return;
            }
            catch (Exception ex)
            {
                status.Text = "Source preview could not be prepared: " + ex.Message;
                dialog.IsPrimaryButtonEnabled = false;
                dialog.IsSecondaryButtonEnabled = false;
            }
        };

        var response = await dialog.ShowAsync();
        previewLifetime.Cancel();
        try
        {
            if (web.CoreWebView2 is not null && !string.IsNullOrWhiteSpace(previewHost))
                web.CoreWebView2.ClearVirtualHostNameToFolderMapping(previewHost);
        }
        catch { }
        try { web.Close(); } catch { }

        if (response == ContentDialogResult.Primary && strictSource is not null)
        {
            // IMPORTANT: forward the immutable original search/source target. Do not
            // derive a new destination from preview scroll/layout state. This makes
            // Search → Go and Preview → Go resolve identically.
            await GoToUniversalSearchResultAsync(result);
        }
        else if (response == ContentDialogResult.Secondary && strictSource is not null)
        {
            // W4 reuses the same immutable Search target in a state-read-only secondary
            // cockpit tab, then hosts that tab in Split View. The primary cockpit is not
            // moved and no second interactive owner is created.
            var selectedBefore = Tabs.SelectedItem as TabViewItem;
            var sourceTab = await CreateReadOnlySourceTabForSplitAsync(subject, result);
            if (selectedBefore is not null && Tabs.TabItems.Contains(selectedBefore)) Tabs.SelectedItem = selectedBefore;
            if (sourceTab is not null) await ShowTabBesideAsync(sourceTab);
        }
    }

    private async Task<SourcePreviewInitialization> InitializeSourcePreviewAsync(
        WebView2 web,
        SubjectEntry subject,
        UniversalSearchResult result,
        TextBlock status,
        CancellationToken cancellationToken)
    {
        var target = _runtimeContent.Prepare(subject);
        var previewHost = $"p{subject.Number:D3}{PathfinderPaths.InternalHostSuffix}";
        var previewUri = new Uri($"https://{previewHost}/{Uri.EscapeDataString(Path.GetFileName(target.LocalFile))}");

        var env = await GetWebEnvironmentAsync();
        cancellationToken.ThrowIfCancellationRequested();
        await web.EnsureCoreWebView2Async(env);
        cancellationToken.ThrowIfCancellationRequested();
        web.CoreWebView2.Settings.AreDevToolsEnabled = false;
        await web.CoreWebView2.AddScriptToExecuteOnDocumentCreatedAsync(SourcePreviewReadOnlyGuardScript);
        cancellationToken.ThrowIfCancellationRequested();
        web.CoreWebView2.SetVirtualHostNameToFolderMapping(previewHost, target.Folder, CoreWebView2HostResourceAccessKind.DenyCors);
        web.CoreWebView2.NewWindowRequested += (_, e) => e.Handled = true;
        web.CoreWebView2.NavigationStarting += (_, e) =>
        {
            if (!Uri.TryCreate(e.Uri, UriKind.Absolute, out var uri)) return;
            if (uri.Scheme.Equals("about", StringComparison.OrdinalIgnoreCase)) return;
            if (!uri.Host.Equals(previewHost, StringComparison.OrdinalIgnoreCase)) e.Cancel = true;
        };

        var navigation = new TaskCompletionSource<CoreWebView2NavigationCompletedEventArgs>(TaskCreationOptions.RunContinuationsAsynchronously);
        void Completed(object? _, CoreWebView2NavigationCompletedEventArgs e) => navigation.TrySetResult(e);
        web.CoreWebView2.NavigationCompleted += Completed;
        web.CoreWebView2.Navigate(previewUri.AbsoluteUri);

        CoreWebView2NavigationCompletedEventArgs completed;
        try
        {
            completed = await navigation.Task.WaitAsync(TimeSpan.FromSeconds(15), cancellationToken);
        }
        finally
        {
            web.CoreWebView2.NavigationCompleted -= Completed;
        }
        if (!completed.IsSuccess)
        {
            status.Text = $"The verified cockpit source could not be displayed ({completed.WebErrorStatus}).";
            return new SourcePreviewInitialization(previewHost, null);
        }

        cancellationToken.ThrowIfCancellationRequested();
        await ApplyThemeToWebViewAsync(web, SelectedTheme());
        cancellationToken.ThrowIfCancellationRequested();
        await InstallSourcePreviewReadOnlyGuardAsync(web);
        cancellationToken.ThrowIfCancellationRequested();
        status.Text = "Resolving exact source against verified cockpit bytes…";

        var resolved = await ResolveSearchDestinationAsync(web, subject, result);
        cancellationToken.ThrowIfCancellationRequested();
        var source = resolved?.Found == true ? resolved.Location : null;
        if (source is null)
        {
            status.Text = "No exact source target could be resolved. The primary cockpit was not changed.";
            return new SourcePreviewInitialization(previewHost, null);
        }

        source.Purpose = "source";
        source.ResourceId = subject.ResourceId;
        source.SourceVersion = subject.ExpectedSha256.ToLowerInvariant();
        source.SchemaVersion = LocationSchemaVersion;
        source.UpdatedUtc = DateTimeOffset.UtcNow;
        status.Text = "Verified read-only source · primary cockpit remains untouched · scroll, touch zoom, select and copy are available.";
        return new SourcePreviewInitialization(previewHost, source);
    }

    private static async Task InstallSourcePreviewReadOnlyGuardAsync(WebView2 web)
    {
        if (web.CoreWebView2 is null) return;
        try { await web.CoreWebView2.ExecuteScriptAsync(SourcePreviewReadOnlyGuardScript); } catch { }
    }

    private const string SourcePreviewReadOnlyGuardScript = """
        (() => {
          try { localStorage.clear(); sessionStorage.clear(); } catch (_) {}
          if (window.__nivareqPathfinderSourcePreview) return;
          window.__nivareqPathfinderSourcePreview = true;
          const install = () => {
            document.documentElement?.setAttribute('data-pathfinder-source-preview','read-only');
            const mutating = 'button,input,textarea,select,[contenteditable="true"],[role="button"],a[href]';
            const blocked = target => {
              const el = target?.closest?.(mutating);
              if (!el) return null;
              if (el.closest('summary')) return null;
              return el;
            };
            const cancelMutation = e => {
              if (!e.isTrusted || !blocked(e.target)) return;
              e.preventDefault();
              e.stopImmediatePropagation();
            };
            const cancelActivation = e => {
              if (!e.isTrusted || e.target?.closest?.('summary')) return;
              e.preventDefault();
              e.stopImmediatePropagation();
            };
            for (const type of ['click','dblclick']) document.addEventListener(type, cancelActivation, true);
            for (const type of ['beforeinput','input','change','submit']) document.addEventListener(type, cancelMutation, true);
            document.addEventListener('keydown', e => {
              if (!e.isTrusted || !blocked(e.target)) return;
              if (e.key.length === 1 || e.key === 'Enter' || e.key === ' ' || e.key === 'Backspace' || e.key === 'Delete') {
                e.preventDefault();
                e.stopImmediatePropagation();
              }
            }, true);
            document.querySelectorAll(mutating).forEach(el => el.setAttribute('aria-disabled','true'));
            try { window.open = () => null; } catch (_) {}
          };
          if (document.documentElement) install(); else addEventListener('DOMContentLoaded', install, {once:true});
        })();
        """;

    private static async Task ClearCockpitSearchFilterAsync(StudyTabContext context)
    {
        if (context.WebView.CoreWebView2 is null) return;
        const string script = """
            (() => {
              const input=document.querySelector('input#search,input[type="search"],input[aria-label*="search" i],input[placeholder*="search" i],input[placeholder*="find" i]');
              if(!input || !input.value) return;
              input.value='';
              input.dispatchEvent(new Event('input',{bubbles:true}));
              input.dispatchEvent(new Event('change',{bubbles:true}));
            })();
            """;
        try
        {
            await context.WebView.CoreWebView2.ExecuteScriptAsync(script);
            await Task.Delay(100);
        }
        catch { }
    }

    private void ArmSourceJumpReturn(StudyTabContext context, StudyLocationState location, TemporaryCockpitViewState? view)
    {
        context.SourceJumpReturnLocation = CloneLocationV2(location);
        context.SourceJumpReturnView = view;
        context.SourceReturnBar.Title = "Source jump";
        context.SourceReturnBar.Message = $"{context.Subject.Title} moved to a source. Your previous study position is saved for this one-level return.";
        context.SourceReturnBar.Visibility = Visibility.Visible;
        context.SourceReturnBar.IsOpen = true;
    }

    private void ClearSourceJumpReturn(StudyTabContext context)
    {
        context.SourceJumpReturnLocation = null;
        context.SourceJumpReturnView = null;
        if (context.ViewRole == CockpitViewRole.ReadOnlySecondary)
        {
            context.SourceReturnBar.Title = "Read-only reference view";
            context.SourceReturnBar.Message = "This secondary cockpit can scroll, zoom, select and copy, but it does not save study progress. The primary cockpit is the view that saves progress.";
            context.SourceReturnBar.ActionButton = null;
            context.SourceReturnBar.IsClosable = false;
            context.SourceReturnBar.Visibility = Visibility.Visible;
            context.SourceReturnBar.IsOpen = true;
            return;
        }
        context.SourceReturnBar.IsOpen = false;
        context.SourceReturnBar.Visibility = Visibility.Collapsed;
    }

    private async Task ReturnToPreviousStudyPositionAsync(StudyTabContext context)
    {
        var location = context.SourceJumpReturnLocation;
        if (location is null) return;
        var view = context.SourceJumpReturnView;
        context.SourceReturnBar.IsOpen = false;
        context.SourceReturnBar.Visibility = Visibility.Collapsed;

        await RestoreTemporaryCockpitViewAsync(context, view);
        await Task.Delay(140);
        var request = BeginLocationRequest(context, "return-to-previous-study-position");
        var restored = await ApplyPathfinderLocationAsync(context, location, request, persistResume: true);
        if (restored)
        {
            ClearSourceJumpReturn(context);
            return;
        }

        context.SourceReturnBar.Title = "Return could not be completed";
        context.SourceReturnBar.Message = "The previous source identity could not be restored exactly. Pathfinder left the current cockpit in place.";
        context.SourceReturnBar.Visibility = Visibility.Visible;
        context.SourceReturnBar.IsOpen = true;
    }

    private sealed record SourcePreviewInitialization(string Host, StudyLocationState? Location);
}
