using System.Text.Json;
using NivareQ.Step2Pathfinder.Models;

namespace NivareQ.Step2Pathfinder.Services;

public sealed class BackupExtensionStore
{
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true, PropertyNameCaseInsensitive = true };

    public PreservedBackupExtensionState State { get; private set; } = new();

    public void Load()
    {
        RestoreTransactionService.EnsureInterruptedRestoreRecovered();
        if (!File.Exists(PathfinderPaths.BackupExtensionsPath))
        {
            State = new();
            return;
        }

        try
        {
            var parsed = JsonSerializer.Deserialize<PreservedBackupExtensionState>(ReadBoundedStoreText(PathfinderPaths.BackupExtensionsPath), JsonOptions) ?? new();
            if (parsed.SchemaVersion > 1) throw new UnsupportedLocalSchemaException($"Preserved-extension store schema {parsed.SchemaVersion} is newer than supported schema 1.");
            if (parsed.SchemaVersion != 1) throw new InvalidDataException("Unsupported preserved-extension store schema.");
            parsed.Values ??= [];
            State = Clone(parsed);
        }
        catch (UnsupportedLocalSchemaException ex)
        {
            RestoreTransactionService.BlockMutationTarget(PathfinderPaths.BackupExtensionsPath, ex.Message);
            State = new();
            PersistenceHealth.Report("Backup extensions compatibility", ex.Message + " The preserved-extension file was kept in place and this build will not overwrite it.");
        }
        catch (Exception ex)
        {
            var quarantined = AtomicFileStore.Quarantine(PathfinderPaths.BackupExtensionsPath, "corrupt");
            var lastGood = AtomicFileStore.LastGoodPath(PathfinderPaths.BackupExtensionsPath);
            if (File.Exists(lastGood))
            {
                try
                {
                    var recovered = JsonSerializer.Deserialize<PreservedBackupExtensionState>(ReadBoundedStoreText(lastGood), JsonOptions) ?? new();
                    if (recovered.SchemaVersion != 1) throw new InvalidDataException("Unsupported preserved-extension store schema.");
                    recovered.Values ??= [];
                    State = Clone(recovered);
                    PersistenceHealth.Report("Backup extensions", $"Preserved cross-platform backup extensions could not be read and were preserved{(quarantined is null ? "" : $" at {quarantined}")}. Pathfinder loaded the last-known-good extension copy instead. {ex.Message}");
                    return;
                }
                catch (Exception lastGoodEx)
                {
                    PersistenceHealth.Report("Backup extensions", $"The preserved-extension store and its last-known-good copy were unreadable. The corrupt current file was preserved{(quarantined is null ? "" : $" at {quarantined}")}; no opaque extension state will be changed unless a backup restore explicitly supplies it. {lastGoodEx.Message}");
                }
            }
            else
            {
                PersistenceHealth.Report("Backup extensions", $"Preserved cross-platform backup extensions could not be read and were preserved{(quarantined is null ? "" : $" at {quarantined}")}. {ex.Message}");
            }
            State = new();
        }
    }

    private static string ReadBoundedStoreText(string path)
    {
        var info = new FileInfo(path);
        if (info.Length > BackupContractService.MaxBackupBytes)
            throw new InvalidDataException("Preserved-extension store exceeds the bounded 100 MB safety limit.");
        return File.ReadAllText(path);
    }

    public PersistenceWriteResult Save()
    {
        var allowed = RestoreTransactionService.RequireMutationAllowed(PathfinderPaths.BackupExtensionsPath);
        if (!allowed.Success) return allowed;
        State.UpdatedUtc = DateTimeOffset.UtcNow;
        var result = AtomicFileStore.WriteText(PathfinderPaths.BackupExtensionsPath, JsonSerializer.Serialize(State, JsonOptions));
        if (!result.Success) PersistenceHealth.Report("Backup extensions", "Could not durably save preserved backup extensions: " + result.Error);
        return result;
    }

    public void ReplaceInMemory(PreservedBackupExtensionState state)
    {
        State = Clone(state ?? new());
    }

    public string Serialize(PreservedBackupExtensionState state) => JsonSerializer.Serialize(Clone(state), JsonOptions);

    public PreservedBackupExtensionState MergeLegacy(PreservedBackupExtensionState imported)
    {
        var merged = Clone(State);
        merged.SchemaVersion = 1;
        merged.LastImportedFrom = imported.LastImportedFrom;
        merged.UpdatedUtc = DateTimeOffset.UtcNow;
        foreach (var pair in imported.Values ?? []) merged.Values[pair.Key] = pair.Value.Clone();
        return merged;
    }

    public static PreservedBackupExtensionState Clone(PreservedBackupExtensionState source)
    {
        var clone = new PreservedBackupExtensionState
        {
            SchemaVersion = source.SchemaVersion,
            LastImportedFrom = source.LastImportedFrom,
            UpdatedUtc = source.UpdatedUtc,
            Values = []
        };
        foreach (var pair in source.Values ?? []) clone.Values[pair.Key] = pair.Value.Clone();
        return clone;
    }
}
