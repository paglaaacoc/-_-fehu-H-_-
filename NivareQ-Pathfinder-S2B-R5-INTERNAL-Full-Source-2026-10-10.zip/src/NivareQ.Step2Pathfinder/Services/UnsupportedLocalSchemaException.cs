namespace NivareQ.Step2Pathfinder.Services;

/// <summary>
/// Signals a syntactically readable local state store that declares a schema newer than this
/// Pathfinder build understands. This is compatibility refusal, not corruption: callers must
/// preserve the original bytes in place and must not overwrite the affected store.
/// </summary>
public sealed class UnsupportedLocalSchemaException : Exception
{
    public UnsupportedLocalSchemaException(string message) : base(message) { }
}
