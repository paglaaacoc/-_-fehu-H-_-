using System.Text;

namespace NivareQ.Step2Pathfinder.Services;

public static class AtomicFileStore
{
    private static readonly UTF8Encoding Utf8NoBom = new(false);

    public static PersistenceWriteResult WriteText(string path, string content, bool keepLastGood = true)
    {
        var tempPath = path + ".tmp-" + Guid.NewGuid().ToString("N");
        try
        {
            var directory = Path.GetDirectoryName(path);
            if (!string.IsNullOrWhiteSpace(directory)) Directory.CreateDirectory(directory);

            var bytes = Utf8NoBom.GetBytes(content);
            using (var stream = new FileStream(tempPath, FileMode.CreateNew, FileAccess.Write, FileShare.None, 64 * 1024, FileOptions.WriteThrough))
            {
                stream.Write(bytes, 0, bytes.Length);
                stream.Flush(flushToDisk: true);
            }

            if (File.Exists(path))
            {
                if (keepLastGood)
                {
                    var backupPath = LastGoodPath(path);
                    if (File.Exists(backupPath)) File.Delete(backupPath);
                    File.Replace(tempPath, path, backupPath, ignoreMetadataErrors: true);
                }
                else
                {
                    File.Move(tempPath, path, overwrite: true);
                }
            }
            else
            {
                File.Move(tempPath, path);
            }

            return PersistenceWriteResult.Ok(path);
        }
        catch (Exception ex)
        {
            try { if (File.Exists(tempPath)) File.Delete(tempPath); } catch { }
            return PersistenceWriteResult.Fail(path, ex);
        }
    }

    public static string LastGoodPath(string path) => path + ".lastgood";

    public static bool TryReadText(string path, out string text, out string error)
    {
        try
        {
            text = File.ReadAllText(path, Utf8NoBom);
            error = "";
            return true;
        }
        catch (Exception ex)
        {
            text = "";
            error = ex.Message;
            return false;
        }
    }

    public static string? Quarantine(string path, string label)
    {
        try
        {
            if (!File.Exists(path)) return null;
            Directory.CreateDirectory(PathfinderPaths.CorruptRecoveryRoot);
            var safeName = Path.GetFileName(path);
            var stamp = DateTimeOffset.UtcNow.ToString("yyyyMMdd-HHmmssfff");
            var destination = Path.Combine(PathfinderPaths.CorruptRecoveryRoot, $"{safeName}.{label}.{stamp}.{Guid.NewGuid():N}.preserved");
            File.Move(path, destination);
            return destination;
        }
        catch (Exception ex)
        {
            PersistenceHealth.Report("Recovery", $"Could not quarantine {Path.GetFileName(path)}: {ex.Message}");
            return null;
        }
    }
}
