using System.Text.Json;
using NivareQ.Step2Pathfinder.Models;

namespace NivareQ.Step2Pathfinder.Services;

public sealed class PersonalStudyService
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true
    };

    public PersonalStudyState State { get; private set; } = new();
    public PersistenceWriteResult LastSaveResult { get; private set; } = PersistenceWriteResult.Ok(PathfinderPaths.PersonalStudyPath);

    public void Load()
    {
        RestoreTransactionService.EnsureInterruptedRestoreRecovered();
        Directory.CreateDirectory(PathfinderPaths.AppDataRoot);
        if (!File.Exists(PathfinderPaths.PersonalStudyPath))
        {
            State = Normalize(new());
            return;
        }

        try
        {
            State = Deserialize(File.ReadAllText(PathfinderPaths.PersonalStudyPath));
        }
        catch (UnsupportedLocalSchemaException ex)
        {
            RestoreTransactionService.BlockMutationTarget(PathfinderPaths.PersonalStudyPath, ex.Message);
            State = Normalize(new());
            PersistenceHealth.Report("My Study compatibility", ex.Message + " personal-study.json was preserved in place and this build will not overwrite it.");
        }
        catch (Exception ex)
        {
            var preserved = AtomicFileStore.Quarantine(PathfinderPaths.PersonalStudyPath, "corrupt");
            var lastGood = AtomicFileStore.LastGoodPath(PathfinderPaths.PersonalStudyPath);
            if (File.Exists(lastGood))
            {
                try
                {
                    State = Deserialize(File.ReadAllText(lastGood));
                    PersistenceHealth.Report("My Study recovery", $"personal-study.json could not be read and was preserved{(preserved is null ? "" : $" at {preserved}")}. Pathfinder loaded the last-known-good My Study copy instead. {ex.Message}");
                    return;
                }
                catch (Exception lastGoodEx)
                {
                    PersistenceHealth.Report("My Study recovery", $"personal-study.json and its last-known-good copy were unreadable. The corrupt current file was preserved{(preserved is null ? "" : $" at {preserved}")}; an empty safe My Study state is active. {lastGoodEx.Message}");
                }
            }
            else
            {
                PersistenceHealth.Report("My Study recovery", $"personal-study.json could not be read and was preserved{(preserved is null ? "" : $" at {preserved}")}. An empty safe My Study state is active. {ex.Message}");
            }
            State = Normalize(new());
        }
    }

    public PersistenceWriteResult Save()
    {
        var allowed = RestoreTransactionService.RequireMutationAllowed(PathfinderPaths.PersonalStudyPath);
        if (!allowed.Success) return LastSaveResult = allowed;
        LastSaveResult = AtomicFileStore.WriteText(PathfinderPaths.PersonalStudyPath, Serialize(State));
        if (!LastSaveResult.Success) PersistenceHealth.Report("My Study save", "Windows could not durably save My Study data: " + LastSaveResult.Error);
        return LastSaveResult;
    }

    public PersistenceWriteResult Replace(PersonalStudyState state)
    {
        var allowed = RestoreTransactionService.RequireMutationAllowed(PathfinderPaths.PersonalStudyPath);
        if (!allowed.Success) return LastSaveResult = allowed;
        State = Normalize(state ?? new());
        return Save();
    }

    public void ReplaceInMemory(PersonalStudyState state)
    {
        State = Normalize(state ?? new());
    }

    public bool IsFavorite(string slug) => State.FavoriteSlugs.Contains(slug);

    public void SetFavorite(string slug, bool favorite)
    {
        if (!RestoreTransactionService.RequireMutationAllowed(PathfinderPaths.PersonalStudyPath).Success) return;
        if (favorite) State.FavoriteSlugs.Add(slug);
        else State.FavoriteSlugs.Remove(slug);
    }

    public void TouchRecent(string slug)
    {
        if (!RestoreTransactionService.RequireMutationAllowed(PathfinderPaths.PersonalStudyPath).Success) return;
        State.RecentSubjects.RemoveAll(x => x.Slug.Equals(slug, StringComparison.OrdinalIgnoreCase));
        State.RecentSubjects.Insert(0, new RecentStudyItem { Slug = slug, LastOpenedUtc = DateTimeOffset.UtcNow });
        if (State.RecentSubjects.Count > 12)
            State.RecentSubjects.RemoveRange(12, State.RecentSubjects.Count - 12);
    }

    public string ProgressFor(string slug)
        => State.ProgressBySlug.TryGetValue(slug, out var value) && !string.IsNullOrWhiteSpace(value) ? value : "Not started";

    public void SetProgress(string slug, string value)
    {
        if (!RestoreTransactionService.RequireMutationAllowed(PathfinderPaths.PersonalStudyPath).Success) return;
        if (string.Equals(value, "Not started", StringComparison.OrdinalIgnoreCase)) State.ProgressBySlug.Remove(slug);
        else State.ProgressBySlug[slug] = value;
    }

    public StudyLocationState? PositionFor(string slug)
        => State.PositionsBySlug.TryGetValue(slug, out var position) ? CloneLocation(position) : null;

    public void SetPosition(string slug, StudyLocationState position)
    {
        if (!RestoreTransactionService.RequireMutationAllowed(PathfinderPaths.PersonalStudyPath).Success) return;
        State.PositionsBySlug[slug] = CloneLocation(position);
    }

    public string NoteFor(string slug)
        => State.SubjectNotes.TryGetValue(slug, out var note) ? note : "";

    public void SetNote(string slug, string note)
    {
        if (!RestoreTransactionService.RequireMutationAllowed(PathfinderPaths.PersonalStudyPath).Success) return;
        note = (note ?? "").Trim();
        if (note.Length == 0) State.SubjectNotes.Remove(slug);
        else State.SubjectNotes[slug] = note;
    }

    public static string Serialize(PersonalStudyState state)
        => JsonSerializer.Serialize(Normalize(Clone(state)), JsonOptions);

    public static PersonalStudyState Deserialize(string json)
    {
        var parsed = JsonSerializer.Deserialize<PersonalStudyState>(json, JsonOptions) ?? new();
        if (parsed.SchemaVersion > 1)
            throw new UnsupportedLocalSchemaException($"My Study schema {parsed.SchemaVersion} is newer than supported schema 1.");
        return Normalize(parsed);
    }

    public static string SerializeBackup(PathfinderBackupEnvelope backup)
        => JsonSerializer.Serialize(backup, JsonOptions);

    public static PathfinderBackupEnvelope? DeserializeBackup(string json)
        => JsonSerializer.Deserialize<PathfinderBackupEnvelope>(json, JsonOptions);

    private static PersonalStudyState Normalize(PersonalStudyState state)
    {
        state.SchemaVersion = Math.Max(1, state.SchemaVersion);
        state.FavoriteSlugs = new HashSet<string>((state.FavoriteSlugs ?? []).Where(x => !string.IsNullOrWhiteSpace(x)), StringComparer.OrdinalIgnoreCase);
        state.RecentSubjects = (state.RecentSubjects ?? [])
            .Where(x => x is not null && !string.IsNullOrWhiteSpace(x.Slug))
            .GroupBy(x => x.Slug, StringComparer.OrdinalIgnoreCase)
            .Select(g => g.OrderByDescending(x => x.LastOpenedUtc).First())
            .OrderByDescending(x => x.LastOpenedUtc)
            .Take(12)
            .ToList();
        state.ProgressBySlug = new Dictionary<string, string>(state.ProgressBySlug ?? new Dictionary<string, string>(), StringComparer.OrdinalIgnoreCase);
        state.PositionsBySlug = new Dictionary<string, StudyLocationState>(state.PositionsBySlug ?? new Dictionary<string, StudyLocationState>(), StringComparer.OrdinalIgnoreCase);
        state.SubjectNotes = new Dictionary<string, string>(state.SubjectNotes ?? new Dictionary<string, string>(), StringComparer.OrdinalIgnoreCase);
        state.Bookmarks = (state.Bookmarks ?? [])
            .Where(x => x is not null && !string.IsNullOrWhiteSpace(x.Slug))
            .OrderByDescending(x => x.CreatedUtc)
            .ToList();
        return state;
    }

    private static PersonalStudyState Clone(PersonalStudyState source)
    {
        var json = JsonSerializer.Serialize(source, JsonOptions);
        return JsonSerializer.Deserialize<PersonalStudyState>(json, JsonOptions) ?? new();
    }

    private static StudyLocationState CloneLocation(StudyLocationState source) => new()
    {
        SchemaVersion = source.SchemaVersion <= 0 ? PathfinderLocation.CurrentSchemaVersion : source.SchemaVersion,
        ResourceId = source.ResourceId ?? "",
        SourceVersion = source.SourceVersion ?? "",
        Purpose = string.IsNullOrWhiteSpace(source.Purpose) ? "resume" : source.Purpose,
        Anchor = source.Anchor ?? "",
        TargetId = source.TargetId ?? "",
        TargetPath = source.TargetPath ?? "",
        Context = source.Context ?? "",
        OffsetY = source.OffsetY,
        TargetOffsetY = source.TargetOffsetY,
        Hash = source.Hash ?? "",
        ScrollX = source.ScrollX,
        ScrollY = source.ScrollY,
        OpenDetails = (source.OpenDetails ?? []).Take(30).ToList(),
        UpdatedUtc = source.UpdatedUtc
    };
}
