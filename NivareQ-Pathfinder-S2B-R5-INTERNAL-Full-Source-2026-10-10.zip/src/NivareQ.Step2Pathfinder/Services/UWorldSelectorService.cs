using System.Security.Cryptography;
using System.Text.Json;
using NivareQ.Step2Pathfinder.Models;

namespace NivareQ.Step2Pathfinder.Services;

public sealed class UWorldSelectorService
{
    public const int SchemaVersion = 1;
    public const int RecipeVersion = 1;
    public const int MaxUnusedCount = 100000;
    public const string ResourceId = "extra-uworld-selector";
    public const string StateKey = "uwsel_state_v1";
    public const int ExpectedRecipeCount = 26;

    private static readonly string[] StableRecipeIds =
    [
        "r01", "r02", "r03", "r04", "r05", "r06", "r07", "r08", "r09",
        "r10a", "r10b", "r11a", "r11b", "r12a", "r12b", "r13", "r14", "r15", "r16", "r17",
        "r18", "r19", "r20", "r21", "residual-six", "final-audit"
    ];

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true
    };

    public UWorldSelectorRecipeCatalog Catalog { get; private set; } = new();
    public UWorldSelectorState State { get; private set; } = NewState();
    public string SourceVersion { get; private set; } = "";
    public IReadOnlyList<UWorldSelectorRecipe> Recipes => Catalog.Recipes;
    public IReadOnlyCollection<string> RecipeIds => Catalog.Recipes.Select(x => x.Id).ToArray();

    public void Load()
    {
        LoadCatalog();
        State = LoadStateWithRecovery();
    }

    public UWorldSelectorRecipe? Recipe(string id)
        => Catalog.Recipes.FirstOrDefault(x => x.Id.Equals(id, StringComparison.OrdinalIgnoreCase));

    public UWorldSelectorReport? Report(string id)
        => State.Reports.TryGetValue(id, out var report) ? CloneReport(report) : null;

    public PersistenceWriteResult Record(string id, int unused)
    {
        var allowed = RestoreTransactionService.RequireMutationAllowed(PathfinderPaths.UWorldSelectorStatePath);
        if (!allowed.Success) return allowed;
        RequireRecipe(id);
        if (unused < 0 || unused > MaxUnusedCount) return PersistenceWriteResult.Fail(PathfinderPaths.UWorldSelectorStatePath, new InvalidDataException($"Unused count must be between 0 and {MaxUnusedCount:N0}."));
        State.Reports[id] = new UWorldSelectorReport { Unused = unused, ReportedUtc = DateTimeOffset.UtcNow };
        State.UpdatedUtc = DateTimeOffset.UtcNow;
        return Save();
    }

    public PersistenceWriteResult Clear(string id)
    {
        var allowed = RestoreTransactionService.RequireMutationAllowed(PathfinderPaths.UWorldSelectorStatePath);
        if (!allowed.Success) return allowed;
        RequireRecipe(id);
        State.Reports.Remove(id);
        State.UpdatedUtc = DateTimeOffset.UtcNow;
        return Save();
    }

    public PersistenceWriteResult ClearAll()
    {
        var allowed = RestoreTransactionService.RequireMutationAllowed(PathfinderPaths.UWorldSelectorStatePath);
        if (!allowed.Success) return allowed;
        State = NewState();
        return Save();
    }

    public PersistenceWriteResult Save()
    {
        var allowed = RestoreTransactionService.RequireMutationAllowed(PathfinderPaths.UWorldSelectorStatePath);
        if (!allowed.Success) return allowed;
        return AtomicFileStore.WriteText(PathfinderPaths.UWorldSelectorStatePath, SerializeState(State));
    }

    public UWorldSelectorState ExportState() => CloneState(State);

    public void ReplaceInMemory(UWorldSelectorState state)
        => State = ValidateAndClone(state, "UWorld Selector state");

    public string SerializeState(UWorldSelectorState state)
        => JsonSerializer.Serialize(ValidateAndClone(state, "UWorld Selector state"), JsonOptions);

    public UWorldSelectorState DeserializeState(string json, string label = "UWorld Selector state")
    {
        var state = JsonSerializer.Deserialize<UWorldSelectorState>(json, JsonOptions)
                    ?? throw new InvalidDataException(label + " is empty.");
        return ValidateAndClone(state, label);
    }

    public UWorldSelectorState ValidateAndClone(UWorldSelectorState state, string label)
    {
        if (state.SchemaVersion > SchemaVersion || state.RecipeVersion > RecipeVersion)
            throw new UnsupportedLocalSchemaException(label + $" declares newer schema/recipe versions ({state.SchemaVersion}/{state.RecipeVersion}) than this build supports ({SchemaVersion}/{RecipeVersion}).");
        if (state.SchemaVersion != SchemaVersion || state.RecipeVersion != RecipeVersion)
            throw new InvalidDataException(label + " has an unsupported schema or recipe version.");
        if (state.Reports.Count > ExpectedRecipeCount)
            throw new InvalidDataException(label + " has too many reports.");

        var output = NewState();
        output.UpdatedUtc = state.UpdatedUtc == default ? DateTimeOffset.UtcNow : state.UpdatedUtc;
        foreach (var pair in state.Reports)
        {
            RequireRecipe(pair.Key);
            if (pair.Value is null) throw new InvalidDataException(label + $" report '{pair.Key}' is missing.");
            if (pair.Value.Unused < 0 || pair.Value.Unused > MaxUnusedCount)
                throw new InvalidDataException(label + $" report '{pair.Key}' has an invalid unused count.");
            if (pair.Value.ReportedUtc == default)
                throw new InvalidDataException(label + $" report '{pair.Key}' has an invalid timestamp.");
            output.Reports[pair.Key] = CloneReport(pair.Value);
        }
        return output;
    }

    public IReadOnlyList<UWorldSelectorRecipe> Search(string query, string status)
    {
        var q = SearchNormalization.Normalize(query);
        var normalizedStatus = status.Trim().ToLowerInvariant();
        return Catalog.Recipes.Where(recipe =>
        {
            var report = State.Reports.GetValueOrDefault(recipe.Id);
            var state = report is null ? "unknown" : report.Unused == 0 ? "zero" : "remaining";
            if (normalizedStatus.Length > 0 && !state.Equals(normalizedStatus, StringComparison.Ordinal)) return false;
            if (q.Length == 0) return true;
            var searchAlias = recipe.Id switch
            {
                "final-audit" => "All Subjects All Systems final audit",
                "residual-six" => "Residual six system sweep verification",
                _ => ""
            };
            var blob = SearchNormalization.Normalize(string.Join(" ", new[]
            {
                recipe.Label, recipe.Title, recipe.Slug, string.Join(" ", recipe.Subjects), string.Join(" ", recipe.Systems), recipe.How, recipe.Group, searchAlias
            }));
            return blob.Contains(q, StringComparison.OrdinalIgnoreCase);
        }).ToList();
    }

    public static UWorldSelectorState CloneState(UWorldSelectorState state)
    {
        var clone = new UWorldSelectorState
        {
            SchemaVersion = state.SchemaVersion,
            RecipeVersion = state.RecipeVersion,
            UpdatedUtc = state.UpdatedUtc,
            Reports = new Dictionary<string, UWorldSelectorReport>(StringComparer.OrdinalIgnoreCase)
        };
        foreach (var pair in state.Reports) clone.Reports[pair.Key] = CloneReport(pair.Value);
        return clone;
    }

    public static UWorldSelectorState NewState() => new()
    {
        SchemaVersion = SchemaVersion,
        RecipeVersion = RecipeVersion,
        UpdatedUtc = DateTimeOffset.UtcNow,
        Reports = new Dictionary<string, UWorldSelectorReport>(StringComparer.OrdinalIgnoreCase)
    };

    private void LoadCatalog()
    {
        if (!File.Exists(PathfinderPaths.UWorldSelectorRecipes))
            throw new FileNotFoundException("UWorld Selector recipe catalog not found.", PathfinderPaths.UWorldSelectorRecipes);
        var bytes = File.ReadAllBytes(PathfinderPaths.UWorldSelectorRecipes);
        SourceVersion = Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
        var parsed = JsonSerializer.Deserialize<UWorldSelectorRecipeCatalog>(bytes, JsonOptions)
                     ?? throw new InvalidDataException("UWorld Selector recipe catalog is empty.");
        if (parsed.SchemaVersion != SchemaVersion || parsed.RecipeVersion != RecipeVersion || !parsed.ResourceId.Equals(ResourceId, StringComparison.Ordinal))
            throw new InvalidDataException("Unsupported UWorld Selector recipe catalog.");
        if (parsed.Recipes.Count != ExpectedRecipeCount)
            throw new InvalidDataException($"UWorld Selector must contain exactly {ExpectedRecipeCount} accepted recipes.");
        var expected = StableRecipeIds.ToHashSet(StringComparer.OrdinalIgnoreCase);
        var actual = parsed.Recipes.Select(x => x.Id).ToHashSet(StringComparer.OrdinalIgnoreCase);
        if (!expected.SetEquals(actual) || parsed.Recipes.Any(x => string.IsNullOrWhiteSpace(x.Id) || string.IsNullOrWhiteSpace(x.Title)))
            throw new InvalidDataException("UWorld Selector recipe identity does not match the accepted B4A contract.");
        if (parsed.AllSystems.Count != 22 || parsed.AllSystems.Distinct(StringComparer.OrdinalIgnoreCase).Count() != 22)
            throw new InvalidDataException("UWorld Selector all-systems reference must contain exactly 22 unique systems.");
        Catalog = parsed;
    }

    private UWorldSelectorState LoadStateWithRecovery()
    {
        if (!File.Exists(PathfinderPaths.UWorldSelectorStatePath)) return NewState();
        try
        {
            return DeserializeState(File.ReadAllText(PathfinderPaths.UWorldSelectorStatePath));
        }
        catch (UnsupportedLocalSchemaException ex)
        {
            RestoreTransactionService.BlockMutationTarget(PathfinderPaths.UWorldSelectorStatePath, ex.Message);
            PersistenceHealth.Report("UWorld Selector compatibility", ex.Message + " The Selector state file was preserved in place and this build will not overwrite it.");
            return NewState();
        }
        catch (Exception ex)
        {
            var lastGood = AtomicFileStore.LastGoodPath(PathfinderPaths.UWorldSelectorStatePath);
            try
            {
                if (File.Exists(lastGood))
                {
                    var recovered = DeserializeState(File.ReadAllText(lastGood), "UWorld Selector last-good state");
                    PersistenceHealth.Report("UWorld Selector recovery", "The primary Selector state was invalid; Pathfinder loaded the last-good copy. " + ex.Message);
                    return recovered;
                }
            }
            catch { }
            AtomicFileStore.Quarantine(PathfinderPaths.UWorldSelectorStatePath, "invalid-selector");
            PersistenceHealth.Report("UWorld Selector recovery", "Selector progress could not be validated and was preserved for recovery; the live Selector starts with Unknown reports. " + ex.Message);
            return NewState();
        }
    }

    private void RequireRecipe(string id)
    {
        if (Recipe(id) is null) throw new InvalidDataException($"Unknown UWorld Selector recipe '{id}'.");
    }

    private static UWorldSelectorReport CloneReport(UWorldSelectorReport report)
        => new() { Unused = report.Unused, ReportedUtc = report.ReportedUtc };
}
