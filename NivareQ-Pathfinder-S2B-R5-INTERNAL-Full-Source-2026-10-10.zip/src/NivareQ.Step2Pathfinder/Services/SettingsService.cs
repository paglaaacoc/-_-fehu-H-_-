using System.Text.Json;

namespace NivareQ.Step2Pathfinder.Services;

public sealed class SessionTabState
{
    public string Kind { get; set; } = "study";
    public string Id { get; set; } = "";
    public bool IsPinned { get; set; }
    public bool HasLocation { get; set; }
    public string Hash { get; set; } = "";
    public double ScrollX { get; set; }
    public double ScrollY { get; set; }
}

public sealed class ShellSettings
{
    public string ThemeId { get; set; } = "light";
    public bool RestoreLastSession { get; set; } = true;
    public bool StrongFocusIndicators { get; set; }
    public bool ReduceMotion { get; set; }
    public bool ComfortableReadingSpacing { get; set; }
    public List<SessionTabState> LastSessionTabs { get; set; } = [];
    public int LastSelectedTabIndex { get; set; }
    public bool RestoreSplitWorkspace { get; set; } = true;
    public bool LastWorkspaceSplitEnabled { get; set; }
    public string LastWorkspaceSecondaryKind { get; set; } = "";
    public string LastWorkspaceSecondaryId { get; set; } = "";
    public double LastWorkspaceSplitRatio { get; set; } = 0.5;
}

public static class SettingsService
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true
    };

    public static ShellSettings Load()
    {
        RestoreTransactionService.EnsureInterruptedRestoreRecovered();
        Directory.CreateDirectory(PathfinderPaths.AppDataRoot);
        if (!File.Exists(PathfinderPaths.SettingsPath)) return new();

        try
        {
            return Deserialize(File.ReadAllText(PathfinderPaths.SettingsPath));
        }
        catch (Exception ex)
        {
            var preserved = AtomicFileStore.Quarantine(PathfinderPaths.SettingsPath, "corrupt");
            var lastGood = AtomicFileStore.LastGoodPath(PathfinderPaths.SettingsPath);
            if (File.Exists(lastGood))
            {
                try
                {
                    var recovered = Deserialize(File.ReadAllText(lastGood));
                    PersistenceHealth.Report("Settings recovery", $"settings.json could not be read and was preserved{(preserved is null ? "" : $" at {preserved}")}. Pathfinder loaded the last-known-good settings copy instead. {ex.Message}");
                    return recovered;
                }
                catch (Exception lastGoodEx)
                {
                    PersistenceHealth.Report("Settings recovery", $"settings.json and its last-known-good copy were unreadable. The corrupt current file was preserved{(preserved is null ? "" : $" at {preserved}")}; safe defaults are active. {lastGoodEx.Message}");
                    return new();
                }
            }

            PersistenceHealth.Report("Settings recovery", $"settings.json could not be read and was preserved{(preserved is null ? "" : $" at {preserved}")}. Safe defaults are active. {ex.Message}");
            return new();
        }
    }

    public static PersistenceWriteResult Save(ShellSettings settings)
    {
        var allowed = RestoreTransactionService.RequireMutationAllowed(PathfinderPaths.SettingsPath);
        if (!allowed.Success) return allowed;
        var result = AtomicFileStore.WriteText(PathfinderPaths.SettingsPath, Serialize(settings));
        if (!result.Success) PersistenceHealth.Report("Settings save", "Windows could not durably save Pathfinder settings: " + result.Error);
        return result;
    }

    public static string Serialize(ShellSettings settings)
        => JsonSerializer.Serialize(Normalize(settings), JsonOptions);

    public static ShellSettings Deserialize(string json)
        => Normalize(JsonSerializer.Deserialize<ShellSettings>(json, JsonOptions) ?? new());

    private static ShellSettings Normalize(ShellSettings settings)
    {
        settings.ThemeId = string.IsNullOrWhiteSpace(settings.ThemeId) ? "light" : settings.ThemeId;
        settings.LastSessionTabs ??= [];
        settings.LastSessionTabs = settings.LastSessionTabs
            .Where(x => x is not null && !string.IsNullOrWhiteSpace(x.Kind) && !string.IsNullOrWhiteSpace(x.Id))
            .ToList();
        if (settings.LastSelectedTabIndex < 0) settings.LastSelectedTabIndex = 0;
        if (settings.LastSelectedTabIndex > settings.LastSessionTabs.Count) settings.LastSelectedTabIndex = settings.LastSessionTabs.Count;
        settings.LastWorkspaceSecondaryKind ??= "";
        settings.LastWorkspaceSecondaryId ??= "";
        if (!double.IsFinite(settings.LastWorkspaceSplitRatio)) settings.LastWorkspaceSplitRatio = 0.5;
        settings.LastWorkspaceSplitRatio = Math.Clamp(settings.LastWorkspaceSplitRatio, 0.28, 0.72);
        return settings;
    }
}
