using System.Text.Json;
using NivareQ.Step2Pathfinder.Models;

namespace NivareQ.Step2Pathfinder.Services;

public sealed class ContentCatalogService
{
    private readonly Dictionary<string, SubjectEntry> _byAlias = new(StringComparer.OrdinalIgnoreCase);

    public List<SubjectEntry> Entries { get; } = [];

    public SubjectEntry? Resolve(string resourceIdOrAlias)
        => string.IsNullOrWhiteSpace(resourceIdOrAlias) ? null : _byAlias.GetValueOrDefault(resourceIdOrAlias.Trim());

    public void Load()
    {
        Entries.Clear();
        _byAlias.Clear();
        if (!File.Exists(PathfinderPaths.ResourceRegistry))
            throw new FileNotFoundException("Pathfinder resource registry not found.", PathfinderPaths.ResourceRegistry);

        using var doc = JsonDocument.Parse(File.ReadAllText(PathfinderPaths.ResourceRegistry));
        var root = doc.RootElement;
        if (!root.TryGetProperty("schemaVersion", out var schema) || schema.GetInt32() != 1)
            throw new InvalidDataException("Unsupported Pathfinder resource-registry schema.");
        if (!root.TryGetProperty("resources", out var resources) || resources.ValueKind != JsonValueKind.Array)
            throw new InvalidDataException("Pathfinder resource registry has no resources array.");

        foreach (var item in resources.EnumerateArray())
        {
            var role = item.TryGetProperty("role", out var roleElement) ? roleElement.GetString() ?? "study" : "study";
            var number = item.TryGetProperty("number", out var n) && n.ValueKind == JsonValueKind.Number ? n.GetInt32() : 100 + Entries.Count(x => x.IsExtra);
            var resourceId = item.GetProperty("resourceId").GetString() ?? "";
            var canonicalPath = item.GetProperty("canonicalPath").GetString() ?? "";

            var entry = new SubjectEntry
            {
                Number = number,
                ResourceId = resourceId,
                Slug = resourceId, // persisted v1.x compatibility alias; resourceId is canonical from W2A onward.
                Title = item.GetProperty("title").GetString() ?? "",
                Subtitle = item.TryGetProperty("subtitle", out var subtitle) ? subtitle.GetString() ?? "" : "",
                Kind = item.TryGetProperty("kind", out var kind) ? kind.GetString() ?? "" : "",
                Phase = item.TryGetProperty("phase", out var phase) ? phase.GetString() ?? "" : "",
                MainPath = canonicalPath,
                LegacyMainPath = item.TryGetProperty("legacyMainPath", out var legacy) ? legacy.GetString() ?? "" : "",
                ExpectedSha256 = item.TryGetProperty("sourceSha256", out var expected) ? expected.GetString() ?? "" : "",
                ContentType = item.TryGetProperty("contentType", out var type) ? type.GetString() ?? "html" : "html",
                IsExtra = !role.Equals("study", StringComparison.OrdinalIgnoreCase)
            };
            Entries.Add(entry);

            RegisterAlias(resourceId, entry);
            RegisterAlias(entry.LegacyMainPath, entry);
            if (item.TryGetProperty("legacyAliases", out var aliases) && aliases.ValueKind == JsonValueKind.Array)
            {
                foreach (var alias in aliases.EnumerateArray())
                    RegisterAlias(alias.GetString(), entry);
            }
        }

        foreach (var entry in Entries)
        {
            if (string.IsNullOrWhiteSpace(entry.ResourceId))
                throw new InvalidDataException("Pathfinder resource registry contains a blank resourceId.");
            var full = Path.Combine(PathfinderPaths.ContentRoot, entry.MainPath.Replace('/', Path.DirectorySeparatorChar));
            if (!File.Exists(full)) throw new FileNotFoundException($"Study content entry missing: {entry.Title}", full);
        }

        var duplicate = Entries.GroupBy(x => x.ResourceId, StringComparer.OrdinalIgnoreCase).FirstOrDefault(g => g.Count() > 1);
        if (duplicate is not null)
            throw new InvalidDataException($"Duplicate Pathfinder resourceId: {duplicate.Key}");
    }

    private void RegisterAlias(string? alias, SubjectEntry entry)
    {
        if (string.IsNullOrWhiteSpace(alias)) return;
        alias = alias.Trim();
        if (_byAlias.TryGetValue(alias, out var existing) && !ReferenceEquals(existing, entry))
            throw new InvalidDataException($"Pathfinder resource alias is ambiguous: {alias}");
        _byAlias[alias] = entry;
    }
}
