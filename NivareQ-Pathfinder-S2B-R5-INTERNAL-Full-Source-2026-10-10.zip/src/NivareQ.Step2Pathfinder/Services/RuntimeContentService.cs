using System.Security.Cryptography;
using NivareQ.Step2Pathfinder.Models;

namespace NivareQ.Step2Pathfinder.Services;

public sealed class RuntimeContentService
{
    private readonly Dictionary<string, RuntimeContentTarget> _byResourceId = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, SubjectEntry> _byHost = new(StringComparer.OrdinalIgnoreCase);

    public RuntimeContentTarget Prepare(SubjectEntry subject)
    {
        var resourceId = string.IsNullOrWhiteSpace(subject.ResourceId) ? subject.Slug : subject.ResourceId;
        if (_byResourceId.TryGetValue(resourceId, out var existing) && File.Exists(existing.LocalFile))
            return existing;

        var source = Path.Combine(PathfinderPaths.ContentRoot, subject.MainPath.Replace('/', Path.DirectorySeparatorChar));
        if (!File.Exists(source))
            throw new FileNotFoundException($"Packaged study file not found for {subject.Title}.", source);

        var sourceHash = HashHex(source);
        if (!string.IsNullOrWhiteSpace(subject.ExpectedSha256)
            && !sourceHash.Equals(subject.ExpectedSha256, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException($"Packaged study content integrity check failed for {subject.Title}. Expected {subject.ExpectedSha256}, found {sourceHash}.");

        var extension = Path.GetExtension(source);
        if (string.IsNullOrWhiteSpace(extension)) extension = ".html";

        var folder = Path.Combine(PathfinderPaths.RuntimeContentRoot, subject.Number.ToString("D3"));
        Directory.CreateDirectory(folder);
        var destination = Path.Combine(folder, "content" + extension.ToLowerInvariant());
        CopyByteExact(source, sourceHash, destination);

        var host = $"s{subject.Number:D3}{PathfinderPaths.InternalHostSuffix}";
        var target = new RuntimeContentTarget(host, folder, destination, new Uri($"https://{host}/{Uri.EscapeDataString(Path.GetFileName(destination))}"));
        _byResourceId[resourceId] = target;
        _byHost[host] = subject;
        return target;
    }

    public bool IsInternalHost(string host) => host.EndsWith(PathfinderPaths.InternalHostSuffix, StringComparison.OrdinalIgnoreCase);

    public SubjectEntry? SubjectForHost(string host) => _byHost.TryGetValue(host, out var subject) ? subject : null;

    private static void CopyByteExact(string source, string sourceHash, string destination)
    {
        if (File.Exists(destination) && sourceHash.Equals(HashHex(destination), StringComparison.OrdinalIgnoreCase)) return;

        File.Copy(source, destination, true);
        if (!sourceHash.Equals(HashHex(destination), StringComparison.OrdinalIgnoreCase))
            throw new IOException("Runtime study copy failed byte-integrity verification. The bundled study source was not modified.");
    }

    private static string HashHex(string path)
    {
        using var stream = File.OpenRead(path);
        return Convert.ToHexString(SHA256.HashData(stream)).ToLowerInvariant();
    }
}

public sealed record RuntimeContentTarget(string Host, string Folder, string LocalFile, Uri Uri);
