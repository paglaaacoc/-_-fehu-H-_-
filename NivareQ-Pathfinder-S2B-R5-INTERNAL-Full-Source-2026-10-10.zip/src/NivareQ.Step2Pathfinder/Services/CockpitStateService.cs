using System.Text;
using System.Text.Json;
using NivareQ.Step2Pathfinder.Models;

namespace NivareQ.Step2Pathfinder.Services;

public sealed class CockpitStateService
{
    public const int SchemaVersion = 1;
    public const long MaxStoreBytes = 16L * 1024L * 1024L;
    public const long MaxResourceStateCharacters = 2_000_000L;
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true, PropertyNameCaseInsensitive = true };

    private readonly CockpitStateRegistry _registry;
    private readonly IReadOnlyDictionary<string, string> _sourceVersions;

    public CockpitStateEnvelope State { get; private set; } = new();

    public CockpitStateService(CockpitStateRegistry registry, IReadOnlyDictionary<string, string> sourceVersions)
    {
        _registry = registry;
        _sourceVersions = sourceVersions;
    }

    public void Load()
    {
        RestoreTransactionService.EnsureInterruptedRestoreRecovered();
        Directory.CreateDirectory(PathfinderPaths.AppDataRoot);
        if (!File.Exists(PathfinderPaths.CockpitStatePath))
        {
            State = new CockpitStateEnvelope();
            return;
        }

        try
        {
            State = Deserialize(ReadBounded(PathfinderPaths.CockpitStatePath));
        }
        catch (UnsupportedLocalSchemaException ex)
        {
            RestoreTransactionService.BlockMutationTarget(PathfinderPaths.CockpitStatePath, ex.Message);
            State = new CockpitStateEnvelope();
            PersistenceHealth.Report("Cockpit state compatibility", ex.Message + " cockpit-state.json was preserved in place and this build will not overwrite it.");
        }
        catch (Exception ex)
        {
            var quarantined = AtomicFileStore.Quarantine(PathfinderPaths.CockpitStatePath, "corrupt");
            var lastGood = AtomicFileStore.LastGoodPath(PathfinderPaths.CockpitStatePath);
            if (File.Exists(lastGood))
            {
                try
                {
                    State = Deserialize(ReadBounded(lastGood));
                    PersistenceHealth.Report("Cockpit state recovery", $"cockpit-state.json could not be read and was preserved{(quarantined is null ? "" : $" at {quarantined}")}. Pathfinder loaded the last-known-good cockpit state instead. {ex.Message}");
                    return;
                }
                catch (Exception lastGoodEx)
                {
                    PersistenceHealth.Report("Cockpit state recovery", $"cockpit-state.json and its last-known-good copy were unreadable. The corrupt current file was preserved{(quarantined is null ? "" : $" at {quarantined}")}; cockpit state will be re-adopted from the existing WebView profile as resources are opened. {lastGoodEx.Message}");
                }
            }
            else
            {
                PersistenceHealth.Report("Cockpit state recovery", $"cockpit-state.json could not be read and was preserved{(quarantined is null ? "" : $" at {quarantined}")}. Cockpit state will be re-adopted from the existing WebView profile as resources are opened. {ex.Message}");
            }
            State = new CockpitStateEnvelope();
        }
    }

    public PersistenceWriteResult Save()
    {
        var allowed = RestoreTransactionService.RequireMutationAllowed(PathfinderPaths.CockpitStatePath);
        if (!allowed.Success) return allowed;
        State.UpdatedUtc = DateTimeOffset.UtcNow;
        var serialized = Serialize(State);
        var result = AtomicFileStore.WriteText(PathfinderPaths.CockpitStatePath, serialized);
        if (!result.Success) PersistenceHealth.Report("Cockpit state save", "Windows could not save cockpit study state: " + result.Error);
        return result;
    }

    public bool HasAuthoritativeState(string resourceId) => State.Resources.ContainsKey(resourceId);

    public CockpitResourceState? StateFor(string resourceId)
        => State.Resources.TryGetValue(resourceId, out var state) ? CloneResource(state) : null;

    public void ReplaceResource(string resourceId, string sourceVersion, IReadOnlyDictionary<string, string> values, bool migratedFromProfile)
    {
        if (!RestoreTransactionService.RequireMutationAllowed(PathfinderPaths.CockpitStatePath).Success) return;
        if (!_registry.SupportsResource(resourceId)) return;
        var validated = _registry.ValidateValues(resourceId, values, "CockpitState." + resourceId);
        State.Resources[resourceId] = new CockpitResourceState
        {
            ResourceId = resourceId,
            SourceVersion = NormalizeSourceVersion(resourceId, sourceVersion),
            MigratedFromWebViewProfile = migratedFromProfile,
            UpdatedUtc = DateTimeOffset.UtcNow,
            Values = validated
        };
        State.UpdatedUtc = DateTimeOffset.UtcNow;
    }

    public bool ApplyChange(string resourceId, string sourceVersion, string key, string? value)
    {
        if (!RestoreTransactionService.RequireMutationAllowed(PathfinderPaths.CockpitStatePath).Success) return false;
        if (!_registry.IsAllowed(resourceId, key)) return false;
        if (value is not null && value.Length > 250_000) return false;
        if (!State.Resources.TryGetValue(resourceId, out var state))
        {
            state = new CockpitResourceState
            {
                ResourceId = resourceId,
                SourceVersion = NormalizeSourceVersion(resourceId, sourceVersion),
                MigratedFromWebViewProfile = true
            };
            State.Resources[resourceId] = state;
        }
        var nextValues = new Dictionary<string, string>(state.Values, StringComparer.Ordinal);
        if (value is null) nextValues.Remove(key); else nextValues[key] = value;
        // Validate the candidate state before mutating the authoritative in-memory provider.
        // A rejected oversized/invalid update must never poison a later canonical save.
        var validated = _registry.ValidateValues(resourceId, nextValues, "CockpitState." + resourceId);
        if (!string.IsNullOrWhiteSpace(sourceVersion)) state.SourceVersion = NormalizeSourceVersion(resourceId, sourceVersion);
        state.Values = validated;
        state.UpdatedUtc = DateTimeOffset.UtcNow;
        State.UpdatedUtc = DateTimeOffset.UtcNow;
        return true;
    }

    public void ClearResource(string resourceId)
    {
        if (!RestoreTransactionService.RequireMutationAllowed(PathfinderPaths.CockpitStatePath).Success) return;
        if (_registry.SupportsResource(resourceId))
        {
            var source = _sourceVersions.TryGetValue(resourceId, out var hash) ? hash : "";
            State.Resources[resourceId] = new CockpitResourceState
            {
                ResourceId = resourceId,
                SourceVersion = source,
                MigratedFromWebViewProfile = false,
                UpdatedUtc = DateTimeOffset.UtcNow,
                Values = new Dictionary<string, string>(StringComparer.Ordinal)
            };
            State.UpdatedUtc = DateTimeOffset.UtcNow;
        }
    }

    public void ClearAll()
    {
        if (!RestoreTransactionService.RequireMutationAllowed(PathfinderPaths.CockpitStatePath).Success) return;
        State = new CockpitStateEnvelope();
        foreach (var resourceId in _registry.ResourceIds)
            ClearResource(resourceId);
    }

    public void ReplaceInMemory(CockpitStateEnvelope state) => State = Clone(state);

    public string Serialize(CockpitStateEnvelope state)
    {
        var validated = ValidateAndClone(state);
        var json = JsonSerializer.Serialize(validated, JsonOptions);
        if (Encoding.UTF8.GetByteCount(json) > MaxStoreBytes)
            throw new InvalidDataException("Cockpit state exceeds the bounded 16 MB safety limit.");
        return json;
    }

    public CockpitStateEnvelope Deserialize(string json)
    {
        if (Encoding.UTF8.GetByteCount(json) > MaxStoreBytes)
            throw new InvalidDataException("Cockpit state exceeds the bounded 16 MB safety limit.");
        var parsed = JsonSerializer.Deserialize<CockpitStateEnvelope>(json, JsonOptions) ?? new CockpitStateEnvelope();
        return ValidateAndClone(parsed);
    }

    public CockpitStateEnvelope ValidateAndClone(CockpitStateEnvelope source)
    {
        if (source.SchemaVersion > SchemaVersion) throw new UnsupportedLocalSchemaException($"Cockpit-state schema {source.SchemaVersion} is newer than supported schema {SchemaVersion}.");
        if (source.SchemaVersion != SchemaVersion) throw new InvalidDataException("Unsupported cockpit-state schema.");
        var output = new CockpitStateEnvelope { SchemaVersion = SchemaVersion, UpdatedUtc = source.UpdatedUtc == default ? DateTimeOffset.UtcNow : source.UpdatedUtc };
        var count = 0;
        foreach (var pair in source.Resources ?? [])
        {
            if (!_registry.SupportsResource(pair.Key)) throw new InvalidDataException($"Cockpit state contains unsupported resource '{pair.Key}'.");
            if (++count > _registry.ResourceCount) throw new InvalidDataException("Cockpit state contains too many resources.");
            var src = pair.Value ?? new CockpitResourceState();
            var sourceVersion = NormalizeSourceVersion(pair.Key, src.SourceVersion);
            var values = _registry.ValidateValues(pair.Key, src.Values ?? [], "CockpitState." + pair.Key);
            output.Resources[pair.Key] = new CockpitResourceState
            {
                ResourceId = pair.Key,
                SourceVersion = sourceVersion,
                MigratedFromWebViewProfile = src.MigratedFromWebViewProfile,
                UpdatedUtc = src.UpdatedUtc == default ? DateTimeOffset.UtcNow : src.UpdatedUtc,
                Values = values
            };
        }
        return output;
    }

    public static CockpitStateEnvelope Clone(CockpitStateEnvelope source)
    {
        var clone = new CockpitStateEnvelope { SchemaVersion = source.SchemaVersion, UpdatedUtc = source.UpdatedUtc };
        foreach (var pair in source.Resources ?? []) clone.Resources[pair.Key] = CloneResource(pair.Value);
        return clone;
    }

    private static CockpitResourceState CloneResource(CockpitResourceState source)
        => new()
        {
            ResourceId = source.ResourceId,
            SourceVersion = source.SourceVersion,
            MigratedFromWebViewProfile = source.MigratedFromWebViewProfile,
            UpdatedUtc = source.UpdatedUtc,
            Values = new Dictionary<string, string>(source.Values ?? [], StringComparer.Ordinal)
        };

    private string NormalizeSourceVersion(string resourceId, string? supplied)
    {
        var expected = _sourceVersions.TryGetValue(resourceId, out var hash) ? hash.ToLowerInvariant() : "";
        var actual = (supplied ?? "").ToLowerInvariant();
        if (!string.IsNullOrWhiteSpace(actual) && actual.Length == 64 && actual.All(Uri.IsHexDigit))
        {
            if (!string.IsNullOrWhiteSpace(expected) && !actual.Equals(expected, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException($"Cockpit state for '{resourceId}' belongs to a different study-content version.");
            return actual;
        }
        if (!string.IsNullOrWhiteSpace(expected)) return expected;
        throw new InvalidDataException($"Cockpit state for '{resourceId}' has no verifiable source identity.");
    }

    private static string ReadBounded(string path)
    {
        var info = new FileInfo(path);
        if (info.Length > MaxStoreBytes) throw new InvalidDataException("Cockpit state store exceeds the bounded 16 MB safety limit.");
        return File.ReadAllText(path);
    }
}
