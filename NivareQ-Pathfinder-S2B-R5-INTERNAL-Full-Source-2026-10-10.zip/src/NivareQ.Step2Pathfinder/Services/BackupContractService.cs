using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using NivareQ.Step2Pathfinder.Models;

namespace NivareQ.Step2Pathfinder.Services;

public sealed class BackupContractService
{
    public const int CanonicalSchemaVersion = 7;
    public const long MaxBackupBytes = 100L * 1024L * 1024L;
    public const string CanonicalFormatId = "nivareq.step2pathfinder.backup";

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true
    };

    private static readonly HashSet<string> AllowedProgress = new(StringComparer.OrdinalIgnoreCase)
    {
        "Not started", "Studying", "First pass done", "Review later"
    };

    private static readonly HashSet<string> SelectorRecipeIds = new(StringComparer.OrdinalIgnoreCase)
    {
        "r01", "r02", "r03", "r04", "r05", "r06", "r07", "r08", "r09",
        "r10a", "r10b", "r11a", "r11b", "r12a", "r12b", "r13", "r14", "r15", "r16", "r17",
        "r18", "r19", "r20", "r21", "residual-six", "final-audit"
    };

    private const string AcceptedPwaSelectorSourceVersion = "8fd96cd34df70ef079f2a12244acfaca28036dfdc052934c4a3b784460af0f5a";

    private static readonly Dictionary<string, string> PwaUtilityToWindows = new(StringComparer.OrdinalIgnoreCase)
    {
        ["search"] = "Search",
        ["glossary"] = "Glossary",
        ["journal"] = "Journal",
        ["mystudy"] = "My Study",
        ["guide"] = "Guide",
        ["time"] = "Study time",
        ["accessibility"] = "Accessibility",
        ["uworld-selector"] = "UWorld Selector",
        ["scratchpad"] = "Scratchpad"
    };

    private static readonly HashSet<string> WindowsUtilityIds = new(StringComparer.OrdinalIgnoreCase)
    {
        "Search", "Glossary", "Journal", "My Study", "Guide", "Study time", "Accessibility", "UWorld Selector", "Scratchpad"
    };

    private readonly HashSet<string> _knownSlugs;
    private readonly HashSet<string> _knownThemeIds;
    private readonly Dictionary<string, string> _sourceVersionByResource;
    private readonly CockpitStateRegistry _cockpitStateRegistry;

    public BackupContractService(IEnumerable<string> knownSlugs, CockpitStateRegistry cockpitStateRegistry, IEnumerable<string>? knownThemeIds = null, IReadOnlyDictionary<string, string>? sourceVersions = null)
    {
        _cockpitStateRegistry = cockpitStateRegistry ?? throw new ArgumentNullException(nameof(cockpitStateRegistry));
        _knownSlugs = new HashSet<string>(knownSlugs.Where(x => !string.IsNullOrWhiteSpace(x)), StringComparer.OrdinalIgnoreCase);
        _knownThemeIds = new HashSet<string>((knownThemeIds ?? []).Where(x => !string.IsNullOrWhiteSpace(x)), StringComparer.OrdinalIgnoreCase);
        _sourceVersionByResource = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if (sourceVersions is not null)
        {
            foreach (var pair in sourceVersions)
                if (!string.IsNullOrWhiteSpace(pair.Key) && !string.IsNullOrWhiteSpace(pair.Value))
                    _sourceVersionByResource[pair.Key] = pair.Value.ToLowerInvariant();
        }
    }

    public PathfinderCanonicalBackupEnvelope CreateCanonicalBackup(
        ShellSettings settings,
        PersonalStudyState personal,
        CockpitStateEnvelope cockpitState,
        JournalState journal,
        UWorldSelectorState uworldSelector,
        PreservedBackupExtensionState preservedExtensions)
    {
        var extensions = new Dictionary<string, JsonElement>(StringComparer.Ordinal);
        foreach (var pair in preservedExtensions.Values ?? []) extensions[pair.Key] = pair.Value.Clone();

        ValidateExtensionAggregate(extensions);
        var opaque = extensions.Keys.OrderBy(x => x, StringComparer.Ordinal).ToList();
        var validatedCockpitState = ValidateCockpitStateEnvelope(cockpitState, "Backup.CockpitState");
        var validatedJournal = CanonicalizeJournal(JournalService.CloneState(journal));
        var validatedSelector = ValidateUWorldSelectorState(uworldSelector, "Backup.UWorldSelector");
        return new PathfinderCanonicalBackupEnvelope
        {
            BackupSchemaVersion = CanonicalSchemaVersion,
            FormatId = CanonicalFormatId,
            ContractAuthority = "windows-canonical",
            Producer = "NivareQ Step 2 Pathfinder Windows",
            ProducerBuild = "1.2.2-S1-TEST",
            ExportedUtc = DateTimeOffset.UtcNow,
            ShellSettings = CloneSettings(settings),
            PersonalStudy = CanonicalizePersonalLocations(ClonePersonal(personal)),
            CockpitState = validatedCockpitState,
            Journal = validatedJournal,
            UWorldSelector = validatedSelector,
            PreservedExtensions = extensions,
            Coverage = new PathfinderBackupCoverage
            {
                Included =
                [
                    "Windows shell settings and accessibility preferences",
                    "open-tab session metadata, Split View workspace state and unified Location v2 resume positions",
                    "My Study favorites, recent subjects, manual progress and Location v2 bookmarks",
                    "native Journal General notes plus cockpit/source-linked notes and exact source locations",
                    "native UWorld Selector 26-recipe user-reported Unused counts and timestamps",
                    "allowlisted canonical cockpit review/quiz/mode state for the frozen HTML study resources",
                    "bounded preserved cross-platform/unknown extensions"
                ],
                Deferred = [],
                PreservedOpaque = opaque
            }
        };
    }

    public string SerializeCanonical(PathfinderCanonicalBackupEnvelope envelope)
    {
        ValidateExtensionAggregate(envelope.PreservedExtensions ?? []);
        envelope.CockpitState = ValidateCockpitStateEnvelope(envelope.CockpitState ?? new(), "Backup.CockpitState");
        envelope.Journal = CanonicalizeJournal(JournalService.CloneState(envelope.Journal ?? new()));
        envelope.UWorldSelector = ValidateUWorldSelectorState(envelope.UWorldSelector ?? UWorldSelectorService.NewState(), "Backup.UWorldSelector");
        var json = JsonSerializer.Serialize(envelope, JsonOptions);
        if (Encoding.UTF8.GetByteCount(json) > MaxBackupBytes)
            throw new InvalidDataException("Canonical backup exceeds the supported 100 MB safety limit.");
        return json;
    }

    public BackupImportPlan ParseImport(
        string json,
        ShellSettings currentSettings,
        CockpitStateEnvelope currentCockpitState,
        JournalState currentJournal,
        UWorldSelectorState currentUWorldSelector,
        PreservedBackupExtensionState currentExtensions)
    {
        if (Encoding.UTF8.GetByteCount(json) > MaxBackupBytes)
            throw new InvalidDataException("Backup is larger than the supported 100 MB safety limit.");

        using var document = JsonDocument.Parse(json, new JsonDocumentOptions { MaxDepth = 96 });
        var root = document.RootElement;
        RequireObject(root, "Backup");

        var schema = RequiredInt(root, "BackupSchemaVersion", "Backup.BackupSchemaVersion");
        if (schema is < 1 or > CanonicalSchemaVersion)
            throw new InvalidDataException($"Unsupported Pathfinder backup schema: {schema}.");

        var isCanonical = schema >= 2;
        if (isCanonical)
        {
            if (schema >= 7)
            {
                EnsureOnlyProperties(root, "Backup",
                    "BackupSchemaVersion", "FormatId", "ContractAuthority", "Producer", "ProducerBuild", "ExportedUtc",
                    "ShellSettings", "PersonalStudy", "CockpitState", "Journal", "UWorldSelector", "Coverage", "PreservedExtensions");
                RequireProperties(root, "Backup",
                    "BackupSchemaVersion", "FormatId", "ContractAuthority", "Producer", "ProducerBuild", "ExportedUtc",
                    "ShellSettings", "PersonalStudy", "CockpitState", "Journal", "UWorldSelector", "Coverage", "PreservedExtensions");
            }
            else if (schema >= 6)
            {
                EnsureOnlyProperties(root, "Backup",
                    "BackupSchemaVersion", "FormatId", "ContractAuthority", "Producer", "ProducerBuild", "ExportedUtc",
                    "ShellSettings", "PersonalStudy", "CockpitState", "Journal", "Coverage", "PreservedExtensions");
                RequireProperties(root, "Backup",
                    "BackupSchemaVersion", "FormatId", "ContractAuthority", "Producer", "ProducerBuild", "ExportedUtc",
                    "ShellSettings", "PersonalStudy", "CockpitState", "Journal", "Coverage", "PreservedExtensions");
            }
            else if (schema >= 4)
            {
                EnsureOnlyProperties(root, "Backup",
                    "BackupSchemaVersion", "FormatId", "ContractAuthority", "Producer", "ProducerBuild", "ExportedUtc",
                    "ShellSettings", "PersonalStudy", "CockpitState", "Coverage", "PreservedExtensions");
                RequireProperties(root, "Backup",
                    "BackupSchemaVersion", "FormatId", "ContractAuthority", "Producer", "ProducerBuild", "ExportedUtc",
                    "ShellSettings", "PersonalStudy", "CockpitState", "Coverage", "PreservedExtensions");
            }
            else
            {
                EnsureOnlyProperties(root, "Backup",
                    "BackupSchemaVersion", "FormatId", "ContractAuthority", "Producer", "ProducerBuild", "ExportedUtc",
                    "ShellSettings", "PersonalStudy", "Coverage", "PreservedExtensions");
                RequireProperties(root, "Backup",
                    "BackupSchemaVersion", "FormatId", "ContractAuthority", "Producer", "ProducerBuild", "ExportedUtc",
                    "ShellSettings", "PersonalStudy", "Coverage", "PreservedExtensions");
            }

            var format = RequiredString(root, "FormatId", "Backup.FormatId", 120);
            if (!format.Equals(CanonicalFormatId, StringComparison.Ordinal))
                throw new InvalidDataException("This canonical file is not a recognized Pathfinder backup.");
            var authority = RequiredString(root, "ContractAuthority", "Backup.ContractAuthority", 120);
            if (!authority.Equals("windows-canonical", StringComparison.Ordinal))
                throw new InvalidDataException("Canonical Pathfinder backup has an unsupported contract authority.");
            if (!root.TryGetProperty("ExportedUtc", out var exportedUtc))
                throw new InvalidDataException("Canonical backup is missing ExportedUtc.");
            _ = DateValue(exportedUtc, "Backup.ExportedUtc");
            _ = RequiredString(root, "Producer", "Backup.Producer", 240);
            _ = RequiredString(root, "ProducerBuild", "Backup.ProducerBuild", 120);
        }

        if (!root.TryGetProperty("ShellSettings", out var shellElement))
            throw new InvalidDataException("Backup is missing ShellSettings.");
        if (!root.TryGetProperty("PersonalStudy", out var personalElement))
            throw new InvalidDataException("Backup is missing PersonalStudy.");

        var warnings = new List<string>();
        var hasPwaState = !isCanonical && root.TryGetProperty("PwaState", out _);
        var shell = ParseShellSettings(shellElement, currentSettings, isCanonical, schema, warnings);
        var personal = ParsePersonalStudy(personalElement, warnings, hasPwaState, isCanonical, schema);
        var cockpitState = CockpitStateService.Clone(currentCockpitState ?? new CockpitStateEnvelope());
        var replaceCockpitState = false;
        var journal = JournalService.CloneState(currentJournal ?? new JournalState());
        var replaceJournal = false;
        var uworldSelector = ValidateUWorldSelectorState(currentUWorldSelector ?? UWorldSelectorService.NewState(), "Current UWorld Selector state");
        var replaceUWorldSelector = false;

        var importedExtensions = new PreservedBackupExtensionState
        {
            SchemaVersion = 1,
            LastImportedFrom = isCanonical ? $"Windows canonical schema {schema}" : (root.TryGetProperty("PwaState", out _) ? "PWA/legacy schema 1" : "Windows/legacy schema 1"),
            UpdatedUtc = DateTimeOffset.UtcNow,
            Values = []
        };

        var replaceExtensions = isCanonical;
        if (isCanonical)
        {
            if (!root.TryGetProperty("PreservedExtensions", out var extensionsElement))
                throw new InvalidDataException("Canonical backup is missing PreservedExtensions.");
            RequireObject(extensionsElement, "Backup.PreservedExtensions");
            var aggregateBytes = 0L;
            foreach (var property in extensionsElement.EnumerateObject())
            {
                ValidateExtensionKey(property.Name);
                if (importedExtensions.Values.ContainsKey(property.Name))
                    throw new InvalidDataException($"PreservedExtensions contains duplicate key '{property.Name}'.");
                var raw = property.Value.GetRawText();
                aggregateBytes += Encoding.UTF8.GetByteCount(raw);
                if (aggregateBytes > 90L * 1024L * 1024L)
                    throw new InvalidDataException("PreservedExtensions exceeds the bounded 90 MB extension budget.");
                importedExtensions.Values[property.Name] = property.Value.Clone();
            }

            if (schema >= 4)
            {
                cockpitState = ParseCanonicalCockpitState(root.GetProperty("CockpitState"));
                replaceCockpitState = true;
            }
            else
            {
                warnings.Add("This older Windows canonical backup predates first-class cockpit-state ownership. Current Windows cockpit review/quiz/mode state will be preserved rather than silently cleared.");
            }

            if (schema >= 6)
            {
                journal = ParseCanonicalJournal(root.GetProperty("Journal"));
                replaceJournal = true;
            }
            else
            {
                warnings.Add("This older Windows canonical backup predates the native Journal provider. Current Journal entries will be preserved rather than silently cleared.");
            }

            if (schema >= 7)
            {
                uworldSelector = ParseCanonicalUWorldSelector(root.GetProperty("UWorldSelector"));
                replaceUWorldSelector = true;
            }
            else
            {
                warnings.Add("This older Windows canonical backup predates the native UWorld Selector provider. Current Selector reports will be preserved rather than silently cleared.");
            }
        }
        else
        {
            foreach (var pair in currentExtensions.Values ?? []) importedExtensions.Values[pair.Key] = pair.Value.Clone();
            if (root.TryGetProperty("PwaState", out var pwaState))
            {
                RequireObject(pwaState, "Backup.PwaState");
                var promotedCockpitProvider = TryParsePwaCockpitState(pwaState, out var promotedCockpitState, out var promotedCount);
                if (promotedCockpitProvider)
                {
                    cockpitState = promotedCockpitState;
                    replaceCockpitState = true;
                }

                var promotedJournalProvider = TryParsePwaJournal(pwaState, out var promotedJournal, out var promotedJournalCount);
                if (promotedJournalProvider)
                {
                    journal = promotedJournal;
                    replaceJournal = true;
                }

                var promotedSelectorProvider = TryParsePwaUWorldSelector(pwaState, out var promotedSelector);
                if (promotedSelectorProvider)
                {
                    uworldSelector = promotedSelector;
                    replaceUWorldSelector = true;
                }

                importedExtensions.Values["PwaState"] = StripPromotedPwaProviders(pwaState, promotedCockpitProvider, promotedJournalProvider, promotedSelectorProvider);
                if (promotedCockpitProvider) warnings.Add($"Imported {promotedCount} PWA cockpit resource state provider(s) into the canonical Windows cockpit-state contract.");
                if (promotedJournalProvider) warnings.Add($"Imported {promotedJournalCount} PWA Journal note(s) into the native Windows Journal replacement set.");
                if (promotedSelectorProvider) warnings.Add($"Imported {promotedSelector.Reports.Count} PWA UWorld Selector report(s) into the native Windows Selector provider.");
                if (!promotedCockpitProvider && !promotedJournalProvider && !promotedSelectorProvider)
                    warnings.Add("PWA-specific strict-location, Journal, Selector and utility state is preserved opaquely. No supported PWA provider was present to promote into Windows.");
                else
                    warnings.Add("Any unsupported PWA-only state remains preserved opaquely for cross-platform round-trip safety.");
            }

            var knownTopLevel = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
            {
                "BackupSchemaVersion", "ExportedUtc", "ShellSettings", "PersonalStudy", "PwaState"
            };
            foreach (var property in root.EnumerateObject())
            {
                if (knownTopLevel.Contains(property.Name)) continue;
                var opaqueKey = "legacy.top." + property.Name;
                ValidateExtensionKey(opaqueKey);
                if (importedExtensions.Values.ContainsKey(opaqueKey))
                    throw new InvalidDataException($"Legacy backup contains duplicate extension field '{property.Name}'.");
                importedExtensions.Values[opaqueKey] = property.Value.Clone();
                warnings.Add($"Unrecognized legacy field '{property.Name}' will be preserved opaquely rather than discarded.");
            }
        }

        ValidateExtensionAggregate(importedExtensions.Values);
        if (isCanonical) ValidateCanonicalCoverage(root.GetProperty("Coverage"), importedExtensions.Values.Keys);

        return new BackupImportPlan
        {
            SourceSchemaVersion = schema,
            SourceDescription = importedExtensions.LastImportedFrom,
            ShellSettings = shell,
            PersonalStudy = personal,
            CockpitState = ValidateCockpitStateEnvelope(cockpitState, "Imported cockpit state"),
            ReplaceCockpitState = replaceCockpitState,
            Journal = journal,
            ReplaceJournal = replaceJournal,
            UWorldSelector = uworldSelector,
            ReplaceUWorldSelector = replaceUWorldSelector,
            PreservedExtensions = importedExtensions,
            ReplacePreservedExtensions = replaceExtensions,
            Warnings = warnings
        };
    }

    private UWorldSelectorState ParseCanonicalUWorldSelector(JsonElement element)
    {
        RequireObject(element, "Backup.UWorldSelector");
        EnsureOnlyProperties(element, "Backup.UWorldSelector", "SchemaVersion", "RecipeVersion", "UpdatedUtc", "Reports");
        RequireProperties(element, "Backup.UWorldSelector", "SchemaVersion", "RecipeVersion", "UpdatedUtc", "Reports");
        if (RequiredInt(element, "SchemaVersion", "Backup.UWorldSelector.SchemaVersion") != UWorldSelectorService.SchemaVersion)
            throw new InvalidDataException("Unsupported canonical UWorld Selector schema.");
        if (RequiredInt(element, "RecipeVersion", "Backup.UWorldSelector.RecipeVersion") != UWorldSelectorService.RecipeVersion)
            throw new InvalidDataException("Unsupported canonical UWorld Selector recipe version.");
        var output = UWorldSelectorService.NewState();
        output.UpdatedUtc = DateValue(element.GetProperty("UpdatedUtc"), "Backup.UWorldSelector.UpdatedUtc");
        var reports = element.GetProperty("Reports");
        RequireObject(reports, "Backup.UWorldSelector.Reports");
        foreach (var report in reports.EnumerateObject())
        {
            if (output.Reports.Count >= UWorldSelectorService.ExpectedRecipeCount) throw new InvalidDataException("Backup.UWorldSelector has too many reports.");
            if (!SelectorRecipeIds.Contains(report.Name)) throw new InvalidDataException($"Backup.UWorldSelector contains unknown recipe '{report.Name}'.");
            RequireObject(report.Value, $"Backup.UWorldSelector.Reports.{report.Name}");
            EnsureOnlyProperties(report.Value, $"Backup.UWorldSelector.Reports.{report.Name}", "Unused", "ReportedUtc");
            RequireProperties(report.Value, $"Backup.UWorldSelector.Reports.{report.Name}", "Unused", "ReportedUtc");
            var unused = RequiredInt(report.Value, "Unused", $"Backup.UWorldSelector.Reports.{report.Name}.Unused");
            if (unused < 0 || unused > UWorldSelectorService.MaxUnusedCount) throw new InvalidDataException($"Backup.UWorldSelector report '{report.Name}' has an invalid unused count.");
            output.Reports[report.Name] = new UWorldSelectorReport
            {
                Unused = unused,
                ReportedUtc = DateValue(report.Value.GetProperty("ReportedUtc"), $"Backup.UWorldSelector.Reports.{report.Name}.ReportedUtc")
            };
        }
        return ValidateUWorldSelectorState(output, "Backup.UWorldSelector");
    }

    private static UWorldSelectorState ValidateUWorldSelectorState(UWorldSelectorState state, string label)
    {
        if (state.SchemaVersion != UWorldSelectorService.SchemaVersion || state.RecipeVersion != UWorldSelectorService.RecipeVersion)
            throw new InvalidDataException(label + " has an unsupported schema or recipe version.");
        if (state.Reports.Count > UWorldSelectorService.ExpectedRecipeCount) throw new InvalidDataException(label + " has too many reports.");
        var output = UWorldSelectorService.NewState();
        output.UpdatedUtc = state.UpdatedUtc == default ? DateTimeOffset.UtcNow : state.UpdatedUtc;
        foreach (var pair in state.Reports)
        {
            if (!SelectorRecipeIds.Contains(pair.Key)) throw new InvalidDataException(label + $" contains unknown recipe '{pair.Key}'.");
            if (pair.Value is null || pair.Value.Unused < 0 || pair.Value.Unused > UWorldSelectorService.MaxUnusedCount || pair.Value.ReportedUtc == default)
                throw new InvalidDataException(label + $" report '{pair.Key}' is invalid.");
            output.Reports[pair.Key] = new UWorldSelectorReport { Unused = pair.Value.Unused, ReportedUtc = pair.Value.ReportedUtc };
        }
        return output;
    }

    private bool TryParsePwaUWorldSelector(JsonElement pwaState, out UWorldSelectorState selector)
    {
        selector = UWorldSelectorService.NewState();
        if (!pwaState.TryGetProperty("CockpitStudyState", out var extension) || extension.ValueKind != JsonValueKind.Object) return false;
        if (!extension.TryGetProperty("Cockpits", out var cockpits) || cockpits.ValueKind != JsonValueKind.Object) return false;
        if (!cockpits.TryGetProperty(UWorldSelectorService.ResourceId, out var bucket) || bucket.ValueKind != JsonValueKind.Object) return false;
        if (!bucket.TryGetProperty("Values", out var values) || values.ValueKind != JsonValueKind.Object) return false;
        if (!values.TryGetProperty(UWorldSelectorService.StateKey, out var raw) || raw.ValueKind != JsonValueKind.String) return false;
        var json = raw.GetString() ?? "";
        if (json.Length == 0 || json.Length > 250_000) throw new InvalidDataException("PWA UWorld Selector state is empty or exceeds the safety limit.");
        var parsed = JsonSerializer.Deserialize<UWorldSelectorState>(json, JsonOptions)
                     ?? throw new InvalidDataException("PWA UWorld Selector state is empty.");
        selector = ValidateUWorldSelectorState(parsed, "PWA UWorld Selector state");
        return true;
    }

    private JournalState ParseCanonicalJournal(JsonElement element)
    {
        RequireObject(element, "Backup.Journal");
        EnsureOnlyProperties(element, "Backup.Journal", "SchemaVersion", "UpdatedUtc", "LegacyPersonalMigrationSlugs", "Entries");
        RequireProperties(element, "Backup.Journal", "SchemaVersion", "UpdatedUtc", "LegacyPersonalMigrationSlugs", "Entries");
        var schema = RequiredInt(element, "SchemaVersion", "Backup.Journal.SchemaVersion");
        if (schema != JournalService.SchemaVersion) throw new InvalidDataException("Unsupported canonical Journal schema.");
        var updated = DateValue(element.GetProperty("UpdatedUtc"), "Backup.Journal.UpdatedUtc");
        var migrationElement = element.GetProperty("LegacyPersonalMigrationSlugs");
        RequireArray(migrationElement, "Backup.Journal.LegacyPersonalMigrationSlugs");
        var migrationSlugs = new List<string>();
        foreach (var item in migrationElement.EnumerateArray())
        {
            if (migrationSlugs.Count >= 500) throw new InvalidDataException("Backup.Journal has too many legacy Personal migration markers.");
            var raw = StringValue(item, $"Backup.Journal.LegacyPersonalMigrationSlugs[{migrationSlugs.Count}]", 240);
            var mapped = MapSlug(raw, $"Backup.Journal.LegacyPersonalMigrationSlugs[{migrationSlugs.Count}]");
            if (migrationSlugs.Contains(mapped, StringComparer.OrdinalIgnoreCase)) throw new InvalidDataException($"Backup.Journal contains duplicate legacy Personal migration marker '{mapped}'.");
            migrationSlugs.Add(mapped);
        }
        var entriesElement = element.GetProperty("Entries");
        RequireArray(entriesElement, "Backup.Journal.Entries");

        var entries = new List<JournalEntry>();
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var index = 0;
        foreach (var item in entriesElement.EnumerateArray())
        {
            if (index >= JournalService.MaxEntries) throw new InvalidDataException($"Backup.Journal exceeds the {JournalService.MaxEntries:N0}-entry safety limit.");
            var label = $"Backup.Journal.Entries[{index}]";
            RequireObject(item, label);
            EnsureOnlyProperties(item, label, "Id", "Title", "Body", "Slug", "SourceVersion", "SourceLocation", "OriginalTimestampKnown", "CreatedUtc", "UpdatedUtc");
            RequireProperties(item, label, "Id", "Title", "Body", "Slug", "SourceVersion", "SourceLocation", "OriginalTimestampKnown", "CreatedUtc", "UpdatedUtc");
            var id = RequiredString(item, "Id", label + ".Id", 240);
            if (!seen.Add(id)) throw new InvalidDataException($"Backup.Journal contains duplicate entry id '{id}'.");
            var title = StringValue(item.GetProperty("Title"), label + ".Title", JournalService.MaxTitleLength).Trim();
            var body = StringValue(item.GetProperty("Body"), label + ".Body", JournalService.MaxBodyLength);
            if (title.Length == 0) throw new InvalidDataException(label + " requires a title.");
            var rawSlug = StringValue(item.GetProperty("Slug"), label + ".Slug", 240).Trim();
            var slug = rawSlug.Length == 0 ? "" : MapSlug(rawSlug, label + ".Slug");
            var sourceVersion = StringValue(item.GetProperty("SourceVersion"), label + ".SourceVersion", 128).Trim().ToLowerInvariant();
            StudyLocationState? location = null;
            var locElement = item.GetProperty("SourceLocation");
            if (locElement.ValueKind != JsonValueKind.Null)
            {
                if (slug.Length == 0) throw new InvalidDataException(label + ".SourceLocation requires a cockpit resource.");
                location = ParseLocation(locElement, label + ".SourceLocation", canonical: true, backupSchema: CanonicalSchemaVersion, owningResourceId: slug);
                if (!location.Purpose.Equals("source", StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException(label + ".SourceLocation must have source purpose.");
                location.Purpose = "source";
            }
            if (slug.Length == 0)
            {
                if (sourceVersion.Length != 0) throw new InvalidDataException(label + ".SourceVersion must be empty for a General note.");
            }
            else
            {
                if (!_sourceVersionByResource.ContainsKey(slug)) throw new InvalidDataException(label + ".Slug has no canonical source identity.");
                if (!System.Text.RegularExpressions.Regex.IsMatch(sourceVersion, "^[a-fA-F0-9]{64}$"))
                    throw new InvalidDataException(label + ".SourceVersion is not a SHA-256 source identity.");
                if (location is not null && !location.SourceVersion.Equals(sourceVersion, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException(label + ".SourceLocation source identity does not match the Journal entry's preserved source identity.");
            }
            entries.Add(new JournalEntry
            {
                Id = id,
                Title = title,
                Body = body,
                Slug = slug,
                SourceVersion = sourceVersion,
                SourceLocation = location,
                OriginalTimestampKnown = BoolValue(item.GetProperty("OriginalTimestampKnown"), label + ".OriginalTimestampKnown"),
                CreatedUtc = DateValue(item.GetProperty("CreatedUtc"), label + ".CreatedUtc"),
                UpdatedUtc = DateValue(item.GetProperty("UpdatedUtc"), label + ".UpdatedUtc")
            });
            index++;
        }
        return JournalService.CloneState(new JournalState { SchemaVersion = JournalService.SchemaVersion, UpdatedUtc = updated, LegacyPersonalMigrationSlugs = migrationSlugs, Entries = entries });
    }

    private CockpitStateEnvelope ParseCanonicalCockpitState(JsonElement element)
    {
        RequireObject(element, "Backup.CockpitState");
        EnsureOnlyProperties(element, "Backup.CockpitState", "SchemaVersion", "UpdatedUtc", "Resources");
        RequireProperties(element, "Backup.CockpitState", "SchemaVersion", "UpdatedUtc", "Resources");
        var schema = RequiredInt(element, "SchemaVersion", "Backup.CockpitState.SchemaVersion");
        if (schema != CockpitStateService.SchemaVersion) throw new InvalidDataException("Unsupported canonical cockpit-state schema.");
        var updated = DateValue(element.GetProperty("UpdatedUtc"), "Backup.CockpitState.UpdatedUtc");
        var resourcesElement = element.GetProperty("Resources");
        RequireObject(resourcesElement, "Backup.CockpitState.Resources");

        var output = new CockpitStateEnvelope { SchemaVersion = CockpitStateService.SchemaVersion, UpdatedUtc = updated };
        var resourceCount = 0;
        foreach (var resource in resourcesElement.EnumerateObject())
        {
            if (++resourceCount > _cockpitStateRegistry.ResourceCount) throw new InvalidDataException("Backup.CockpitState contains too many resource providers.");
            if (!_cockpitStateRegistry.SupportsResource(resource.Name)) throw new InvalidDataException($"Backup.CockpitState contains unsupported resource '{resource.Name}'.");
            RequireObject(resource.Value, $"Backup.CockpitState.Resources.{resource.Name}");
            EnsureOnlyProperties(resource.Value, $"Backup.CockpitState.Resources.{resource.Name}", "ResourceId", "SourceVersion", "MigratedFromWebViewProfile", "UpdatedUtc", "Values");
            RequireProperties(resource.Value, $"Backup.CockpitState.Resources.{resource.Name}", "ResourceId", "SourceVersion", "MigratedFromWebViewProfile", "UpdatedUtc", "Values");
            var resourceId = RequiredString(resource.Value, "ResourceId", $"Backup.CockpitState.Resources.{resource.Name}.ResourceId", 180);
            if (!resourceId.Equals(resource.Name, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException($"Backup.CockpitState resource id mismatch for '{resource.Name}'.");
            var sourceVersion = RequiredString(resource.Value, "SourceVersion", $"Backup.CockpitState.Resources.{resource.Name}.SourceVersion", 64).ToLowerInvariant();
            if (sourceVersion.Length != 64 || !sourceVersion.All(Uri.IsHexDigit)) throw new InvalidDataException($"Backup.CockpitState source identity for '{resource.Name}' is invalid.");
            if (_sourceVersionByResource.TryGetValue(resource.Name, out var expected) && !sourceVersion.Equals(expected, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException($"Backup.CockpitState for '{resource.Name}' belongs to a different frozen source version.");
            var migrated = BoolValue(resource.Value.GetProperty("MigratedFromWebViewProfile"), $"Backup.CockpitState.Resources.{resource.Name}.MigratedFromWebViewProfile");
            var resourceUpdated = DateValue(resource.Value.GetProperty("UpdatedUtc"), $"Backup.CockpitState.Resources.{resource.Name}.UpdatedUtc");
            var valuesElement = resource.Value.GetProperty("Values");
            RequireObject(valuesElement, $"Backup.CockpitState.Resources.{resource.Name}.Values");
            var values = new Dictionary<string, string>(StringComparer.Ordinal);
            foreach (var value in valuesElement.EnumerateObject())
            {
                if (!_cockpitStateRegistry.IsAllowed(resource.Name, value.Name)) throw new InvalidDataException($"Backup.CockpitState contains unrecognized key '{value.Name}' for '{resource.Name}'.");
                values[value.Name] = StringValue(value.Value, $"Backup.CockpitState.Resources.{resource.Name}.Values.{value.Name}", 250_000);
            }
            values = _cockpitStateRegistry.ValidateValues(resource.Name, values, $"Backup.CockpitState.Resources.{resource.Name}");
            output.Resources[resource.Name] = new CockpitResourceState
            {
                ResourceId = resource.Name,
                SourceVersion = sourceVersion,
                MigratedFromWebViewProfile = migrated,
                UpdatedUtc = resourceUpdated,
                Values = values
            };
        }
        return ValidateCockpitStateEnvelope(output, "Backup.CockpitState");
    }

    private bool TryParsePwaCockpitState(JsonElement pwaState, out CockpitStateEnvelope cockpitState, out int promotedCount)
    {
        cockpitState = new CockpitStateEnvelope();
        promotedCount = 0;
        if (!pwaState.TryGetProperty("CockpitStudyState", out var extension)) return false;
        RequireObject(extension, "PwaState.CockpitStudyState");
        EnsureOnlyProperties(extension, "PwaState.CockpitStudyState", "SchemaVersion", "Replace", "Cockpits");
        if (RequiredInt(extension, "SchemaVersion", "PwaState.CockpitStudyState.SchemaVersion") != 1)
            throw new InvalidDataException("Unsupported PWA cockpit-study-state schema.");
        if (!extension.TryGetProperty("Replace", out var replace) || replace.ValueKind is not (JsonValueKind.True or JsonValueKind.False) || !replace.GetBoolean())
            throw new InvalidDataException("PWA cockpit-study-state restore must be a complete replacement.");
        if (!extension.TryGetProperty("Cockpits", out var cockpits)) throw new InvalidDataException("PwaState.CockpitStudyState is missing Cockpits.");
        RequireObject(cockpits, "PwaState.CockpitStudyState.Cockpits");

        // Replace semantics: every Windows-supported cockpit provider becomes authoritative,
        // including an explicit empty provider when the PWA backup had no values for it.
        foreach (var resourceId in _cockpitStateRegistry.ResourceIds)
        {
            var sourceVersion = _sourceVersionByResource.TryGetValue(resourceId, out var hash) ? hash : "";
            cockpitState.Resources[resourceId] = new CockpitResourceState
            {
                ResourceId = resourceId,
                SourceVersion = sourceVersion,
                MigratedFromWebViewProfile = false,
                UpdatedUtc = DateTimeOffset.UtcNow,
                Values = new Dictionary<string, string>(StringComparer.Ordinal)
            };
        }

        foreach (var cockpit in cockpits.EnumerateObject())
        {
            if (!_cockpitStateRegistry.SupportsResource(cockpit.Name)) continue; // e.g. future/native PWA UWorld selector remains opaque.
            RequireObject(cockpit.Value, $"PwaState.CockpitStudyState.Cockpits.{cockpit.Name}");
            EnsureOnlyProperties(cockpit.Value, $"PwaState.CockpitStudyState.Cockpits.{cockpit.Name}", "Values", "LegacyMigration");
            var combined = new Dictionary<string, string>(StringComparer.Ordinal);
            foreach (var bucketName in new[] { "Values", "LegacyMigration" })
            {
                if (!cockpit.Value.TryGetProperty(bucketName, out var bucket)) continue;
                RequireObject(bucket, $"PwaState.CockpitStudyState.Cockpits.{cockpit.Name}.{bucketName}");
                foreach (var pair in bucket.EnumerateObject())
                {
                    if (!_cockpitStateRegistry.IsAllowed(cockpit.Name, pair.Name))
                        throw new InvalidDataException($"PWA cockpit state contains unrecognized key '{pair.Name}' for '{cockpit.Name}'.");
                    if (pair.Value.ValueKind != JsonValueKind.String)
                        throw new InvalidDataException($"PWA cockpit state value '{cockpit.Name}.{pair.Name}' must be a string.");
                    if (!combined.TryAdd(pair.Name, pair.Value.GetString() ?? ""))
                        throw new InvalidDataException($"PWA cockpit state contains duplicate key '{pair.Name}' for '{cockpit.Name}'.");
                }
            }
            var sourceVersion = _sourceVersionByResource.TryGetValue(cockpit.Name, out var hash) ? hash : "";
            cockpitState.Resources[cockpit.Name] = new CockpitResourceState
            {
                ResourceId = cockpit.Name,
                SourceVersion = sourceVersion,
                MigratedFromWebViewProfile = false,
                UpdatedUtc = DateTimeOffset.UtcNow,
                Values = _cockpitStateRegistry.ValidateValues(cockpit.Name, combined, $"PwaState.CockpitStudyState.{cockpit.Name}")
            };
            promotedCount++;
        }
        cockpitState.UpdatedUtc = DateTimeOffset.UtcNow;
        cockpitState = ValidateCockpitStateEnvelope(cockpitState, "PWA promoted cockpit state");
        return true;
    }

    private bool TryParsePwaJournal(JsonElement pwaState, out JournalState journal, out int promotedCount)
    {
        journal = new JournalState();
        promotedCount = 0;
        if (!pwaState.TryGetProperty("Journal", out var extension)) return false;
        RequireObject(extension, "PwaState.Journal");
        EnsureOnlyProperties(extension, "PwaState.Journal", "SchemaVersion", "Replace", "StorageVersion", "Entries");
        if (RequiredInt(extension, "SchemaVersion", "PwaState.Journal.SchemaVersion") != 1)
            throw new InvalidDataException("Unsupported PWA Journal schema.");
        if (!extension.TryGetProperty("Replace", out var replace) || replace.ValueKind is not (JsonValueKind.True or JsonValueKind.False) || !replace.GetBoolean())
            throw new InvalidDataException("PWA Journal restore must be a complete replacement.");
        if (!extension.TryGetProperty("Entries", out var entriesElement)) throw new InvalidDataException("PwaState.Journal is missing Entries.");
        RequireArray(entriesElement, "PwaState.Journal.Entries");

        var entries = new List<JournalEntry>();
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var index = 0;
        foreach (var item in entriesElement.EnumerateArray())
        {
            if (index >= JournalService.MaxEntries) throw new InvalidDataException($"PwaState.Journal exceeds the {JournalService.MaxEntries:N0}-entry safety limit.");
            var label = $"PwaState.Journal.Entries[{index}]";
            RequireObject(item, label);
            EnsureOnlyProperties(item, label, "Id", "Title", "Body", "Slug", "SourceVersion", "SourceLocation", "OriginalTimestampKnown", "CreatedUtc", "UpdatedUtc");
            var id = RequiredString(item, "Id", label + ".Id", 240);
            if (!seen.Add(id)) throw new InvalidDataException($"PwaState.Journal contains duplicate entry id '{id}'.");
            var title = RequiredString(item, "Title", label + ".Title", JournalService.MaxTitleLength).Trim();
            if (title.Length == 0) throw new InvalidDataException(label + " requires a nonblank title.");
            var body = item.TryGetProperty("Body", out var bodyElement) ? StringValue(bodyElement, label + ".Body", JournalService.MaxBodyLength) : "";
            var rawSlug = item.TryGetProperty("Slug", out var slugElement) ? StringValue(slugElement, label + ".Slug", 240).Trim() : "";
            var slug = rawSlug.Length == 0 ? "" : MapSlug(rawSlug, label + ".Slug");
            var created = item.TryGetProperty("CreatedUtc", out var createdElement)
                ? DateValue(createdElement, label + ".CreatedUtc")
                : throw new InvalidDataException(label + ".CreatedUtc is required for native promotion.");
            var updated = item.TryGetProperty("UpdatedUtc", out var updatedElement)
                ? DateValue(updatedElement, label + ".UpdatedUtc")
                : throw new InvalidDataException(label + ".UpdatedUtc is required for native promotion.");

            StudyLocationState? location = null;
            if (item.TryGetProperty("SourceLocation", out var locationElement) && locationElement.ValueKind != JsonValueKind.Null)
            {
                if (slug.Length == 0) throw new InvalidDataException(label + ".SourceLocation requires cockpit ownership.");
                location = ParsePwaJournalSourceLocation(locationElement, label + ".SourceLocation", slug);
            }

            var sourceVersion = "";
            if (slug.Length > 0)
            {
                if (!_sourceVersionByResource.TryGetValue(slug, out var expected)) throw new InvalidDataException(label + ".Slug has no canonical source identity.");
                sourceVersion = expected;
                if (location is not null && !location.SourceVersion.Equals(expected, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException(label + ".SourceLocation belongs to a different frozen source version.");
            }

            entries.Add(new JournalEntry
            {
                Id = id,
                Title = title,
                Body = body,
                Slug = slug,
                SourceVersion = sourceVersion,
                SourceLocation = location,
                OriginalTimestampKnown = true,
                CreatedUtc = created,
                UpdatedUtc = updated
            });
            index++;
        }

        journal = JournalService.CloneState(new JournalState
        {
            SchemaVersion = JournalService.SchemaVersion,
            UpdatedUtc = DateTimeOffset.UtcNow,
            Entries = entries
        });
        promotedCount = journal.Entries.Count;
        return true;
    }

    private StudyLocationState ParsePwaJournalSourceLocation(JsonElement element, string label, string owningResourceId)
    {
        RequireObject(element, label);
        EnsureOnlyProperties(element, label, "SchemaVersion", "Slug", "SourceVersion", "Purpose", "Anchor", "TargetId", "TargetPath", "Context", "OffsetY", "TargetOffsetY", "Hash", "ScrollX", "ScrollY", "OpenDetails", "UpdatedUtc");
        var schema = RequiredInt(element, "SchemaVersion", label + ".SchemaVersion");
        if (schema != PathfinderLocation.CurrentSchemaVersion) throw new InvalidDataException(label + ".SchemaVersion is unsupported.");
        var slug = RequiredString(element, "Slug", label + ".Slug", 240);
        if (!slug.Equals(owningResourceId, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException(label + ".Slug does not match its Journal owner.");
        var sourceVersion = RequiredString(element, "SourceVersion", label + ".SourceVersion", 128).ToLowerInvariant();
        if (!_sourceVersionByResource.TryGetValue(owningResourceId, out var expected))
            throw new InvalidDataException(label + ".SourceVersion has no installed source identity.");
        var selectorTranslation = owningResourceId.Equals(UWorldSelectorService.ResourceId, StringComparison.OrdinalIgnoreCase)
                                  && sourceVersion.Equals(AcceptedPwaSelectorSourceVersion, StringComparison.OrdinalIgnoreCase);
        if (!sourceVersion.Equals(expected, StringComparison.OrdinalIgnoreCase) && !selectorTranslation)
            throw new InvalidDataException(label + ".SourceVersion does not match the installed source contract.");
        if (selectorTranslation) sourceVersion = expected;
        var purpose = RequiredString(element, "Purpose", label + ".Purpose", 32);
        if (!purpose.Equals("source", StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException(label + ".Purpose must be source.");

        var result = new StudyLocationState
        {
            SchemaVersion = PathfinderLocation.CurrentSchemaVersion,
            ResourceId = owningResourceId,
            SourceVersion = sourceVersion,
            Purpose = "source",
            Anchor = OptionalString(element, "Anchor", "", label + ".Anchor", 1024),
            TargetId = OptionalString(element, "TargetId", "", label + ".TargetId", 1024),
            TargetPath = OptionalString(element, "TargetPath", "", label + ".TargetPath", 2000),
            Context = OptionalString(element, "Context", "", label + ".Context", 1000),
            OffsetY = OptionalFiniteDouble(element, "OffsetY", 0, label + ".OffsetY", -100_000_000, 100_000_000),
            TargetOffsetY = OptionalFiniteDouble(element, "TargetOffsetY", 0, label + ".TargetOffsetY", -100_000_000, 100_000_000),
            Hash = OptionalString(element, "Hash", "", label + ".Hash", 1024),
            ScrollX = OptionalFiniteDouble(element, "ScrollX", 0, label + ".ScrollX", 0, 100_000_000),
            ScrollY = OptionalFiniteDouble(element, "ScrollY", 0, label + ".ScrollY", 0, 100_000_000),
            UpdatedUtc = element.TryGetProperty("UpdatedUtc", out var updated) ? DateValue(updated, label + ".UpdatedUtc") : DateTimeOffset.UtcNow
        };
        if (element.TryGetProperty("OpenDetails", out var details))
        {
            RequireArray(details, label + ".OpenDetails");
            foreach (var item in details.EnumerateArray())
            {
                if (result.OpenDetails.Count >= 30) throw new InvalidDataException(label + ".OpenDetails exceeds the 30-item safety limit.");
                var id = StringValue(item, label + ".OpenDetails", 1024);
                if (!result.OpenDetails.Contains(id, StringComparer.Ordinal)) result.OpenDetails.Add(id);
            }
        }
        if (result.TargetId.Length == 0 && result.TargetPath.Length == 0 && result.Context.Length == 0)
            throw new InvalidDataException(label + " is missing strict target identity.");
        return result;
    }

    private JsonElement StripPromotedPwaProviders(JsonElement pwaState, bool promotedCockpitState, bool promotedJournal, bool promotedSelector)
    {
        try
        {
            var node = JsonNode.Parse(pwaState.GetRawText()) as JsonObject;
            if (node is null) return pwaState.Clone();
            if (promotedCockpitState && node["CockpitStudyState"] is JsonObject extension && extension["Cockpits"] is JsonObject cockpits)
            {
                foreach (var resourceId in _cockpitStateRegistry.ResourceIds.ToList()) cockpits.Remove(resourceId);
                if (cockpits.Count == 0) node.Remove("CockpitStudyState");
            }
            if (promotedSelector && node["CockpitStudyState"] is JsonObject selectorExtension && selectorExtension["Cockpits"] is JsonObject selectorCockpits)
            {
                selectorCockpits.Remove(UWorldSelectorService.ResourceId);
                if (selectorCockpits.Count == 0) node.Remove("CockpitStudyState");
            }
            if (promotedJournal) node.Remove("Journal");
            using var doc = JsonDocument.Parse(node.ToJsonString());
            return doc.RootElement.Clone();
        }
        catch
        {
            return pwaState.Clone();
        }
    }

    private CockpitStateEnvelope ValidateCockpitStateEnvelope(CockpitStateEnvelope state, string label)
    {
        if (state.SchemaVersion != CockpitStateService.SchemaVersion) throw new InvalidDataException($"{label} has an unsupported schema.");
        var output = new CockpitStateEnvelope { SchemaVersion = CockpitStateService.SchemaVersion, UpdatedUtc = state.UpdatedUtc == default ? DateTimeOffset.UtcNow : state.UpdatedUtc };
        var count = 0;
        foreach (var pair in state.Resources ?? [])
        {
            if (++count > _cockpitStateRegistry.ResourceCount) throw new InvalidDataException($"{label} has too many resource providers.");
            if (!_cockpitStateRegistry.SupportsResource(pair.Key)) throw new InvalidDataException($"{label} contains unsupported resource '{pair.Key}'.");
            var source = pair.Value ?? new CockpitResourceState();
            var sourceVersion = string.IsNullOrWhiteSpace(source.SourceVersion) && _sourceVersionByResource.TryGetValue(pair.Key, out var expected) ? expected : source.SourceVersion;
            if (sourceVersion.Length != 64 || !sourceVersion.All(Uri.IsHexDigit)) throw new InvalidDataException($"{label}.{pair.Key} has invalid source identity.");
            if (_sourceVersionByResource.TryGetValue(pair.Key, out var expectedHash) && !sourceVersion.Equals(expectedHash, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException($"{label}.{pair.Key} belongs to a different frozen source version.");
            output.Resources[pair.Key] = new CockpitResourceState
            {
                ResourceId = pair.Key,
                SourceVersion = sourceVersion.ToLowerInvariant(),
                MigratedFromWebViewProfile = source.MigratedFromWebViewProfile,
                UpdatedUtc = source.UpdatedUtc == default ? DateTimeOffset.UtcNow : source.UpdatedUtc,
                Values = _cockpitStateRegistry.ValidateValues(pair.Key, source.Values ?? [], label + "." + pair.Key)
            };
        }
        return output;
    }

    private ShellSettings ParseShellSettings(JsonElement element, ShellSettings current, bool canonical, int sourceSchema, List<string> warnings)
    {
        RequireObject(element, "ShellSettings");
        if (canonical)
        {
            if (sourceSchema >= 5)
            {
                EnsureOnlyProperties(element, "ShellSettings",
                    "ThemeId", "RestoreLastSession", "StrongFocusIndicators", "ReduceMotion", "ComfortableReadingSpacing",
                    "LastSessionTabs", "LastSelectedTabIndex", "RestoreSplitWorkspace", "LastWorkspaceSplitEnabled",
                    "LastWorkspaceSecondaryKind", "LastWorkspaceSecondaryId", "LastWorkspaceSplitRatio");
                RequireProperties(element, "ShellSettings",
                    "ThemeId", "RestoreLastSession", "StrongFocusIndicators", "ReduceMotion", "ComfortableReadingSpacing",
                    "LastSessionTabs", "LastSelectedTabIndex", "RestoreSplitWorkspace", "LastWorkspaceSplitEnabled",
                    "LastWorkspaceSecondaryKind", "LastWorkspaceSecondaryId", "LastWorkspaceSplitRatio");
            }
            else
            {
                EnsureOnlyProperties(element, "ShellSettings",
                    "ThemeId", "RestoreLastSession", "StrongFocusIndicators", "ReduceMotion", "ComfortableReadingSpacing",
                    "LastSessionTabs", "LastSelectedTabIndex");
                RequireProperties(element, "ShellSettings",
                    "ThemeId", "RestoreLastSession", "StrongFocusIndicators", "ReduceMotion", "ComfortableReadingSpacing",
                    "LastSessionTabs", "LastSelectedTabIndex");
            }
        }
        var next = canonical ? new ShellSettings() : CloneSettings(current);

        if (element.TryGetProperty("ThemeId", out var theme)) next.ThemeId = StringValue(theme, "ShellSettings.ThemeId", 100);
        else if (canonical) throw new InvalidDataException("Canonical ShellSettings.ThemeId is required.");

        if (element.TryGetProperty("RestoreLastSession", out var restore)) next.RestoreLastSession = BoolValue(restore, "ShellSettings.RestoreLastSession");
        else if (canonical) throw new InvalidDataException("Canonical ShellSettings.RestoreLastSession is required.");

        ReadNativeBool(element, "StrongFocusIndicators", canonical, current.StrongFocusIndicators, v => next.StrongFocusIndicators = v, warnings);
        ReadNativeBool(element, "ReduceMotion", canonical, current.ReduceMotion, v => next.ReduceMotion = v, warnings);
        ReadNativeBool(element, "ComfortableReadingSpacing", canonical, current.ComfortableReadingSpacing, v => next.ComfortableReadingSpacing = v, warnings);

        HashSet<int> skippedSourceTabIndices = [];
        if (element.TryGetProperty("LastSessionTabs", out var tabsElement))
            next.LastSessionTabs = ParseSessionTabs(tabsElement, warnings, canonical, out skippedSourceTabIndices);
        else if (canonical)
            throw new InvalidDataException("Canonical ShellSettings.LastSessionTabs is required.");
        else
            next.LastSessionTabs = [];

        if (element.TryGetProperty("LastSelectedTabIndex", out var indexElement))
        {
            if (indexElement.ValueKind != JsonValueKind.Number || !indexElement.TryGetInt32(out var index) || index < 0)
                throw new InvalidDataException("ShellSettings.LastSelectedTabIndex is invalid.");
            if (!canonical && index > 0 && skippedSourceTabIndices.Count > 0)
            {
                var skippedBefore = skippedSourceTabIndices.Count(x => x < index);
                if (skippedSourceTabIndices.Contains(index))
                {
                    warnings.Add("The legacy selected tab has no faithful current Windows live-tab equivalent; Pathfinder will select the nearest safe preceding restored tab instead.");
                    index = Math.Max(0, index - 1 - skippedBefore);
                }
                else
                {
                    index = Math.Max(0, index - skippedBefore);
                }
            }
            if (index > next.LastSessionTabs.Count)
            {
                if (canonical) throw new InvalidDataException("ShellSettings.LastSelectedTabIndex is outside the restored tab range.");
                warnings.Add("The legacy selected-tab index referred to a tab that cannot be represented in the current Windows session; Pathfinder will select the nearest safe restored tab instead.");
                index = next.LastSessionTabs.Count;
            }
            next.LastSelectedTabIndex = index;
        }
        else if (canonical)
        {
            throw new InvalidDataException("Canonical ShellSettings.LastSelectedTabIndex is required.");
        }
        else
        {
            next.LastSelectedTabIndex = 0;
        }

        if (sourceSchema >= 5 && canonical)
        {
            next.RestoreSplitWorkspace = BoolValue(element.GetProperty("RestoreSplitWorkspace"), "ShellSettings.RestoreSplitWorkspace");
            next.LastWorkspaceSplitEnabled = BoolValue(element.GetProperty("LastWorkspaceSplitEnabled"), "ShellSettings.LastWorkspaceSplitEnabled");
            next.LastWorkspaceSecondaryKind = StringValue(element.GetProperty("LastWorkspaceSecondaryKind"), "ShellSettings.LastWorkspaceSecondaryKind", 40);
            next.LastWorkspaceSecondaryId = StringValue(element.GetProperty("LastWorkspaceSecondaryId"), "ShellSettings.LastWorkspaceSecondaryId", 200);
            next.LastWorkspaceSplitRatio = OptionalFiniteDouble(element, "LastWorkspaceSplitRatio", 0.5, "ShellSettings.LastWorkspaceSplitRatio", 0.20, 0.80);
            var splitKinds = new HashSet<string>(["", "study", "readonly-study", "shell"], StringComparer.OrdinalIgnoreCase);
            if (!splitKinds.Contains(next.LastWorkspaceSecondaryKind))
                throw new InvalidDataException("ShellSettings.LastWorkspaceSecondaryKind is unsupported.");
            if (next.LastWorkspaceSplitEnabled)
            {
                var hasSecondaryKind = !string.IsNullOrWhiteSpace(next.LastWorkspaceSecondaryKind);
                var hasSecondaryId = !string.IsNullOrWhiteSpace(next.LastWorkspaceSecondaryId);
                // W5 schema 6 allows Split View to be intentionally open with an empty secondary
                // slot. W4 schema 5 never emitted that state, so keep its stricter contract when
                // validating an older canonical backup.
                if (sourceSchema < 6 && (!hasSecondaryKind || !hasSecondaryId))
                    throw new InvalidDataException("Enabled schema-5 Split View requires a secondary kind and id.");
                if (sourceSchema >= 6 && hasSecondaryKind != hasSecondaryId)
                    throw new InvalidDataException("Canonical Split View secondary kind and id must either both be present or both be empty.");
                if (hasSecondaryKind && hasSecondaryId)
                {
                    if ((next.LastWorkspaceSecondaryKind.Equals("study", StringComparison.OrdinalIgnoreCase) || next.LastWorkspaceSecondaryKind.Equals("readonly-study", StringComparison.OrdinalIgnoreCase))
                        && !_knownSlugs.Contains(next.LastWorkspaceSecondaryId))
                        throw new InvalidDataException("Canonical Split View refers to an unknown study resource.");
                    if (next.LastWorkspaceSecondaryKind.Equals("shell", StringComparison.OrdinalIgnoreCase)
                        && !next.LastWorkspaceSecondaryId.Equals("Search", StringComparison.OrdinalIgnoreCase)
                        && !next.LastWorkspaceSecondaryId.Equals("Glossary", StringComparison.OrdinalIgnoreCase)
                        && !next.LastWorkspaceSecondaryId.Equals("Journal", StringComparison.OrdinalIgnoreCase)
                        && !next.LastWorkspaceSecondaryId.Equals("UWorld Selector", StringComparison.OrdinalIgnoreCase))
                        throw new InvalidDataException("Canonical Split View refers to an unsupported tool workspace.");
                }
            }
            else if (!string.IsNullOrWhiteSpace(next.LastWorkspaceSecondaryKind) || !string.IsNullOrWhiteSpace(next.LastWorkspaceSecondaryId))
            {
                throw new InvalidDataException("Disabled canonical Split View must not retain a secondary assignment.");
            }
        }
        else if (!canonical)
        {
            // Legacy/PWA imports cannot describe the richer Windows workspace; preserve
            // the current native split preference rather than silently resetting it.
            next.RestoreSplitWorkspace = current.RestoreSplitWorkspace;
            next.LastWorkspaceSplitEnabled = false;
            next.LastWorkspaceSecondaryKind = "";
            next.LastWorkspaceSecondaryId = "";
            next.LastWorkspaceSplitRatio = current.LastWorkspaceSplitRatio;
        }
        else
        {
            // Canonical schemas 2–4 predate W4. Import safely with split closed.
            next.RestoreSplitWorkspace = true;
            next.LastWorkspaceSplitEnabled = false;
            next.LastWorkspaceSecondaryKind = "";
            next.LastWorkspaceSecondaryId = "";
            next.LastWorkspaceSplitRatio = 0.5;
            warnings.Add("This older Windows canonical backup predates Split View workspace persistence; tabs restore normally and Split View starts closed.");
        }

        if (string.IsNullOrWhiteSpace(next.ThemeId)) next.ThemeId = "light";
        if (_knownThemeIds.Count > 0 && !_knownThemeIds.Contains(next.ThemeId))
            warnings.Add($"Theme '{next.ThemeId}' is retained in the restored/canonical data, but this Windows build cannot render it yet and will visually use the current default theme until support is added.");
        return next;
    }

    private static void ReadNativeBool(JsonElement parent, string propertyName, bool canonical, bool currentValue, Action<bool> setter, List<string> warnings)
    {
        if (parent.TryGetProperty(propertyName, out var element))
        {
            setter(BoolValue(element, "ShellSettings." + propertyName));
            return;
        }
        if (canonical) throw new InvalidDataException($"Canonical ShellSettings.{propertyName} is required.");
        setter(currentValue);
        warnings.Add($"Legacy backup does not contain Windows-only setting {propertyName}; the current Windows value will be preserved.");
    }

    private List<SessionTabState> ParseSessionTabs(JsonElement element, List<string> warnings, bool canonical, out HashSet<int> skippedSourceTabIndices)
    {
        skippedSourceTabIndices = [];
        RequireArray(element, "ShellSettings.LastSessionTabs");
        var tabs = new List<SessionTabState>();
        var index = 0;
        foreach (var item in element.EnumerateArray())
        {
            if (index >= 100) throw new InvalidDataException("ShellSettings.LastSessionTabs exceeds the 100-tab safety limit.");
            RequireObject(item, $"LastSessionTabs[{index}]");
            if (canonical)
            {
                EnsureOnlyProperties(item, $"LastSessionTabs[{index}]", "Kind", "Id", "IsPinned", "HasLocation", "Hash", "ScrollX", "ScrollY");
                RequireProperties(item, $"LastSessionTabs[{index}]", "Kind", "Id", "IsPinned", "HasLocation", "Hash", "ScrollX", "ScrollY");
            }
            var kindRaw = RequiredString(item, "Kind", $"LastSessionTabs[{index}].Kind", 40);
            var idRaw = RequiredString(item, "Id", $"LastSessionTabs[{index}].Id", 200);
            var pinned = OptionalBool(item, "IsPinned", false, $"LastSessionTabs[{index}].IsPinned");
            var hasLocation = OptionalBool(item, "HasLocation", false, $"LastSessionTabs[{index}].HasLocation");
            var hash = OptionalString(item, "Hash", "", $"LastSessionTabs[{index}].Hash", 1024);
            var scrollX = OptionalFiniteDouble(item, "ScrollX", 0, $"LastSessionTabs[{index}].ScrollX", 0, 100_000_000);
            var scrollY = OptionalFiniteDouble(item, "ScrollY", 0, $"LastSessionTabs[{index}].ScrollY", 0, 100_000_000);

            if (kindRaw.Equals("study", StringComparison.OrdinalIgnoreCase) || kindRaw.Equals("subject", StringComparison.OrdinalIgnoreCase))
            {
                if (idRaw.Equals(UWorldSelectorService.ResourceId, StringComparison.OrdinalIgnoreCase))
                {
                    if (canonical) throw new InvalidDataException($"LastSessionTabs[{index}].Id uses the PWA study-tab identity for the native Selector; canonical Windows backups must store it as a shell tool tab.");
                    tabs.Add(new SessionTabState { Kind = "shell", Id = "UWorld Selector", IsPinned = false, HasLocation = false });
                    index++;
                    continue;
                }
                tabs.Add(new SessionTabState
                {
                    Kind = "study",
                    Id = MapSlug(idRaw, $"LastSessionTabs[{index}].Id"),
                    IsPinned = pinned,
                    HasLocation = hasLocation,
                    Hash = hash,
                    ScrollX = scrollX,
                    ScrollY = scrollY
                });
            }
            else
            {
                string windowsId;
                if (kindRaw.Equals("shell", StringComparison.OrdinalIgnoreCase))
                {
                    windowsId = NormalizeWindowsUtilityId(idRaw, $"LastSessionTabs[{index}].Id");
                }
                else if (PwaUtilityToWindows.TryGetValue(kindRaw, out var mapped))
                {
                    windowsId = mapped;
                }
                else
                {
                    throw new InvalidDataException($"LastSessionTabs[{index}] has unsupported tab kind '{kindRaw}'.");
                }

                tabs.Add(new SessionTabState { Kind = "shell", Id = windowsId, IsPinned = false, HasLocation = false });
            }
            index++;
        }
        return tabs;
    }

    private PersonalStudyState ParsePersonalStudy(JsonElement element, List<string> warnings, bool isPwaLegacy, bool canonical, int backupSchema)
    {
        RequireObject(element, "PersonalStudy");
        if (canonical)
        {
            EnsureOnlyProperties(element, "PersonalStudy", "SchemaVersion", "ShowProgress", "FavoriteSlugs", "RecentSubjects", "ProgressBySlug", "PositionsBySlug", "SubjectNotes", "Bookmarks");
            RequireProperties(element, "PersonalStudy", "SchemaVersion", "ShowProgress", "FavoriteSlugs", "RecentSubjects", "ProgressBySlug", "PositionsBySlug", "SubjectNotes", "Bookmarks");
        }
        if (element.TryGetProperty("SchemaVersion", out var version))
        {
            if (version.ValueKind != JsonValueKind.Number || !version.TryGetInt32(out var v) || v != 1)
                throw new InvalidDataException("Unsupported PersonalStudy schema.");
        }
        else if (canonical) throw new InvalidDataException("Canonical PersonalStudy.SchemaVersion is required.");

        var state = new PersonalStudyState { SchemaVersion = 1 };
        if (element.TryGetProperty("ShowProgress", out var show)) state.ShowProgress = BoolValue(show, "PersonalStudy.ShowProgress");
        else if (canonical) throw new InvalidDataException("Canonical PersonalStudy.ShowProgress is required.");
        state.FavoriteSlugs = ParseSlugSet(element, "FavoriteSlugs", 500, warnings, isPwaLegacy, canonical);
        state.RecentSubjects = ParseRecent(element, warnings, isPwaLegacy, canonical);
        state.ProgressBySlug = ParseStringMapBySlug(element, "ProgressBySlug", 500, 80, validateProgress: true, warnings, isPwaLegacy, canonical);
        state.PositionsBySlug = ParsePositions(element, warnings, canonical, backupSchema);
        state.SubjectNotes = ParseStringMapBySlug(element, "SubjectNotes", 500, 500_000, validateProgress: false, warnings, isPwaLegacy, canonical);
        state.Bookmarks = ParseBookmarks(element, warnings, canonical, backupSchema);
        return state;
    }

    private HashSet<string> ParseSlugSet(JsonElement parent, string name, int max, List<string> warnings, bool isPwaLegacy, bool canonical)
    {
        var result = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        if (!parent.TryGetProperty(name, out var element))
        {
            if (canonical) throw new InvalidDataException($"Canonical PersonalStudy.{name} is required.");
            return result;
        }
        RequireArray(element, "PersonalStudy." + name);
        var count = 0;
        foreach (var item in element.EnumerateArray())
        {
            if (++count > max) throw new InvalidDataException($"PersonalStudy.{name} exceeds the {max}-item safety limit.");
            var rawSlug = StringValue(item, $"PersonalStudy.{name}[{count - 1}]", 200);
            if (ShouldPreservePwaSelectorOnly(rawSlug, isPwaLegacy, warnings, $"PersonalStudy.{name}")) continue;
            var slug = MapSlug(rawSlug, $"PersonalStudy.{name}[{count - 1}]");
            if (!result.Add(slug)) throw new InvalidDataException($"PersonalStudy.{name} contains duplicate slug '{slug}'.");
        }
        return result;
    }

    private List<RecentStudyItem> ParseRecent(JsonElement parent, List<string> warnings, bool isPwaLegacy, bool canonical)
    {
        var result = new List<RecentStudyItem>();
        if (!parent.TryGetProperty("RecentSubjects", out var element))
        {
            if (canonical) throw new InvalidDataException("Canonical PersonalStudy.RecentSubjects is required.");
            return result;
        }
        RequireArray(element, "PersonalStudy.RecentSubjects");
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var index = 0;
        foreach (var item in element.EnumerateArray())
        {
            if (index >= 100) throw new InvalidDataException("PersonalStudy.RecentSubjects exceeds the 100-item safety limit.");
            RequireObject(item, $"RecentSubjects[{index}]");
            if (canonical)
            {
                EnsureOnlyProperties(item, $"RecentSubjects[{index}]", "Slug", "LastOpenedUtc");
                RequireProperties(item, $"RecentSubjects[{index}]", "Slug", "LastOpenedUtc");
            }
            var rawSlug = RequiredString(item, "Slug", $"RecentSubjects[{index}].Slug", 200);
            if (ShouldPreservePwaSelectorOnly(rawSlug, isPwaLegacy, warnings, "PersonalStudy.RecentSubjects")) { index++; continue; }
            var slug = MapSlug(rawSlug, $"RecentSubjects[{index}].Slug");
            if (!seen.Add(slug)) throw new InvalidDataException($"RecentSubjects contains duplicate slug '{slug}'.");
            var when = item.TryGetProperty("LastOpenedUtc", out var date) ? DateValue(date, $"RecentSubjects[{index}].LastOpenedUtc")
                : canonical ? throw new InvalidDataException($"Canonical RecentSubjects[{index}].LastOpenedUtc is required.") : DateTimeOffset.UtcNow;
            result.Add(new RecentStudyItem { Slug = slug, LastOpenedUtc = when });
            index++;
        }
        return result.OrderByDescending(x => x.LastOpenedUtc).Take(12).ToList();
    }

    private Dictionary<string, string> ParseStringMapBySlug(JsonElement parent, string name, int maxEntries, int maxValueLength, bool validateProgress, List<string> warnings, bool isPwaLegacy, bool canonical)
    {
        var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if (!parent.TryGetProperty(name, out var element))
        {
            if (canonical) throw new InvalidDataException($"Canonical PersonalStudy.{name} is required.");
            return result;
        }
        RequireObject(element, "PersonalStudy." + name);
        foreach (var property in element.EnumerateObject())
        {
            if (result.Count >= maxEntries) throw new InvalidDataException($"PersonalStudy.{name} exceeds the {maxEntries}-entry safety limit.");
            if (ShouldPreservePwaSelectorOnly(property.Name, isPwaLegacy, warnings, $"PersonalStudy.{name}")) continue;
            var slug = MapSlug(property.Name, $"PersonalStudy.{name} key");
            if (result.ContainsKey(slug)) throw new InvalidDataException($"PersonalStudy.{name} maps more than one source resource to '{slug}'.");
            var value = StringValue(property.Value, $"PersonalStudy.{name}.{slug}", maxValueLength);
            if (validateProgress && !AllowedProgress.Contains(value)) throw new InvalidDataException($"PersonalStudy.{name}.{slug} has unsupported progress value '{value}'.");
            result[slug] = value;
        }
        return result;
    }

    private Dictionary<string, StudyLocationState> ParsePositions(JsonElement parent, List<string> warnings, bool canonical, int backupSchema)
    {
        var result = new Dictionary<string, StudyLocationState>(StringComparer.OrdinalIgnoreCase);
        if (!parent.TryGetProperty("PositionsBySlug", out var element))
        {
            if (canonical) throw new InvalidDataException("Canonical PersonalStudy.PositionsBySlug is required.");
            return result;
        }
        RequireObject(element, "PersonalStudy.PositionsBySlug");
        foreach (var property in element.EnumerateObject())
        {
            if (result.Count >= 500) throw new InvalidDataException("PersonalStudy.PositionsBySlug exceeds the 500-entry safety limit.");
            if (property.Name.Equals("extra-uworld-selector", StringComparison.OrdinalIgnoreCase))
            {
                warnings.Add("A PWA UWorld Selector reading position was not mapped onto the legacy Windows PDF because they are not the same source. The richer PWA source/location state remains preserved opaquely when present.");
                continue;
            }
            var slug = MapSlug(property.Name, "PersonalStudy.PositionsBySlug key");
            if (result.ContainsKey(slug)) throw new InvalidDataException($"PersonalStudy.PositionsBySlug maps more than one source resource to '{slug}'.");
            result[slug] = ParseLocation(property.Value, $"PersonalStudy.PositionsBySlug.{slug}", canonical, backupSchema, slug);
        }
        return result;
    }

    private List<StudyBookmark> ParseBookmarks(JsonElement parent, List<string> warnings, bool canonical, int backupSchema)
    {
        var result = new List<StudyBookmark>();
        if (!parent.TryGetProperty("Bookmarks", out var element))
        {
            if (canonical) throw new InvalidDataException("Canonical PersonalStudy.Bookmarks is required.");
            return result;
        }
        RequireArray(element, "PersonalStudy.Bookmarks");
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var index = 0;
        foreach (var item in element.EnumerateArray())
        {
            if (index >= 5000) throw new InvalidDataException("PersonalStudy.Bookmarks exceeds the 5000-item safety limit.");
            RequireObject(item, $"Bookmarks[{index}]");
            if (canonical)
            {
                EnsureOnlyProperties(item, $"Bookmarks[{index}]", "Id", "Slug", "Name", "Note", "Location", "CreatedUtc");
                RequireProperties(item, $"Bookmarks[{index}]", "Id", "Slug", "Name", "Note", "Location", "CreatedUtc");
            }
            var id = RequiredString(item, "Id", $"Bookmarks[{index}].Id", 240);
            if (!seen.Add(id)) throw new InvalidDataException($"Bookmarks contains duplicate ID '{id}'.");
            var rawSlug = RequiredString(item, "Slug", $"Bookmarks[{index}].Slug", 200);
            if (rawSlug.Equals("extra-uworld-selector", StringComparison.OrdinalIgnoreCase))
            {
                warnings.Add("A PWA UWorld Selector source bookmark was not redirected to the legacy Windows PDF. Its source record remains preserved in the PWA extension when present.");
                index++;
                continue;
            }
            var slug = MapSlug(rawSlug, $"Bookmarks[{index}].Slug");
            if (!item.TryGetProperty("Location", out var loc)) throw new InvalidDataException($"Bookmarks[{index}] is missing Location.");
            result.Add(new StudyBookmark
            {
                Id = id,
                Slug = slug,
                Name = OptionalString(item, "Name", "", $"Bookmarks[{index}].Name", 1000),
                Note = OptionalString(item, "Note", "", $"Bookmarks[{index}].Note", 20_000),
                Location = ParseLocation(loc, $"Bookmarks[{index}].Location", canonical, backupSchema, slug),
                CreatedUtc = item.TryGetProperty("CreatedUtc", out var created) ? DateValue(created, $"Bookmarks[{index}].CreatedUtc")
                    : canonical ? throw new InvalidDataException($"Canonical Bookmarks[{index}].CreatedUtc is required.") : DateTimeOffset.UtcNow
            });
            index++;
        }
        return result;
    }

    private static StudyLocationState ParseLocation(JsonElement element, string label, bool canonical, int backupSchema, string owningResourceId)
    {
        RequireObject(element, label);
        var rich = canonical && backupSchema >= 3;
        if (canonical)
        {
            if (rich)
            {
                EnsureOnlyProperties(element, label, "SchemaVersion", "ResourceId", "SourceVersion", "Purpose", "Anchor", "TargetId", "TargetPath", "Context", "OffsetY", "TargetOffsetY", "Hash", "ScrollX", "ScrollY", "OpenDetails", "UpdatedUtc");
                RequireProperties(element, label, "SchemaVersion", "ResourceId", "SourceVersion", "Purpose", "Anchor", "TargetId", "TargetPath", "Context", "OffsetY", "TargetOffsetY", "Hash", "ScrollX", "ScrollY", "OpenDetails", "UpdatedUtc");
            }
            else
            {
                EnsureOnlyProperties(element, label, "Hash", "ScrollX", "ScrollY", "UpdatedUtc");
                RequireProperties(element, label, "Hash", "ScrollX", "ScrollY", "UpdatedUtc");
            }
        }

        var result = new StudyLocationState
        {
            SchemaVersion = rich ? RequiredInt(element, "SchemaVersion", label + ".SchemaVersion") : 1,
            ResourceId = rich ? RequiredString(element, "ResourceId", label + ".ResourceId", 200) : owningResourceId,
            SourceVersion = rich ? RequiredString(element, "SourceVersion", label + ".SourceVersion", 128) : "",
            Purpose = rich ? RequiredString(element, "Purpose", label + ".Purpose", 32) : "resume",
            Anchor = rich ? RequiredString(element, "Anchor", label + ".Anchor", 1024) : "",
            TargetId = rich ? RequiredString(element, "TargetId", label + ".TargetId", 1024) : "",
            TargetPath = rich ? RequiredString(element, "TargetPath", label + ".TargetPath", 2000) : "",
            Context = rich ? RequiredString(element, "Context", label + ".Context", 1000) : "",
            OffsetY = rich ? OptionalFiniteDouble(element, "OffsetY", 0, label + ".OffsetY", -100_000_000, 100_000_000) : 0,
            TargetOffsetY = rich ? OptionalFiniteDouble(element, "TargetOffsetY", 0, label + ".TargetOffsetY", -100_000_000, 100_000_000) : 0,
            Hash = OptionalString(element, "Hash", "", label + ".Hash", 1024),
            ScrollX = OptionalFiniteDouble(element, "ScrollX", 0, label + ".ScrollX", 0, 100_000_000),
            ScrollY = OptionalFiniteDouble(element, "ScrollY", 0, label + ".ScrollY", 0, 100_000_000),
            UpdatedUtc = element.TryGetProperty("UpdatedUtc", out var updated) ? DateValue(updated, label + ".UpdatedUtc")
                : canonical ? throw new InvalidDataException($"Canonical {label}.UpdatedUtc is required.") : DateTimeOffset.UtcNow
        };
        if (rich)
        {
            if (result.SchemaVersion != PathfinderLocation.CurrentSchemaVersion) throw new InvalidDataException($"{label}.SchemaVersion is unsupported.");
            if (!result.ResourceId.Equals(owningResourceId, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException($"{label}.ResourceId does not match its owning Pathfinder resource.");
            if (!result.Purpose.Equals("resume", StringComparison.OrdinalIgnoreCase) && !result.Purpose.Equals("source", StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException($"{label}.Purpose is unsupported.");
            if (!System.Text.RegularExpressions.Regex.IsMatch(result.SourceVersion, "^[a-fA-F0-9]{64}$")) throw new InvalidDataException($"{label}.SourceVersion is not a SHA-256 source identity.");
            result.SourceVersion = result.SourceVersion.ToLowerInvariant();
            if (element.TryGetProperty("OpenDetails", out var details))
            {
                RequireArray(details, label + ".OpenDetails");
                foreach (var item in details.EnumerateArray())
                {
                    if (result.OpenDetails.Count >= 30) throw new InvalidDataException($"{label}.OpenDetails exceeds the 30-item safety limit.");
                    var id = StringValue(item, label + ".OpenDetails", 1024);
                    if (!result.OpenDetails.Contains(id, StringComparer.Ordinal)) result.OpenDetails.Add(id);
                }
            }
        }
        return result;
    }

    private static bool ShouldPreservePwaSelectorOnly(string rawSlug, bool isPwaLegacy, List<string> warnings, string area)
    {
        if (!isPwaLegacy || !rawSlug.Equals("extra-uworld-selector", StringComparison.OrdinalIgnoreCase)) return false;
        var message = $"{area} contains the PWA-native UWorld Selector. The native Windows Selector is a tool workspace rather than a My Study subject, so this subject-layer association is not imported or redirected to the legacy checkbox PDF; the native Selector progress provider is handled separately.";
        if (!warnings.Contains(message, StringComparer.Ordinal)) warnings.Add(message);
        return true;
    }

    private string MapSlug(string raw, string label)
    {
        if (!_knownSlugs.Contains(raw)) throw new InvalidDataException($"{label} refers to an unknown Pathfinder resource '{raw}'.");
        return raw;
    }

    private static string NormalizeWindowsUtilityId(string raw, string label)
    {
        var exact = WindowsUtilityIds.FirstOrDefault(x => x.Equals(raw, StringComparison.OrdinalIgnoreCase));
        if (exact is not null) return exact;
        if (PwaUtilityToWindows.TryGetValue(raw, out var mapped)) return mapped;
        throw new InvalidDataException($"{label} refers to unsupported utility tab '{raw}'.");
    }

    private static void ValidateExtensionAggregate(IReadOnlyDictionary<string, JsonElement> values)
    {
        var aggregateBytes = 0L;
        foreach (var pair in values)
        {
            ValidateExtensionKey(pair.Key);
            aggregateBytes += Encoding.UTF8.GetByteCount(pair.Value.GetRawText());
            if (aggregateBytes > 90L * 1024L * 1024L)
                throw new InvalidDataException("PreservedExtensions exceeds the bounded 90 MB extension budget.");
        }
    }

    private static void ValidateExtensionKey(string key)
    {
        if (string.IsNullOrWhiteSpace(key) || key.Length > 240) throw new InvalidDataException("Backup contains an invalid preserved-extension key.");
    }


    private JournalState CanonicalizeJournal(JournalState journal)
    {
        var state = JournalService.CloneState(journal);
        state.LegacyPersonalMigrationSlugs = state.LegacyPersonalMigrationSlugs
            .Select(x => MapSlug(x, "Journal legacy Personal migration marker"))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(x => x, StringComparer.OrdinalIgnoreCase)
            .ToList();
        foreach (var entry in state.Entries)
        {
            entry.Slug = (entry.Slug ?? "").Trim();
            if (entry.Slug.Length == 0)
            {
                entry.SourceVersion = "";
                entry.SourceLocation = null;
                continue;
            }
            entry.Slug = MapSlug(entry.Slug, "Journal entry source");
            if (!_sourceVersionByResource.TryGetValue(entry.Slug, out var expected))
                throw new InvalidDataException($"Journal entry '{entry.Id}' has no canonical source identity.");

            var preservedVersion = (entry.SourceVersion ?? "").Trim().ToLowerInvariant();
            if (entry.SourceLocation is not null)
            {
                entry.SourceLocation = CanonicalizeLocation(entry.Slug, entry.SourceLocation, "source");
                if (preservedVersion.Length == 0) preservedVersion = entry.SourceLocation.SourceVersion;
                if (!entry.SourceLocation.SourceVersion.Equals(preservedVersion, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException($"Journal entry '{entry.Id}' has inconsistent preserved source identities; backup export was refused rather than relabeling the source.");
            }
            else if (preservedVersion.Length == 0)
            {
                // Legacy subject-linked notes without an exact source anchor have no historical
                // target to mislabel. Bind that non-exact subject link to the installed source.
                preservedVersion = expected.ToLowerInvariant();
            }
            if (!System.Text.RegularExpressions.Regex.IsMatch(preservedVersion, "^[a-fA-F0-9]{64}$"))
                throw new InvalidDataException($"Journal entry '{entry.Id}' has an invalid preserved source identity.");
            entry.SourceVersion = preservedVersion;
        }
        state.UpdatedUtc = DateTimeOffset.UtcNow;
        return state;
    }

    private PersonalStudyState CanonicalizePersonalLocations(PersonalStudyState personal)
    {
        foreach (var pair in personal.PositionsBySlug.ToList())
            personal.PositionsBySlug[pair.Key] = CanonicalizeLocation(pair.Key, pair.Value, "resume");
        foreach (var bookmark in personal.Bookmarks)
            bookmark.Location = CanonicalizeLocation(bookmark.Slug, bookmark.Location, "resume");
        return personal;
    }

    private StudyLocationState CanonicalizeLocation(string resourceId, StudyLocationState? source, string purpose)
    {
        source ??= new StudyLocationState();
        if (!_sourceVersionByResource.TryGetValue(resourceId, out var installedVersion))
            throw new InvalidDataException($"Location for '{resourceId}' has no canonical source identity.");
        var sourceVersion = (source.SourceVersion ?? "").Trim().ToLowerInvariant();
        var hasDurableTarget = !string.IsNullOrWhiteSpace(source.TargetId) || !string.IsNullOrWhiteSpace(source.TargetPath) || !string.IsNullOrWhiteSpace(source.Anchor);
        if (sourceVersion.Length == 0)
        {
            if (hasDurableTarget)
                throw new InvalidDataException($"Location for '{resourceId}' has an exact target but no preserved source identity. Backup export was refused rather than stamping the current source hash onto an unverifiable historical anchor.");
            sourceVersion = installedVersion.ToLowerInvariant();
        }
        if (!System.Text.RegularExpressions.Regex.IsMatch(sourceVersion, "^[a-fA-F0-9]{64}$"))
            throw new InvalidDataException($"Location for '{resourceId}' has an invalid source identity.");
        return new StudyLocationState
        {
            SchemaVersion = PathfinderLocation.CurrentSchemaVersion,
            ResourceId = resourceId,
            SourceVersion = sourceVersion,
            Purpose = purpose,
            Anchor = source.Anchor ?? "",
            TargetId = source.TargetId ?? "",
            TargetPath = source.TargetPath ?? "",
            Context = source.Context ?? "",
            OffsetY = source.OffsetY,
            TargetOffsetY = source.TargetOffsetY,
            Hash = source.Hash ?? "",
            ScrollX = Math.Max(0, source.ScrollX),
            ScrollY = Math.Max(0, source.ScrollY),
            OpenDetails = (source.OpenDetails ?? []).Where(x => !string.IsNullOrWhiteSpace(x)).Distinct(StringComparer.Ordinal).Take(30).ToList(),
            UpdatedUtc = source.UpdatedUtc == default ? DateTimeOffset.UtcNow : source.UpdatedUtc
        };
    }

    private static ShellSettings CloneSettings(ShellSettings source) => new()
    {
        ThemeId = source.ThemeId,
        RestoreLastSession = source.RestoreLastSession,
        StrongFocusIndicators = source.StrongFocusIndicators,
        ReduceMotion = source.ReduceMotion,
        ComfortableReadingSpacing = source.ComfortableReadingSpacing,
        LastSelectedTabIndex = source.LastSelectedTabIndex,
        RestoreSplitWorkspace = source.RestoreSplitWorkspace,
        LastWorkspaceSplitEnabled = source.LastWorkspaceSplitEnabled,
        LastWorkspaceSecondaryKind = source.LastWorkspaceSecondaryKind ?? "",
        LastWorkspaceSecondaryId = source.LastWorkspaceSecondaryId ?? "",
        LastWorkspaceSplitRatio = source.LastWorkspaceSplitRatio,
        LastSessionTabs = (source.LastSessionTabs ?? []).Select(x => new SessionTabState
        {
            Kind = x.Kind,
            Id = x.Id,
            IsPinned = x.IsPinned,
            HasLocation = x.HasLocation,
            Hash = x.Hash,
            ScrollX = x.ScrollX,
            ScrollY = x.ScrollY
        }).ToList()
    };

    private static PersonalStudyState ClonePersonal(PersonalStudyState source)
    {
        var json = JsonSerializer.Serialize(source, JsonOptions);
        return JsonSerializer.Deserialize<PersonalStudyState>(json, JsonOptions) ?? new();
    }

    private static void EnsureOnlyProperties(JsonElement element, string label, params string[] allowed)
    {
        RequireObject(element, label);
        var allowedSet = new HashSet<string>(allowed, StringComparer.Ordinal);
        foreach (var property in element.EnumerateObject())
        {
            if (!allowedSet.Contains(property.Name))
                throw new InvalidDataException($"{label} contains unsupported canonical field '{property.Name}'. Future/richer canonical state must use a newer schema or PreservedExtensions rather than be silently discarded.");
        }
    }

    private static void RequireProperties(JsonElement element, string label, params string[] required)
    {
        foreach (var property in required)
            if (!element.TryGetProperty(property, out _)) throw new InvalidDataException($"Canonical {label}.{property} is required.");
    }

    private static void ValidateCanonicalCoverage(JsonElement element, IEnumerable<string> extensionKeys)
    {
        RequireObject(element, "Backup.Coverage");
        EnsureOnlyProperties(element, "Backup.Coverage", "Included", "Deferred", "PreservedOpaque");
        RequireProperties(element, "Backup.Coverage", "Included", "Deferred", "PreservedOpaque");
        ValidateStringArray(element.GetProperty("Included"), "Backup.Coverage.Included", 100, 500);
        ValidateStringArray(element.GetProperty("Deferred"), "Backup.Coverage.Deferred", 100, 500);
        var opaque = ValidateStringArray(element.GetProperty("PreservedOpaque"), "Backup.Coverage.PreservedOpaque", 500, 240);
        var expected = new HashSet<string>(extensionKeys, StringComparer.Ordinal);
        if (!opaque.SetEquals(expected)) throw new InvalidDataException("Canonical Backup.Coverage.PreservedOpaque does not match PreservedExtensions keys.");
    }

    private static HashSet<string> ValidateStringArray(JsonElement element, string label, int maxItems, int maxLength)
    {
        RequireArray(element, label);
        var result = new HashSet<string>(StringComparer.Ordinal);
        var index = 0;
        foreach (var item in element.EnumerateArray())
        {
            if (++index > maxItems) throw new InvalidDataException($"{label} exceeds the {maxItems}-item safety limit.");
            var value = StringValue(item, $"{label}[{index - 1}]", maxLength);
            if (!result.Add(value)) throw new InvalidDataException($"{label} contains duplicate value '{value}'.");
        }
        return result;
    }

    private static void RequireObject(JsonElement element, string label)
    {
        if (element.ValueKind != JsonValueKind.Object) throw new InvalidDataException(label + " must be an object.");
    }

    private static void RequireArray(JsonElement element, string label)
    {
        if (element.ValueKind != JsonValueKind.Array) throw new InvalidDataException(label + " must be an array.");
    }

    private static int RequiredInt(JsonElement parent, string property, string label)
    {
        if (!parent.TryGetProperty(property, out var element) || element.ValueKind != JsonValueKind.Number || !element.TryGetInt32(out var value))
            throw new InvalidDataException(label + " must be an integer.");
        return value;
    }

    private static string RequiredString(JsonElement parent, string property, string label, int max)
    {
        if (!parent.TryGetProperty(property, out var element)) throw new InvalidDataException(label + " is required.");
        return StringValue(element, label, max);
    }

    private static string OptionalString(JsonElement parent, string property, string fallback, string label, int max)
        => parent.TryGetProperty(property, out var element) ? StringValue(element, label, max) : fallback;

    private static string StringValue(JsonElement element, string label, int max)
    {
        if (element.ValueKind != JsonValueKind.String) throw new InvalidDataException(label + " must be text.");
        var value = element.GetString() ?? "";
        if (value.Length > max) throw new InvalidDataException(label + $" exceeds the {max}-character safety limit.");
        return value;
    }

    private static bool BoolValue(JsonElement element, string label)
    {
        if (element.ValueKind != JsonValueKind.True && element.ValueKind != JsonValueKind.False) throw new InvalidDataException(label + " must be true or false.");
        return element.GetBoolean();
    }

    private static bool OptionalBool(JsonElement parent, string property, bool fallback, string label)
        => parent.TryGetProperty(property, out var element) ? BoolValue(element, label) : fallback;

    private static double OptionalFiniteDouble(JsonElement parent, string property, double fallback, string label, double min, double max)
    {
        if (!parent.TryGetProperty(property, out var element)) return fallback;
        if (element.ValueKind != JsonValueKind.Number || !element.TryGetDouble(out var value) || double.IsNaN(value) || double.IsInfinity(value) || value < min || value > max)
            throw new InvalidDataException(label + " is outside the supported range.");
        return value;
    }

    private static DateTimeOffset DateValue(JsonElement element, string label)
    {
        if (element.ValueKind != JsonValueKind.String || !DateTimeOffset.TryParse(element.GetString(), out var value))
            throw new InvalidDataException(label + " must be a valid timestamp.");
        return value;
    }
}
