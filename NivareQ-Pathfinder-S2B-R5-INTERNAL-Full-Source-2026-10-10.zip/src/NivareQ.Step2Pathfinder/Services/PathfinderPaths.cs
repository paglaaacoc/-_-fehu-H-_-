namespace NivareQ.Step2Pathfinder.Services;

public static class PathfinderPaths
{
    public const string InternalHostSuffix = ".pathfinder.invalid";
    public static string AppRoot => AppContext.BaseDirectory;
    public static string ContentRoot => Path.Combine(AppRoot, "MedicalPayload", "R2");
    public static string ResourceRegistry => Path.Combine(AppRoot, "ShellData", "resource-registry.json");
    public static string FrozenContentMap => Path.Combine(AppRoot, "ShellData", "frozen-content-map.json");
    public static string CockpitStateRegistry => Path.Combine(AppRoot, "ShellData", "cockpit-state-allowlist.json");
    public static string ThemeRegistry => Path.Combine(AppRoot, "Brand", "Themes", "registry.json");
    public static string StudyTimes => Path.Combine(AppRoot, "ShellData", "study-times.json");
    public static string UWorldSelectorRecipes => Path.Combine(AppRoot, "ShellData", "uworld-selector-recipes.json");
    public static string AppDataRoot => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "NivareQ", "Step2Pathfinder");
    public static string WebViewDataRoot => Path.Combine(AppDataRoot, "WebView2");
    public static string RuntimeContentRoot => Path.Combine(AppDataRoot, "FrozenContent", "R2-8fcde78900b3");
    public static string SettingsPath => Path.Combine(AppDataRoot, "settings.json");
    public static string PersonalStudyPath => Path.Combine(AppDataRoot, "personal-study.json");
    public static string JournalRoot => Path.Combine(AppDataRoot, "Journal");
    public static string JournalSnapshotPath => Path.Combine(JournalRoot, "journal-snapshot.json");
    public static string JournalLogPath => Path.Combine(JournalRoot, "journal-operations.ndjson");
    public static string UWorldSelectorStatePath => Path.Combine(AppDataRoot, "uworld-selector.json");
    public static string DiagnosticsPath => Path.Combine(AppDataRoot, "study-view-events.log");
    public static string BackupExtensionsPath => Path.Combine(AppDataRoot, "backup-extensions.json");
    public static string CockpitStatePath => Path.Combine(AppDataRoot, "cockpit-state.json");
    public static string RestoreTransactionsRoot => Path.Combine(AppDataRoot, "RestoreTransactions");
    public static string RestoreJournalPath => Path.Combine(AppDataRoot, "restore-transaction.json");
    public static string CorruptRecoveryRoot => Path.Combine(AppDataRoot, "Recovery", "Corrupt");
}
