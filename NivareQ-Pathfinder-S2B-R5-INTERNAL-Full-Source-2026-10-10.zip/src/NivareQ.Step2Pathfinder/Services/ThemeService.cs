using System.Text.Json;
using NivareQ.Step2Pathfinder.Models;

namespace NivareQ.Step2Pathfinder.Services;

public sealed class ThemeService
{
    public ThemeRegistry Registry { get; private set; } = new();

    public void Load()
    {
        var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
        Registry = JsonSerializer.Deserialize<ThemeRegistry>(File.ReadAllText(PathfinderPaths.ThemeRegistry), options) ?? new();
        Registry.Themes = Registry.Themes.Where(x => x.Enabled).ToList();
    }

    public ThemeChoice DefaultTheme => Registry.Themes.FirstOrDefault(t => t.Name.Equals(Registry.DefaultTheme, StringComparison.OrdinalIgnoreCase))
        ?? Registry.Themes.First();
}
