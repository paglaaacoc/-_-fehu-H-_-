using System.Text.Json;

namespace NivareQ.Step2Pathfinder.Services;

public sealed class CockpitStateRegistry
{
    private readonly Dictionary<string, HashSet<string>> _allowed = new(StringComparer.OrdinalIgnoreCase);
    public int SchemaVersion { get; private set; }
    public int ResourceCount => _allowed.Count;
    public int KeyCount => _allowed.Values.Sum(x => x.Count);
    public IEnumerable<string> ResourceIds => _allowed.Keys;

    public void Load()
    {
        using var document = JsonDocument.Parse(File.ReadAllText(PathfinderPaths.CockpitStateRegistry));
        var root = document.RootElement;
        if (root.ValueKind != JsonValueKind.Object) throw new InvalidDataException("Cockpit state registry must be an object.");
        if (!root.TryGetProperty("schemaVersion", out var schema) || schema.ValueKind != JsonValueKind.Number || !schema.TryGetInt32(out var version) || version != 1)
            throw new InvalidDataException("Unsupported cockpit state registry schema.");
        if (!root.TryGetProperty("resources", out var resources) || resources.ValueKind != JsonValueKind.Object)
            throw new InvalidDataException("Cockpit state registry is missing resources.");

        _allowed.Clear();
        foreach (var resource in resources.EnumerateObject())
        {
            if (string.IsNullOrWhiteSpace(resource.Name) || resource.Name.Length > 180)
                throw new InvalidDataException("Cockpit state registry contains an invalid resource id.");
            if (resource.Value.ValueKind != JsonValueKind.Array)
                throw new InvalidDataException($"Cockpit state registry entry '{resource.Name}' must be an array.");
            var keys = new HashSet<string>(StringComparer.Ordinal);
            foreach (var item in resource.Value.EnumerateArray())
            {
                if (item.ValueKind != JsonValueKind.String) throw new InvalidDataException($"Cockpit state registry entry '{resource.Name}' contains a non-string key.");
                var key = item.GetString() ?? "";
                if (string.IsNullOrWhiteSpace(key) || key.Length > 240 || !keys.Add(key))
                    throw new InvalidDataException($"Cockpit state registry entry '{resource.Name}' contains an invalid/duplicate key.");
            }
            _allowed[resource.Name] = keys;
        }
        SchemaVersion = version;
    }

    public bool SupportsResource(string resourceId) => _allowed.ContainsKey(resourceId);

    public bool IsAllowed(string resourceId, string key)
        => _allowed.TryGetValue(resourceId, out var keys) && keys.Contains(key);

    public IReadOnlyCollection<string> AllowedKeysFor(string resourceId)
        => _allowed.TryGetValue(resourceId, out var keys) ? keys : Array.Empty<string>();

    public Dictionary<string, string> ValidateValues(string resourceId, IEnumerable<KeyValuePair<string, string>> values, string label)
    {
        if (!_allowed.TryGetValue(resourceId, out var allowed))
            throw new InvalidDataException($"{label} refers to unsupported cockpit resource '{resourceId}'.");

        var result = new Dictionary<string, string>(StringComparer.Ordinal);
        long aggregateBytes = 0;
        foreach (var pair in values)
        {
            if (!allowed.Contains(pair.Key))
                throw new InvalidDataException($"{label} contains an unrecognized cockpit state key '{pair.Key}'.");
            var value = pair.Value ?? "";
            if (value.Length > 250_000)
                throw new InvalidDataException($"{label}.{pair.Key} exceeds the per-value safety limit.");
            aggregateBytes += pair.Key.Length + value.Length;
            if (aggregateBytes > CockpitStateService.MaxResourceStateCharacters)
                throw new InvalidDataException($"{label} exceeds the per-resource cockpit-state safety limit.");
            if (!result.TryAdd(pair.Key, value))
                throw new InvalidDataException($"{label} contains duplicate cockpit state key '{pair.Key}'.");
        }
        return result;
    }
}
