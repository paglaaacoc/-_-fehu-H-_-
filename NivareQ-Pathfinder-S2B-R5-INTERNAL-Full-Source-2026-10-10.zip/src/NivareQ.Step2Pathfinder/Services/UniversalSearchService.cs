using System.Net;
using System.Text.Json;
using System.Text.RegularExpressions;
using NivareQ.Step2Pathfinder.Models;

namespace NivareQ.Step2Pathfinder.Services;

public sealed class UniversalSearchService
{
    private static readonly Regex ScriptRegex = new(@"<script\b[^>]*>(?<body>.*?)</script\s*>", RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.CultureInvariant | RegexOptions.Compiled);
    private static readonly Regex StyleNoiseRegex = new(@"<(style|noscript|svg)\b[^>]*>.*?</\1\s*>", RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.CultureInvariant | RegexOptions.Compiled);
    private static readonly Regex JsonStringRegex = new("\"(?:\\\\.|[^\"\\\\])*\"", RegexOptions.Singleline | RegexOptions.CultureInvariant | RegexOptions.Compiled);
    private static readonly Regex CommentRegex = new(@"<!--.*?-->", RegexOptions.Singleline | RegexOptions.CultureInvariant | RegexOptions.Compiled);
    private static readonly Regex TagRegex = new(@"<[^>]+>", RegexOptions.Singleline | RegexOptions.CultureInvariant | RegexOptions.Compiled);
    private static readonly Regex WhiteSpaceRegex = new(@"\s+", RegexOptions.CultureInvariant | RegexOptions.Compiled);
    private readonly List<SearchDocument> _documents = [];
    private GlossaryService? _glossary;

    public bool IsBuilt { get; private set; }
    public int DocumentCount => _documents.Count;

    public void Build(IEnumerable<SubjectEntry> entries, GlossaryService? glossary = null)
    {
        _documents.Clear();
        _glossary = glossary;
        foreach (var entry in entries.Where(x => !x.IsExtra && x.ContentType.Equals("html", StringComparison.OrdinalIgnoreCase)).OrderBy(x => x.Number))
        {
            var fullPath = Path.Combine(PathfinderPaths.ContentRoot, entry.MainPath.Replace('/', Path.DirectorySeparatorChar));
            if (!File.Exists(fullPath)) continue;
            var html = File.ReadAllText(fullPath);
            var displayText = ExtractVisibleText(html);
            if (displayText.Length == 0) continue;
            _documents.Add(new SearchDocument(entry, displayText, SearchNormalization.NormalizeWithMap(displayText)));
        }
        IsBuilt = true;
    }

    public IReadOnlyList<UniversalSearchResult> Search(string? query, int maxResults = 50)
    {
        var rawQuery = (query ?? "").Trim();
        var q = SearchNormalization.Normalize(rawQuery);
        if (q.Length < 2 || _documents.Count == 0) return [];

        var tokens = q.Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Where(x => x.Length >= 2)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToArray();
        if (tokens.Length == 0) return [];

        // Deterministic alias expansion is a global fallback only. If the accepted
        // literal/all-token search already finds any cockpit, do not broaden that
        // result set with abbreviation aliases.
        var hasAnyDirectMatch = _documents.Any(doc =>
        {
            if (SearchNormalization.ContainsWholeTerm(doc.Normalized.Value, q)) return true;
            var title = SearchNormalization.Normalize(doc.Entry.Title + " " + doc.Entry.Subtitle + " " + doc.Entry.Phase);
            var positions = tokens.Select(t => SearchNormalization.IndexOfWholeTerm(doc.Normalized.Value, t)).ToArray();
            var titleMatches = tokens.Count(t => SearchNormalization.ContainsWholeTerm(title, t));
            return positions.All(x => x >= 0) || titleMatches == tokens.Length;
        });

        IReadOnlyList<string> aliasSourceTerms = hasAnyDirectMatch ? Array.Empty<string>() : (_glossary?.ResolveSourceTerms(rawQuery) ?? Array.Empty<string>());
        var normalizedAliasTerms = aliasSourceTerms
            .Select(x => (Display: x, Normalized: SearchNormalization.Normalize(x)))
            .Where(x => x.Normalized.Length >= 2 && !x.Normalized.Equals(q, StringComparison.OrdinalIgnoreCase))
            .DistinctBy(x => x.Normalized, StringComparer.OrdinalIgnoreCase)
            .ToArray();

        var results = new List<UniversalSearchResult>();
        foreach (var doc in _documents)
        {
            var title = SearchNormalization.Normalize(doc.Entry.Title + " " + doc.Entry.Subtitle + " " + doc.Entry.Phase);
            var exactIndexes = FindAllOccurrences(doc.Normalized.Value, q);
            var tokenPositions = tokens.Select(t => SearchNormalization.IndexOfWholeTerm(doc.Normalized.Value, t)).ToArray();
            var titleMatches = tokens.Count(t => SearchNormalization.ContainsWholeTerm(title, t));
            var directTokenMatch = tokenPositions.All(x => x >= 0) || titleMatches == tokens.Length;

            // W2C R2: exact phrases are occurrence-level source results, not one result
            // per cockpit. This preserves distinct learning modules/questions that happen
            // to share the same phrase inside one verified cockpit.
            if (exactIndexes.Count > 0)
            {
                for (var occurrence = 0; occurrence < exactIndexes.Count; occurrence++)
                {
                    var exactMatchIndex = exactIndexes[occurrence];
                    var exactScore = 1000 + Math.Min(250, q.Length * 4);
                    if (SearchNormalization.ContainsWholeTerm(title, q)) exactScore += 500;
                    exactScore += titleMatches * 90;
                    if (doc.Entry.Number == 0) exactScore -= 10;
                    results.Add(new UniversalSearchResult
                    {
                        Query = rawQuery,
                        Needle = rawQuery,
                        SubjectSlug = doc.Entry.Slug,
                        SubjectTitle = doc.Entry.Title,
                        SubjectNumber = doc.Entry.Number,
                        SourceVersion = doc.Entry.ExpectedSha256.ToLowerInvariant(),
                        Snippet = MakeSnippet(doc, exactMatchIndex, q.Length, [rawQuery]),
                        Score = exactScore - Math.Min(occurrence, 20),
                        IsExactPhrase = true,
                        MatchedByAlias = false,
                        AliasLabel = "",
                        HighlightTerms = [rawQuery],
                        SourceOccurrence = occurrence,
                        SourceOccurrenceCount = exactIndexes.Count,
                        ContextHint = MakeContextHint(doc, exactMatchIndex, q.Length),
                        ContextBefore = MakeContextBefore(doc, exactMatchIndex),
                        ContextAfter = MakeContextAfter(doc, exactMatchIndex, q.Length)
                    });
                }
                continue;
            }

            var aliasIndex = -1;
            var aliasNeedle = "";
            if (!directTokenMatch)
            {
                foreach (var alias in normalizedAliasTerms)
                {
                    var idx = SearchNormalization.IndexOfWholeTerm(doc.Normalized.Value, alias.Normalized);
                    if (idx < 0) continue;
                    if (aliasIndex < 0 || idx < aliasIndex)
                    {
                        aliasIndex = idx;
                        aliasNeedle = alias.Display;
                    }
                }
            }

            var partialPositions = tokens.Select(t => doc.Normalized.Value.IndexOf(t, StringComparison.OrdinalIgnoreCase)).ToArray();
            var partialTokenMatch = partialPositions.All(x => x >= 0);
            if (!directTokenMatch && aliasIndex < 0 && !partialTokenMatch) continue;

            int matchIndex;
            int matchLength;
            string needle;
            int score;
            bool matchedByAlias = false;
            string aliasLabel = "";
            IReadOnlyList<string> highlightTerms;

            if (directTokenMatch)
            {
                var present = tokenPositions.Where(x => x >= 0).ToArray();
                if (present.Length == 0)
                {
                    matchIndex = 0;
                    needle = tokens[0];
                }
                else
                {
                    matchIndex = present.Min();
                    needle = tokens[Array.IndexOf(tokenPositions, matchIndex)];
                }
                matchLength = Math.Max(needle.Length, 1);
                var span = present.Length > 1 ? present.Max() - present.Min() : 0;
                score = 500 + (tokens.Length * 40) - Math.Min(250, span / 8);
                highlightTerms = tokens;
            }
            else if (aliasIndex >= 0)
            {
                matchIndex = aliasIndex;
                var normalizedNeedle = SearchNormalization.Normalize(aliasNeedle);
                matchLength = Math.Max(1, normalizedNeedle.Length);
                needle = aliasNeedle;
                score = 430 + Math.Min(120, normalizedNeedle.Length * 3);
                matchedByAlias = true;
                aliasLabel = aliasNeedle;
                highlightTerms = [aliasNeedle];
            }
            else
            {
                var present = partialPositions.Where(x => x >= 0).ToArray();
                matchIndex = present.Length == 0 ? 0 : present.Min();
                needle = present.Length == 0 ? tokens[0] : tokens[Array.IndexOf(partialPositions, matchIndex)];
                matchLength = Math.Max(needle.Length, 1);
                var span = present.Length > 1 ? present.Max() - present.Min() : 0;
                score = 220 + (tokens.Length * 20) - Math.Min(160, span / 10);
                highlightTerms = tokens;
            }

            score += titleMatches * 90;
            if (doc.Entry.Number == 0) score -= 10;

            results.Add(new UniversalSearchResult
            {
                Query = rawQuery,
                Needle = needle,
                SubjectSlug = doc.Entry.Slug,
                SubjectTitle = doc.Entry.Title,
                SubjectNumber = doc.Entry.Number,
                SourceVersion = doc.Entry.ExpectedSha256.ToLowerInvariant(),
                Snippet = MakeSnippet(doc, matchIndex, matchLength, highlightTerms),
                Score = score,
                IsExactPhrase = false,
                MatchedByAlias = matchedByAlias,
                AliasLabel = aliasLabel,
                HighlightTerms = highlightTerms,
                SourceOccurrence = 0,
                SourceOccurrenceCount = 1,
                ContextHint = MakeContextHint(doc, matchIndex, matchLength),
                ContextBefore = MakeContextBefore(doc, matchIndex),
                ContextAfter = MakeContextAfter(doc, matchIndex, matchLength)
            });
        }

        return results
            .OrderByDescending(x => x.IsExactPhrase)
            .ThenByDescending(x => x.Score)
            .ThenBy(x => x.SubjectNumber)
            .ThenBy(x => x.SubjectTitle, StringComparer.OrdinalIgnoreCase)
            .ThenBy(x => x.SourceOccurrence)
            .Take(Math.Clamp(maxResults, 1, 100))
            .ToList();
    }

    private static List<int> FindAllOccurrences(string haystack, string needle)
    {
        var found = new List<int>();
        if (string.IsNullOrWhiteSpace(haystack) || string.IsNullOrWhiteSpace(needle)) return found;
        var at = 0;
        while (at < haystack.Length)
        {
            var index = SearchNormalization.IndexOfWholeTerm(haystack, needle, at);
            if (index < 0) break;
            found.Add(index);
            at = index + Math.Max(1, needle.Length);
            if (found.Count >= 32) break;
        }
        return found;
    }

    private static string MakeContextHint(SearchDocument doc, int normalizedIndex, int normalizedLength)
    {
        if (doc.Normalized.Value.Length == 0) return "";
        var start = Math.Max(0, normalizedIndex - 110);
        var end = Math.Min(doc.Normalized.Value.Length, normalizedIndex + Math.Max(1, normalizedLength) + 170);
        return doc.Normalized.Value[start..end].Trim();
    }

    private static string MakeContextBefore(SearchDocument doc, int normalizedIndex)
    {
        if (doc.Normalized.Value.Length == 0) return "";
        var end = Math.Clamp(normalizedIndex, 0, doc.Normalized.Value.Length);
        var start = Math.Max(0, end - 110);
        return doc.Normalized.Value[start..end].Trim();
    }

    private static string MakeContextAfter(SearchDocument doc, int normalizedIndex, int normalizedLength)
    {
        if (doc.Normalized.Value.Length == 0) return "";
        var start = Math.Clamp(normalizedIndex + Math.Max(1, normalizedLength), 0, doc.Normalized.Value.Length);
        var end = Math.Min(doc.Normalized.Value.Length, start + 170);
        return doc.Normalized.Value[start..end].Trim();
    }

    private static string ExtractVisibleText(string html)
    {
        // Most cockpit teaching content is rendered from frozen JavaScript data arrays.
        // Index string literals from those arrays in addition to already-visible HTML,
        // while ignoring executable code itself. No medical source file is rewritten.
        var scriptStrings = new List<string>();
        foreach (Match script in ScriptRegex.Matches(html))
        {
            var body = script.Groups["body"].Value;
            foreach (Match literal in JsonStringRegex.Matches(body))
            {
                try
                {
                    var value = JsonSerializer.Deserialize<string>(literal.Value);
                    if (!string.IsNullOrWhiteSpace(value) && value.Length >= 2)
                        scriptStrings.Add(value);
                }
                catch { }
            }
        }

        var text = ScriptRegex.Replace(html, " ");
        text = StyleNoiseRegex.Replace(text, " ");
        text = CommentRegex.Replace(text, " ");
        text = Regex.Replace(text, @"<(br|hr)\b[^>]*>", " ", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
        text = Regex.Replace(text, @"</(p|div|section|article|li|tr|h[1-6]|table|ul|ol)>\s*", " ", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
        text = TagRegex.Replace(text, " ");
        text = WebUtility.HtmlDecode(text);
        if (scriptStrings.Count > 0) text += " " + string.Join(" · ", scriptStrings);
        return WhiteSpaceRegex.Replace(text.Replace('\u00A0', ' '), " ").Trim();
    }

    private static string MakeSnippet(SearchDocument doc, int normalizedIndex, int normalizedLength, IReadOnlyList<string> highlightTerms)
    {
        if (doc.DisplayText.Length == 0) return "";
        if (doc.Normalized.SourceMap.Length == 0) return doc.DisplayText.Length <= 250 ? doc.DisplayText : doc.DisplayText[..250] + "…";

        var windows = new List<(int Start, int End)>();
        AddWindow(normalizedIndex, normalizedLength, 90, 145);

        // For non-exact all-token matches, show a compact extra fragment when a matched
        // token lives outside the primary snippet. This makes the reason for a match
        // visible without changing the matching/ranking behavior that Build 4 already had.
        foreach (var term in highlightTerms.Take(6))
        {
            var needle = SearchNormalization.Normalize(term);
            if (needle.Length < 2) continue;
            var idx = SearchNormalization.IndexOfWholeTerm(doc.Normalized.Value, needle);
            if (idx >= 0) AddWindow(idx, needle.Length, 45, 75);
        }

        var merged = windows
            .OrderBy(x => x.Start)
            .Aggregate(new List<(int Start, int End)>(), (acc, current) =>
            {
                if (acc.Count == 0) { acc.Add(current); return acc; }
                var last = acc[^1];
                if (current.Start <= last.End + 28)
                    acc[^1] = (last.Start, Math.Max(last.End, current.End));
                else
                    acc.Add(current);
                return acc;
            })
            .Take(4)
            .ToList();

        var pieces = new List<string>();
        foreach (var window in merged)
        {
            var start = window.Start;
            var end = window.End;
            if (start > 0)
            {
                var nextSpace = doc.DisplayText.IndexOf(' ', start);
                if (nextSpace >= 0 && nextSpace < end) start = nextSpace + 1;
            }
            if (end < doc.DisplayText.Length)
            {
                var prevSpace = doc.DisplayText.LastIndexOf(' ', Math.Max(start, end - 1));
                if (prevSpace > start) end = prevSpace;
            }
            if (end <= start) continue;
            var piece = doc.DisplayText[start..end].Trim();
            if (piece.Length > 0) pieces.Add(piece);
        }

        if (pieces.Count == 0) return doc.DisplayText.Length <= 250 ? doc.DisplayText : doc.DisplayText[..250] + "…";
        return (merged[0].Start > 0 ? "…" : "") + string.Join(" … ", pieces) + (merged[^1].End < doc.DisplayText.Length ? "…" : "");

        void AddWindow(int index, int length, int before, int after)
        {
            if (doc.Normalized.SourceMap.Length == 0) return;
            index = Math.Clamp(index, 0, Math.Max(0, doc.Normalized.SourceMap.Length - 1));
            var normalizedEnd = Math.Clamp(index + Math.Max(length, 1) - 1, 0, doc.Normalized.SourceMap.Length - 1);
            var sourceStart = doc.Normalized.SourceMap[index];
            var sourceEnd = doc.Normalized.SourceMap[normalizedEnd];
            windows.Add((Math.Max(0, sourceStart - before), Math.Min(doc.DisplayText.Length, sourceEnd + 1 + after)));
        }
    }

    private sealed record SearchDocument(SubjectEntry Entry, string DisplayText, SearchNormalization.NormalizedText Normalized);
}
