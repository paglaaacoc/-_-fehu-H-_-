using System.Text.Json;

namespace NivareQ.Step2Pathfinder.Services;

public sealed class RestoreTransactionTarget
{
    public string TargetPath { get; set; } = "";
    public string SnapshotPath { get; set; } = "";
    public bool ExistedBefore { get; set; }
}

public sealed class RestoreTransactionJournal
{
    public int SchemaVersion { get; set; } = 1;
    public string TransactionId { get; set; } = "";
    public string TransactionDirectory { get; set; } = "";
    public DateTimeOffset PreparedUtc { get; set; } = DateTimeOffset.UtcNow;
    public bool Committed { get; set; }
    public List<RestoreTransactionTarget> Targets { get; set; } = [];
}

public static class RestoreTransactionService
{
    private static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true, PropertyNameCaseInsensitive = true };
    private static readonly object RecoverySync = new();
    private static bool _recoveryChecked;
    private static bool _mutationsBlocked;
    private static string _mutationBlockReason = "";
    private static readonly Dictionary<string, string> BlockedMutationTargets = new(StringComparer.OrdinalIgnoreCase);

    public static bool MutationsBlocked
    {
        get { lock (RecoverySync) return _mutationsBlocked; }
    }

    public static string MutationBlockReason
    {
        get { lock (RecoverySync) return _mutationBlockReason; }
    }

    public static PersistenceWriteResult RequireMutationAllowed(string targetPath)
    {
        EnsureInterruptedRestoreRecovered();
        lock (RecoverySync)
        {
            if (_mutationsBlocked)
                return PersistenceWriteResult.Fail(targetPath, "Pathfinder persistence is temporarily blocked for this process. " + _mutationBlockReason);
            var full = SafeFullPath(targetPath);
            if (full is not null && BlockedMutationTargets.TryGetValue(full, out var reason))
                return PersistenceWriteResult.Fail(targetPath, "Pathfinder will not overwrite this local state because it was created by a newer/unsupported data schema. " + reason);
            return PersistenceWriteResult.Ok(targetPath);
        }
    }

    public static void BlockMutationTarget(string targetPath, string reason)
    {
        var full = SafeFullPath(targetPath);
        if (full is null) return;
        lock (RecoverySync) BlockedMutationTargets[full] = reason;
    }

    public static void BlockMutationTargets(IEnumerable<string> targetPaths, string reason)
    {
        lock (RecoverySync)
        {
            foreach (var targetPath in targetPaths)
            {
                var full = SafeFullPath(targetPath);
                if (full is not null) BlockedMutationTargets[full] = reason;
            }
        }
    }

    private static string? SafeFullPath(string path)
    {
        try { return string.IsNullOrWhiteSpace(path) ? null : Path.GetFullPath(path); }
        catch { return null; }
    }

    private static void SetMutationBlock(string reason)
    {
        lock (RecoverySync)
        {
            _mutationsBlocked = true;
            _mutationBlockReason = reason;
        }
    }

    public static void BlockMutationsUntilRestart(string reason)
        => SetMutationBlock(string.IsNullOrWhiteSpace(reason) ? "A clean restart is required before Pathfinder accepts more state changes." : reason.Trim());

    public static void EnsureInterruptedRestoreRecovered()
    {
        lock (RecoverySync)
        {
            if (_recoveryChecked) return;
            _recoveryChecked = true;
        }

        try
        {
            if (!File.Exists(PathfinderPaths.RestoreJournalPath)) return;
            var journal = JsonSerializer.Deserialize<RestoreTransactionJournal>(File.ReadAllText(PathfinderPaths.RestoreJournalPath), JsonOptions);
            if (journal is null)
            {
                var reason = "An invalid interrupted-restore journal was preserved without applying it. The journal could not be parsed.";
                SetMutationBlock(reason);
                PersistenceHealth.Report("Restore recovery", reason + " Persistence is blocked until recovery evidence is resolved.");
                return;
            }
            if (!TryValidateJournal(journal, out var journalError))
            {
                var reason = "An invalid interrupted-restore journal was preserved without applying it. " + journalError;
                SetMutationBlock(reason);
                PersistenceHealth.Report("Restore recovery", reason + " Persistence is blocked until recovery evidence is resolved.");
                return;
            }

            if (journal.Committed)
            {
                var cleanupFailures = Cleanup(journal);
                if (cleanupFailures.Count > 0)
                    PersistenceHealth.Report("Restore cleanup", "A previously committed restore is intact, but Pathfinder could not remove all obsolete recovery files: " + string.Join("; ", cleanupFailures));
                return;
            }

            var failures = RollBack(journal);
            if (failures.Count == 0)
            {
                var cleanupFailures = Cleanup(journal);
                if (File.Exists(PathfinderPaths.RestoreJournalPath))
                {
                    var reason = "Pathfinder rolled back an interrupted restore, but the uncommitted recovery journal could not be retired. New writes are blocked so that a later launch cannot replay the old rollback over acknowledged data.";
                    SetMutationBlock(reason);
                    PersistenceHealth.Report("Restore recovery", reason + " Cleanup reported: " + string.Join("; ", cleanupFailures));
                    return;
                }
                var suffix = cleanupFailures.Count == 0 ? "" : " Some obsolete recovery files could not be removed: " + string.Join("; ", cleanupFailures);
                PersistenceHealth.Report("Restore recovery", "Pathfinder detected an interrupted backup restore and rolled the affected data files back to their pre-restore state before startup." + suffix);
            }
            else
            {
                var reason = "An interrupted backup restore could not be fully rolled back. Preserved recovery files remain under AppData. " + string.Join("; ", failures);
                SetMutationBlock(reason);
                PersistenceHealth.Report("Restore recovery", reason + " Persistence is blocked until recovery succeeds.");
            }
        }
        catch (Exception ex)
        {
            var reason = "Pathfinder could not complete interrupted-restore recovery: " + ex.Message;
            SetMutationBlock(reason);
            PersistenceHealth.Report("Restore recovery", reason + " Persistence is blocked until recovery succeeds.");
        }
    }

    public static PersistenceWriteResult Commit(IReadOnlyDictionary<string, string> candidateTextByTarget)
    {
        EnsureInterruptedRestoreRecovered();
        lock (RecoverySync)
        {
            if (_mutationsBlocked)
                return PersistenceWriteResult.Fail(PathfinderPaths.RestoreJournalPath, "Cannot start a new restore/reset transaction while interrupted recovery is unresolved. " + _mutationBlockReason);
        }
        if (File.Exists(PathfinderPaths.RestoreJournalPath))
            return PersistenceWriteResult.Fail(PathfinderPaths.RestoreJournalPath, "Cannot start a new restore/reset transaction while a recovery journal still exists. Restart Pathfinder or resolve the preserved recovery evidence first.");
        if (candidateTextByTarget.Count == 0) return PersistenceWriteResult.Fail(PathfinderPaths.RestoreJournalPath, "Restore contained no writable state.");
        if (candidateTextByTarget.Count > 32) return PersistenceWriteResult.Fail(PathfinderPaths.RestoreJournalPath, "Restore contains too many writable state stores.");
        foreach (var target in candidateTextByTarget.Keys)
        {
            var allowed = RequireMutationAllowed(target);
            if (!allowed.Success) return allowed;
            if (!IsSafeTargetPath(target))
                return PersistenceWriteResult.Fail(PathfinderPaths.RestoreJournalPath, $"Restore target is outside the bounded Pathfinder AppData state area: {target}");
        }

        var txId = Guid.NewGuid().ToString("N");
        var txDir = Path.Combine(PathfinderPaths.RestoreTransactionsRoot, txId);
        var journal = new RestoreTransactionJournal { TransactionId = txId, TransactionDirectory = txDir };

        try
        {
            Directory.CreateDirectory(txDir);
            var index = 0;
            foreach (var pair in candidateTextByTarget)
            {
                var target = pair.Key;
                var candidatePath = Path.Combine(txDir, $"candidate-{index}.json");
                var snapshotPath = Path.Combine(txDir, $"before-{index}.bin");
                var existed = File.Exists(target);
                if (existed) File.Copy(target, snapshotPath, overwrite: true);

                var candidateWrite = AtomicFileStore.WriteText(candidatePath, pair.Value, keepLastGood: false);
                if (!candidateWrite.Success) throw new IOException($"Could not stage {Path.GetFileName(target)}: {candidateWrite.Error}");

                journal.Targets.Add(new RestoreTransactionTarget { TargetPath = target, SnapshotPath = snapshotPath, ExistedBefore = existed });
                index++;
            }

            Directory.CreateDirectory(PathfinderPaths.AppDataRoot);
            var journalWrite = AtomicFileStore.WriteText(PathfinderPaths.RestoreJournalPath, JsonSerializer.Serialize(journal, JsonOptions), keepLastGood: false);
            if (!journalWrite.Success) throw new IOException("Could not create restore recovery journal: " + journalWrite.Error);

            index = 0;
            foreach (var pair in candidateTextByTarget)
            {
                var write = AtomicFileStore.WriteText(pair.Key, pair.Value);
                if (!write.Success) throw new IOException($"Could not commit {Path.GetFileName(pair.Key)}: {write.Error}");
                index++;
            }

            journal.Committed = true;
            var commitMarker = AtomicFileStore.WriteText(PathfinderPaths.RestoreJournalPath, JsonSerializer.Serialize(journal, JsonOptions), keepLastGood: false);
            if (!commitMarker.Success) throw new IOException("Restore data files were written, but the committed recovery marker could not be recorded: " + commitMarker.Error);

            var cleanupFailures = Cleanup(journal);
            if (cleanupFailures.Count > 0)
                PersistenceHealth.Report("Restore cleanup", "Restore committed successfully, but some obsolete recovery files could not be removed: " + string.Join("; ", cleanupFailures));
            return PersistenceWriteResult.Ok(PathfinderPaths.RestoreJournalPath);
        }
        catch (Exception ex)
        {
            var failures = RollBack(journal);
            if (failures.Count == 0)
            {
                var cleanupFailures = Cleanup(journal);
                if (File.Exists(PathfinderPaths.RestoreJournalPath))
                {
                    var rollbackCleanupReason = "Restore commit failed and all targets were rolled back, but the uncommitted recovery journal could not be retired. Persistence is blocked so that a later startup cannot replay the old rollback over newer acknowledged writes.";
                    SetMutationBlock(rollbackCleanupReason);
                    return PersistenceWriteResult.Fail(PathfinderPaths.RestoreJournalPath, rollbackCleanupReason + " Original error: " + ex.Message + (cleanupFailures.Count == 0 ? "" : " Cleanup also reported: " + string.Join("; ", cleanupFailures) + "."));
                }
                var cleanup = cleanupFailures.Count == 0 ? "" : " Cleanup also reported: " + string.Join("; ", cleanupFailures) + ".";
                return PersistenceWriteResult.Fail(PathfinderPaths.RestoreJournalPath, $"Restore commit failed; all staged data files were rolled back. {ex.Message}{cleanup}");
            }

            var reason = $"Restore commit failed and rollback was incomplete ({string.Join("; ", failures)}). Recovery files were preserved. Original error: {ex.Message}";
            SetMutationBlock(reason);
            return PersistenceWriteResult.Fail(PathfinderPaths.RestoreJournalPath, reason);
        }
    }

    private static bool TryValidateJournal(RestoreTransactionJournal journal, out string error)
    {
        error = "";
        if (journal.SchemaVersion != 1) { error = "Unsupported restore-journal schema."; return false; }
        if (journal.Targets is null || journal.Targets.Count == 0 || journal.Targets.Count > 32) { error = "Restore journal has an invalid target count."; return false; }
        if (string.IsNullOrWhiteSpace(journal.TransactionDirectory) || !IsPathUnder(journal.TransactionDirectory, PathfinderPaths.RestoreTransactionsRoot)) { error = "Restore transaction directory is outside the bounded recovery area."; return false; }

        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var target in journal.Targets)
        {
            if (target is null || !IsSafeTargetPath(target.TargetPath)) { error = "Restore journal contains an unsafe target path."; return false; }
            if (!seen.Add(Path.GetFullPath(target.TargetPath))) { error = "Restore journal contains duplicate target paths."; return false; }
            if (target.ExistedBefore && (string.IsNullOrWhiteSpace(target.SnapshotPath) || !IsPathUnder(target.SnapshotPath, journal.TransactionDirectory))) { error = "Restore journal contains an unsafe snapshot path."; return false; }
        }
        return true;
    }

    private static bool IsSafeTargetPath(string path)
    {
        if (string.IsNullOrWhiteSpace(path) || !IsPathUnder(path, PathfinderPaths.AppDataRoot)) return false;
        var full = Path.GetFullPath(path);
        if (full.Equals(Path.GetFullPath(PathfinderPaths.RestoreJournalPath), StringComparison.OrdinalIgnoreCase)) return false;
        if (IsPathUnder(full, PathfinderPaths.RestoreTransactionsRoot)) return false;
        return true;
    }

    private static bool IsPathUnder(string path, string root)
    {
        try
        {
            var fullPath = Path.GetFullPath(path);
            var fullRoot = Path.GetFullPath(root);
            var relative = Path.GetRelativePath(fullRoot, fullPath);
            return !Path.IsPathRooted(relative)
                && !relative.Equals("..", StringComparison.Ordinal)
                && !relative.StartsWith(".." + Path.DirectorySeparatorChar, StringComparison.Ordinal)
                && !relative.StartsWith(".." + Path.AltDirectorySeparatorChar, StringComparison.Ordinal);
        }
        catch { return false; }
    }

    private static List<string> RollBack(RestoreTransactionJournal journal)
    {
        var failures = new List<string>();
        foreach (var target in journal.Targets)
        {
            try
            {
                if (target.ExistedBefore)
                {
                    if (!File.Exists(target.SnapshotPath))
                    {
                        failures.Add($"missing snapshot for {Path.GetFileName(target.TargetPath)}");
                        continue;
                    }
                    var content = File.ReadAllText(target.SnapshotPath);
                    // Do not rotate the failed restore candidate into .lastgood.
                    // The commit path already placed the true pre-restore file there.
                    var result = AtomicFileStore.WriteText(target.TargetPath, content, keepLastGood: false);
                    if (!result.Success) failures.Add($"{Path.GetFileName(target.TargetPath)}: {result.Error}");
                }
                else if (File.Exists(target.TargetPath))
                {
                    File.Delete(target.TargetPath);
                }
            }
            catch (Exception ex)
            {
                failures.Add($"{Path.GetFileName(target.TargetPath)}: {ex.Message}");
            }
        }
        return failures;
    }

    private static List<string> Cleanup(RestoreTransactionJournal journal)
    {
        var failures = new List<string>();
        var journalRemoved = true;
        try
        {
            if (File.Exists(PathfinderPaths.RestoreJournalPath)) File.Delete(PathfinderPaths.RestoreJournalPath);
        }
        catch (Exception ex)
        {
            journalRemoved = false;
            failures.Add("restore journal: " + ex.Message);
        }

        // If the journal survives, preserve its snapshots as well so a later startup can
        // deterministically finish cleanup/recovery rather than discovering missing evidence.
        if (journalRemoved)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(journal.TransactionDirectory) && Directory.Exists(journal.TransactionDirectory))
                    Directory.Delete(journal.TransactionDirectory, recursive: true);
            }
            catch (Exception ex)
            {
                failures.Add("transaction directory: " + ex.Message);
            }
        }
        return failures;
    }
}
