using System.Text;
using System.Text.Json;
using NivareQ.Step2Pathfinder.Models;

namespace NivareQ.Step2Pathfinder.Services;

/// <summary>
/// Native Windows Journal provider. Runtime edits are append-only operations so a long-form
/// Journal does not rewrite one large JSON document for every keystroke/save. A compact snapshot
/// is written periodically. Canonical backup/restore serializes the logical JournalState, not the
/// implementation log.
/// </summary>
public sealed class JournalService
{
    public const int SchemaVersion = 1;
    public const int MaxEntries = 20_000;
    public const int MaxTitleLength = 500;
    public const int MaxBodyLength = 500_000;
    // Keep every supported native Journal state comfortably inside the canonical backup envelope.
    // This is a UTF-8 title+body budget; metadata/JSON overhead remains additional headroom.
    public const long MaxLogicalTextBytes = 48L * 1024L * 1024L;
    private const long MaxSnapshotBytes = 300L * 1024L * 1024L;
    private const long CompactLogBytes = 2L * 1024L * 1024L;
    private const int CompactOperationCount = 100;

    private static readonly UTF8Encoding Utf8NoBom = new(false);
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true
    };
    private static readonly JsonSerializerOptions LogJsonOptions = new()
    {
        WriteIndented = false,
        PropertyNameCaseInsensitive = true
    };

    private readonly Dictionary<string, JournalEntry> _entries = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, string> _searchTextById = new(StringComparer.OrdinalIgnoreCase);
    private readonly HashSet<string> _legacyPersonalMigrationSlugs = new(StringComparer.OrdinalIgnoreCase);
    private int _operationsSinceCompact;
    private long _logicalTextBytes;

    private sealed class JournalOperation
    {
        public int SchemaVersion { get; set; } = 1;
        public string Operation { get; set; } = ""; // upsert | delete
        public string Id { get; set; } = "";
        public JournalEntry? Entry { get; set; }
        public DateTimeOffset WrittenUtc { get; set; } = DateTimeOffset.UtcNow;
    }

    public int Count => _entries.Count;
    public IReadOnlyList<JournalEntry> Entries => _entries.Values
        .OrderByDescending(x => x.UpdatedUtc)
        .ThenBy(x => x.Id, StringComparer.OrdinalIgnoreCase)
        .Select(CloneEntry)
        .ToList();

    public IReadOnlyList<string> RepresentedSlugs => _entries.Values
        .Where(x => !string.IsNullOrWhiteSpace(x.Slug))
        .Select(x => x.Slug)
        .Distinct(StringComparer.OrdinalIgnoreCase)
        .ToList();

    public IReadOnlyList<JournalEntry> Recent(int count)
        => _entries.Values.OrderByDescending(x => x.UpdatedUtc).ThenBy(x => x.Id, StringComparer.OrdinalIgnoreCase).Take(Math.Max(0, count)).Select(CloneEntry).ToList();

    public IReadOnlyList<JournalEntry> Query(string? query, string? filterSlug, Func<string, string>? ownerLabel = null)
    {
        var q = SearchNormalization.Normalize(query ?? "");
        var results = new List<JournalEntry>();
        foreach (var entry in _entries.Values)
        {
            if (filterSlug is not null)
            {
                if (filterSlug.Length == 0)
                {
                    if (!string.IsNullOrWhiteSpace(entry.Slug)) continue;
                }
                else if (!entry.Slug.Equals(filterSlug, StringComparison.OrdinalIgnoreCase)) continue;
            }
            if (q.Length > 0)
            {
                var bodyMatches = _searchTextById.TryGetValue(entry.Id, out var search) && search.Contains(q, StringComparison.OrdinalIgnoreCase);
                var owner = string.IsNullOrWhiteSpace(entry.Slug) ? "General" : ownerLabel?.Invoke(entry.Slug) ?? entry.Slug;
                var ownerMatches = SearchNormalization.Normalize(owner).Contains(q, StringComparison.OrdinalIgnoreCase);
                if (!bodyMatches && !ownerMatches) continue;
            }
            results.Add(CloneEntry(entry));
        }
        return results.OrderByDescending(x => x.UpdatedUtc).ThenBy(x => x.Id, StringComparer.OrdinalIgnoreCase).ToList();
    }

    public void Load()
    {
        Directory.CreateDirectory(PathfinderPaths.JournalRoot);
        _entries.Clear();
        _searchTextById.Clear();
        _legacyPersonalMigrationSlugs.Clear();
        _operationsSinceCompact = 0;
        _logicalTextBytes = 0;

        if (File.Exists(PathfinderPaths.JournalSnapshotPath))
        {
            try
            {
                var size = new FileInfo(PathfinderPaths.JournalSnapshotPath).Length;
                if (size > MaxSnapshotBytes) throw new InvalidDataException("Journal snapshot exceeds the bounded safety limit.");
                var state = DeserializeState(File.ReadAllText(PathfinderPaths.JournalSnapshotPath, Utf8NoBom));
                foreach (var entry in state.Entries) _entries[entry.Id] = CloneEntry(entry);
                foreach (var slug in state.LegacyPersonalMigrationSlugs) _legacyPersonalMigrationSlugs.Add(slug);
            }
            catch (UnsupportedLocalSchemaException ex)
            {
                RestoreTransactionService.BlockMutationTargets([PathfinderPaths.JournalSnapshotPath, PathfinderPaths.JournalLogPath], ex.Message);
                PersistenceHealth.Report("Journal compatibility", ex.Message + " The current Journal files were preserved in place and this build will not overwrite or compact them.");
                return;
            }
            catch (Exception ex)
            {
                var recovered = TryLoadLastGoodSnapshot(out var state, out var recoveryMessage);
                if (recovered)
                {
                    foreach (var entry in state!.Entries) _entries[entry.Id] = CloneEntry(entry);
                    foreach (var slug in state.LegacyPersonalMigrationSlugs) _legacyPersonalMigrationSlugs.Add(slug);
                    PersistenceHealth.Report("Journal", $"The current Journal snapshot could not be read ({ex.Message}). {recoveryMessage}");
                }
                else
                {
                    var quarantined = AtomicFileStore.Quarantine(PathfinderPaths.JournalSnapshotPath, "journal-corrupt");
                    var suffix = quarantined is null ? "" : $" The unreadable file was preserved at {quarantined}.";
                    PersistenceHealth.Report("Journal", "The Journal snapshot could not be read. Pathfinder preserved recoverable operation history and did not invent replacement notes." + suffix);
                }
            }
        }

        _logicalTextBytes = _entries.Values.Sum(EntryLogicalTextBytes);
        ReplayOperationLog();
        NormalizeInMemory();
    }

    public JournalState ExportState() => new()
    {
        SchemaVersion = SchemaVersion,
        UpdatedUtc = DateTimeOffset.UtcNow,
        LegacyPersonalMigrationSlugs = _legacyPersonalMigrationSlugs.OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToList(),
        Entries = _entries.Values.OrderByDescending(x => x.UpdatedUtc).ThenBy(x => x.Id, StringComparer.OrdinalIgnoreCase).Select(CloneEntry).ToList()
    };

    public JournalEntry? Find(string id)
        => !string.IsNullOrWhiteSpace(id) && _entries.TryGetValue(id, out var entry) ? CloneEntry(entry) : null;

    public PersistenceWriteResult Upsert(JournalEntry entry)
    {
        var allowed = RestoreTransactionService.RequireMutationAllowed(PathfinderPaths.JournalLogPath);
        if (!allowed.Success) return allowed;
        try
        {
            var normalized = NormalizeEntry(entry, "Journal entry");
            var isNew = !_entries.ContainsKey(normalized.Id);
            if (isNew && _entries.Count >= MaxEntries)
                return PersistenceWriteResult.Fail(PathfinderPaths.JournalLogPath, $"Journal has reached the {MaxEntries:N0}-entry safety limit.");
            var previousBytes = _entries.TryGetValue(normalized.Id, out var previous) ? EntryLogicalTextBytes(previous) : 0L;
            var nextBytes = EntryLogicalTextBytes(normalized);
            var projectedBytes = _logicalTextBytes - previousBytes + nextBytes;
            if (projectedBytes > MaxLogicalTextBytes)
                return PersistenceWriteResult.Fail(PathfinderPaths.JournalLogPath, $"Journal has reached its {MaxLogicalTextBytes / (1024 * 1024)} MB recoverable text budget. Export/backup capacity is protected; shorten or remove another note before saving this one.");

            var operation = new JournalOperation { Operation = "upsert", Id = normalized.Id, Entry = CloneEntry(normalized) };
            var write = AppendOperation(operation);
            if (!write.Success) return write;

            _entries[normalized.Id] = CloneEntry(normalized);
            _logicalTextBytes = projectedBytes;
            _searchTextById[normalized.Id] = SearchNormalization.Normalize(normalized.Title + " " + normalized.Body);
            MaybeCompact();
            return PersistenceWriteResult.Ok(PathfinderPaths.JournalLogPath);
        }
        catch (Exception ex)
        {
            return PersistenceWriteResult.Fail(PathfinderPaths.JournalLogPath, ex);
        }
    }

    public bool IsLegacyPersonalMigrated(string slug)
        => !string.IsNullOrWhiteSpace(slug) && _legacyPersonalMigrationSlugs.Contains(slug.Trim());

    public PersistenceWriteResult MigrateLegacyPersonal(JournalEntry entry, string legacySlug)
    {
        var allowed = RestoreTransactionService.RequireMutationAllowed(PathfinderPaths.JournalLogPath);
        if (!allowed.Success) return allowed;
        try
        {
            var marker = (legacySlug ?? "").Trim();
            if (marker.Length == 0 || marker.Length > 240)
                return PersistenceWriteResult.Fail(PathfinderPaths.JournalLogPath, "Imported Personal-note migration has an invalid resource id.");
            var normalized = NormalizeEntry(entry, "Imported Personal Journal entry");
            var isNew = !_entries.ContainsKey(normalized.Id);
            if (isNew && _entries.Count >= MaxEntries)
                return PersistenceWriteResult.Fail(PathfinderPaths.JournalLogPath, $"Journal has reached the {MaxEntries:N0}-entry safety limit.");
            var previousBytes = _entries.TryGetValue(normalized.Id, out var previous) ? EntryLogicalTextBytes(previous) : 0L;
            var nextBytes = EntryLogicalTextBytes(normalized);
            var projectedBytes = _logicalTextBytes - previousBytes + nextBytes;
            if (projectedBytes > MaxLogicalTextBytes)
                return PersistenceWriteResult.Fail(PathfinderPaths.JournalLogPath, "Journal has reached its recoverable text budget; the released Personal note was left untouched for a later retry.");

            // Entry + migration marker are one append-only operation. Recovery can therefore never
            // apply the marker without also applying the note it protects from resurrection.
            var operation = new JournalOperation
            {
                Operation = "legacy-personal-migrate",
                Id = marker,
                Entry = CloneEntry(normalized)
            };
            var write = AppendOperation(operation);
            if (!write.Success) return write;

            _entries[normalized.Id] = CloneEntry(normalized);
            _logicalTextBytes = projectedBytes;
            _searchTextById[normalized.Id] = SearchNormalization.Normalize(normalized.Title + " " + normalized.Body);
            _legacyPersonalMigrationSlugs.Add(marker);
            MaybeCompact();
            return PersistenceWriteResult.Ok(PathfinderPaths.JournalLogPath);
        }
        catch (Exception ex)
        {
            return PersistenceWriteResult.Fail(PathfinderPaths.JournalLogPath, ex);
        }
    }

    public PersistenceWriteResult Delete(string id)
    {
        var allowed = RestoreTransactionService.RequireMutationAllowed(PathfinderPaths.JournalLogPath);
        if (!allowed.Success) return allowed;
        if (string.IsNullOrWhiteSpace(id) || !_entries.ContainsKey(id))
            return PersistenceWriteResult.Ok(PathfinderPaths.JournalLogPath);

        var normalizedId = id.Trim();
        var removedBytes = _entries.TryGetValue(normalizedId, out var existing) ? EntryLogicalTextBytes(existing) : 0L;
        var write = AppendOperation(new JournalOperation { Operation = "delete", Id = normalizedId });
        if (!write.Success) return write;
        _entries.Remove(normalizedId);
        _logicalTextBytes = Math.Max(0, _logicalTextBytes - removedBytes);
        _searchTextById.Remove(normalizedId);
        MaybeCompact();
        return PersistenceWriteResult.Ok(PathfinderPaths.JournalLogPath);
    }

    public PersistenceWriteResult Compact()
    {
        var allowed = RestoreTransactionService.RequireMutationAllowed(PathfinderPaths.JournalSnapshotPath);
        if (!allowed.Success) return allowed;
        allowed = RestoreTransactionService.RequireMutationAllowed(PathfinderPaths.JournalLogPath);
        if (!allowed.Success) return allowed;
        try
        {
            var snapshot = SerializeState(ExportState());
            // Snapshot replacement and operation-log retirement are one recoverable transaction.
            // A crash/failure can therefore expose either the complete pre-compaction pair or the
            // complete post-compaction pair, never a new snapshot followed by replay of its old log.
            var result = RestoreTransactionService.Commit(new Dictionary<string, string>
            {
                [PathfinderPaths.JournalSnapshotPath] = snapshot,
                [PathfinderPaths.JournalLogPath] = EmptyOperationLog
            });
            if (!result.Success) return result;
            _operationsSinceCompact = 0;
            return PersistenceWriteResult.Ok(PathfinderPaths.JournalSnapshotPath);
        }
        catch (Exception ex)
        {
            return PersistenceWriteResult.Fail(PathfinderPaths.JournalSnapshotPath, ex);
        }
    }

    public void ReplaceInMemory(JournalState state)
    {
        var normalized = NormalizeState(state);
        _entries.Clear();
        _searchTextById.Clear();
        _legacyPersonalMigrationSlugs.Clear();
        foreach (var slug in normalized.LegacyPersonalMigrationSlugs) _legacyPersonalMigrationSlugs.Add(slug);
        foreach (var entry in normalized.Entries)
        {
            _entries[entry.Id] = CloneEntry(entry);
            _searchTextById[entry.Id] = SearchNormalization.Normalize(entry.Title + " " + entry.Body);
        }
        _operationsSinceCompact = 0;
        _logicalTextBytes = normalized.Entries.Sum(EntryLogicalTextBytes);
    }

    public static string SerializeState(JournalState state)
        => JsonSerializer.Serialize(NormalizeState(state), JsonOptions);

    public static JournalState DeserializeState(string json)
    {
        var parsed = JsonSerializer.Deserialize<JournalState>(json, JsonOptions) ?? new JournalState();
        if (parsed.SchemaVersion > SchemaVersion)
            throw new UnsupportedLocalSchemaException($"Journal snapshot schema {parsed.SchemaVersion} is newer than supported schema {SchemaVersion}.");
        return NormalizeState(parsed);
    }

    public static string EmptyOperationLog => "";

    public static JournalState CloneState(JournalState source)
        => DeserializeState(SerializeState(source));

    private PersistenceWriteResult AppendOperation(JournalOperation operation)
    {
        try
        {
            Directory.CreateDirectory(PathfinderPaths.JournalRoot);
            var line = JsonSerializer.Serialize(operation, LogJsonOptions) + "\n";
            var bytes = Utf8NoBom.GetBytes(line);
            using var stream = new FileStream(
                PathfinderPaths.JournalLogPath,
                FileMode.OpenOrCreate,
                FileAccess.ReadWrite,
                FileShare.Read,
                64 * 1024,
                FileOptions.WriteThrough);
            // Keep any interrupted final append separate from this new operation.
            // Preserve the old bytes for replay diagnostics; never acknowledge an
            // operation that is concatenated onto an incomplete JSON line.
            if (stream.Length > 0)
            {
                stream.Seek(-1, SeekOrigin.End);
                var lastByte = stream.ReadByte();
                stream.Seek(0, SeekOrigin.End);
                if (lastByte != (byte)'\n') stream.WriteByte((byte)'\n');
            }
            stream.Write(bytes, 0, bytes.Length);
            stream.Flush(flushToDisk: true);
            _operationsSinceCompact++;
            return PersistenceWriteResult.Ok(PathfinderPaths.JournalLogPath);
        }
        catch (Exception ex)
        {
            return PersistenceWriteResult.Fail(PathfinderPaths.JournalLogPath, ex);
        }
    }

    private void ReplayOperationLog()
    {
        if (!File.Exists(PathfinderPaths.JournalLogPath)) return;
        try
        {
            var info = new FileInfo(PathfinderPaths.JournalLogPath);
            if (info.Length > MaxSnapshotBytes) throw new InvalidDataException("Journal operation log exceeds the bounded safety limit.");
            var lines = File.ReadAllLines(PathfinderPaths.JournalLogPath, Utf8NoBom);
            for (var i = 0; i < lines.Length; i++)
            {
                var line = lines[i];
                if (string.IsNullOrWhiteSpace(line)) continue;
                try
                {
                    var op = JsonSerializer.Deserialize<JournalOperation>(line, LogJsonOptions)
                             ?? throw new InvalidDataException("Operation is empty.");
                    ApplyOperation(op);
                    _operationsSinceCompact++;
                }
                catch (UnsupportedLocalSchemaException ex)
                {
                    RestoreTransactionService.BlockMutationTargets([PathfinderPaths.JournalSnapshotPath, PathfinderPaths.JournalLogPath], ex.Message);
                    PersistenceHealth.Report("Journal compatibility", ex.Message + $" Operation {i + 1} was preserved in place; this build will not compact or append to the Journal store.");
                    return;
                }
                catch (Exception ex)
                {
                    // A power loss can leave only the final append partial. Preserve everything
                    // before it and report the ignored tail instead of discarding the Journal.
                    if (i == lines.Length - 1)
                    {
                        PersistenceHealth.Report("Journal", "An incomplete final Journal write was ignored after recovery. Earlier notes remain intact. " + ex.Message);
                        break;
                    }
                    PersistenceHealth.Report("Journal", $"Journal operation {i + 1} could not be applied and was skipped: {ex.Message}");
                }
            }
        }
        catch (Exception ex)
        {
            var quarantined = AtomicFileStore.Quarantine(PathfinderPaths.JournalLogPath, "journal-log-corrupt");
            var suffix = quarantined is null ? "" : $" The unreadable log was preserved at {quarantined}.";
            PersistenceHealth.Report("Journal", "The Journal operation log could not be replayed. The last compact snapshot remains available." + suffix + " " + ex.Message);
        }
    }

    private void ApplyOperation(JournalOperation op)
    {
        if (op.SchemaVersion > SchemaVersion) throw new UnsupportedLocalSchemaException($"Journal operation schema {op.SchemaVersion} is newer than supported schema {SchemaVersion}.");
        if (op.SchemaVersion != SchemaVersion) throw new InvalidDataException("Unsupported Journal operation schema.");
        if (op.Operation.Equals("upsert", StringComparison.Ordinal))
        {
            if (op.Entry is null) throw new InvalidDataException("Journal upsert is missing Entry.");
            var entry = NormalizeEntry(op.Entry, "Journal operation entry");
            var isNew = !_entries.ContainsKey(entry.Id);
            if (isNew && _entries.Count >= MaxEntries) throw new InvalidDataException($"Journal operation would exceed the {MaxEntries:N0}-entry safety limit.");
            var previousBytes = _entries.TryGetValue(entry.Id, out var previous) ? EntryLogicalTextBytes(previous) : 0L;
            var projectedBytes = _logicalTextBytes - previousBytes + EntryLogicalTextBytes(entry);
            if (projectedBytes > MaxLogicalTextBytes) throw new InvalidDataException("Journal operation would exceed the recoverable text budget.");
            _entries[entry.Id] = entry;
            _logicalTextBytes = projectedBytes;
            _searchTextById[entry.Id] = SearchNormalization.Normalize(entry.Title + " " + entry.Body);
            return;
        }
        if (op.Operation.Equals("legacy-personal-migrate", StringComparison.Ordinal))
        {
            if (op.Entry is null) throw new InvalidDataException("Imported Personal-note migration is missing its Journal entry.");
            var marker = (op.Id ?? "").Trim();
            if (marker.Length == 0 || marker.Length > 240) throw new InvalidDataException("Imported Personal-note migration has an invalid resource id.");
            var entry = NormalizeEntry(op.Entry, "Imported Personal Journal operation entry");
            var isNew = !_entries.ContainsKey(entry.Id);
            if (isNew && _entries.Count >= MaxEntries) throw new InvalidDataException($"Journal operation would exceed the {MaxEntries:N0}-entry safety limit.");
            var previousBytes = _entries.TryGetValue(entry.Id, out var previous) ? EntryLogicalTextBytes(previous) : 0L;
            var projectedBytes = _logicalTextBytes - previousBytes + EntryLogicalTextBytes(entry);
            if (projectedBytes > MaxLogicalTextBytes) throw new InvalidDataException("Journal operation would exceed the recoverable text budget.");
            _entries[entry.Id] = entry;
            _logicalTextBytes = projectedBytes;
            _searchTextById[entry.Id] = SearchNormalization.Normalize(entry.Title + " " + entry.Body);
            _legacyPersonalMigrationSlugs.Add(marker);
            return;
        }
        if (op.Operation.Equals("delete", StringComparison.Ordinal))
        {
            if (string.IsNullOrWhiteSpace(op.Id)) throw new InvalidDataException("Journal delete is missing Id.");
            var id = op.Id.Trim();
            if (_entries.TryGetValue(id, out var existing)) _logicalTextBytes = Math.Max(0, _logicalTextBytes - EntryLogicalTextBytes(existing));
            _entries.Remove(id);
            _searchTextById.Remove(id);
            return;
        }
        throw new InvalidDataException("Unsupported Journal operation type.");
    }

    private void MaybeCompact()
    {
        try
        {
            var logBytes = File.Exists(PathfinderPaths.JournalLogPath) ? new FileInfo(PathfinderPaths.JournalLogPath).Length : 0;
            if (_operationsSinceCompact >= CompactOperationCount || logBytes >= CompactLogBytes)
            {
                var result = Compact();
                if (!result.Success) PersistenceHealth.Report("Journal", "Journal compaction could not complete; append-only persistence remains active. " + result.Error);
            }
        }
        catch (Exception ex)
        {
            PersistenceHealth.Report("Journal", "Journal compaction check failed; append-only persistence remains active. " + ex.Message);
        }
    }

    private static JournalState NormalizeState(JournalState state)
    {
        if (state.SchemaVersion != SchemaVersion && state.SchemaVersion != 0)
            throw new InvalidDataException("Unsupported Journal schema.");
        var entries = state.Entries ?? [];
        if (entries.Count > MaxEntries) throw new InvalidDataException($"Journal exceeds the {MaxEntries:N0}-entry safety limit.");
        var migrationSlugs = (state.LegacyPersonalMigrationSlugs ?? [])
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Select(x => x.Trim())
            .ToList();
        if (migrationSlugs.Count > 500) throw new InvalidDataException("Journal has too many imported Personal-note migration markers.");
        if (migrationSlugs.Any(x => x.Length > 240)) throw new InvalidDataException("Journal contains an invalid imported Personal-note migration marker.");
        if (migrationSlugs.Distinct(StringComparer.OrdinalIgnoreCase).Count() != migrationSlugs.Count)
            throw new InvalidDataException("Journal contains duplicate imported Personal-note migration markers.");
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var normalized = new List<JournalEntry>(entries.Count);
        long logicalTextBytes = 0;
        foreach (var raw in entries)
        {
            var entry = NormalizeEntry(raw, "Journal entry");
            if (!seen.Add(entry.Id)) throw new InvalidDataException($"Journal contains duplicate entry id '{entry.Id}'.");
            logicalTextBytes += EntryLogicalTextBytes(entry);
            if (logicalTextBytes > MaxLogicalTextBytes) throw new InvalidDataException("Journal exceeds the recoverable text budget.");
            normalized.Add(entry);
        }
        return new JournalState
        {
            SchemaVersion = SchemaVersion,
            UpdatedUtc = state.UpdatedUtc == default ? DateTimeOffset.UtcNow : state.UpdatedUtc,
            LegacyPersonalMigrationSlugs = migrationSlugs.OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToList(),
            Entries = normalized.OrderByDescending(x => x.UpdatedUtc).ThenBy(x => x.Id, StringComparer.OrdinalIgnoreCase).ToList()
        };
    }

    private static JournalEntry NormalizeEntry(JournalEntry? raw, string label)
    {
        if (raw is null) throw new InvalidDataException(label + " is missing.");
        var id = (raw.Id ?? "").Trim();
        if (id.Length == 0 || id.Length > 240) throw new InvalidDataException(label + " has an invalid Id.");
        var title = (raw.Title ?? "").Trim();
        var body = raw.Body ?? "";
        if (title.Length == 0) throw new InvalidDataException(label + " requires a title.");
        if (title.Length > MaxTitleLength) throw new InvalidDataException(label + $" title exceeds {MaxTitleLength} characters.");
        if (body.Length > MaxBodyLength) throw new InvalidDataException(label + $" body exceeds {MaxBodyLength:N0} characters.");
        var slug = (raw.Slug ?? "").Trim();
        if (slug.Length > 240) throw new InvalidDataException(label + " has an invalid source resource id.");
        var version = (raw.SourceVersion ?? "").Trim().ToLowerInvariant();
        if (version.Length > 128) throw new InvalidDataException(label + " has an invalid source version.");
        var created = raw.CreatedUtc == default ? DateTimeOffset.UtcNow : raw.CreatedUtc;
        var updated = raw.UpdatedUtc == default ? created : raw.UpdatedUtc;
        return new JournalEntry
        {
            Id = id,
            Title = title,
            Body = body,
            Slug = slug,
            SourceVersion = version,
            SourceLocation = raw.SourceLocation is null ? null : CloneLocation(raw.SourceLocation),
            OriginalTimestampKnown = raw.OriginalTimestampKnown,
            CreatedUtc = created,
            UpdatedUtc = updated
        };
    }

    private static StudyLocationState CloneLocation(StudyLocationState source) => new()
    {
        SchemaVersion = source.SchemaVersion <= 0 ? PathfinderLocation.CurrentSchemaVersion : source.SchemaVersion,
        ResourceId = source.ResourceId ?? "",
        SourceVersion = source.SourceVersion ?? "",
        Purpose = string.IsNullOrWhiteSpace(source.Purpose) ? "source" : source.Purpose,
        Anchor = source.Anchor ?? "",
        TargetId = source.TargetId ?? "",
        TargetPath = source.TargetPath ?? "",
        Context = source.Context ?? "",
        OffsetY = source.OffsetY,
        TargetOffsetY = source.TargetOffsetY,
        Hash = source.Hash ?? "",
        ScrollX = source.ScrollX,
        ScrollY = source.ScrollY,
        OpenDetails = (source.OpenDetails ?? []).Take(30).ToList(),
        UpdatedUtc = source.UpdatedUtc
    };

    private static JournalEntry CloneEntry(JournalEntry source) => new()
    {
        Id = source.Id,
        Title = source.Title,
        Body = source.Body,
        Slug = source.Slug,
        SourceVersion = source.SourceVersion,
        SourceLocation = source.SourceLocation is null ? null : CloneLocation(source.SourceLocation),
        OriginalTimestampKnown = source.OriginalTimestampKnown,
        CreatedUtc = source.CreatedUtc,
        UpdatedUtc = source.UpdatedUtc
    };

    private bool TryLoadLastGoodSnapshot(out JournalState? state, out string message)
    {
        state = null;
        message = "No valid last-good Journal snapshot was available.";
        var lastGood = AtomicFileStore.LastGoodPath(PathfinderPaths.JournalSnapshotPath);
        if (!File.Exists(lastGood)) return false;
        try
        {
            state = DeserializeState(File.ReadAllText(lastGood, Utf8NoBom));
            message = "The last-good Journal snapshot was recovered; newer valid append-only operations will still be replayed.";
            return true;
        }
        catch (Exception ex)
        {
            message = "The last-good Journal snapshot was also unreadable: " + ex.Message;
            return false;
        }
    }

    private void NormalizeInMemory()
    {
        _searchTextById.Clear();
        _logicalTextBytes = 0;
        foreach (var entry in _entries.Values)
        {
            _logicalTextBytes += EntryLogicalTextBytes(entry);
            _searchTextById[entry.Id] = SearchNormalization.Normalize(entry.Title + " " + entry.Body);
        }
        if (_entries.Count > MaxEntries || _logicalTextBytes > MaxLogicalTextBytes)
            PersistenceHealth.Report("Journal", "Recovered Journal state exceeds the current creation budget. Existing recovered notes were kept intact; new notes may be blocked until the Journal is back within the supported recoverable envelope.");
    }

    private static long EntryLogicalTextBytes(JournalEntry entry)
        => Encoding.UTF8.GetByteCount(entry.Title ?? "") + Encoding.UTF8.GetByteCount(entry.Body ?? "");
}
