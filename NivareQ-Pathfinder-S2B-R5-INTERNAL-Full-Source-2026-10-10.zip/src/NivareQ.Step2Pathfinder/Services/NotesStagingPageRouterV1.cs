using System.Security.Cryptography;
using System.Text.Json;

namespace NivareQ.Step2Pathfinder.Services;

// S2-B R4 INTERNAL ONLY. This is an in-process staging transport contract, not
// a WebView2 or active-data bridge. No startup hook, no pointer writer, no backup
// hook: the current S1 JSON bridge remains completely unchanged until S2-D.
public sealed record NotesPageDraft(string Guide, int Spacing,
    IReadOnlyList<NotesInkCell> Cells, IReadOnlyList<NotesImageObject> Images);
public sealed record NotesPageSession(string SessionId, string NoteId, string PageId,
    long PersistedRevision, NotesPageDraft Page);
public sealed record NotesPageWritePacket(string Protocol, string SessionId, long Sequence,
    string NoteId, string PageId, long ExpectedRevision, NotesPageDraft Page);
public sealed record NotesPageWriteAck(string Protocol, string SessionId, long Sequence,
    string NoteId, string PageId, long PersistedRevision);
public sealed record NotesPageProbeRequest(string Protocol, string SessionId, string NoteId, string PageId);
public sealed record NotesPageProbe(string Protocol, string SessionId, string NoteId, string PageId,
    long PersistedRevision, NotesPageDraft Page);

public sealed class NotesStagingPageRouterV1
{
    public const string Protocol = "nivareq.notes.page-save.v1";
    private readonly NotesStoreV1 _store;
    private readonly object _gate = new();
    private readonly Dictionary<string, PendingSession> _sessions = new(StringComparer.Ordinal);

    private sealed class PendingSession(string noteId, string pageId, long revision)
    {
        public string NoteId { get; } = noteId;
        public string PageId { get; } = pageId;
        public long Revision { get; set; } = revision;
        public long LastSequence { get; set; }
        public string? LastRequestHash { get; set; }
        public NotesPageWriteAck? LastAck { get; set; }
    }

    public NotesStagingPageRouterV1(NotesStoreV1 inactiveGeneration)
        => _store = inactiveGeneration ?? throw new ArgumentNullException(nameof(inactiveGeneration));

    public NotesPageSession OpenStagingPage(string noteId, string pageId)
    {
        lock (_gate)
        {
            if (_sessions.Count >= 32)
                throw new InvalidOperationException("Too many inactive Notes page sessions; no session was replaced.");
            if (_sessions.Values.Any(s => s.NoteId == noteId && s.PageId == pageId))
                throw new InvalidOperationException("This Notes page already has a writer session; no competing session was opened.");
            var note = _store.ReadNote(noteId);
            if (note.DeletedUtc is not null)
                throw new InvalidOperationException("A trashed note cannot be opened for editing.");
            var page = _store.ReadPage(noteId, pageId); // also validates page ownership
            var session = Guid.NewGuid().ToString("N");
            _sessions.Add(session, new PendingSession(noteId, pageId, page.Revision));
            return new NotesPageSession(session, noteId, pageId, page.Revision,
                new NotesPageDraft(page.Guide, page.Spacing, page.Cells, page.Images));
        }
    }

    // The UI must first drain/ACK its draft before requesting release. Even on
    // a duplicate release the native service never deletes persisted page data.
    public void ReleaseStagingPage(string sessionId, long lastAcknowledgedSequence,
        long lastAcknowledgedRevision)
    {
        lock (_gate)
        {
            if (!_sessions.TryGetValue(sessionId, out var session) ||
                session.LastSequence != lastAcknowledgedSequence ||
                session.Revision != lastAcknowledgedRevision)
                throw new InvalidOperationException("Page session release does not match its last committed ACK.");
            _sessions.Remove(sessionId);
        }
    }

    // Recovery is strictly read-only, bound to the original writer session,
    // and never upgrades an uncertain renderer save into an optimistic ACK.
    // The renderer compares revision AND canonical page payload before proceeding.
    public NotesPageProbe Probe(NotesPageProbeRequest request)
    {
        ArgumentNullException.ThrowIfNull(request);
        lock (_gate)
        {
            if (request.Protocol != Protocol ||
                !_sessions.TryGetValue(request.SessionId, out var session) ||
                session.NoteId != request.NoteId || session.PageId != request.PageId)
                throw new InvalidDataException("Notes recovery request does not own the page session.");
            var page = _store.ReadPage(request.NoteId, request.PageId);
            return new NotesPageProbe(Protocol, request.SessionId, request.NoteId, request.PageId,
                page.Revision, new NotesPageDraft(page.Guide, page.Spacing, page.Cells, page.Images));
        }
    }

    // Native responses represent actual committed revisions, NEVER optimistic
    // success. Duplicate retransmission of the same payload gets the same ACK
    // without issuing a second SavePage; a different payload/older sequence fails.
    public NotesPageWriteAck Write(NotesPageWritePacket packet)
    {
        ArgumentNullException.ThrowIfNull(packet);
        lock (_gate)
        {
            if (packet.Protocol != Protocol || packet.Sequence < 1 ||
                !_sessions.TryGetValue(packet.SessionId, out var session) ||
                session.NoteId != packet.NoteId || session.PageId != packet.PageId ||
                packet.Page is null)
                throw new InvalidDataException("Invalid Notes save session, page ownership or protocol.");
            var payloadHash = Convert.ToHexString(SHA256.HashData(JsonSerializer.SerializeToUtf8Bytes(packet)));
            if (packet.Sequence == session.LastSequence && session.LastRequestHash == payloadHash && session.LastAck is not null)
                return session.LastAck;
            if (packet.Sequence <= session.LastSequence || packet.ExpectedRevision != session.Revision)
                throw new InvalidOperationException("Stale Notes save sequence or revision; no data was overwritten.");
            var updatedRevision = _store.SavePage(packet.NoteId, packet.PageId,
                packet.ExpectedRevision, packet.Page.Guide, packet.Page.Spacing,
                packet.Page.Cells, packet.Page.Images);
            var ack = new NotesPageWriteAck(Protocol, packet.SessionId, packet.Sequence,
                packet.NoteId, packet.PageId, updatedRevision);
            session.Revision = updatedRevision;
            session.LastSequence = packet.Sequence;
            session.LastRequestHash = payloadHash;
            session.LastAck = ack;
            return ack;
        }
    }
}
