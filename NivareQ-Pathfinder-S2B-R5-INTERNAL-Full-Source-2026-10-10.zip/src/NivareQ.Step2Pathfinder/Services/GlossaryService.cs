﻿using System.Text.Json;
using NivareQ.Step2Pathfinder.Models;

namespace NivareQ.Step2Pathfinder.Services;

public sealed class GlossaryService
{
    private readonly List<GlossaryEntry> _entries = [];

    public IReadOnlyList<GlossaryEntry> Entries => _entries;
    public int Count => _entries.Count;
    public bool IsLoaded { get; private set; }

    public void Load()
    {
        _entries.Clear();
        var path = Path.Combine(AppContext.BaseDirectory, "ShellData", "medical-glossary.json");
        if (!File.Exists(path))
            throw new FileNotFoundException("Pathfinder medical glossary was not found.", path);

        var file = JsonSerializer.Deserialize<GlossaryFile>(File.ReadAllText(path), new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        }) ?? new GlossaryFile();

        _entries.AddRange(file.Entries
            .Where(x => !string.IsNullOrWhiteSpace(x.Term) && !string.IsNullOrWhiteSpace(x.Expansion))
            .OrderBy(x => x.Term, StringComparer.OrdinalIgnoreCase)
            .ThenBy(x => x.Expansion, StringComparer.OrdinalIgnoreCase));
        IsLoaded = true;
    }

    public IReadOnlyList<GlossaryEntry> FindExact(string? text)
    {
        var q = SearchNormalization.Normalize(text);
        if (q.Length < 2) return [];
        return _entries.Where(e => EntryKeys(e).Any(k => k.Equals(q, StringComparison.OrdinalIgnoreCase)))
            .ToList();
    }

    public IReadOnlyList<GlossaryEntry> BrowseByInitial(char initial)
    {
        var q = SearchNormalization.Normalize(initial.ToString());
        if (q.Length != 1) return [];
        return _entries
            .Where(e => SearchNormalization.Normalize(e.Term).StartsWith(q, StringComparison.OrdinalIgnoreCase))
            .OrderBy(e => e.Term, StringComparer.OrdinalIgnoreCase)
            .ThenBy(e => e.Expansion, StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    public IReadOnlyList<GlossaryEntry> Search(string? text, int maxResults = 80)
    {
        var q = SearchNormalization.Normalize(text);
        if (q.Length < 2) return [];
        var tokens = q.Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Where(x => x.Length >= 2).Distinct(StringComparer.OrdinalIgnoreCase).ToArray();

        return _entries
            .Select(e =>
            {
                var keys = EntryKeys(e).ToArray();
                var exact = keys.Any(k => k.Equals(q, StringComparison.OrdinalIgnoreCase));
                var prefix = keys.Any(k => k.StartsWith(q, StringComparison.OrdinalIgnoreCase));
                var allTokens = tokens.Length > 0 && tokens.All(t => keys.Any(k => k.Contains(t, StringComparison.OrdinalIgnoreCase)));
                var score = exact ? 3000 : prefix ? 2000 : allTokens ? 1000 : 0;
                if (SearchNormalization.Normalize(e.Term).Equals(q, StringComparison.OrdinalIgnoreCase)) score += 300;
                return (Entry: e, Score: score);
            })
            .Where(x => x.Score > 0)
            .OrderByDescending(x => x.Score)
            .ThenBy(x => x.Entry.Term, StringComparer.OrdinalIgnoreCase)
            .ThenBy(x => x.Entry.Expansion, StringComparer.OrdinalIgnoreCase)
            .Take(Math.Clamp(maxResults, 1, 200))
            .Select(x => x.Entry)
            .ToList();
    }

    public IReadOnlyList<string> ResolveSourceTerms(string? query)
    {
        var q = SearchNormalization.Normalize(query);
        if (q.Length < 2) return [];

        // Alias expansion is intentionally narrower than glossary lookup. Only explicitly
        // curated aliases bridge a user's wording to a different literal source term.
        // The expansion field alone never silently rewrites a cockpit query.
        var sourceTerms = _entries
            .Where(e => e.Aliases.Any(a => SearchNormalization.Normalize(a).Equals(q, StringComparison.OrdinalIgnoreCase)))
            .SelectMany(e => e.SourceTerms.Count > 0 ? e.SourceTerms : [e.Term])
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        // Do not bridge through an abbreviation that is itself glossary-ambiguous
        // (for example GBS). That would create false cross-subject results.
        return sourceTerms.Where(source =>
        {
            var sourceKey = SearchNormalization.Normalize(source);
            var meanings = _entries.Count(e => SearchNormalization.Normalize(e.Term).Equals(sourceKey, StringComparison.OrdinalIgnoreCase));
            return meanings <= 1;
        }).ToList();
    }

    private static IEnumerable<string> EntryKeys(GlossaryEntry entry)
    {
        yield return SearchNormalization.Normalize(entry.Term);
        yield return SearchNormalization.Normalize(entry.Expansion);
        foreach (var alias in entry.Aliases)
            yield return SearchNormalization.Normalize(alias);
    }
}
