using Microsoft.Data.Sqlite;

namespace NivareQ.Step2Pathfinder.Services;

// S2-B R2: data-only Notes collection contracts. No live bridge, pointer or UI integration.
public sealed record NotesPageSummary(string Id, int Ordinal, string Guide, int Spacing, long Revision);

public sealed partial class NotesStoreV1
{
    public IReadOnlyList<NotesNotebook> ListNotebooks(int limit = 200)
    {
        if (limit is < 1 or > 1000) throw new InvalidDataException("Invalid notebook list limit.");
        lock (_writeGate)
        {
            ObjectDisposedException.ThrowIf(_disposed, this);
            using var cmd = Command(_db, null,
                "SELECT id,title,ordinal FROM notebooks ORDER BY ordinal,title,id LIMIT @l", ("@l", limit));
            using var reader = cmd.ExecuteReader();
            var result = new List<NotesNotebook>();
            while (reader.Read()) result.Add(new(reader.GetString(0), reader.GetString(1), reader.GetInt32(2)));
            return result;
        }
    }

    // Paginate metadata only; do not load note bodies or image bytes to draw the library.
    // Trash is an explicit separate view, never intermingled with normal search/results.
    public IReadOnlyList<NotesDocument> ListNotes(string? notebookId = null, bool trash = false,
        int limit = 100, int offset = 0)
    {
        if (limit is < 1 or > 200 || offset < 0 || offset > 1000000)
            throw new InvalidDataException("Invalid Notes library page bounds.");
        if (notebookId is not null) Bounded(notebookId, "notebook ID", 64);
        lock (_writeGate)
        {
            ObjectDisposedException.ThrowIf(_disposed, this);
            using var cmd = Command(_db, null, """
                SELECT id,notebook_id,title,subject_id,active_page_id,revision,pinned,deleted_utc
                  FROM notes WHERE (@book IS NULL OR notebook_id=@book)
                  AND ((@trash=1 AND deleted_utc IS NOT NULL) OR (@trash=0 AND deleted_utc IS NULL))
                  ORDER BY pinned DESC, updated_utc DESC, id LIMIT @l OFFSET @o
                """, ("@book", notebookId), ("@trash", trash ? 1 : 0), ("@l", limit), ("@o", offset));
            using var reader = cmd.ExecuteReader();
            var result = new List<NotesDocument>();
            while (reader.Read()) result.Add(ReadNoteRecord(reader));
            return result;
        }
    }

    // The navigator may display an exact position only when the original
    // note-level verification flag is set AND the source registry revalidates it
    // at open time. Storage does not silently upgrade subject-only references.
    public IReadOnlyList<NotesReference> ReadNoteSources(string noteId)
    {
        Bounded(noteId, "note ID", 64);
        lock (_writeGate)
        {
            ObjectDisposedException.ThrowIf(_disposed, this);
            using var cmd = Command(_db, null, """
                SELECT resource_id,source_version,source_location_json,verified
                  FROM note_sources WHERE note_id=@n ORDER BY id
                """, ("@n", noteId));
            using var reader = cmd.ExecuteReader();
            var sources = new List<NotesReference>();
            while (reader.Read()) sources.Add(new(reader.GetString(0), reader.GetString(1),
                reader.IsDBNull(2) ? null : reader.GetString(2), reader.GetInt32(3) == 1));
            return sources;
        }
    }

    public NotesDocument ReadNote(string noteId)
    {
        Bounded(noteId, "note ID", 64);
        lock (_writeGate)
        {
            ObjectDisposedException.ThrowIf(_disposed, this);
            using var cmd = Command(_db, null, """
                SELECT id,notebook_id,title,subject_id,active_page_id,revision,pinned,deleted_utc
                  FROM notes WHERE id=@id
                """, ("@id", noteId));
            using var reader = cmd.ExecuteReader();
            if (!reader.Read()) throw new KeyNotFoundException("Note not found.");
            return ReadNoteRecord(reader);
        }
    }

    private static NotesDocument ReadNoteRecord(SqliteDataReader reader) => new(
        reader.GetString(0), reader.GetString(1), reader.GetString(2),
        reader.IsDBNull(3) ? null : reader.GetString(3),
        reader.IsDBNull(4) ? null : reader.GetString(4), reader.GetInt64(5),
        reader.GetInt32(6) == 1,
        reader.IsDBNull(7) ? null : DateTimeOffset.Parse(reader.GetString(7),
            System.Globalization.CultureInfo.InvariantCulture));

    public IReadOnlyList<NotesPageSummary> ListPages(string noteId)
    {
        Bounded(noteId, "note ID", 64);
        lock (_writeGate)
        {
            ObjectDisposedException.ThrowIf(_disposed, this);
            using var cmd = Command(_db, null,
                "SELECT id,ordinal,guide,spacing,revision FROM pages WHERE note_id=@id ORDER BY ordinal,id", ("@id", noteId));
            using var reader = cmd.ExecuteReader();
            var pages = new List<NotesPageSummary>();
            while (reader.Read()) pages.Add(new(reader.GetString(0), reader.GetInt32(1),
                reader.GetString(2), reader.GetInt32(3), reader.GetInt64(4)));
            return pages;
        }
    }

    // Note-level CAS complements SavePage's page-level CAS. A pending save or
    // navigation cannot silently overwrite a note rename, move or pin action.
    public long UpdateNoteMetadata(string noteId, long expectedRevision, string notebookId,
        string title, string? subjectId, bool pinned)
    {
        Bounded(noteId, "note ID", 64);
        Bounded(notebookId, "notebook ID", 64);
        Bounded(title, "note title", 240);
        if (subjectId is not null) Bounded(subjectId, "subject ID", 160, true);
        if (expectedRevision < 0) throw new InvalidDataException("Invalid note revision.");
        lock (_writeGate)
        {
            RequireWritableStaging();
            using var tx = _db.BeginTransaction();
            using (var cmd = Command(_db, tx, """
                UPDATE notes SET notebook_id=@b,title=@t,subject_id=@s,pinned=@p,
                    revision=revision+1,updated_utc=@now
                 WHERE id=@id AND revision=@rev AND deleted_utc IS NULL
                """, ("@b", notebookId), ("@t", title), ("@s", subjectId), ("@p", pinned ? 1 : 0),
                ("@now", Now()), ("@id", noteId), ("@rev", expectedRevision)))
                if (cmd.ExecuteNonQuery() != 1) throw new InvalidOperationException("Stale, missing or trashed note metadata.");
            UpdateSearchIndex(tx, noteId);
            tx.Commit();
            return expectedRevision + 1;
        }
    }

    public long SetActivePage(string noteId, string pageId, long expectedNoteRevision)
    {
        Bounded(noteId, "note ID", 64);
        Bounded(pageId, "page ID", 64);
        if (expectedNoteRevision < 0) throw new InvalidDataException("Invalid note revision.");
        lock (_writeGate)
        {
            RequireWritableStaging();
            using var cmd = Command(_db, null, """
                UPDATE notes SET active_page_id=@p,revision=revision+1,updated_utc=@now
                WHERE id=@n AND revision=@rev AND deleted_utc IS NULL
                  AND EXISTS (SELECT 1 FROM pages WHERE id=@p AND note_id=@n)
                """, ("@p", pageId), ("@now", Now()), ("@n", noteId), ("@rev", expectedNoteRevision));
            if (cmd.ExecuteNonQuery() != 1) throw new InvalidOperationException("Stale note or page is not owned by this note.");
            return expectedNoteRevision + 1;
        }
    }

    // Reversible note Trash: do not cascade-delete pages, ink or attachments.
    public long SetTrashed(string noteId, long expectedRevision, bool trashed)
    {
        Bounded(noteId, "note ID", 64);
        if (expectedRevision < 0) throw new InvalidDataException("Invalid note revision.");
        lock (_writeGate)
        {
            RequireWritableStaging();
            using var tx = _db.BeginTransaction();
            using (var cmd = Command(_db, tx, """
                UPDATE notes SET deleted_utc=@deleted,revision=revision+1,updated_utc=@now
                WHERE id=@id AND revision=@rev
                AND ((@trash=1 AND deleted_utc IS NULL) OR (@trash=0 AND deleted_utc IS NOT NULL))
                """, ("@deleted", trashed ? Now() : null), ("@now", Now()),
                ("@id", noteId), ("@rev", expectedRevision), ("@trash", trashed ? 1 : 0)))
                if (cmd.ExecuteNonQuery() != 1) throw new InvalidOperationException("Stale note revision or invalid Trash transition.");
            UpdateSearchIndex(tx, noteId);
            tx.Commit();
            return expectedRevision + 1;
        }
    }
}
