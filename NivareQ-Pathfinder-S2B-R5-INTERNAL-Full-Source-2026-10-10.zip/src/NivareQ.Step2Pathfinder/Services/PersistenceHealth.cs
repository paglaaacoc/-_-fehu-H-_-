namespace NivareQ.Step2Pathfinder.Services;

public sealed class PersistenceNotice
{
    public string Area { get; init; } = "";
    public string Message { get; init; } = "";
    public DateTimeOffset WhenUtc { get; init; } = DateTimeOffset.UtcNow;
}

public sealed class PersistenceWriteResult
{
    public bool Success { get; init; }
    public string Error { get; init; } = "";
    public string Path { get; init; } = "";

    public static PersistenceWriteResult Ok(string path) => new() { Success = true, Path = path };
    public static PersistenceWriteResult Fail(string path, Exception ex) => new() { Success = false, Path = path, Error = ex.Message };
    public static PersistenceWriteResult Fail(string path, string error) => new() { Success = false, Path = path, Error = error };
}

public static class PersistenceHealth
{
    private static readonly object Sync = new();
    private static readonly List<PersistenceNotice> Notices = [];

    public static void Report(string area, string message)
    {
        lock (Sync)
        {
            if (Notices.Any(x => x.Area.Equals(area, StringComparison.OrdinalIgnoreCase) && x.Message == message)) return;
            Notices.Add(new PersistenceNotice { Area = area, Message = message, WhenUtc = DateTimeOffset.UtcNow });
        }
    }

    public static IReadOnlyList<PersistenceNotice> Snapshot()
    {
        lock (Sync) return Notices.ToList();
    }

    public static IReadOnlyList<PersistenceNotice> Drain()
    {
        lock (Sync)
        {
            var copy = Notices.ToList();
            Notices.Clear();
            return copy;
        }
    }
}
