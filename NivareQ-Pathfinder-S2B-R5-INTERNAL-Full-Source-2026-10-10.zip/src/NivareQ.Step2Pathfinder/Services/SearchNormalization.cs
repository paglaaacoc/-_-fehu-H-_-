using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace NivareQ.Step2Pathfinder.Services;

public static class SearchNormalization
{
    private static readonly Regex WhiteSpaceRegex = new(@"\s+", RegexOptions.CultureInvariant | RegexOptions.Compiled);

    public sealed record NormalizedText(string Value, int[] SourceMap);

    public static string Normalize(string? input) => NormalizeWithMap(input ?? "").Value;

    public static NormalizedText NormalizeWithMap(string input)
    {
        if (string.IsNullOrEmpty(input)) return new NormalizedText("", []);

        var sb = new StringBuilder(input.Length);
        var map = new List<int>(input.Length);
        var pendingSpace = false;
        var pendingIndex = 0;

        void AppendSpaceIfNeeded()
        {
            if (!pendingSpace || sb.Length == 0 || sb[^1] == ' ') { pendingSpace = false; return; }
            sb.Append(' ');
            map.Add(pendingIndex);
            pendingSpace = false;
        }

        for (var i = 0; i < input.Length; i++)
        {
            var decomposed = input[i].ToString().Normalize(NormalizationForm.FormD);
            var wroteAlphaNumeric = false;
            foreach (var d in decomposed)
            {
                if (CharUnicodeInfo.GetUnicodeCategory(d) == UnicodeCategory.NonSpacingMark) continue;
                if (!char.IsLetterOrDigit(d)) continue;
                AppendSpaceIfNeeded();
                sb.Append(char.ToLowerInvariant(d));
                map.Add(i);
                wroteAlphaNumeric = true;
            }

            if (!wroteAlphaNumeric)
            {
                pendingSpace = true;
                pendingIndex = i;
            }
        }

        var value = WhiteSpaceRegex.Replace(sb.ToString(), " ").Trim();
        // The builder already collapses separators in normal operation. If Trim removed a
        // leading/trailing separator, keep the mapping aligned with the resulting value.
        if (value.Length == map.Count) return new NormalizedText(value, map.ToArray());

        // Defensive rebuild for unusual Unicode sequences.
        var rebuilt = new StringBuilder(value.Length);
        var rebuiltMap = new List<int>(value.Length);
        var j = 0;
        foreach (var c in value)
        {
            while (j < sb.Length && sb[j] != c) j++;
            rebuilt.Append(c);
            rebuiltMap.Add(j < map.Count ? map[j] : Math.Max(0, input.Length - 1));
            if (j < sb.Length) j++;
        }
        return new NormalizedText(rebuilt.ToString(), rebuiltMap.ToArray());
    }

    public static bool IsTermBoundary(string text, int index)
    {
        if (index <= 0 || index >= text.Length) return true;
        return char.IsWhiteSpace(text[index]);
    }

    public static bool IsWholeTermMatch(string text, int index, int length)
    {
        if (index < 0 || length <= 0 || index + length > text.Length) return false;
        var leftOk = index == 0 || char.IsWhiteSpace(text[index - 1]);
        var right = index + length;
        var rightOk = right >= text.Length || char.IsWhiteSpace(text[right]);
        return leftOk && rightOk;
    }

    public static int IndexOfWholeTerm(string haystack, string needle, int startIndex = 0)
    {
        if (string.IsNullOrWhiteSpace(haystack) || string.IsNullOrWhiteSpace(needle)) return -1;
        var at = Math.Max(0, startIndex);
        while (at < haystack.Length)
        {
            var index = haystack.IndexOf(needle, at, StringComparison.OrdinalIgnoreCase);
            if (index < 0) return -1;
            if (IsWholeTermMatch(haystack, index, needle.Length)) return index;
            at = index + 1;
        }
        return -1;
    }

    public static bool ContainsWholeTerm(string haystack, string needle)
        => IndexOfWholeTerm(haystack, needle) >= 0;

    public static IReadOnlyList<(int Start, int Length)> FindDisplayRanges(string displayText, IEnumerable<string> terms, bool wholeTermsOnly = false)
    {
        if (string.IsNullOrEmpty(displayText)) return [];
        var normalized = NormalizeWithMap(displayText);
        if (normalized.Value.Length == 0 || normalized.SourceMap.Length == 0) return [];

        var ranges = new List<(int Start, int Length)>();
        foreach (var term in terms.Where(x => !string.IsNullOrWhiteSpace(x)).Distinct(StringComparer.OrdinalIgnoreCase))
        {
            var needle = Normalize(term);
            if (needle.Length < 2) continue;
            var at = 0;
            while (at < normalized.Value.Length)
            {
                var index = normalized.Value.IndexOf(needle, at, StringComparison.OrdinalIgnoreCase);
                if (index < 0) break;
                if (wholeTermsOnly && !IsWholeTermMatch(normalized.Value, index, needle.Length))
                {
                    at = index + 1;
                    continue;
                }
                var endIndex = Math.Min(normalized.SourceMap.Length - 1, index + needle.Length - 1);
                var sourceStart = normalized.SourceMap[Math.Min(index, normalized.SourceMap.Length - 1)];
                var sourceEnd = normalized.SourceMap[endIndex];
                if (sourceEnd >= sourceStart)
                    ranges.Add((sourceStart, Math.Max(1, sourceEnd - sourceStart + 1)));
                at = index + Math.Max(1, needle.Length);
            }
        }

        return ranges
            .OrderBy(x => x.Start)
            .ThenByDescending(x => x.Length)
            .Aggregate(new List<(int Start, int Length)>(), (acc, current) =>
            {
                if (acc.Count == 0) { acc.Add(current); return acc; }
                var last = acc[^1];
                var lastEnd = last.Start + last.Length;
                var currentEnd = current.Start + current.Length;
                if (current.Start <= lastEnd)
                    acc[^1] = (last.Start, Math.Max(lastEnd, currentEnd) - last.Start);
                else
                    acc.Add(current);
                return acc;
            });
    }
}
