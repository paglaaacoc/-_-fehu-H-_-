using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Data.Sqlite;

namespace NivareQ.Step2Pathfinder.Services;

// S2-B INTERNAL / NOT YET CONNECTED TO THE APPLICATION.
// An unactivated generation can be created and verified, but only the future
// Backup VNext restore transaction may publish a generation pointer.
public sealed record NotesNotebook(string Id, string Title, int Ordinal);
public sealed record NotesReference(string ResourceId, string SourceVersion, string? SourceLocationJson, bool Verified);
public sealed record NotesInkCell(string Text, string StrokesJson);
public sealed record NotesImageObject(string Id, int CellIndex, string Sha256, double X, double Y, double Width, double Height, int ZIndex);
public sealed record NotesAttachment(string Sha256, string Mime, long ByteLength, int Width, int Height);
public sealed record NotesPage(string Id, string NoteId, int Ordinal, string Guide, int Spacing, long Revision,
    IReadOnlyList<NotesInkCell> Cells, IReadOnlyList<NotesImageObject> Images);
public sealed record NotesDocument(string Id, string NotebookId, string Title, string? SubjectId,
    string? ActivePageId, long Revision, bool Pinned, DateTimeOffset? DeletedUtc);
public sealed record S1ImportReport(int PadCount, int PageCount, int CellCount, int InkStrokeCount, string SourceSha256);

public sealed partial class NotesStoreV1 : IDisposable
{
    public const string GenerationPointerKey = "nivareq.notes.activeGeneration.v1";
    private const int MaxImageBytes = 25 * 1024 * 1024;
    private const int MaxImageDimension = 8192;
    private const long MaxImagePixels = 40_000_000;
    private readonly SqliteConnection _db;
    private readonly string _generationDirectory;
    private readonly object _writeGate = new();
    private bool _disposed;
    private readonly bool _writableStaging;

    private NotesStoreV1(string generationDirectory, SqliteConnection db, bool writableStaging)
    {
        _generationDirectory = generationDirectory;
        _db = db;
        _writableStaging = writableStaging;
    }

    // There is intentionally no active-generation writer yet. S2-D must
    // provide an atomic provider-pointer/mutation-gate owner before enabling it.
    private void RequireWritableStaging()
    {
        // SQLite connections are not shared concurrently: lock even the initial
        // guard read, not only the subsequent mutation. The lock is reentrant.
        lock (_writeGate)
        {
            ObjectDisposedException.ThrowIf(_disposed, this);
            if (!_writableStaging)
                throw new InvalidOperationException("This verified generation is read-only. Active-store mutation is not authorized by S2-B.");
            using var cmd = Command(_db, null, "SELECT value FROM meta WHERE key='stage_state'");
            if ((string?)cmd.ExecuteScalar() != "building")
                throw new InvalidOperationException("This generation is sealed or invalid; no further staging writes are allowed.");
        }
    }

    public string GenerationId => Path.GetFileName(_generationDirectory);
    public string DatabasePath => Path.Combine(_generationDirectory, "notes.sqlite");
    public string AttachmentsRoot => Path.Combine(_generationDirectory, "attachments");

    // Never called automatically on startup, while S2-D atomic activation is unfinished.
    // Staging creates a *new* random generation; it never replaces a live generation.
    public static NotesStoreV1 CreateStaging(string notesRoot)
    {
        var root = Path.Combine(notesRoot, "generations");
        Directory.CreateDirectory(root);
        var id = Guid.NewGuid().ToString("N");
        var dir = Path.Combine(root, id);
        Directory.CreateDirectory(dir);
        try
        {
            Directory.CreateDirectory(Path.Combine(dir, "attachments"));
            var db = new SqliteConnection(new SqliteConnectionStringBuilder
            {
                DataSource = Path.Combine(dir, "notes.sqlite"),
                Mode = SqliteOpenMode.ReadWriteCreate,
                Cache = SqliteCacheMode.Private,
                Pooling = false
            }.ToString());
            db.Open();
            try
            {
                using var pragma = db.CreateCommand();
                pragma.CommandText = "PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;";
                pragma.ExecuteNonQuery();
                Initialize(db);
                return new NotesStoreV1(dir, db, writableStaging: true);
            }
            catch { db.Dispose(); throw; }
        }
        catch
        {
            // Preserve partially created evidence for forensic review; do not delete it.
            throw;
        }
    }

    // An untrusted pointer must never be interpreted as an arbitrary filesystem path.
    // Internal recovery/verification open; still NOT a live-store activation API.
    // Never create an empty DB in place of missing/corrupt authoritative data.
    public static NotesStoreV1 OpenStagedGeneration(string notesRoot, string generationId)
    {
        if (!IsValidGenerationId(generationId)) throw new InvalidDataException("Invalid Notes generation pointer.");
        var dir = Path.Combine(notesRoot, "generations", generationId);
        var dbPath = Path.Combine(dir, "notes.sqlite");
        if (!File.Exists(dbPath)) throw new FileNotFoundException("Notes SQLite generation is missing; no replacement was created.", dbPath);
        var db = new SqliteConnection(new SqliteConnectionStringBuilder
        {
            DataSource = dbPath, Mode = SqliteOpenMode.ReadOnly,
            Cache = SqliteCacheMode.Private, Pooling = false
        }.ToString());
        db.Open();
        try
        {
            using (var pragma = db.CreateCommand())
            {
                pragma.CommandText = "PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;";
                pragma.ExecuteNonQuery();
            }
            using (var schema = Command(db, null, "SELECT value FROM meta WHERE key='schema_version'"))
                if ((string?)schema.ExecuteScalar() != "1")
                    throw new InvalidDataException("Notes schema is unsupported. Existing data has not been modified.");
            using (var stage = Command(db, null, "SELECT value FROM meta WHERE key='stage_state'"))
                if ((string?)stage.ExecuteScalar() is not ("building" or "sealed"))
                    throw new InvalidDataException("Unrecognized Notes generation state.");
            var store = new NotesStoreV1(dir, db, writableStaging: false);
            store.VerifyIntegrity();
            return store;
        }
        catch { db.Dispose(); throw; }
    }

    public static bool IsValidGenerationId(string? id)
        => id is { Length: 32 } && id.All(c => c is >= '0' and <= '9' or >= 'a' and <= 'f');

    private static SqliteCommand Command(SqliteConnection db, SqliteTransaction? tx, string sql,
        params (string Name, object? Value)[] bindings)
    {
        var cmd = db.CreateCommand();
        cmd.Transaction = tx;
        cmd.CommandText = sql;
        foreach (var (name, value) in bindings) cmd.Parameters.AddWithValue(name, value ?? DBNull.Value);
        return cmd;
    }

    private static void Initialize(SqliteConnection db)
    {
        using var transaction = db.BeginTransaction();
        using (var cmd = Command(db, transaction, """
            CREATE TABLE meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
            INSERT INTO meta VALUES ('schema_version','1');
            INSERT INTO meta VALUES ('stage_state','building');
            CREATE TABLE notebooks (
              id TEXT PRIMARY KEY NOT NULL, title TEXT NOT NULL CHECK(length(title) BETWEEN 1 AND 160),
              ordinal INTEGER NOT NULL, created_utc TEXT NOT NULL, updated_utc TEXT NOT NULL);
            CREATE TABLE notes (
              id TEXT PRIMARY KEY NOT NULL, notebook_id TEXT NOT NULL REFERENCES notebooks(id) ON DELETE RESTRICT,
              title TEXT NOT NULL CHECK(length(title) BETWEEN 1 AND 240), subject_id TEXT,
              active_page_id TEXT, revision INTEGER NOT NULL DEFAULT 0,
              pinned INTEGER NOT NULL DEFAULT 0 CHECK(pinned IN (0,1)), deleted_utc TEXT,
              legacy_s1_pad_id TEXT UNIQUE, created_utc TEXT NOT NULL, updated_utc TEXT NOT NULL);
            CREATE INDEX idx_notes_notebook ON notes(notebook_id,deleted_utc,updated_utc);
            CREATE TABLE note_sources (
              id TEXT PRIMARY KEY, note_id TEXT NOT NULL REFERENCES notes(id) ON DELETE CASCADE,
              resource_id TEXT NOT NULL, source_version TEXT NOT NULL, source_location_json TEXT,
              verified INTEGER NOT NULL CHECK(verified IN (0,1)),
              CHECK(verified=0 OR (length(resource_id)>0 AND length(source_version)>0 AND source_location_json IS NOT NULL)));
            CREATE INDEX idx_note_sources_note ON note_sources(note_id);
            CREATE TABLE pages (
              id TEXT PRIMARY KEY NOT NULL, note_id TEXT NOT NULL REFERENCES notes(id) ON DELETE CASCADE,
              ordinal INTEGER NOT NULL, guide TEXT NOT NULL CHECK(guide IN ('blank','ruled','triple')),
              spacing INTEGER NOT NULL CHECK(spacing BETWEEN 20 AND 100),
              revision INTEGER NOT NULL DEFAULT 0, legacy_s1_page_id TEXT,
              UNIQUE(note_id,ordinal));
            CREATE TABLE cells (
              page_id TEXT NOT NULL REFERENCES pages(id) ON DELETE CASCADE, cell_index INTEGER NOT NULL CHECK(cell_index BETWEEN 0 AND 3),
              text TEXT NOT NULL, strokes_json TEXT NOT NULL, PRIMARY KEY(page_id,cell_index));
            CREATE TABLE attachments (
              sha256 TEXT PRIMARY KEY, mime TEXT NOT NULL CHECK(mime IN ('image/png','image/jpeg')),
              bytes INTEGER NOT NULL CHECK(bytes>0 AND bytes<=26214400),
              width INTEGER NOT NULL CHECK(width>0 AND width<=8192),
              height INTEGER NOT NULL CHECK(height>0 AND height<=8192), added_utc TEXT NOT NULL);
            CREATE TABLE image_objects (
              id TEXT PRIMARY KEY, page_id TEXT NOT NULL REFERENCES pages(id) ON DELETE CASCADE,
              cell_index INTEGER NOT NULL CHECK(cell_index BETWEEN 0 AND 3),
              sha256 TEXT NOT NULL REFERENCES attachments(sha256) ON DELETE RESTRICT,
              x REAL NOT NULL, y REAL NOT NULL, width REAL NOT NULL, height REAL NOT NULL,
              z_index INTEGER NOT NULL,
              CHECK(x>=0 AND x<=1 AND y>=0 AND y<=1 AND width>0 AND width<=1 AND height>0 AND height<=1));
            CREATE INDEX idx_image_objects_sha ON image_objects(sha256);
            CREATE VIRTUAL TABLE note_fts USING fts5(note_id UNINDEXED, title, body, tokenize='unicode61');
            """)) cmd.ExecuteNonQuery();
        transaction.Commit();
    }

    private static string Now() => DateTimeOffset.UtcNow.ToString("O", CultureInfo.InvariantCulture);
    private static string Id() => Guid.NewGuid().ToString("N");
    private static void Bounded(string? value, string name, int max, bool allowEmpty = false)
    {
        if (value is null || value.Length > max || (!allowEmpty && value.Length == 0) || value.IndexOf('\0') >= 0)
            throw new InvalidDataException($"Invalid {name}.");
    }
    private static void ValidatePage(string guide, int spacing, IReadOnlyList<NotesInkCell> cells,
        IReadOnlyList<NotesImageObject> images)
    {
        if (guide is not ("blank" or "ruled" or "triple") || spacing < 20 || spacing > 100)
            throw new InvalidDataException("Invalid writing guide.");
        if (cells.Count is not (1 or 2 or 4)) throw new InvalidDataException("Only 1, 2 or 4 writing spaces are allowed.");
        foreach (var cell in cells)
        {
            Bounded(cell.Text, "cell text", 120000, true);
            using var ink = JsonDocument.Parse(cell.StrokesJson);
            if (ink.RootElement.ValueKind != JsonValueKind.Array || ink.RootElement.GetArrayLength() > 25000)
                throw new InvalidDataException("Invalid ink collection.");
            foreach (var stroke in ink.RootElement.EnumerateArray())
            {
                var color = stroke.GetProperty("color").GetString();
                if (color is not ("#142235" or "#2563eb" or "#b91c1c" or "#047857"))
                    throw new InvalidDataException("Invalid ink color.");
                var width = stroke.GetProperty("width").GetDouble();
                if (!double.IsFinite(width) || width < 1 || width > 12) throw new InvalidDataException("Invalid ink width.");
                var points = stroke.GetProperty("points");
                if (points.ValueKind != JsonValueKind.Array || points.GetArrayLength() is < 1 or > 4000)
                    throw new InvalidDataException("Invalid ink points.");
                foreach (var pt in points.EnumerateArray())
                {
                    if (pt.ValueKind != JsonValueKind.Array || pt.GetArrayLength() != 2) throw new InvalidDataException("Invalid ink point.");
                    foreach (var v in pt.EnumerateArray())
                        if (v.ValueKind != JsonValueKind.Number || !double.IsFinite(v.GetDouble()) || v.GetDouble() < 0 || v.GetDouble() > 1)
                            throw new InvalidDataException("Invalid ink coordinate.");
                }
            }
        }
        var ids = new HashSet<string>(StringComparer.Ordinal);
        foreach (var obj in images)
        {
            Bounded(obj.Id, "image object ID", 100);
            if (!ids.Add(obj.Id) || obj.CellIndex < 0 || obj.CellIndex >= cells.Count ||
                !IsHash(obj.Sha256) || obj.ZIndex is < -10000 or > 10000 ||
                !ValidRatio(obj.X) || !ValidRatio(obj.Y) || !ValidRatio(obj.Width, false) || !ValidRatio(obj.Height, false) ||
                obj.X + obj.Width > 1.000001 || obj.Y + obj.Height > 1.000001)
                throw new InvalidDataException("Invalid floating image object.");
        }
    }
    private static bool ValidRatio(double v, bool zeroAllowed = true) => double.IsFinite(v) && (zeroAllowed ? v >= 0 : v > 0) && v <= 1;
    private static bool IsHash(string? hash) => hash is { Length: 64 } && hash.All(c => c is >= '0' and <= '9' or >= 'a' and <= 'f');

    public string CreateNotebook(string title, int ordinal = 0)
    {
        RequireWritableStaging();
        Bounded(title, "notebook title", 160);
        lock (_writeGate)
        {
            RequireWritableStaging();
            using var cmd = Command(_db, null,
                "INSERT INTO notebooks (id,title,ordinal,created_utc,updated_utc) VALUES (@id,@title,@o,@t,@t)",
                ("@id", Id()), ("@title", title), ("@o", ordinal), ("@t", Now()));
            var id = (string)cmd.Parameters["@id"].Value;
            cmd.ExecuteNonQuery();
            return id;
        }
    }

    public string CreateNote(string notebookId, string title, string? subjectId = null,
        IReadOnlyList<NotesReference>? references = null, string? legacyS1PadId = null,
        Func<NotesReference, bool>? verifyExactSource = null)
    {
        RequireWritableStaging();
        foreach (var source in references ?? [])
            if (source.Verified && (verifyExactSource is null || !verifyExactSource(source)))
                throw new InvalidDataException("Verified source reference rejected: source must be validated against the active source registry.");
        Bounded(notebookId, "notebook ID", 64);
        Bounded(title, "note title", 240);
        if (subjectId is not null) Bounded(subjectId, "subject ID", 160, true);
        if (legacyS1PadId is not null) Bounded(legacyS1PadId, "legacy ID", 64);
        var noteId = Id(); var pageId = Id(); var time = Now();
        lock (_writeGate)
        {
            RequireWritableStaging();
            using var tx = _db.BeginTransaction();
            using (var cmd = Command(_db, tx, """
                INSERT INTO notes (id,notebook_id,title,subject_id,active_page_id,legacy_s1_pad_id,created_utc,updated_utc)
                VALUES (@id,@notebook,@title,@subject,@page,@legacy,@now,@now)
                """, ("@id", noteId), ("@notebook", notebookId), ("@title", title), ("@subject", subjectId),
                ("@page", pageId), ("@legacy", legacyS1PadId), ("@now", time))) cmd.ExecuteNonQuery();
            using (var cmd = Command(_db, tx,
                "INSERT INTO pages (id,note_id,ordinal,guide,spacing,revision) VALUES (@page,@note,0,'ruled',32,0)",
                ("@page", pageId), ("@note", noteId))) cmd.ExecuteNonQuery();
            using (var cmd = Command(_db, tx,
                "INSERT INTO cells (page_id,cell_index,text,strokes_json) VALUES (@page,0,'','[]')", ("@page", pageId))) cmd.ExecuteNonQuery();
            InsertSources(tx, noteId, references ?? []);
            UpdateSearchIndex(tx, noteId);
            tx.Commit();
        }
        return noteId;
    }

    private void InsertSources(SqliteTransaction tx, string noteId, IReadOnlyList<NotesReference> refs)
    {
        if (refs.Count > 100) throw new InvalidDataException("Too many note source references.");
        foreach (var reference in refs)
        {
            Bounded(reference.ResourceId, "resource ID", 180, true);
            Bounded(reference.SourceVersion, "source version", 180, true);
            if (reference.SourceLocationJson is not null)
            {
                Bounded(reference.SourceLocationJson, "source location", 16000);
                using var json = JsonDocument.Parse(reference.SourceLocationJson);
                if (json.RootElement.ValueKind != JsonValueKind.Object) throw new InvalidDataException("Invalid source location.");
            }
            if (reference.Verified && (string.IsNullOrWhiteSpace(reference.ResourceId) ||
                string.IsNullOrWhiteSpace(reference.SourceVersion) || reference.SourceLocationJson is null))
                throw new InvalidDataException("An exact source must be verified; no position may be invented.");
            using var cmd = Command(_db, tx, """
                INSERT INTO note_sources (id,note_id,resource_id,source_version,source_location_json,verified)
                VALUES (@id,@n,@r,@v,@loc,@verified)
                """, ("@id", Id()), ("@n", noteId), ("@r", reference.ResourceId),
                ("@v", reference.SourceVersion), ("@loc", reference.SourceLocationJson), ("@verified", reference.Verified ? 1 : 0));
            cmd.ExecuteNonQuery();
        }
    }

    public string AddPage(string noteId, int ordinal, string guide = "ruled", int spacing = 32,
        string? legacyS1PageId = null)
    {
        RequireWritableStaging();
        Bounded(noteId, "note ID", 64);
        if (ordinal < 0 || guide is not ("blank" or "ruled" or "triple") || spacing is < 20 or > 100)
            throw new InvalidDataException("Invalid page.");
        if (legacyS1PageId is not null) Bounded(legacyS1PageId, "legacy page ID", 64);
        var id = Id();
        lock (_writeGate)
        {
            RequireWritableStaging();
            using var tx = _db.BeginTransaction();
            using (var status = Command(_db, tx,
                "SELECT COUNT(*) FROM notes WHERE id=@n AND deleted_utc IS NULL", ("@n", noteId)))
                if ((long)(status.ExecuteScalar() ?? 0L) != 1L)
                    throw new InvalidOperationException("Cannot add a page to a missing or trashed note.");
            using (var cmd = Command(_db, tx,
                "INSERT INTO pages (id,note_id,ordinal,guide,spacing,legacy_s1_page_id) VALUES (@id,@n,@o,@g,@s,@legacy)",
                ("@id", id), ("@n", noteId), ("@o", ordinal), ("@g", guide), ("@s", spacing), ("@legacy", legacyS1PageId))) cmd.ExecuteNonQuery();
            using (var cmd = Command(_db, tx,
                "INSERT INTO cells (page_id,cell_index,text,strokes_json) VALUES (@id,0,'','[]')", ("@id", id))) cmd.ExecuteNonQuery();
            using (var cmd = Command(_db, tx,
                "UPDATE notes SET revision=revision+1,updated_utc=@now WHERE id=@n", ("@now", Now()), ("@n", noteId)))
                if (cmd.ExecuteNonQuery() != 1) throw new InvalidDataException("Page belongs to a missing note.");
            tx.Commit();
        }
        return id;
    }

    // Page-level compare-and-swap: an older pending save cannot overwrite an ACKed revision.
    // The renderer's future S2-C bridge must send its last acknowledged revision.
    public long SavePage(string noteId, string pageId, long expectedRevision,
        string guide, int spacing, IReadOnlyList<NotesInkCell> cells,
        IReadOnlyList<NotesImageObject>? images = null)
    {
        RequireWritableStaging();
        var objects = images ?? [];
        ValidatePage(guide, spacing, cells, objects);
        if (expectedRevision < 0) throw new InvalidDataException("Invalid page revision.");
        lock (_writeGate)
        {
            RequireWritableStaging();
            using var tx = _db.BeginTransaction();
            // S2 cannot silently discard writing spaces. Smaller layouts may only
            // trim demonstrably EMPTY cells with no image objects. Populated cells
            // require an eventual reversible per-cell Trash operation.
            using (var removed = Command(_db, tx,
                "SELECT text,strokes_json FROM cells WHERE page_id=@p AND cell_index>=@count",
                ("@p", pageId), ("@count", cells.Count)))
            using (var reader = removed.ExecuteReader())
                while (reader.Read())
                    if (reader.GetString(0).Length != 0 || reader.GetString(1) != "[]")
                        throw new InvalidOperationException("Reducing writing spaces would discard saved text or ink.");
            using (var removedImages = Command(_db, tx,
                "SELECT COUNT(*) FROM image_objects WHERE page_id=@p AND cell_index>=@count",
                ("@p", pageId), ("@count", cells.Count)))
                if ((long)(removedImages.ExecuteScalar() ?? 0L) != 0)
                    throw new InvalidOperationException("Reducing writing spaces would discard an image.");
            using (var cmd = Command(_db, tx, """
                UPDATE pages SET guide=@g, spacing=@s, revision=revision+1
                 WHERE id=@p AND note_id=@n AND revision=@rev
                   AND EXISTS (SELECT 1 FROM notes WHERE id=@n AND deleted_utc IS NULL)
                """, ("@g", guide), ("@s", spacing), ("@p", pageId),
                ("@n", noteId), ("@rev", expectedRevision)))
            {
                if (cmd.ExecuteNonQuery() != 1)
                    throw new InvalidOperationException("The page changed since the last acknowledged save; reload before retrying.");
            }
            using (var cmd = Command(_db, tx, "DELETE FROM image_objects WHERE page_id=@p", ("@p", pageId))) cmd.ExecuteNonQuery();
            using (var cmd = Command(_db, tx, "DELETE FROM cells WHERE page_id=@p", ("@p", pageId))) cmd.ExecuteNonQuery();
            for (var i = 0; i < cells.Count; i++)
            {
                var cell = cells[i];
                using var cmd = Command(_db, tx,
                    "INSERT INTO cells (page_id,cell_index,text,strokes_json) VALUES (@p,@i,@t,@s)",
                    ("@p", pageId), ("@i", i), ("@t", cell.Text), ("@s", cell.StrokesJson));
                cmd.ExecuteNonQuery();
            }
            foreach (var obj in objects)
            {
                using var cmd = Command(_db, tx, """
                    INSERT INTO image_objects (id,page_id,cell_index,sha256,x,y,width,height,z_index)
                    VALUES (@id,@p,@c,@sha,@x,@y,@w,@h,@z)
                    """, ("@id", obj.Id), ("@p", pageId), ("@c", obj.CellIndex), ("@sha", obj.Sha256),
                    ("@x", obj.X), ("@y", obj.Y), ("@w", obj.Width), ("@h", obj.Height), ("@z", obj.ZIndex));
                cmd.ExecuteNonQuery();
            }
            using (var cmd = Command(_db, tx, "UPDATE notes SET revision=revision+1,updated_utc=@now WHERE id=@n",
                ("@now", Now()), ("@n", noteId))) cmd.ExecuteNonQuery();
            UpdateSearchIndex(tx, noteId);
            tx.Commit();
            return expectedRevision + 1;
        }
    }

    private void UpdateSearchIndex(SqliteTransaction tx, string noteId)
    {
        using (var del = Command(_db, tx, "DELETE FROM note_fts WHERE note_id=@id", ("@id", noteId))) del.ExecuteNonQuery();
        using (var add = Command(_db, tx, """
            INSERT INTO note_fts(note_id,title,body)
            SELECT n.id,n.title,COALESCE((SELECT group_concat(c.text,' ') FROM pages p
                    JOIN cells c ON c.page_id=p.id WHERE p.note_id=n.id),'')
            FROM notes n WHERE n.id=@id AND n.deleted_utc IS NULL
            """, ("@id", noteId))) add.ExecuteNonQuery();
    }

    public NotesPage ReadPage(string noteId, string pageId)
    {
        lock (_writeGate)
        {
            ObjectDisposedException.ThrowIf(_disposed, this);
            using var cmd = Command(_db, null,
                "SELECT ordinal,guide,spacing,revision FROM pages WHERE id=@p AND note_id=@n",
                ("@p", pageId), ("@n", noteId));
            using var r = cmd.ExecuteReader();
            if (!r.Read()) throw new KeyNotFoundException("Page not found.");
            var ordinal = r.GetInt32(0); var guide = r.GetString(1);
            var spacing = r.GetInt32(2); var revision = r.GetInt64(3);
            r.Close();
            using var cellCmd = Command(_db, null,
                "SELECT text,strokes_json FROM cells WHERE page_id=@p ORDER BY cell_index", ("@p", pageId));
            using var cellsReader = cellCmd.ExecuteReader();
            var cells = new List<NotesInkCell>();
            while (cellsReader.Read()) cells.Add(new NotesInkCell(cellsReader.GetString(0), cellsReader.GetString(1)));
            cellsReader.Close();
            using var imageCmd = Command(_db, null, """
                SELECT id,cell_index,sha256,x,y,width,height,z_index
                  FROM image_objects WHERE page_id=@p ORDER BY z_index,id
                """, ("@p", pageId));
            using var imageReader = imageCmd.ExecuteReader();
            var images = new List<NotesImageObject>();
            while (imageReader.Read()) images.Add(new NotesImageObject(
                imageReader.GetString(0), imageReader.GetInt32(1), imageReader.GetString(2),
                imageReader.GetDouble(3), imageReader.GetDouble(4), imageReader.GetDouble(5),
                imageReader.GetDouble(6), imageReader.GetInt32(7)));
            return new NotesPage(pageId, noteId, ordinal, guide, spacing, revision, cells, images);
        }
    }

    public IReadOnlyList<string> SearchNoteIds(string query, int limit = 50)
    {
        lock (_writeGate)
        {
            ObjectDisposedException.ThrowIf(_disposed, this);
            if (string.IsNullOrWhiteSpace(query)) return [];
            if (query.Length > 256 || limit < 1 || limit > 200) throw new InvalidDataException("Search bounds exceeded.");
            // Treat plain user words as quoted FTS phrases, never as a user-supplied FTS query program.
            var phrase = "\"" + query.Replace("\"", "\"\"") + "\"";
            using var cmd = Command(_db, null,
                "SELECT note_id FROM note_fts WHERE note_fts MATCH @term LIMIT @limit", ("@term", phrase), ("@limit", limit));
            using var reader = cmd.ExecuteReader();
            var result = new List<string>();
            while (reader.Read()) result.Add(reader.GetString(0));
            return result;
        }
    }

    // Immutable blob first, database ref second. No automatic orphan cleanup; S2-D
    // backup will include ONLY referenced blobs and integrity-check them.
    public NotesAttachment PutAttachment(Stream input, string declaredMime)
    {
        lock (_writeGate) return PutAttachmentCore(input, declaredMime);
    }

    private NotesAttachment PutAttachmentCore(Stream input, string declaredMime)
    {
        RequireWritableStaging();
        if (declaredMime is not ("image/png" or "image/jpeg"))
            throw new InvalidDataException("Only PNG/JPEG images are currently allowed.");
        var tmp = Path.Combine(AttachmentsRoot, ".incoming-" + Id());
        Directory.CreateDirectory(AttachmentsRoot);
        try
        {
            using (var output = new FileStream(tmp, FileMode.CreateNew, FileAccess.Write,
                FileShare.None, 65536, FileOptions.WriteThrough))
            {
                var buffer = new byte[65536];
                var total = 0;
                int count;
                while ((count = input.Read(buffer, 0, buffer.Length)) > 0)
                {
                    total = checked(total + count);
                    if (total > MaxImageBytes) throw new InvalidDataException("Image exceeds 25 MB.");
                    output.Write(buffer, 0, count);
                }
                output.Flush(flushToDisk: true);
            }
            var bytes = File.ReadAllBytes(tmp); // bounded to 25 MB by the streaming admission gate
            var (mime, width, height) = InspectImage(bytes);
            if (mime != declaredMime) throw new InvalidDataException("Image MIME type and bytes disagree.");
            var hash = Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
            var extension = mime == "image/png" ? ".png" : ".jpg";
            var destination = Path.Combine(AttachmentsRoot, hash + extension);
            lock (_writeGate)
            {
                if (File.Exists(destination))
                {
                    if (!SHA256.HashData(File.ReadAllBytes(destination)).SequenceEqual(SHA256.HashData(bytes)))
                        throw new InvalidDataException("An existing image hash has corrupt bytes. Saving is blocked.");
                }
                else File.Move(tmp, destination); // same directory, no partial published blob
                using var cmd = Command(_db, null, """
                    INSERT OR IGNORE INTO attachments (sha256,mime,bytes,width,height,added_utc)
                    VALUES (@sha,@mime,@bytes,@w,@h,@now)
                    """, ("@sha", hash), ("@mime", mime), ("@bytes", bytes.Length),
                    ("@w", width), ("@h", height), ("@now", Now()));
                cmd.ExecuteNonQuery();
                return new NotesAttachment(hash, mime, bytes.Length, width, height);
            }
        }
        finally { try { if (File.Exists(tmp)) File.Delete(tmp); } catch { /* retained orphan, never ACKed */ } }
    }

    private static (string mime, int width, int height) InspectImage(byte[] bytes)
    {
        if (bytes.Length < 24) throw new InvalidDataException("Truncated image.");
        int w, h; string mime;
        if (bytes.AsSpan(0, 8).SequenceEqual(new byte[] { 137,80,78,71,13,10,26,10 }))
        {
            // Structural PNG validation (including every chunk CRC) before publication.
            // S2-C must additionally verify actual decoding through the image renderer.
            var pos = 8; var ihdr = false; var idat = false; var ended = false;
            w = 0; h = 0; mime = "image/png";
            while (pos + 12 <= bytes.Length)
            {
                var length = System.Buffers.Binary.BinaryPrimitives.ReadUInt32BigEndian(bytes.AsSpan(pos,4));
                if (length > MaxImageBytes || (long)pos + length + 12 > bytes.Length)
                    throw new InvalidDataException("Truncated PNG chunk.");
                var chunkType = Encoding.ASCII.GetString(bytes,pos+4,4);
                var chunkStart = pos + 4;
                var expectedCrc = System.Buffers.Binary.BinaryPrimitives.ReadUInt32BigEndian(
                    bytes.AsSpan(checked(pos+8+(int)length),4));
                if (PngCrc(bytes.AsSpan(chunkStart,checked(4+(int)length))) != expectedCrc)
                    throw new InvalidDataException("PNG checksum mismatch.");
                if (!ihdr && chunkType != "IHDR") throw new InvalidDataException("PNG IHDR must be first.");
                if (chunkType == "IHDR")
                {
                    if (ihdr || length != 13) throw new InvalidDataException("Invalid PNG IHDR.");
                    ihdr = true;
                    w = checked((int)System.Buffers.Binary.BinaryPrimitives.ReadUInt32BigEndian(bytes.AsSpan(pos+8,4)));
                    h = checked((int)System.Buffers.Binary.BinaryPrimitives.ReadUInt32BigEndian(bytes.AsSpan(pos+12,4)));
                    if (bytes[pos+16] is not (1 or 2 or 4 or 8 or 16) || bytes[pos+18] != 0 || bytes[pos+19] != 0)
                        throw new InvalidDataException("Unsupported PNG parameters.");
                }
                else if (chunkType == "IDAT") idat = true;
                else if (chunkType == "IEND")
                {
                    if (length != 0 || !idat) throw new InvalidDataException("PNG missing image data.");
                    ended = true;
                }
                else if (chunkType.Length == 4 && char.IsUpper(chunkType[0]) &&
                    chunkType is not ("PLTE" or "sRGB" or "gAMA" or "cHRM" or "iCCP"))
                    throw new InvalidDataException("Unsupported required PNG chunk.");
                pos = checked(pos + 12 + (int)length);
                if (ended) break;
            }
            if (!ended || pos != bytes.Length) throw new InvalidDataException("PNG missing final IEND or contains trailing data.");
        }
        else if (bytes[0] == 0xff && bytes[1] == 0xd8 && bytes[^2] == 0xff && bytes[^1] == 0xd9)
        {
            mime = "image/jpeg"; w = 0; h = 0; var pos = 2;
            while (pos + 4 < bytes.Length && pos < 1_000_000)
            {
                if (bytes[pos] != 0xff) throw new InvalidDataException("Invalid JPEG marker.");
                while (pos < bytes.Length && bytes[pos] == 0xff) pos++;
                if (pos >= bytes.Length) break;
                var marker = bytes[pos++];
                if (marker == 0xd9 || marker == 0xda) break;
                if (marker is 0x01 or >= 0xd0 and <= 0xd7) continue;
                if (pos + 2 > bytes.Length) break;
                var length = System.Buffers.Binary.BinaryPrimitives.ReadUInt16BigEndian(bytes.AsSpan(pos,2));
                if (length < 2 || pos + length > bytes.Length) throw new InvalidDataException("Invalid JPEG segment.");
                if (marker is >= 0xc0 and <= 0xc3 or >= 0xc5 and <= 0xc7 or >= 0xc9 and <= 0xcb or >= 0xcd and <= 0xcf)
                {
                    if (length < 7) throw new InvalidDataException("Truncated JPEG dimensions.");
                    h = System.Buffers.Binary.BinaryPrimitives.ReadUInt16BigEndian(bytes.AsSpan(pos + 3,2));
                    w = System.Buffers.Binary.BinaryPrimitives.ReadUInt16BigEndian(bytes.AsSpan(pos + 5,2));
                    break;
                }
                pos += length;
            }
        }
        else throw new InvalidDataException("Unsupported or malformed image.");
        if (w <= 0 || h <= 0 || w > MaxImageDimension || h > MaxImageDimension || (long)w * h > MaxImagePixels)
            throw new InvalidDataException("Image dimensions exceed safety limits or could not be decoded.");
        return (mime, w, h);
    }

    private static uint PngCrc(ReadOnlySpan<byte> bytes)
    {
        uint crc = 0xffffffff;
        foreach (var b in bytes)
        {
            crc ^= b;
            for (var i=0; i<8; i++) crc = (crc & 1) != 0 ? (crc >> 1) ^ 0xedb88320u : crc >> 1;
        }
        return ~crc;
    }

    public void SealStaging()
    {
        RequireWritableStaging();
        lock (_writeGate)
        {
            RequireWritableStaging();
            VerifyIntegrity();
            // An incomplete or interrupted S1 import is permanently quarantine-only.
            // No activation/backup may mistake its partial rows for completed migration.
            using (var cmd = Command(_db, null, "SELECT value FROM meta WHERE key='s1_import_state'"))
            {
                var status = cmd.ExecuteScalar() as string;
                if (status is not null && status != "complete")
                    throw new InvalidDataException("Incomplete S1 import: generation cannot be sealed.");
                if (status is null && File.Exists(Path.Combine(_generationDirectory, "s1-import-source.json")))
                    throw new InvalidDataException("Unmarked S1 source evidence: generation cannot be sealed.");
            }
            using (var cmd = Command(_db, null,
                "UPDATE meta SET value='sealed' WHERE key='stage_state' AND value='building'"))
                if (cmd.ExecuteNonQuery() != 1) throw new InvalidDataException("Invalid stage state.");
            // Force a consistent checkpoint of this generation before eventual backup/activation.
            using var checkpoint = Command(_db, null, "PRAGMA wal_checkpoint(TRUNCATE)");
            using var reader = checkpoint.ExecuteReader();
            if (!reader.Read() || reader.GetInt32(0) != 0)
                throw new IOException("Could not checkpoint Notes staging SQLite database.");
        }
    }

    public void VerifyIntegrity()
    {
        lock (_writeGate)
        {
            using (var cmd = Command(_db, null, "PRAGMA integrity_check"))
                if ((string?)cmd.ExecuteScalar() != "ok") throw new InvalidDataException("Notes SQLite integrity check failed.");
            using (var cmd = Command(_db, null, "PRAGMA foreign_key_check"))
                using (var reader = cmd.ExecuteReader())
                    if (reader.Read()) throw new InvalidDataException("Notes contain a broken foreign-key reference.");
            // active_page_id is a deliberately non-FK circular reference; verify
            // its note ownership rather than trusting PRAGMA foreign_key_check.
            using (var cmd = Command(_db, null, """
                SELECT COUNT(*) FROM notes n WHERE n.active_page_id IS NULL
                    OR NOT EXISTS (SELECT 1 FROM pages p WHERE p.id=n.active_page_id AND p.note_id=n.id)
                """))
                if ((long)(cmd.ExecuteScalar() ?? 0L) != 0)
                    throw new InvalidDataException("A note references a missing or foreign active page.");
            using (var cmd = Command(_db, null, """
                SELECT COUNT(*) FROM (
                  SELECT p.id,COUNT(c.cell_index) AS count_cells,
                         MIN(c.cell_index) AS first_cell,MAX(c.cell_index) AS last_cell
                    FROM pages p LEFT JOIN cells c ON c.page_id=p.id GROUP BY p.id
                ) WHERE count_cells NOT IN (1,2,4) OR first_cell!=0 OR last_cell!=count_cells-1
                """))
                if ((long)(cmd.ExecuteScalar() ?? 0L) != 0)
                    throw new InvalidDataException("A Notes page has missing or non-contiguous writing spaces.");
            using (var state = Command(_db, null, "SELECT value FROM meta WHERE key='s1_import_state'"))
            {
                var importState = state.ExecuteScalar() as string;
                if (importState is not null && importState != "complete")
                    throw new InvalidDataException("Unfinished S1 migration staged; activation is forbidden.");
                var source = Path.Combine(_generationDirectory, "s1-import-source.json");
                if (importState == "complete")
                {
                    using var cmd = Command(_db, null, "SELECT value FROM meta WHERE key='s1_source_sha256'");
                    var expected = cmd.ExecuteScalar() as string;
                    if (!IsHash(expected) || !File.Exists(source)) throw new InvalidDataException("S1 recovery evidence is missing.");
                    using var file = File.OpenRead(source);
                    if (Convert.ToHexString(SHA256.HashData(file)).ToLowerInvariant() != expected)
                        throw new InvalidDataException("S1 recovery source checksum does not match.");
                }
                else if (File.Exists(source)) throw new InvalidDataException("Unmarked S1 recovery evidence was found.");
            }
            using (var cmd = Command(_db, null,
                "SELECT a.sha256,a.mime,a.bytes FROM attachments a JOIN image_objects o ON o.sha256=a.sha256 GROUP BY a.sha256"))
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    var sha = reader.GetString(0);
                    if (!IsHash(sha)) throw new InvalidDataException("Malformed attachment hash.");
                    var ext = reader.GetString(1) == "image/png" ? ".png" : ".jpg";
                    var path = Path.Combine(AttachmentsRoot, sha + ext);
                    if (!File.Exists(path) || new FileInfo(path).Length != reader.GetInt64(2))
                        throw new InvalidDataException("Missing or changed referenced attachment: " + sha);
                    using var stream = File.OpenRead(path);
                    if (Convert.ToHexString(SHA256.HashData(stream)).ToLowerInvariant() != sha)
                        throw new InvalidDataException("Attachment checksum mismatch: " + sha);
                }
            }
        }
    }

    // Imports S1 trial data into an INACTIVE generation only. The legacy extension
    // remains byte-for-byte untouched until an owner-authorized activation policy.
    // Caller must already have preserved and independently verified a recovery copy.
    public S1ImportReport ImportS1(JsonElement legacy)
    {
        lock (_writeGate) return ImportS1Core(legacy);
    }

    private S1ImportReport ImportS1Core(JsonElement legacy)
    {
        RequireWritableStaging();
        if (legacy.ValueKind != JsonValueKind.Object || legacy.GetProperty("schemaVersion").GetInt32() != 1)
            throw new InvalidDataException("Not an S1 Scratchpad document.");
        var raw = legacy.GetRawText();
        if (Encoding.UTF8.GetByteCount(raw) > 12 * 1024 * 1024) throw new InvalidDataException("S1 source exceeds its schema limit.");
        var pads = legacy.GetProperty("pads");
        if (pads.ValueKind != JsonValueKind.Array || pads.GetArrayLength() is < 1 or > 80)
            throw new InvalidDataException("Invalid S1 pad count.");
        // Preserve source evidence on disk before beginning any import mutation.
        var sourcePath = Path.Combine(_generationDirectory, "s1-import-source.json");
        using (var state = Command(_db, null, "SELECT value FROM meta WHERE key='s1_import_state'"))
            if (state.ExecuteScalar() is not null || File.Exists(sourcePath))
                throw new InvalidOperationException("An S1 import was already attempted; use a fresh inactive generation.");
        // Durable fail-closed marker BEFORE any import data is written. If power
        // fails anywhere during import, SealStaging refuses this generation.
        using (var state = Command(_db, null,
            "INSERT INTO meta(key,value) VALUES ('s1_import_state','in_progress')")) state.ExecuteNonQuery();
        var sourceBytes = Encoding.UTF8.GetBytes(raw);
        var hash = Convert.ToHexString(SHA256.HashData(sourceBytes)).ToLowerInvariant();
        using (var output = new FileStream(sourcePath, FileMode.CreateNew, FileAccess.Write, FileShare.None, 65536, FileOptions.WriteThrough))
        { output.Write(sourceBytes); output.Flush(true); }
        int pageCount=0, cellCount=0, strokes=0;
        var seenPads = new HashSet<string>(StringComparer.Ordinal);
        var notebookId = CreateNotebook("Imported Scratchpads");
        foreach (var pad in pads.EnumerateArray())
        {
            var legacyPadId = pad.GetProperty("id").GetString() ?? "";
            Bounded(legacyPadId, "S1 pad ID", 64);
            if (!seenPads.Add(legacyPadId)) throw new InvalidDataException("Duplicate S1 pad ID.");
            var title = pad.GetProperty("title").GetString() ?? "";
            Bounded(title, "S1 title", 120, true);
            var pages = pad.GetProperty("pages");
            if (pages.ValueKind != JsonValueKind.Array || pages.GetArrayLength() is < 1 or > 100)
                throw new InvalidDataException("Invalid S1 pages.");
            var seenPages = new HashSet<string>(StringComparer.Ordinal);
            var note = CreateNote(notebookId, string.IsNullOrWhiteSpace(title) ? "Untitled imported note" : title,
                legacyS1PadId: legacyPadId);
            var firstPage = true;
            foreach (var (page, ordinal) in pages.EnumerateArray().Select((p,i) => (p,i)))
            {
                var legacyPageId = page.GetProperty("id").GetString() ?? "";
                Bounded(legacyPageId, "S1 page ID", 64);
                if (!seenPages.Add(legacyPageId)) throw new InvalidDataException("Duplicate S1 page ID.");
                var guide = page.GetProperty("guide").GetString() ?? "";
                var spacing = page.GetProperty("spacing").GetInt32();
                var cells = page.GetProperty("cells").EnumerateArray().Select(c =>
                    new NotesInkCell(c.GetProperty("text").GetString() ?? "", c.GetProperty("strokes").GetRawText())).ToList();
                var pageId = firstPage ? FirstPageId(note) : AddPage(note, ordinal, guide, spacing, legacyPageId);
                SavePage(note, pageId, 0, guide, spacing, cells);
                if (firstPage)
                {
                    using var cmd = Command(_db, null, "UPDATE pages SET legacy_s1_page_id=@legacy WHERE id=@id",
                        ("@legacy", legacyPageId), ("@id", pageId));
                    cmd.ExecuteNonQuery();
                }
                foreach (var cell in page.GetProperty("cells").EnumerateArray()) strokes += cell.GetProperty("strokes").GetArrayLength();
                cellCount += cells.Count; pageCount++; firstPage=false;
            }
            var activeLegacyPageId = pad.GetProperty("activePageId").GetString();
            using (var cmd = Command(_db, null, """
                UPDATE notes SET active_page_id=(SELECT id FROM pages WHERE note_id=@n AND legacy_s1_page_id=@legacy)
                WHERE id=@n
                """, ("@n", note), ("@legacy", activeLegacyPageId))) cmd.ExecuteNonQuery();
            using (var cmd = Command(_db, null, "SELECT active_page_id FROM notes WHERE id=@id", ("@id", note)))
                if (cmd.ExecuteScalar() is DBNull) throw new InvalidDataException("S1 active page is missing.");
        }
        if (!seenPads.Contains(legacy.GetProperty("activePadId").GetString() ?? ""))
            throw new InvalidDataException("S1 active pad is missing.");
        // The import is still inactive. Prove every original text/ink body and
        // page identity round-tripped before writing the migration-complete marker.
        foreach (var oldPad in pads.EnumerateArray())
        {
            var oldPadId = oldPad.GetProperty("id").GetString();
            string newNoteId;
            using (var cmd = Command(_db, null, "SELECT id FROM notes WHERE legacy_s1_pad_id=@id", ("@id", oldPadId)))
                newNoteId = (string)(cmd.ExecuteScalar() ?? throw new InvalidDataException("Imported S1 note missing."));
            foreach (var oldPage in oldPad.GetProperty("pages").EnumerateArray())
            {
                string newPageId;
                using (var cmd = Command(_db, null,
                    "SELECT id FROM pages WHERE note_id=@n AND legacy_s1_page_id=@p",
                    ("@n", newNoteId), ("@p", oldPage.GetProperty("id").GetString())))
                    newPageId = (string)(cmd.ExecuteScalar() ?? throw new InvalidDataException("Imported S1 page missing."));
                var loaded = ReadPage(newNoteId, newPageId);
                var expectedCells = oldPage.GetProperty("cells").EnumerateArray().ToArray();
                if (loaded.Guide != oldPage.GetProperty("guide").GetString() ||
                    loaded.Spacing != oldPage.GetProperty("spacing").GetInt32() || loaded.Cells.Count != expectedCells.Length)
                    throw new InvalidDataException("Imported S1 page structure differs from source.");
                for (var i = 0; i < expectedCells.Length; i++)
                    if (loaded.Cells[i].Text != expectedCells[i].GetProperty("text").GetString() ||
                        loaded.Cells[i].StrokesJson != expectedCells[i].GetProperty("strokes").GetRawText())
                        throw new InvalidDataException("Imported S1 text/ink differs from source.");
            }
        }
        using (var stagedSource = File.OpenRead(sourcePath))
            if (Convert.ToHexString(SHA256.HashData(stagedSource)).ToLowerInvariant() != hash)
                throw new InvalidDataException("Staged S1 recovery source changed unexpectedly.");
        using (var cmd = Command(_db, null, "INSERT INTO meta (key,value) VALUES ('s1_source_sha256',@hash)", ("@hash", hash))) cmd.ExecuteNonQuery();
        using (var tx = _db.BeginTransaction())
        {
            using (var cmd = Command(_db, tx, "INSERT INTO meta (key,value) VALUES ('s1_active_pad_id',@pad)",
                ("@pad", legacy.GetProperty("activePadId").GetString()))) cmd.ExecuteNonQuery();
            using (var cmd = Command(_db, tx,
                "UPDATE meta SET value='complete' WHERE key='s1_import_state' AND value='in_progress'"))
                if (cmd.ExecuteNonQuery() != 1) throw new InvalidDataException("S1 import did not finish consistently.");
            tx.Commit();
        }
        VerifyIntegrity();
        return new S1ImportReport(pads.GetArrayLength(), pageCount, cellCount, strokes, hash);
    }

    private string FirstPageId(string noteId)
    {
        using var cmd = Command(_db, null, "SELECT id FROM pages WHERE note_id=@n ORDER BY ordinal LIMIT 1", ("@n", noteId));
        return (string)(cmd.ExecuteScalar() ?? throw new InvalidDataException("The note has no first page."));
    }

    public void Dispose()
    {
        lock (_writeGate)
        {
            if (_disposed) return;
            _disposed = true;
            _db.Dispose();
        }
    }
}
