using System.Text.Json;
using NivareQ.Step2Pathfinder.Models;

namespace NivareQ.Step2Pathfinder.Services;

public sealed class StudyTimeService
{
    public StudyTimeFile Data { get; private set; } = new();
    public IReadOnlyDictionary<string, StudyTimeEstimate> BySlug => _bySlug;
    private readonly Dictionary<string, StudyTimeEstimate> _bySlug = new(StringComparer.OrdinalIgnoreCase);

    public void Load()
    {
        var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
        Data = JsonSerializer.Deserialize<StudyTimeFile>(File.ReadAllText(PathfinderPaths.StudyTimes), options) ?? new();
        _bySlug.Clear();
        foreach (var item in Data.Items) _bySlug[item.Slug] = item;
    }

    public static string FormatMinutes(int minutes)
    {
        if (minutes < 60) return $"{minutes}m";
        var h = minutes / 60; var m = minutes % 60;
        return m == 0 ? $"{h}h" : $"{h}h {m:00}m";
    }

    public static string FormatRange(int min, int max) => $"{FormatMinutes(min)}–{FormatMinutes(max)}";
}
