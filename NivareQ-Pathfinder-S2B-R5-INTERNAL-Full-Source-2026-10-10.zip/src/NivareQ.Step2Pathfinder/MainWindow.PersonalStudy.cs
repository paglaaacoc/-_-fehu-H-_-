using System.Text.Json;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using Microsoft.Web.WebView2.Core;
using NivareQ.Step2Pathfinder.Models;
using NivareQ.Step2Pathfinder.Services;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.Storage.Streams;

namespace NivareQ.Step2Pathfinder;

public sealed partial class MainWindow
{
    private readonly PersonalStudyService _personal = new();
    private readonly JournalService _journal = new();
    private readonly BackupExtensionStore _backupExtensions = new();
    private readonly CockpitStateRegistry _cockpitStateRegistry = new();
    private CockpitStateService? _cockpitState;
    private BackupContractService? _backupContract;
    private CancellationTokenSource? _personalSaveCts;
    private bool _deferSessionSaveUntilRestart;
    private bool _suspendCockpitPositionPersistenceUntilRestart;
    private bool _suspendCockpitStatePersistenceUntilRestart;
    private bool _persistenceFailureNoticeQueued;

    private static readonly string[] ProgressChoices = ["Not started", "Studying", "First pass done", "Review later"];

    private void InitializePersonalStudyFeatures()
    {
        _personal.Load();
        _backupExtensions.Load();
        _cockpitStateRegistry.Load();
        var sourceVersions = _catalog.Entries.ToDictionary(x => x.ResourceId, x => x.ExpectedSha256, StringComparer.OrdinalIgnoreCase);
        sourceVersions[UWorldSelectorService.ResourceId] = _uworldSelector.SourceVersion;
        _cockpitState = new CockpitStateService(_cockpitStateRegistry, sourceVersions);
        _cockpitState.Load();
        _backupContract = new BackupContractService(
            _catalog.Entries.Select(x => x.ResourceId).Append(UWorldSelectorService.ResourceId),
            _cockpitStateRegistry,
            _themes.Registry.Themes.Select(x => x.Id),
            sourceVersions);
        InitializeJournalFeatures();
        Closed += MainWindow_Closed;
    }

    private void MainWindow_Closed(object sender, WindowEventArgs args)
    {
        if (!_runtimeClosing)
        {
            _runtimeClosing = true;
            AdvanceRuntimeMutationEpoch("window-closed");
        }
        try
        {
            _personalSaveCts?.Cancel();
            _personal.Save();
            _backupExtensions.Save();
            _journal.Compact();
            _uworldSelector.Save();
            if (!_suspendCockpitStatePersistenceUntilRestart) _cockpitState?.Save();
            if (!_deferSessionSaveUntilRestart) SaveCurrentSession();
        }
        catch { /* shutdown should never be blocked by state persistence */ }
    }

    private void ApplyPersonalDecorationsToSubjects()
    {
        foreach (var entry in _catalog.Entries)
        {
            entry.IsFavorite = _personal.IsFavorite(entry.Slug);
            entry.ProgressLabel = _personal.State.ShowProgress ? _personal.ProgressFor(entry.Slug) : "";
        }
    }

    private Border MakePersonalStudySettingsCard()
    {
        var stack = new StackPanel { Spacing = 8 };
        stack.Children.Add(new TextBlock
        {
            Text = "Personal study layer",
            FontSize = 17,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });
        stack.Children.Add(new TextBlock
        {
            Text = "Favorites, recent subjects, bookmarks, Journal notes, and exact reading positions are stored locally in Pathfinder. Progress tracking is optional.",
            FontSize = 14,
            Opacity = .78,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });

        var progress = new CheckBox
        {
            Content = "Show study progress in the subject library",
            IsChecked = _personal.State.ShowProgress,
            MinHeight = 36
        };
        progress.Checked += (_, _) => SetProgressVisibility(true);
        progress.Unchecked += (_, _) => SetProgressVisibility(false);
        stack.Children.Add(progress);
        stack.Children.Add(new TextBlock
        {
            Text = "Turning progress off only hides it. Existing states are preserved and return when you turn it back on.",
            FontSize = 12,
            Opacity = .68,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });

        var card = new Border
        {
            Child = stack,
            Padding = new Thickness(16),
            CornerRadius = new CornerRadius(12),
            BorderThickness = new Thickness(1)
        };
        RegisterThemedSurface(card);
        return card;
    }

    private void SetProgressVisibility(bool enabled)
    {
        _personal.State.ShowProgress = enabled;
        QueuePersistenceFailureNotice(_personal.Save(), "My Study progress visibility");
        RebuildSubjectGroups(SubjectSearchBox.Text);
        RefreshMyStudyTab();
    }

    private UIElement MakeHomeStudySnapshotCard()
    {
        var stack = new StackPanel { Spacing = 9 };
        stack.Children.Add(new TextBlock
        {
            Text = "Continue & study snapshot",
            FontSize = 17,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });

        var recent = _personal.State.RecentSubjects
            .Select(x => _catalog.Entries.FirstOrDefault(s => s.Slug.Equals(x.Slug, StringComparison.OrdinalIgnoreCase)))
            .FirstOrDefault(x => x is not null);
        var favorites = _personal.State.FavoriteSlugs.Count;
        var studying = _personal.State.ProgressBySlug.Values.Count(x => x.Equals("Studying", StringComparison.OrdinalIgnoreCase));
        var firstPass = _personal.State.ProgressBySlug.Values.Count(x => x.Equals("First pass done", StringComparison.OrdinalIgnoreCase));
        var reviewLater = _personal.State.ProgressBySlug.Values.Count(x => x.Equals("Review later", StringComparison.OrdinalIgnoreCase));

        stack.Children.Add(new TextBlock
        {
            Text = recent is null
                ? $"No recent cockpit yet · {favorites} favorite{(favorites == 1 ? "" : "s")} · {firstPass} first-pass done"
                : $"Continue: {recent.Title} · {favorites} favorite{(favorites == 1 ? "" : "s")} · {studying} studying · {firstPass} first-pass done · {reviewLater} review later",
            TextWrapping = TextWrapping.Wrap,
            Opacity = .78,
            IsTextSelectionEnabled = true
        });

        var actions = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        if (recent is not null)
        {
            var recentSlug = recent.Slug;
            actions.Children.Add(MakeActionButton("Continue " + recent.Title, async (_, _) => await OpenBySlugAsync(recentSlug, false)));
        }
        actions.Children.Add(MakeActionButton("Open My Study", (_, _) => OpenAppSurfaceSafe("my-study", "My Study", CreateMyStudyView)));
        actions.SizeChanged += (_, e) => actions.Orientation = e.NewSize.Width < 640 ? Orientation.Vertical : Orientation.Horizontal;
        stack.Children.Add(actions);

        var card = new Border
        {
            Child = stack,
            Padding = new Thickness(16),
            CornerRadius = new CornerRadius(12),
            BorderThickness = new Thickness(1)
        };
        RegisterThemedSurface(card);
        return card;
    }

    private UIElement CreateMyStudyView()
    {
        var stack = new StackPanel { Spacing = 16, MaxWidth = 1050, HorizontalAlignment = HorizontalAlignment.Left };
        stack.Children.Add(MakeHeading("My Study"));
        stack.Children.Add(MakeLead("Your local Pathfinder layer: where you were, what you saved, and the subjects you want close at hand."));

        var actions = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        actions.Children.Add(MakeActionButton("Bookmark current place", async (_, _) => await AddBookmarkForActiveStudyAsync()));
        actions.Children.Add(MakeActionButton("Back up my data", async (_, _) => await BackupPersonalDataAsync()));
        actions.Children.Add(MakeActionButton("Restore backup", async (_, _) => await RestorePersonalDataAsync()));
        actions.SizeChanged += (_, e) => actions.Orientation = e.NewSize.Width < 620 ? Orientation.Vertical : Orientation.Horizontal;
        stack.Children.Add(actions);

        stack.Children.Add(MakePersonalStudySettingsCard());
        stack.Children.Add(MakeStudyPlanningCard());

        var favorites = _catalog.Entries.Where(x => _personal.IsFavorite(x.Slug)).OrderBy(x => x.Number).ToList();
        stack.Children.Add(MakeHeading("Favorites"));
        if (favorites.Count == 0)
            stack.Children.Add(MakeBody("No favorites yet. Right-click a subject in the library and choose Add to favorites."));
        else
            foreach (var subject in favorites) stack.Children.Add(MakeSubjectQuickCard(subject, "Favorite", includeNoteButton: true));

        stack.Children.Add(MakeHeading("Recently studied"));
        var recent = _personal.State.RecentSubjects
            .Select(x => _catalog.Entries.FirstOrDefault(s => s.Slug.Equals(x.Slug, StringComparison.OrdinalIgnoreCase)))
            .Where(x => x is not null)
            .Cast<SubjectEntry>()
            .Take(8)
            .ToList();
        if (recent.Count == 0)
            stack.Children.Add(MakeBody("Subjects you open will appear here automatically."));
        else
            foreach (var subject in recent) stack.Children.Add(MakeSubjectQuickCard(subject, "Recent", includeNoteButton: true));

        stack.Children.Add(MakeHeading("Bookmarks"));
        if (_personal.State.Bookmarks.Count == 0)
        {
            stack.Children.Add(MakeBody("Open a study cockpit, then use Bookmark current place here or from the study tab's right-click menu."));
        }
        else
        {
            foreach (var bookmark in _personal.State.Bookmarks.OrderByDescending(x => x.CreatedUtc).ToList())
                stack.Children.Add(MakeBookmarkCard(bookmark));
        }

        stack.Children.Add(MakeHeading("Journal"));
        var journalRecent = _journal.Recent(3).ToList();
        if (journalRecent.Count == 0)
        {
            stack.Children.Add(MakeBody("No Journal notes yet. Create a General note or capture one from an open study cockpit."));
        }
        else
        {
            stack.Children.Add(MakeBody($"{_journal.Count:N0} Journal {(_journal.Count == 1 ? "note" : "notes")} · showing the most recently updated."));
            foreach (var entry in journalRecent) stack.Children.Add(MakeJournalCard(entry));
        }
        var journalActions = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        journalActions.Children.Add(MakeActionButton("Open Journal", (_, _) => OpenJournal()));
        journalActions.Children.Add(MakeActionButton("New note", async (_, _) => await EditJournalEntryAsync(null, null, null)));
        journalActions.Children.Add(MakeActionButton("From Study", async (_, _) => await CreateJournalNoteFromCurrentStudyAsync()));
        journalActions.SizeChanged += (_, e) => journalActions.Orientation = e.NewSize.Width < 560 ? Orientation.Vertical : Orientation.Horizontal;
        stack.Children.Add(journalActions);

        stack.Children.Add(MakeHeading("Recently closed tabs"));
        var closed = _recentlyClosedStudyTabs.Take(10).ToList();
        if (closed.Count == 0)
        {
            stack.Children.Add(MakeBody("Closed study tabs from this session will appear here. Ctrl+Shift+T reopens the newest one."));
        }
        else
        {
            stack.Children.Add(MakeActionButton("Reopen last closed tab", async (_, _) => await ReopenNewestClosedStudyAsync()));
            foreach (var snapshot in closed)
            {
                var subject = _catalog.Entries.FirstOrDefault(x => x.Slug.Equals(snapshot.Slug, StringComparison.OrdinalIgnoreCase));
                if (subject is not null) stack.Children.Add(MakeClosedStudyQuickCard(subject, snapshot));
            }
        }

        stack.Children.Add(MakeBody("All My Study data stays local to this Windows profile unless you explicitly export a backup."));
        return WrapScrollableStack(stack);
    }

    private Border MakeStudyPlanningCard()
    {
        var body = new StackPanel { Spacing = 9 };
        body.Children.Add(new TextBlock
        {
            Text = "Study planning & time estimates",
            FontSize = 17,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });
        body.Children.Add(new TextBlock
        {
            Text = _studyTimes.Data.Disclaimer + " Use these ranges as planning aids, not deadlines.",
            FontSize = 14,
            Opacity = .78,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });
        if (TryGetStudyTimeTotals(out var quick, out var standardMin, out var standardMax, out var deepMin, out var deepMax))
        {
            body.Children.Add(new TextBlock
            {
                Text = $"Whole suite · Quick {StudyTimeService.FormatMinutes(quick)} · Standard {StudyTimeService.FormatRange(standardMin, standardMax)} · Deep {StudyTimeService.FormatRange(deepMin, deepMax)}",
                FontSize = 13,
                Opacity = .82,
                TextWrapping = TextWrapping.Wrap,
                IsTextSelectionEnabled = true
            });
        }

        var details = new StackPanel { Spacing = 8, Margin = new Thickness(0, 8, 0, 2) };
        foreach (var estimate in _studyTimes.Data.Items)
        {
            var row = new StackPanel { Spacing = 3 };
            row.Children.Add(new TextBlock
            {
                Text = estimate.Title,
                FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
                TextWrapping = TextWrapping.Wrap,
                IsTextSelectionEnabled = true
            });
            row.Children.Add(new TextBlock
            {
                Text = $"Quick ≈ {StudyTimeService.FormatMinutes(estimate.QuickMinutes)} · Standard ≈ {StudyTimeService.FormatRange(estimate.StandardMinMinutes, estimate.StandardMaxMinutes)} · Deep ≈ {StudyTimeService.FormatRange(estimate.DeepMinMinutes, estimate.DeepMaxMinutes)}",
                FontSize = 12.5,
                Opacity = .75,
                TextWrapping = TextWrapping.Wrap,
                IsTextSelectionEnabled = true
            });
            details.Children.Add(row);
        }
        details.Children.Add(new TextBlock
        {
            Text = _studyTimes.Data.Formula,
            FontSize = 12,
            Opacity = .68,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });
        body.Children.Add(new Expander
        {
            Header = "View all subject estimates",
            HorizontalAlignment = HorizontalAlignment.Stretch,
            Content = details
        });

        var card = new Border { Child = body, Padding = new Thickness(16), CornerRadius = new CornerRadius(12), BorderThickness = new Thickness(1) };
        RegisterThemedSurface(card);
        return card;
    }

    private Border MakeSubjectQuickCard(SubjectEntry subject, string label, bool includeNoteButton)
    {
        var stack = new StackPanel { Spacing = 7 };
        stack.Children.Add(new TextBlock { Text = subject.DisplayTitle, FontSize = 17, FontWeight = Microsoft.UI.Text.FontWeights.SemiBold, TextWrapping = TextWrapping.Wrap, IsTextSelectionEnabled = true });
        var detail = label;
        if (_personal.State.ShowProgress) detail += " · " + _personal.ProgressFor(subject.Slug);
        if (!string.IsNullOrWhiteSpace(subject.StudyTimeBase)) detail += " · " + subject.StudyTimeBase;
        stack.Children.Add(new TextBlock { Text = detail, FontSize = 12, Opacity = .68, TextWrapping = TextWrapping.Wrap, IsTextSelectionEnabled = true });
        var row = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        row.Children.Add(MakeActionButton("Open", async (_, _) => await OpenSubjectAsync(subject, true)));
        if (includeNoteButton) row.Children.Add(MakeActionButton("Journal", (_, _) => OpenJournal(subject.ResourceId)));
        stack.Children.Add(row);
        var card = new Border { Child = stack, Padding = new Thickness(14), CornerRadius = new CornerRadius(12), BorderThickness = new Thickness(1) };
        RegisterThemedSurface(card);
        return card;
    }


    private Border MakeClosedStudyQuickCard(SubjectEntry subject, ClosedStudyTabSnapshot snapshot)
    {
        var stack = new StackPanel { Spacing = 7 };
        stack.Children.Add(new TextBlock { Text = subject.DisplayTitle, FontSize = 17, FontWeight = Microsoft.UI.Text.FontWeights.SemiBold, TextWrapping = TextWrapping.Wrap, IsTextSelectionEnabled = true });
        var locationText = snapshot.Location is null
            ? "Closed this session"
            : "Closed this session · reading position remembered";
        stack.Children.Add(new TextBlock { Text = locationText, FontSize = 12, Opacity = .68, TextWrapping = TextWrapping.Wrap, IsTextSelectionEnabled = true });
        var row = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        row.Children.Add(MakeActionButton("Reopen", async (_, _) => await ReopenSpecificClosedStudyAsync(snapshot)));
        stack.Children.Add(row);
        var card = new Border { Child = stack, Padding = new Thickness(14), CornerRadius = new CornerRadius(12), BorderThickness = new Thickness(1) };
        RegisterThemedSurface(card);
        return card;
    }

    private async Task ReopenSpecificClosedStudyAsync(ClosedStudyTabSnapshot snapshot)
    {
        RemoveClosedSnapshot(snapshot.Id);
        var subject = _catalog.Entries.FirstOrDefault(x => x.Slug.Equals(snapshot.Slug, StringComparison.OrdinalIgnoreCase));
        if (subject is not null)
            await CreateStudyTabAsync(subject, false, CloneLocation(snapshot.Location));
        RefreshMyStudyTab();
    }

    private async Task<bool> ReopenNewestClosedStudyAsync()
    {
        while (_recentlyClosedStudyTabs.Count > 0)
        {
            var snapshot = _recentlyClosedStudyTabs.Pop();
            var subject = _catalog.Entries.FirstOrDefault(x => x.Slug.Equals(snapshot.Slug, StringComparison.OrdinalIgnoreCase));
            if (subject is null) continue;
            await CreateStudyTabAsync(subject, false, CloneLocation(snapshot.Location));
            RefreshMyStudyTab();
            return true;
        }
        RefreshMyStudyTab();
        return false;
    }

    private void RemoveClosedSnapshot(string id)
    {
        var keep = _recentlyClosedStudyTabs.Where(x => !x.Id.Equals(id, StringComparison.Ordinal)).Reverse().ToList();
        _recentlyClosedStudyTabs.Clear();
        foreach (var item in keep) _recentlyClosedStudyTabs.Push(item);
    }

    private Border MakeBookmarkCard(StudyBookmark bookmark)
    {
        var subject = _catalog.Entries.FirstOrDefault(x => x.Slug.Equals(bookmark.Slug, StringComparison.OrdinalIgnoreCase));
        var stack = new StackPanel { Spacing = 7 };
        stack.Children.Add(new TextBlock { Text = string.IsNullOrWhiteSpace(bookmark.Name) ? (subject?.Title ?? "Bookmark") : bookmark.Name, FontSize = 17, FontWeight = Microsoft.UI.Text.FontWeights.SemiBold, TextWrapping = TextWrapping.Wrap, IsTextSelectionEnabled = true });
        stack.Children.Add(new TextBlock { Text = subject?.Title ?? bookmark.Slug, FontSize = 12, Opacity = .68, TextWrapping = TextWrapping.Wrap, IsTextSelectionEnabled = true });
        if (!string.IsNullOrWhiteSpace(bookmark.Note))
            stack.Children.Add(new TextBlock { Text = bookmark.Note, FontSize = 14, Opacity = .80, TextWrapping = TextWrapping.Wrap, IsTextSelectionEnabled = true });
        var row = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        row.Children.Add(MakeActionButton("Go to bookmark", async (_, _) => await OpenBookmarkAsync(bookmark)));
        row.Children.Add(MakeActionButton("Delete", (_, _) => DeleteBookmark(bookmark.Id)));
        stack.Children.Add(row);
        var card = new Border { Child = stack, Padding = new Thickness(14), CornerRadius = new CornerRadius(12), BorderThickness = new Thickness(1) };
        RegisterThemedSurface(card);
        return card;
    }

    private void RefreshMyStudyTab()
    {
        // W2D: My Study is an app surface, not a closable study/tool tab.
        if (_activeAppSurfaceId.Equals("my-study", StringComparison.OrdinalIgnoreCase) &&
            AppSurfaceHost.Visibility == Visibility.Visible)
        {
            AppSurfaceContent.Content = PrepareShellContent(CreateMyStudyView());
        }
    }

    private void MyStudyButton_Click(object sender, RoutedEventArgs e)
        => OpenAppSurfaceSafe("my-study", "My Study", CreateMyStudyView);

    private void AppendSubjectPersonalMenuItems(MenuFlyout flyout, SubjectEntry subject)
    {
        flyout.Items.Add(new MenuFlyoutSeparator());

        var favorite = new MenuFlyoutItem { Text = _personal.IsFavorite(subject.Slug) ? "Remove from favorites" : "Add to favorites" };
        favorite.Click += (_, _) => ToggleFavorite(subject);
        flyout.Items.Add(favorite);

        var journal = new MenuFlyoutItem { Text = "Open Journal for this cockpit" };
        journal.Click += (_, _) => OpenJournal(subject.ResourceId);
        flyout.Items.Add(journal);

        if (_personal.State.ShowProgress)
        {
            var progress = new MenuFlyoutSubItem { Text = "Study progress" };
            foreach (var choice in ProgressChoices)
            {
                var item = new MenuFlyoutItem { Text = (_personal.ProgressFor(subject.Slug) == choice ? "✓ " : "") + choice };
                item.Click += (_, _) => SetSubjectProgress(subject, choice);
                progress.Items.Add(item);
            }
            flyout.Items.Add(progress);
        }
    }

    private void ToggleFavorite(SubjectEntry subject)
    {
        _personal.SetFavorite(subject.Slug, !_personal.IsFavorite(subject.Slug));
        QueuePersistenceFailureNotice(_personal.Save(), "Favorite");
        RebuildSubjectGroups(SubjectSearchBox.Text);
        RefreshMyStudyTab();
    }

    private void SetSubjectProgress(SubjectEntry subject, string progress)
    {
        _personal.SetProgress(subject.Slug, progress);
        QueuePersistenceFailureNotice(_personal.Save(), "Study progress");
        RebuildSubjectGroups(SubjectSearchBox.Text);
        RefreshMyStudyTab();
    }

    private async Task AddBookmarkForActiveStudyAsync()
    {
        var context = ActiveStudyTab();
        if (context is null)
        {
            await ShowPersonalMessageAsync("Open a study cockpit first", "A bookmark records your exact place inside the active study cockpit.");
            return;
        }

        var location = await CapturePositionAsync(context) ?? _personal.PositionFor(context.Subject.Slug) ?? new StudyLocationState();
        var name = new TextBox { PlaceholderText = "Bookmark name", Text = context.Subject.Title };
        var note = new TextBox { PlaceholderText = "Optional note", AcceptsReturn = true, TextWrapping = TextWrapping.Wrap, MinHeight = 100 };
        var content = new StackPanel { Spacing = 8 };
        content.Children.Add(name);
        content.Children.Add(note);
        var dialog = new ContentDialog
        {
            XamlRoot = RootGrid.XamlRoot,
            Title = "Bookmark this place",
            Content = content,
            PrimaryButtonText = "Save bookmark",
            CloseButtonText = "Cancel",
            DefaultButton = ContentDialogButton.Primary
        };
        if (await dialog.ShowAsync() != ContentDialogResult.Primary) return;

        _personal.State.Bookmarks.Insert(0, new StudyBookmark
        {
            Slug = context.Subject.Slug,
            Name = string.IsNullOrWhiteSpace(name.Text) ? context.Subject.Title : name.Text.Trim(),
            Note = note.Text.Trim(),
            Location = location,
            CreatedUtc = DateTimeOffset.UtcNow
        });
        QueuePersistenceFailureNotice(_personal.Save(), "Bookmark");
        RefreshMyStudyTab();
    }

    private void DeleteBookmark(string id)
    {
        _personal.State.Bookmarks.RemoveAll(x => x.Id.Equals(id, StringComparison.OrdinalIgnoreCase));
        QueuePersistenceFailureNotice(_personal.Save(), "Bookmark deletion");
        RefreshMyStudyTab();
    }

    private async Task OpenBookmarkAsync(StudyBookmark bookmark)
    {
        var subject = _catalog.Entries.FirstOrDefault(x => x.Slug.Equals(bookmark.Slug, StringComparison.OrdinalIgnoreCase));
        if (subject is null) return;
        var existing = _studyTabs.Values.FirstOrDefault(x => x.Subject.Slug.Equals(subject.Slug, StringComparison.OrdinalIgnoreCase));
        if (existing is not null)
        {
            Tabs.SelectedItem = existing.Tab;
            await RestoreStudyLocationAsync(existing, bookmark.Location);
            return;
        }
        await CreateStudyTabAsync(subject, false, bookmark.Location);
    }

    private void ConfigureStudyTabPersonalFeatures(StudyTabContext context)
    {
        context.Tab.RightTapped += (_, e) =>
        {
            var flyout = new MenuFlyout();
            if (context.ViewRole == CockpitViewRole.ReadOnlySecondary)
            {
                var activate = new MenuFlyoutItem { Text = "Activate primary cockpit" };
                activate.Click += (_, _) =>
                {
                    if (FindPrimaryStudyContext(context.Subject.ResourceId) is { } primary) Tabs.SelectedItem = primary.Tab;
                };
                flyout.Items.Add(activate);
                var showBesideReadOnly = new MenuFlyoutItem { Text = "Show beside in Split View" };
                showBesideReadOnly.Click += async (_, _) => await ShowTabBesideAsync(context.Tab);
                flyout.Items.Add(showBesideReadOnly);
                var closeReadOnly = new MenuFlyoutItem { Text = "Close read-only tab" };
                closeReadOnly.Click += async (_, _) => await CloseTabItemAsync(context.Tab, false);
                flyout.Items.Add(closeReadOnly);
                flyout.ShowAt(context.Tab);
                e.Handled = true;
                return;
            }

            var pin = new MenuFlyoutItem { Text = context.IsPinned ? "Unpin tab" : "Pin tab" };
            pin.Click += (_, _) => SetTabPinned(context, !context.IsPinned);
            flyout.Items.Add(pin);
            var bookmark = new MenuFlyoutItem { Text = "Bookmark this place" };
            bookmark.Click += async (_, _) => { Tabs.SelectedItem = context.Tab; await AddBookmarkForActiveStudyAsync(); };
            flyout.Items.Add(bookmark);
            var showBeside = new MenuFlyoutItem { Text = "Show beside in Split View" };
            showBeside.Click += async (_, _) => await ShowTabBesideAsync(context.Tab);
            flyout.Items.Add(showBeside);
            var journalNote = new MenuFlyoutItem { Text = "Add note to Journal…" };
            journalNote.Click += async (_, _) => await CreateJournalNoteFromStudyAsync(context);
            flyout.Items.Add(journalNote);
            flyout.Items.Add(new MenuFlyoutSeparator());
            if (_recentlyClosedStudyTabs.Count > 0)
            {
                var reopen = new MenuFlyoutItem { Text = "Reopen closed tab" };
                reopen.Click += async (_, _) => await ReopenNewestClosedStudyAsync();
                flyout.Items.Add(reopen);
            }
            var closeOthers = new MenuFlyoutItem { Text = "Close other tabs" };
            closeOthers.Click += async (_, _) => await CloseOtherTabsAsync(context.Tab);
            flyout.Items.Add(closeOthers);
            var closeRight = new MenuFlyoutItem { Text = "Close tabs to the right" };
            closeRight.Click += async (_, _) => await CloseTabsToRightAsync(context.Tab);
            flyout.Items.Add(closeRight);
            if (!context.IsPinned)
            {
                var close = new MenuFlyoutItem { Text = "Close tab" };
                close.Click += async (_, _) => await CloseTabItemAsync(context.Tab, true);
                flyout.Items.Add(close);
            }
            flyout.ShowAt(context.Tab);
            e.Handled = true;
        };
        UpdateStudyTabHeader(context);
    }

    private void SetTabPinned(StudyTabContext context, bool pinned)
    {
        context.IsPinned = pinned;
        UpdateStudyTabHeader(context);
        QueuePersistenceFailureNotice(SaveCurrentSession(), "Pinned tab state");
    }

    private static void UpdateStudyTabHeader(StudyTabContext context)
    {
        if (context.ViewRole == CockpitViewRole.ReadOnlySecondary)
        {
            context.Tab.Header = context.Subject.Title + " · Read-only";
            context.Tab.IsClosable = true;
            return;
        }
        context.Tab.Header = context.IsPinned ? "📌 " + context.Subject.Title : context.Subject.Title;
        context.Tab.IsClosable = !context.IsPinned;
    }

    private void RememberClosedStudyTab(StudyTabContext study, StudyLocationState? location)
    {
        _recentlyClosedStudyTabs.Push(new ClosedStudyTabSnapshot
        {
            Slug = study.Subject.Slug,
            Location = CloneLocation(location),
            ClosedUtc = DateTimeOffset.UtcNow
        });
        while (_recentlyClosedStudyTabs.Count > 10)
        {
            var newestFirst = _recentlyClosedStudyTabs.Take(10).Reverse().ToList();
            _recentlyClosedStudyTabs.Clear();
            foreach (var item in newestFirst) _recentlyClosedStudyTabs.Push(item);
        }
        RefreshMyStudyTab();
    }

    private async Task CloseTabItemAsync(TabViewItem tab, bool rememberStudy)
    {
        if (tab == _homeTab) return;
        if (Equals(tab.Tag, "shell:Journal"))
        {
            if (!await ConfirmDiscardJournalDraftAsync()) return;
            _journalEditorSession = null;
            _journalWorkspaceRoot = null;
            _journalInlineEditorHost = null;
            _journalRenderResults = null;
            _journalRefreshFilters = null;
        }
        if (Equals(tab.Tag, "shell:Scratchpad"))
        {
            if (!await FlushScratchpadBeforeLeavingAsync()) return;
            _scratchpadWeb = null;
        }
        PrepareTabForCloseInSplitWorkspace(tab);
        if (_studyTabs.TryGetValue(tab, out var study))
        {
            if (study.IsPinned) return;
            if (study.ViewRole == CockpitViewRole.Primary) await CaptureCockpitStateSnapshotAsync(study);
            var location = study.ViewRole == CockpitViewRole.Primary
                ? await CapturePositionAsync(study) ?? study.LastKnownLocation ?? _personal.PositionFor(study.Subject.Slug)
                : study.LastKnownLocation;
            if (rememberStudy && study.ViewRole == CockpitViewRole.Primary) RememberClosedStudyTab(study, location);
            RetireStudyContext(study, "tab-closed");
            _studyTabs.Remove(tab);
        }
        Tabs.TabItems.Remove(tab);
        ValidateSplitWorkspaceAfterTabChange();
        if (Tabs.TabItems.Count == 0 && _homeTab is not null)
        {
            Tabs.TabItems.Add(_homeTab);
            Tabs.SelectedItem = _homeTab;
        }
        UpdateNavigationButtons();
        QueuePersistenceFailureNotice(SaveCurrentSession(), "Session state");
    }

    private async Task CloseOtherTabsAsync(TabViewItem keep)
    {
        foreach (var tab in Tabs.TabItems.OfType<TabViewItem>().ToList())
        {
            if (tab == keep || tab == _homeTab) continue;
            if (_studyTabs.TryGetValue(tab, out var study) && study.IsPinned) continue;
            await CloseTabItemAsync(tab, true);
        }
    }

    private async Task CloseTabsToRightAsync(TabViewItem anchor)
    {
        var index = Tabs.TabItems.IndexOf(anchor);
        if (index < 0) return;
        var tabs = Tabs.TabItems.OfType<TabViewItem>().Skip(index + 1).ToList();
        foreach (var tab in tabs)
        {
            if (_studyTabs.TryGetValue(tab, out var study) && study.IsPinned) continue;
            await CloseTabItemAsync(tab, true);
        }
    }

    private static StudyLocationState? CloneLocation(StudyLocationState? source)
        => source is null ? null : CloneLocationV2(source);

    private void TouchRecentSubject(SubjectEntry subject)
    {
        _personal.TouchRecent(subject.Slug);
        QueuePersistenceFailureNotice(_personal.Save(), "Recent subjects");
        RefreshMyStudyTab();
    }

    private void SchedulePersonalSave()
    {
        if (_suspendCockpitPositionPersistenceUntilRestart) return;
        _personalSaveCts?.Cancel();
        var cts = new CancellationTokenSource();
        _personalSaveCts = cts;
        var epoch = CaptureRuntimeMutationEpoch();
        _ = SavePersonalAfterDelayAsync(cts, epoch);
    }

    private async Task SavePersonalAfterDelayAsync(CancellationTokenSource cts, long epoch)
    {
        try
        {
            await Task.Delay(700, cts.Token);
            if (!cts.IsCancellationRequested && IsRuntimeMutationCurrent(epoch))
                QueuePersistenceFailureNotice(_personal.Save(), "My Study autosave");
        }
        catch (OperationCanceledException) { }
        finally
        {
            if (ReferenceEquals(_personalSaveCts, cts)) _personalSaveCts = null;
            cts.Dispose();
        }
    }

    private void QueuePersistenceFailureNotice(PersistenceWriteResult result, string area)
    {
        if (result.Success || _persistenceFailureNoticeQueued) return;
        _persistenceFailureNoticeQueued = true;
        RootGrid.DispatcherQueue.TryEnqueue(async () =>
        {
            if (RootGrid.XamlRoot is null) { _persistenceFailureNoticeQueued = false; return; }
            try
            {
                await ShowPersonalMessageAsync(
                    "Pathfinder could not save local data",
                    $"{area} changed in memory, but Windows could not durably write it to Pathfinder AppData. The app will not pretend the change is safely persisted.\n\n{result.Error}\n\nYou can continue reading, but create a backup to a writable location before closing Pathfinder if the problem persists.");
            }
            catch
            {
                // A different ContentDialog may already be open. Keep the durable health record and
                // allow the next failed save to try surfacing the warning again.
                _persistenceFailureNoticeQueued = false;
            }
        });
    }

    private async Task BackupPersonalDataAsync()
    {
        try
        {
            var result = await CreateCanonicalBackupFileAsync(
                $"NivareQ-Step2-Pathfinder-Backup-{DateTime.Now:yyyy-MM-dd}",
                verifyAfterWrite: true);
            if (result.File is null) return;

            var body = "Pathfinder backup saved and verified. It includes settings and accessibility preferences, the tab/session record, My Study state, Journal data, UWorld Selector data, and supported preserved extension data.";
            body += "\n\nOpen cockpit review, quiz and study-mode state that Pathfinder supports is included in this backup.";
            if (result.Warnings.Count > 0) body += "\n\nWarning: " + string.Join("; ", result.Warnings) + ".";
            await ShowPersonalMessageAsync("Backup saved", body);
        }
        catch (Exception ex)
        {
            await ShowPersonalMessageAsync("Backup could not be saved", ex.Message);
        }
    }

    private async Task<(StorageFile? File, string CanonicalJson, List<string> Warnings)> CreateCanonicalBackupFileAsync(
        string suggestedFileName,
        bool verifyAfterWrite)
    {
        if (_backupContract is null) throw new InvalidOperationException("Backup contract is not initialized.");
        var backupEpoch = CaptureRuntimeMutationEpoch();
        if (!IsRuntimeMutationCurrent(backupEpoch)) throw new InvalidOperationException("Pathfinder state changed before backup capture could begin. Try the backup again.");

        // S1: canonical backup must include the latest editable Scratchpad state, not
        // only the last debounced browser message. An unsavable pad aborts export.
        if (!await FlushScratchpadBeforeLeavingAsync())
            throw new IOException("Scratchpad edits could not be durably captured. The backup was not created.");

        _personalSaveCts?.Cancel();
        var captureFailures = 0;
        if (!_suspendCockpitPositionPersistenceUntilRestart)
        {
            foreach (var context in _studyTabs.Values.ToList())
            {
                if (await CapturePositionAsync(context) is null) captureFailures++;
                if (!IsRuntimeMutationCurrent(backupEpoch))
                    throw new InvalidOperationException("Pathfinder state changed while the backup was capturing open cockpit positions. No backup was written.");
            }
        }

        var cockpitCaptureFailures = await FlushOpenPrimaryCockpitStateAsync();
        if (!IsRuntimeMutationCurrent(backupEpoch))
            throw new InvalidOperationException("Pathfinder state changed while the backup was capturing cockpit state. No backup was written.");
        var settingsWrite = SaveCurrentSession();
        var personalWrite = _personal.Save();
        var journalWrite = _journal.Compact();
        var selectorWrite = _uworldSelector.Save();
        var extensionWrite = _backupExtensions.Save();
        var cockpitWrite = _cockpitState?.Save() ?? PersistenceWriteResult.Ok(PathfinderPaths.CockpitStatePath);

        var picker = new FileSavePicker { SuggestedFileName = suggestedFileName };
        picker.FileTypeChoices.Add("Pathfinder backup", new List<string> { ".json" });
        WinRT.Interop.InitializeWithWindow.Initialize(picker, WinRT.Interop.WindowNative.GetWindowHandle(this));
        var file = await picker.PickSaveFileAsync();
        if (file is null) return (null, "", []);
        if (!IsRuntimeMutationCurrent(backupEpoch))
            throw new InvalidOperationException("Pathfinder state changed while the backup destination was being chosen. No backup was written.");

        if (_cockpitState is null) throw new InvalidOperationException("Cockpit state provider is not initialized.");
        var backup = _backupContract.CreateCanonicalBackup(_settings, _personal.State, _cockpitState.State, _journal.ExportState(), _uworldSelector.ExportState(), _backupExtensions.State);
        var canonicalJson = _backupContract.SerializeCanonical(backup);
        await WriteBackupTransactionallyAsync(file, canonicalJson);
        if (!IsRuntimeMutationCurrent(backupEpoch))
            throw new InvalidOperationException("Pathfinder state changed before backup verification completed. Discard this file and create a new backup.");

        if (verifyAfterWrite)
        {
            var properties = await file.GetBasicPropertiesAsync();
            if (properties.Size == 0 || properties.Size > (ulong)BackupContractService.MaxBackupBytes)
                throw new InvalidDataException("The just-written backup failed the size verification gate.");

            var readBack = await FileIO.ReadTextAsync(file);
            if (!IsRuntimeMutationCurrent(backupEpoch))
                throw new InvalidOperationException("Pathfinder state changed during backup verification. Discard this file and create a new backup.");
            // Parse through the same strict canonical importer used by Restore. A reset
            // is never permitted to proceed on the strength of an unverified file write.
            var verificationPlan = _backupContract.ParseImport(readBack, _settings, _cockpitState.State, _journal.ExportState(), _uworldSelector.ExportState(), _backupExtensions.State);
            if (verificationPlan.SourceSchemaVersion < 7 ||
                !verificationPlan.SourceDescription.Contains("canonical", StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("The just-written file did not verify as a current Pathfinder backup.");
        }

        var warnings = new List<string>();
        if (!settingsWrite.Success) warnings.Add("the local settings flush failed, but the backup contains the current in-memory settings");
        if (!personalWrite.Success) warnings.Add("the local My Study flush failed, but the backup contains the current in-memory My Study state");
        if (!journalWrite.Success) warnings.Add("the local Journal snapshot flush failed, but the backup contains the current in-memory Journal state");
        if (!selectorWrite.Success) warnings.Add("the local UWorld Selector flush failed, but the backup contains the current in-memory Selector state");
        if (!extensionWrite.Success) warnings.Add("the local preserved-extension flush failed, but the backup contains the current in-memory preserved extensions");
        if (!cockpitWrite.Success) warnings.Add("the local cockpit-state save failed, but the backup contains the current in-memory cockpit state");
        if (captureFailures > 0) warnings.Add($"{captureFailures} open cockpit position(s) could not be freshly captured and used their last-known saved position instead");
        if (cockpitCaptureFailures > 0) warnings.Add($"{cockpitCaptureFailures} open primary cockpit state snapshot(s) could not be freshly captured and used the last saved cockpit state instead");
        return (file, canonicalJson, warnings);
    }


    private static async Task WriteBackupTransactionallyAsync(StorageFile file, string content)
    {
        using var transaction = await file.OpenTransactedWriteAsync();
        transaction.Stream.Size = 0;
        transaction.Stream.Seek(0);
        using (var writer = new DataWriter(transaction.Stream) { UnicodeEncoding = UnicodeEncoding.Utf8 })
        {
            writer.WriteString(content);
            await writer.StoreAsync();
            writer.DetachStream();
        }
        await transaction.CommitAsync();
    }

    private async Task RestorePersonalDataAsync()
    {
        try
        {
            if (_backupContract is null) throw new InvalidOperationException("Backup contract is not initialized.");

            var picker = new FileOpenPicker();
            picker.FileTypeFilter.Add(".json");
            WinRT.Interop.InitializeWithWindow.Initialize(picker, WinRT.Interop.WindowNative.GetWindowHandle(this));
            var file = await picker.PickSingleFileAsync();
            if (file is null) return;

            var properties = await file.GetBasicPropertiesAsync();
            if (properties.Size > (ulong)BackupContractService.MaxBackupBytes)
                throw new InvalidDataException("Backup is larger than the supported 100 MB safety limit.");

            var json = await FileIO.ReadTextAsync(file);
            // Backups predating S1 do not contain Scratchpad. Preserve modern local pads
            // when that key is absent, rather than silently deleting new writing.
            if (_cockpitState is null) throw new InvalidOperationException("Cockpit state provider is not initialized.");
            var plan = _backupContract.ParseImport(json, _settings, _cockpitState.State, _journal.ExportState(), _uworldSelector.ExportState(), _backupExtensions.State);
            var preserveExistingPads = !plan.PreservedExtensions.Values.ContainsKey(ScratchpadExtensionKey)
                                       && _backupExtensions.State.Values.ContainsKey(ScratchpadExtensionKey);
            if (preserveExistingPads)
                plan.Warnings.Add("The selected backup does not contain Scratchpad data; existing local scratchpads will be retained. Use full data reset to erase them.");
            if (!await ConfirmRestorePlanAsync(plan)) return;

            var extensionTarget = plan.ReplacePreservedExtensions
                ? BackupExtensionStore.Clone(plan.PreservedExtensions)
                : _backupExtensions.MergeLegacy(plan.PreservedExtensions);
            if (preserveExistingPads && _backupExtensions.State.Values.TryGetValue(ScratchpadExtensionKey, out var retainedPads))
                extensionTarget.Values[ScratchpadExtensionKey] = retainedPads.Clone();

            var cockpitTarget = plan.ReplaceCockpitState ? CockpitStateService.Clone(plan.CockpitState) : CockpitStateService.Clone(_cockpitState.State);
            var journalTarget = BuildJournalRestoreTarget(plan);
            var selectorTarget = plan.ReplaceUWorldSelector ? UWorldSelectorService.CloneState(plan.UWorldSelector) : _uworldSelector.ExportState();
            AdvanceRuntimeMutationEpoch("restore-commit");
            var previousDeferSession = _deferSessionSaveUntilRestart;
            var previousPositionSuspend = _suspendCockpitPositionPersistenceUntilRestart;
            var previousStateSuspend = _suspendCockpitStatePersistenceUntilRestart;
            _deferSessionSaveUntilRestart = true;
            _suspendCockpitPositionPersistenceUntilRestart = true;
            _suspendCockpitStatePersistenceUntilRestart = true;
            _personalSaveCts?.Cancel();
            _cockpitStateSaveCts?.Cancel();

            var commit = RestoreTransactionService.Commit(new Dictionary<string, string>
            {
                [PathfinderPaths.SettingsPath] = SettingsService.Serialize(plan.ShellSettings),
                [PathfinderPaths.PersonalStudyPath] = PersonalStudyService.Serialize(plan.PersonalStudy),
                [PathfinderPaths.BackupExtensionsPath] = _backupExtensions.Serialize(extensionTarget),
                [PathfinderPaths.CockpitStatePath] = _cockpitState.Serialize(cockpitTarget),
                [PathfinderPaths.JournalSnapshotPath] = JournalService.SerializeState(journalTarget),
                [PathfinderPaths.JournalLogPath] = JournalService.EmptyOperationLog,
                [PathfinderPaths.UWorldSelectorStatePath] = _uworldSelector.SerializeState(selectorTarget)
            });
            if (!commit.Success)
            {
                if (!RestoreTransactionService.MutationsBlocked)
                {
                    _deferSessionSaveUntilRestart = previousDeferSession;
                    _suspendCockpitPositionPersistenceUntilRestart = previousPositionSuspend;
                    _suspendCockpitStatePersistenceUntilRestart = previousStateSuspend;
                }
                throw new IOException(commit.Error);
            }

            CopyShellSettings(plan.ShellSettings, _settings);
            _personal.ReplaceInMemory(plan.PersonalStudy);
            _backupExtensions.ReplaceInMemory(extensionTarget);
            _cockpitState.ReplaceInMemory(cockpitTarget);
            _journal.ReplaceInMemory(journalTarget);
            _journalEditorSession = null;
            _uworldSelector.ReplaceInMemory(selectorTarget);
            RestoreTransactionService.BlockMutationsUntilRestart("A backup was restored successfully. Restart Pathfinder before making further study-state changes so pre-restore views cannot mutate the restored state.");
            _deferSessionSaveUntilRestart = true;
            _suspendCockpitPositionPersistenceUntilRestart = true;
            _suspendCockpitStatePersistenceUntilRestart = true;
            _personalSaveCts?.Cancel();

            SelectSavedTheme();
            await ApplyThemeToAllWebViewsAsync(SelectedTheme());
            RebuildSubjectGroups(SubjectSearchBox.Text);
            RefreshMyStudyTab();
            RefreshJournalWorkspace();
            RefreshUWorldSelectorWorkspace();

            var message = "Backup restored successfully. Settings, accessibility preferences, My Study data, Journal data, UWorld Selector reports, cockpit study state, session information, and preserved extensions were restored together. Restart Pathfinder once to reopen the restored tab session exactly as saved.";
            if (plan.Warnings.Count > 0) message += "\n\nCompatibility notes: " + string.Join(" ", plan.Warnings);
            message += "\n\nOpen cockpit WebViews from before the restore are temporarily prevented from overwriting restored reading positions or cockpit study state until restart.";
            await ShowPersonalMessageAsync("Backup restored", message);
        }
        catch (Exception ex)
        {
            await ShowPersonalMessageAsync("Backup could not be restored", ex.Message);
        }
    }

    private async Task<bool> ConfirmRestorePlanAsync(BackupImportPlan plan)
    {
        var lines = new List<string>
        {
            $"Source: {plan.SourceDescription}",
            $"Open/session tabs: {plan.SessionTabCount}",
            $"Favorites: {plan.FavoriteCount}",
            $"Bookmarks: {plan.BookmarkCount}",
            $"Journal notes: {plan.NoteCount}",
            $"UWorld Selector reports: {plan.UWorldSelectorReportCount}/26",
            $"Imported Personal notes queued for Journal migration: {plan.LegacyNoteCount}",
            $"Saved reading positions: {plan.PositionCount}",
            $"Cockpit-state providers: {plan.CockpitState.Resources.Count}",
            "",
            "Restore replaces supported Windows shell/My Study/Journal/UWorld Selector/cockpit state only after the entire backup validates. A recovery checkpoint is created before any AppData file is changed."
        };
        if (plan.Warnings.Count > 0)
        {
            lines.Add("");
            lines.Add("Compatibility notes:");
            lines.AddRange(plan.Warnings.Select(x => "• " + x));
        }

        var dialog = new ContentDialog
        {
            XamlRoot = RootGrid.XamlRoot,
            Title = "Restore this Pathfinder backup?",
            Content = new TextBlock { Text = string.Join(Environment.NewLine, lines), TextWrapping = TextWrapping.Wrap, MaxWidth = 620, IsTextSelectionEnabled = true },
            PrimaryButtonText = "Restore",
            CloseButtonText = "Cancel",
            DefaultButton = ContentDialogButton.Primary
        };
        return await dialog.ShowAsync() == ContentDialogResult.Primary;
    }

    private async Task ShowPendingPersistenceNoticesAsync()
    {
        var notices = PersistenceHealth.Drain();
        if (notices.Count == 0 || RootGrid.XamlRoot is null) return;
        var body = string.Join(Environment.NewLine + Environment.NewLine, notices.Select(x => $"{x.Area}: {x.Message}"));
        await ShowPersonalMessageAsync("Pathfinder recovered local data", body);
    }

    private static ShellSettings CloneShellSettings(ShellSettings source) => new()
    {
        ThemeId = source.ThemeId,
        RestoreLastSession = source.RestoreLastSession,
        StrongFocusIndicators = source.StrongFocusIndicators,
        ReduceMotion = source.ReduceMotion,
        ComfortableReadingSpacing = source.ComfortableReadingSpacing,
        LastSelectedTabIndex = source.LastSelectedTabIndex,
        RestoreSplitWorkspace = source.RestoreSplitWorkspace,
        LastWorkspaceSplitEnabled = source.LastWorkspaceSplitEnabled,
        LastWorkspaceSecondaryKind = source.LastWorkspaceSecondaryKind ?? "",
        LastWorkspaceSecondaryId = source.LastWorkspaceSecondaryId ?? "",
        LastWorkspaceSplitRatio = source.LastWorkspaceSplitRatio,
        LastSessionTabs = source.LastSessionTabs.Select(x => new SessionTabState { Kind = x.Kind, Id = x.Id, IsPinned = x.IsPinned, HasLocation = x.HasLocation, Hash = x.Hash, ScrollX = x.ScrollX, ScrollY = x.ScrollY }).ToList()
    };

    private static void CopyShellSettings(ShellSettings source, ShellSettings target)
    {
        target.ThemeId = string.IsNullOrWhiteSpace(source.ThemeId) ? "light" : source.ThemeId;
        target.RestoreLastSession = source.RestoreLastSession;
        target.StrongFocusIndicators = source.StrongFocusIndicators;
        target.ReduceMotion = source.ReduceMotion;
        target.ComfortableReadingSpacing = source.ComfortableReadingSpacing;
        target.LastSelectedTabIndex = Math.Max(0, source.LastSelectedTabIndex);
        target.RestoreSplitWorkspace = source.RestoreSplitWorkspace;
        target.LastWorkspaceSplitEnabled = source.LastWorkspaceSplitEnabled;
        target.LastWorkspaceSecondaryKind = source.LastWorkspaceSecondaryKind ?? "";
        target.LastWorkspaceSecondaryId = source.LastWorkspaceSecondaryId ?? "";
        target.LastWorkspaceSplitRatio = double.IsFinite(source.LastWorkspaceSplitRatio) ? Math.Clamp(source.LastWorkspaceSplitRatio, 0.28, 0.72) : 0.5;
        target.LastSessionTabs = (source.LastSessionTabs ?? []).Select(x => new SessionTabState { Kind = x.Kind, Id = x.Id, IsPinned = x.IsPinned, HasLocation = x.HasLocation, Hash = x.Hash, ScrollX = x.ScrollX, ScrollY = x.ScrollY }).ToList();
    }

    private async Task ShowPersonalMessageAsync(string title, string body)
    {
        var dialog = new ContentDialog
        {
            XamlRoot = RootGrid.XamlRoot,
            Title = title,
            Content = new TextBlock { Text = body, TextWrapping = TextWrapping.Wrap, MaxWidth = 560, IsTextSelectionEnabled = true },
            CloseButtonText = "OK"
        };
        await dialog.ShowAsync();
    }

}
