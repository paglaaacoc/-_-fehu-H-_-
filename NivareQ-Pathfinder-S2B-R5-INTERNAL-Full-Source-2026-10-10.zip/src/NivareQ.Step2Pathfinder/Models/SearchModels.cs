namespace NivareQ.Step2Pathfinder.Models;

public sealed class UniversalSearchResult
{
    public string Query { get; init; } = "";
    public string Needle { get; init; } = "";
    public string SubjectSlug { get; init; } = "";
    public string SubjectTitle { get; init; } = "";
    public int SubjectNumber { get; init; }
    public string SourceVersion { get; init; } = "";
    public string Snippet { get; init; } = "";
    public int Score { get; init; }
    public bool IsExactPhrase { get; init; }
    public bool MatchedByAlias { get; init; }
    public string AliasLabel { get; init; } = "";
    public IReadOnlyList<string> HighlightTerms { get; init; } = [];
    public int SourceOccurrence { get; init; }
    public int SourceOccurrenceCount { get; init; } = 1;
    public string ContextHint { get; init; } = "";
    public string ContextBefore { get; init; } = "";
    public string ContextAfter { get; init; } = "";
}

public sealed class ClosedStudyTabSnapshot
{
    public string Id { get; init; } = Guid.NewGuid().ToString("N");
    public string Slug { get; init; } = "";
    public StudyLocationState? Location { get; init; }
    public DateTimeOffset ClosedUtc { get; init; } = DateTimeOffset.UtcNow;
}
