namespace NivareQ.Step2Pathfinder.Models;

public sealed class SubjectEntry
{
    public int Number { get; init; }
    public string ResourceId { get; init; } = "";
    // Slug remains as the v1.x persisted compatibility identifier. W2A keeps it equal to ResourceId.
    public string Slug { get; init; } = "";
    public string Title { get; init; } = "";
    public string Subtitle { get; init; } = "";
    public string Kind { get; init; } = "";
    public string Phase { get; init; } = "";
    public string MainPath { get; init; } = "";
    public string LegacyMainPath { get; init; } = "";
    public string ExpectedSha256 { get; init; } = "";
    public string ContentType { get; init; } = "html";
    public bool IsExtra { get; init; }
    public string StudyTimeBase { get; set; } = "";
    public string ProgressLabel { get; set; } = "";
    public bool IsFavorite { get; set; }
    public string StudyTimeShort => string.IsNullOrWhiteSpace(ProgressLabel) ? StudyTimeBase : StudyTimeBase + "\n" + ProgressLabel;
    public string DisplayTitle => (IsFavorite ? "★  " : "") + (IsExtra ? Title : $"{Number:00}  {Title}");
}
