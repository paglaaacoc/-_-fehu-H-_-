using System.Text.Json;
using NivareQ.Step2Pathfinder.Services;

namespace NivareQ.Step2Pathfinder.Models;

public sealed class PathfinderBackupCoverage
{
    public List<string> Included { get; set; } = [];
    public List<string> Deferred { get; set; } = [];
    public List<string> PreservedOpaque { get; set; } = [];
}

public sealed class PathfinderCanonicalBackupEnvelope
{
    public int BackupSchemaVersion { get; set; } = 7;
    public string FormatId { get; set; } = "nivareq.step2pathfinder.backup";
    public string ContractAuthority { get; set; } = "windows-canonical";
    public string Producer { get; set; } = "NivareQ Step 2 Pathfinder Windows";
    public string ProducerBuild { get; set; } = "1.2.2-S1-TEST";
    public DateTimeOffset ExportedUtc { get; set; } = DateTimeOffset.UtcNow;
    public ShellSettings ShellSettings { get; set; } = new();
    public PersonalStudyState PersonalStudy { get; set; } = new();
    public CockpitStateEnvelope CockpitState { get; set; } = new();
    public JournalState Journal { get; set; } = new();
    public UWorldSelectorState UWorldSelector { get; set; } = UWorldSelectorService.NewState();
    public PathfinderBackupCoverage Coverage { get; set; } = new();
    public Dictionary<string, JsonElement> PreservedExtensions { get; set; } = [];
}

public sealed class PreservedBackupExtensionState
{
    public int SchemaVersion { get; set; } = 1;
    public string LastImportedFrom { get; set; } = "";
    public DateTimeOffset UpdatedUtc { get; set; } = DateTimeOffset.UtcNow;
    public Dictionary<string, JsonElement> Values { get; set; } = [];
}

public sealed class BackupImportPlan
{
    public int SourceSchemaVersion { get; init; }
    public string SourceDescription { get; init; } = "";
    public ShellSettings ShellSettings { get; init; } = new();
    public PersonalStudyState PersonalStudy { get; init; } = new();
    public PreservedBackupExtensionState PreservedExtensions { get; init; } = new();
    public CockpitStateEnvelope CockpitState { get; init; } = new();
    public bool ReplaceCockpitState { get; init; }
    public JournalState Journal { get; init; } = new();
    public bool ReplaceJournal { get; init; }
    public UWorldSelectorState UWorldSelector { get; init; } = UWorldSelectorService.NewState();
    public bool ReplaceUWorldSelector { get; init; }
    public bool ReplacePreservedExtensions { get; init; }
    public int SessionTabCount => ShellSettings.LastSessionTabs.Count;
    public int FavoriteCount => PersonalStudy.FavoriteSlugs.Count;
    public int BookmarkCount => PersonalStudy.Bookmarks.Count;
    public int NoteCount => Journal.Entries.Count;
    public int UWorldSelectorReportCount => UWorldSelector.Reports.Count;
    public int LegacyNoteCount => PersonalStudy.SubjectNotes.Count(x => !string.IsNullOrWhiteSpace(x.Value) && !Journal.LegacyPersonalMigrationSlugs.Contains(x.Key, StringComparer.OrdinalIgnoreCase));
    public int PositionCount => PersonalStudy.PositionsBySlug.Count;
    public List<string> Warnings { get; init; } = [];
}
