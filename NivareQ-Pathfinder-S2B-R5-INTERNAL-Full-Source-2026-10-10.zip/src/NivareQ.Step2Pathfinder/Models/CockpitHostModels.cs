namespace NivareQ.Step2Pathfinder.Models;

public enum CockpitViewRole
{
    Primary = 0,
    ReadOnlySecondary = 1
}

public enum CockpitHostLifecycle
{
    Created = 0,
    Initializing = 1,
    Navigating = 2,
    Ready = 3,
    Recovering = 4,
    Failed = 5,
    Closed = 6
}

public sealed class CockpitResourceState
{
    public string ResourceId { get; set; } = "";
    public string SourceVersion { get; set; } = "";
    public bool MigratedFromWebViewProfile { get; set; }
    public DateTimeOffset UpdatedUtc { get; set; } = DateTimeOffset.UtcNow;
    public Dictionary<string, string> Values { get; set; } = new(StringComparer.Ordinal);
}

public sealed class CockpitStateEnvelope
{
    public int SchemaVersion { get; set; } = 1;
    public DateTimeOffset UpdatedUtc { get; set; } = DateTimeOffset.UtcNow;
    public Dictionary<string, CockpitResourceState> Resources { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

public sealed class SourceActionDraft
{
    public string ResourceId { get; set; } = "";
    public string SourceVersion { get; set; } = "";
    public StudyLocationState? Location { get; set; }
    public string SelectedText { get; set; } = "";
    public DateTimeOffset CapturedUtc { get; set; } = DateTimeOffset.UtcNow;
}
