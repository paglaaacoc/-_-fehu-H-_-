namespace NivareQ.Step2Pathfinder.Models;

public sealed class GlossaryFile
{
    public int Version { get; set; }
    public string Generated { get; set; } = "";
    public string Scope { get; set; } = "";
    public List<string> Rules { get; set; } = [];
    public List<GlossaryEntry> Entries { get; set; } = [];
}

public sealed class GlossaryEntry
{
    public string Term { get; set; } = "";
    public string Expansion { get; set; } = "";
    public List<string> Aliases { get; set; } = [];
    public string Note { get; set; } = "";
    public List<string> SourceTerms { get; set; } = [];
    public List<string> Subjects { get; set; } = [];
    public int Occurrences { get; set; }

    public string DisplayLine => $"{Term} — {Expansion}";
}
