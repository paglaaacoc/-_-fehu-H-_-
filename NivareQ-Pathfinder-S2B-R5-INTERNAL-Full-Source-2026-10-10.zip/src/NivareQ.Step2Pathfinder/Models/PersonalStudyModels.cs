namespace NivareQ.Step2Pathfinder.Models;

public sealed class StudyLocationState : PathfinderLocation
{
}

public sealed class RecentStudyItem
{
    public string Slug { get; set; } = "";
    public DateTimeOffset LastOpenedUtc { get; set; } = DateTimeOffset.UtcNow;
}

public sealed class StudyBookmark
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Slug { get; set; } = "";
    public string Name { get; set; } = "";
    public string Note { get; set; } = "";
    public StudyLocationState Location { get; set; } = new();
    public DateTimeOffset CreatedUtc { get; set; } = DateTimeOffset.UtcNow;
}

public sealed class PersonalStudyState
{
    public int SchemaVersion { get; set; } = 1;
    public bool ShowProgress { get; set; }
    public HashSet<string> FavoriteSlugs { get; set; } = [];
    public List<RecentStudyItem> RecentSubjects { get; set; } = [];
    public Dictionary<string, string> ProgressBySlug { get; set; } = [];
    public Dictionary<string, StudyLocationState> PositionsBySlug { get; set; } = [];
    public Dictionary<string, string> SubjectNotes { get; set; } = [];
    public List<StudyBookmark> Bookmarks { get; set; } = [];
}

public sealed class PathfinderBackupEnvelope
{
    public int BackupSchemaVersion { get; set; } = 1;
    public DateTimeOffset ExportedUtc { get; set; } = DateTimeOffset.UtcNow;
    public NivareQ.Step2Pathfinder.Services.ShellSettings ShellSettings { get; set; } = new();
    public PersonalStudyState PersonalStudy { get; set; } = new();
}
