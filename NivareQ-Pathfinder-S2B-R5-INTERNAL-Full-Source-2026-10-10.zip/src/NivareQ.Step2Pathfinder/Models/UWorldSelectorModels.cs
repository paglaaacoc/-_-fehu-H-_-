namespace NivareQ.Step2Pathfinder.Models;

public sealed class UWorldSelectorRecipeCatalog
{
    public int SchemaVersion { get; set; } = 1;
    public int RecipeVersion { get; set; } = 1;
    public string ResourceId { get; set; } = "extra-uworld-selector";
    public string Title { get; set; } = "UWorld Selector";
    public List<UWorldSelectorRecipe> Recipes { get; set; } = [];
    public List<string> AllSystems { get; set; } = [];
}

public sealed class UWorldSelectorRecipe
{
    public string Id { get; set; } = "";
    public string Label { get; set; } = "";
    public string Title { get; set; } = "";
    public string Slug { get; set; } = "";
    public List<string> Subjects { get; set; } = [];
    public List<string> Systems { get; set; } = [];
    public string How { get; set; } = "";
    public string Group { get; set; } = "";
}

public sealed class UWorldSelectorReport
{
    public int Unused { get; set; }
    public DateTimeOffset ReportedUtc { get; set; } = DateTimeOffset.UtcNow;
}

public sealed class UWorldSelectorState
{
    public int SchemaVersion { get; set; } = 1;
    public int RecipeVersion { get; set; } = 1;
    public DateTimeOffset UpdatedUtc { get; set; } = DateTimeOffset.UtcNow;
    public Dictionary<string, UWorldSelectorReport> Reports { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}
