using System.Text.Json.Serialization;

namespace NivareQ.Step2Pathfinder.Models;

/// <summary>
/// Unified Pathfinder location contract introduced in Windows W2B.
/// Resume locations may fall back to scroll coordinates; strict source locations never do.
/// </summary>
public class PathfinderLocation
{
    public const int CurrentSchemaVersion = 2;

    public int SchemaVersion { get; set; } = CurrentSchemaVersion;
    public string ResourceId { get; set; } = "";
    public string SourceVersion { get; set; } = "";
    public string Purpose { get; set; } = "resume"; // resume | source
    public string Anchor { get; set; } = "";
    public string TargetId { get; set; } = "";
    public string TargetPath { get; set; } = "";
    public string Context { get; set; } = "";
    public double OffsetY { get; set; }
    public double TargetOffsetY { get; set; }
    public string Hash { get; set; } = "";
    public double ScrollX { get; set; }
    public double ScrollY { get; set; }
    public List<string> OpenDetails { get; set; } = [];
    public DateTimeOffset UpdatedUtc { get; set; } = DateTimeOffset.UtcNow;

    [JsonIgnore]
    public bool IsStrictSource => Purpose.Equals("source", StringComparison.OrdinalIgnoreCase);

    [JsonIgnore]
    public bool HasDurableTarget => !string.IsNullOrWhiteSpace(TargetId) || !string.IsNullOrWhiteSpace(TargetPath) || !string.IsNullOrWhiteSpace(Context);
}

public sealed class SourceLocationValidationResult
{
    public bool Ok { get; init; }
    public string Reason { get; init; } = "";
    public string Message { get; init; } = "";

    public static SourceLocationValidationResult Pass() => new() { Ok = true, Reason = "verified" };
    public static SourceLocationValidationResult Fail(string reason, string message) => new() { Ok = false, Reason = reason, Message = message };
}
