namespace NivareQ.Step2Pathfinder.Models;

public sealed class ThemeChoice
{
    public string Id { get; set; } = "light";
    public string Name { get; set; } = "Light";
    public bool Enabled { get; set; } = true;
    public bool IsDark { get; set; }
    public string? ShellBackground { get; set; }
    public string? ShellPanel { get; set; }
    public string? ShellForeground { get; set; }
    public string? ShellMuted { get; set; }
    public string? ShellAccent { get; set; }
    public string? ShellBorder { get; set; }
    public string ContentCss { get; set; } = "";
    public string Note { get; set; } = "";
}

public sealed class ThemeRegistry
{
    public string Status { get; set; } = "";
    public string SourceReference { get; set; } = "";
    public string DefaultTheme { get; set; } = "Light";
    public string Note { get; set; } = "";
    public List<ThemeChoice> Themes { get; set; } = [];
}
