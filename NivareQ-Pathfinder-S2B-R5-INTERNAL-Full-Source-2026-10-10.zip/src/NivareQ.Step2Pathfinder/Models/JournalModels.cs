namespace NivareQ.Step2Pathfinder.Models;

public sealed class JournalEntry
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Title { get; set; } = "";
    public string Body { get; set; } = "";
    // Empty = General note. Otherwise this is the canonical ResourceId/legacy-compatible slug.
    public string Slug { get; set; } = "";
    public string SourceVersion { get; set; } = "";
    public StudyLocationState? SourceLocation { get; set; }
    // False only when a migrated released note had no historical per-note timestamp.
    // Created/Updated then record the migration operation time, never a claimed original date.
    public bool OriginalTimestampKnown { get; set; } = true;
    public DateTimeOffset CreatedUtc { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset UpdatedUtc { get; set; } = DateTimeOffset.UtcNow;
}

public sealed class JournalState
{
    public int SchemaVersion { get; set; } = 1;
    public DateTimeOffset UpdatedUtc { get; set; } = DateTimeOffset.UtcNow;
    // Durable idempotence markers for released Personal subject-note migration. Keeping these
    // inside Journal storage makes them survive an intentional rollback to W4, which does not
    // know about or rewrite the W5 Journal files.
    public List<string> LegacyPersonalMigrationSlugs { get; set; } = [];
    public List<JournalEntry> Entries { get; set; } = [];
}
