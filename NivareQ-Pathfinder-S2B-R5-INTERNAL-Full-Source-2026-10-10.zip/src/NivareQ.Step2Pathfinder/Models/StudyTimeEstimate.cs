namespace NivareQ.Step2Pathfinder.Models;

public sealed class StudyTimeEstimate
{
    public string Slug { get; set; } = "";
    public string Title { get; set; } = "";
    public int WordsApprox { get; set; }
    public int DrillsDetected { get; set; }
    public int QuickMinutes { get; set; }
    public int StandardMinMinutes { get; set; }
    public int StandardMaxMinutes { get; set; }
    public int DeepMinMinutes { get; set; }
    public int DeepMaxMinutes { get; set; }
    public string Method { get; set; } = "";
}

public sealed class StudyTimeFile
{
    public string Disclaimer { get; set; } = "";
    public string Formula { get; set; } = "";
    public Dictionary<string, int> Totals { get; set; } = [];
    public List<StudyTimeEstimate> Items { get; set; } = [];
}
