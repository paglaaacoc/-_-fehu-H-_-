using System.Runtime.InteropServices;
using Microsoft.UI.Dispatching;
using Microsoft.UI.Xaml;
using WinRT.Interop;

namespace NivareQ.Step2Pathfinder;

public partial class App : Application
{
    private const string InstanceMutexName = @"Local\NivareQ.Step2Pathfinder.SingleInstance.v1";
    private const string ActivationEventName = @"Local\NivareQ.Step2Pathfinder.Activate.v1";

    private Mutex? _instanceMutex;
    private EventWaitHandle? _activationEvent;
    private CancellationTokenSource? _activationListenerCts;
    private Window? _window;

    public App() => InitializeComponent();

    protected override void OnLaunched(LaunchActivatedEventArgs args)
    {
        // Keep the normal WinUI-generated STA entry point intact.  The accepted v1.1
        // WebView2 study surface depends on that STA UI thread, so single-instancing is
        // intentionally implemented here with Win32 kernel primitives rather than a
        // custom AppInstance Main that can alter startup/apartment initialization.
        _instanceMutex = new Mutex(initiallyOwned: false, InstanceMutexName, out var createdNew);
        if (!createdNew)
        {
            SignalExistingInstance();
            _instanceMutex.Dispose();
            _instanceMutex = null;
            Exit();
            return;
        }

        // Create the activation signal immediately after claiming the instance name so a
        // near-simultaneous second launch has a deterministic route to the primary window.
        _activationEvent = new EventWaitHandle(false, EventResetMode.AutoReset, ActivationEventName);

        _window = new MainWindow();
        _window.Activate();
        StartActivationListener();
    }

    private void StartActivationListener()
    {
        if (_window is null || _activationEvent is null) return;

        _activationListenerCts = new CancellationTokenSource();
        var token = _activationListenerCts.Token;
        var signal = _activationEvent;
        var dispatcher = _window.DispatcherQueue;

        _ = Task.Run(() =>
        {
            try
            {
                while (!token.IsCancellationRequested)
                {
                    if (!signal.WaitOne(250)) continue;
                    if (token.IsCancellationRequested) break;
                    dispatcher.TryEnqueue(DispatcherQueuePriority.Normal, ActivateExistingWindow);
                }
            }
            catch (ObjectDisposedException)
            {
                // Normal during shutdown.
            }
        }, token);

        _window.Closed += (_, _) => StopActivationListener();
    }

    private static void SignalExistingInstance()
    {
        // The primary creates the activation event immediately after the mutex. A very
        // small retry window covers simultaneous launches without starting a second UI.
        for (var attempt = 0; attempt < 12; attempt++)
        {
            try
            {
                using var signal = EventWaitHandle.OpenExisting(ActivationEventName);
                signal.Set();
                return;
            }
            catch (WaitHandleCannotBeOpenedException)
            {
                Thread.Sleep(25);
            }
        }
    }

    internal void ActivateExistingWindow()
    {
        if (_window is null) return;

        _window.Activate();
        try
        {
            var hwnd = WindowNative.GetWindowHandle(_window);
            if (hwnd != IntPtr.Zero)
            {
                ShowWindow(hwnd, SW_RESTORE);
                SetForegroundWindow(hwnd);
            }
        }
        catch
        {
            // Window.Activate above remains the safe fallback.
        }
    }

    private void StopActivationListener()
    {
        try
        {
            _activationListenerCts?.Cancel();
            _activationEvent?.Set();
        }
        catch { }

        _activationEvent?.Dispose();
        _activationEvent = null;
        _activationListenerCts?.Dispose();
        _activationListenerCts = null;
        _instanceMutex?.Dispose();
        _instanceMutex = null;
    }

    private const int SW_RESTORE = 9;

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetForegroundWindow(IntPtr hWnd);
}
