using System.Text.Json;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using NivareQ.Step2Pathfinder.Models;
using NivareQ.Step2Pathfinder.Services;

namespace NivareQ.Step2Pathfinder;

public sealed partial class MainWindow
{
    private CancellationTokenSource? _cockpitStateSaveCts;

    private static bool IsPrimaryCockpit(StudyTabContext context)
        => context.ViewRole == CockpitViewRole.Primary;

    private bool IsCurrentPrimaryCockpitWriter(StudyTabContext context)
        => !_suspendCockpitStatePersistenceUntilRestart
           && !RestoreTransactionService.MutationsBlocked
           && context.ViewRole == CockpitViewRole.Primary
           && context.DocumentHealthy
           && _studyTabs.TryGetValue(context.Tab, out var registered)
           && ReferenceEquals(registered, context)
           && context.WebView.CoreWebView2 is not null;

    private async Task PrepareCockpitDocumentBridgeAsync(StudyTabContext context)
    {
        if (context.WebView.CoreWebView2 is null) return;
        var epoch = CaptureRuntimeMutationEpoch();
        var generation = context.ContentGeneration;
        if (context.DocumentCreatedScriptId is not null)
        {
            try { context.WebView.CoreWebView2.RemoveScriptToExecuteOnDocumentCreated(context.DocumentCreatedScriptId); } catch { }
            context.DocumentCreatedScriptId = null;
        }

        var resourceId = context.Subject.ResourceId;
        var sourceVersion = context.Subject.ExpectedSha256.ToLowerInvariant();
        var supportsState = _cockpitState is not null && _cockpitStateRegistry.SupportsResource(resourceId);
        var state = supportsState ? _cockpitState!.StateFor(resourceId) : null;
        var allowed = supportsState ? _cockpitStateRegistry.AllowedKeysFor(resourceId) : Array.Empty<string>();
        var values = state?.Values ?? new Dictionary<string, string>(StringComparer.Ordinal);
        var readOnly = context.ViewRole == CockpitViewRole.ReadOnlySecondary;
        context.NeedsLegacyStateAdoption = !readOnly && supportsState && state is null;

        var script = CockpitStateBridgeTemplate
            .Replace("__RESOURCE_ID__", JsonSerializer.Serialize(resourceId))
            .Replace("__SOURCE_VERSION__", JsonSerializer.Serialize(sourceVersion))
            .Replace("__ALLOWED_KEYS__", JsonSerializer.Serialize(allowed))
            .Replace("__STATE_VALUES__", JsonSerializer.Serialize(values))
            .Replace("__HAS_CANONICAL_STATE__", state is null ? "false" : "true")
            .Replace("__READ_ONLY__", readOnly ? "true" : "false")
            .Replace("__RUNTIME_COMPAT__", BuildRuntimeCompatibilityScript(resourceId));

        var scriptId = await context.WebView.CoreWebView2.AddScriptToExecuteOnDocumentCreatedAsync(script);
        if (!IsRuntimeMutationCurrent(epoch, context) || context.ContentGeneration != generation)
        {
            try { context.WebView.CoreWebView2.RemoveScriptToExecuteOnDocumentCreated(scriptId); } catch { }
            return;
        }
        context.DocumentCreatedScriptId = scriptId;
    }

    private const string CockpitStateBridgeTemplate = """
        (() => {
          'use strict';
          const resourceId=__RESOURCE_ID__,sourceVersion=__SOURCE_VERSION__;
          const allowed=new Set(__ALLOWED_KEYS__),seed=__STATE_VALUES__;
          const authoritative=__HAS_CANONICAL_STATE__,readOnly=__READ_ONLY__;
          const storage=()=>{try{return localStorage}catch(_){return null}};
          const ls=storage();
          if(ls && (authoritative||readOnly)){
            for(const key of allowed){try{if(!Object.prototype.hasOwnProperty.call(seed,key))ls.removeItem(key)}catch(_){}}
            for(const [key,value] of Object.entries(seed)){if(allowed.has(key)){try{ls.setItem(key,String(value))}catch(_){}}}
          }
          const post=(action,key,value)=>{if(readOnly)return;try{chrome.webview.postMessage(JSON.stringify({type:'pathfinder-cockpit-state',resourceId,sourceVersion,action,key:key||'',value:value??null}))}catch(_){}};
          if(!readOnly && ls && !window.__nivareqCockpitStateBridge){
            window.__nivareqCockpitStateBridge=true;
            const set=Storage.prototype.setItem,remove=Storage.prototype.removeItem,clear=Storage.prototype.clear;
            Storage.prototype.setItem=function(key,value){set.call(this,key,value);if(this===localStorage&&allowed.has(String(key)))post('set',String(key),String(value));};
            Storage.prototype.removeItem=function(key){remove.call(this,key);if(this===localStorage&&allowed.has(String(key)))post('remove',String(key),null);};
            Storage.prototype.clear=function(){const owned=this===localStorage;if(owned){const keys=[...allowed].filter(k=>{try{return localStorage.getItem(k)!==null}catch(_){return false}});clear.call(this);for(const k of keys)post('remove',k,null);}else clear.call(this);};
          }
          if(readOnly){
            const install=()=>{
              document.documentElement?.setAttribute('data-pathfinder-view-role','read-only-secondary');
              const mutating='button,input,textarea,select,[contenteditable="true"],[role="button"]';
              const cancel=e=>{if(!e.isTrusted)return;const el=e.target?.closest?.(mutating);if(!el||el.closest('summary'))return;e.preventDefault();e.stopImmediatePropagation();};
              for(const t of ['click','dblclick','beforeinput','input','change','submit'])document.addEventListener(t,cancel,true);
              document.addEventListener('keydown',e=>{if(!e.isTrusted)return;const el=e.target?.closest?.(mutating);if(!el)return;if(e.key.length===1||['Enter',' ','Backspace','Delete'].includes(e.key)){e.preventDefault();e.stopImmediatePropagation();}},true);
              document.querySelectorAll(mutating).forEach(el=>el.setAttribute('aria-disabled','true'));
              try{window.open=()=>null}catch(_){}
            };
            if(document.documentElement)install();else addEventListener('DOMContentLoaded',install,{once:true});
          }
          __RUNTIME_COMPAT__
        })();
        """;

    private static string BuildRuntimeCompatibilityScript(string resourceId)
    {
        var parts = new List<string> { RuntimeSelectionSnapshotTemplate };
        var labels = resourceId switch
        {
            "rheumatology-msk-dermatology" => new[] { "Foundation", "Inflammatory arthritis", "Crystal arthritis", "Spondyloarthritis", "Connective tissue disease", "Vasculitis", "Medication integration", "MSK / spine", "MSK / upper limb", "MSK / knee", "MSK / lower limb", "MSK / emergencies", "MSK / pain", "Dermatology foundation", "Dermatitis", "Skin infection crossover", "Drug eruptions", "Blistering disease", "Skin cancer", "Systemic skin clues", "Dermatology other", "Pediatric rheum crossover" },
            "obstetrics" => new[] { "Prenatal foundations", "Early pregnancy", "Hypertension / medical pregnancy", "Fetal / placental disorders", "Preterm / PROM / infection", "Labor / delivery", "Postpartum" },
            "repro-gyn-breast" => new[] { "Core reproductive reasoning", "Bleeding / amenorrhea / uterine disorders", "Pelvic pain / adnexa / infection", "Contraception / fertility", "Cancer screening / gynecologic oncology", "Breast", "Menopause / pelvic floor / sexual health", "Male reproductive / sexual health" },
            _ => Array.Empty<string>()
        };
        if (labels.Length > 0)
        {
            parts.Add(RuntimeStudyMapRepairTemplate.Replace("__LABELS__", JsonSerializer.Serialize(labels)));
        }

        var quizPrefix = resourceId switch
        {
            "allergy-immunology" => "ai-quiz-q",
            "ent-ophthalmology" => "ento-quiz-q",
            "poisoning-environmental" => "poisonenv-quiz-q",
            "general-principles-misc" => "generalmulti-quiz-q",
            _ => ""
        };
        if (quizPrefix.Length > 0)
        {
            parts.Add(RuntimeSupplementalQuizTemplate.Replace("__QUIZ_PREFIX__", JsonSerializer.Serialize(quizPrefix)));
        }
        if (resourceId.Equals("biostats-ebm", StringComparison.OrdinalIgnoreCase)) parts.Add(RuntimeBiostatCompatibilityScript);
        return string.Join("\n", parts);
    }

    private const string RuntimeSelectionSnapshotTemplate = """
        (()=>{
          const clean=v=>String(v||'').replace(/\r\n?/g,'\n').replace(/\u00a0/g,' ').slice(0,12000);
          const capture=()=>{try{const text=clean(window.getSelection?.()?.toString?.()||'');if(text.trim())window.__nivareqSelectionSnapshot={text,at:Date.now()};}catch(_){}};
          document.addEventListener('pointerup',capture,true);
          document.addEventListener('keyup',capture,true);
          document.addEventListener('contextmenu',capture,true);
        })();
        """;

    private const string RuntimeStudyMapRepairTemplate = """
        addEventListener('DOMContentLoaded',()=>{
          const labels=__LABELS__,links=[...document.querySelectorAll('#study-map a.jump[href="#library"]')];
          links.forEach((link,i)=>{if(i>=labels.length)return;link.addEventListener('click',e=>{if(typeof window.focusSection!=='function')return;e.preventDefault();e.stopImmediatePropagation();window.focusSection(labels[i]);},true);});
        },{once:true});
        """;

    private const string RuntimeSupplementalQuizTemplate = """
        addEventListener('DOMContentLoaded',()=>{
          const prefix=__QUIZ_PREFIX__;
          document.querySelectorAll('.q').forEach((q,index)=>{
            const key=prefix+String(index+1).padStart(3,'0');
            const paint=choice=>{const ans=Number(q.dataset.answer);q.dataset.done='1';q.querySelectorAll('.opt').forEach(x=>{x.disabled=true;if(Number(x.dataset.i)===ans)x.classList.add('correct')});const picked=q.querySelector(`.opt[data-i="${choice}"]`);if(picked&&Number(choice)!==ans)picked.classList.add('wrong');const exp=q.querySelector('.explain');if(exp)exp.style.display='block';};
            let saved=null;try{saved=localStorage.getItem(key)}catch(_){}
            if(saved!==null&&/^\d+$/.test(saved)&&q.querySelector(`.opt[data-i="${saved}"]`))paint(Number(saved));
            q.querySelectorAll('.opt').forEach(btn=>btn.addEventListener('click',()=>{if(q.dataset.done)return;try{localStorage.setItem(key,String(btn.dataset.i))}catch(_){}},true));
          });
        },{once:true});
        """;

    private const string RuntimeBiostatCompatibilityScript = """
        addEventListener('DOMContentLoaded',()=>{
          try{
            if(typeof Q==='undefined')return;
            const valid=(q,v)=>Number.isInteger(Number(v))&&Number(v)>=0&&Number(v)<(q?.a?.length??0)?Number(v):null;
            let modernRaw=localStorage.getItem('bioQuizV2'),modern=null;
            try{const p=JSON.parse(modernRaw??'null');if(p&&typeof p==='object'&&!Array.isArray(p))modern=p}catch(_){}
            let legacy=null;try{const p=JSON.parse(localStorage.getItem('bioQuiz')??'null');if(p&&typeof p==='object'&&!Array.isArray(p))legacy=p}catch(_){}
            const explicitReset=modernRaw!==null&&modern&&Object.keys(modern).length===0;
            const merged={};
            if(modern){for(const q of Q){if(Object.prototype.hasOwnProperty.call(modern,q.id)){const v=valid(q,modern[q.id]);if(v!==null)merged[q.id]=v}}}
            if(!explicitReset&&legacy){for(const [i,v0] of Object.entries(legacy)){const q=Q[Number(i)],v=valid(q,v0);if(q&&v!==null&&!Object.prototype.hasOwnProperty.call(merged,q.id))merged[q.id]=v}}
            const encoded=JSON.stringify(merged);localStorage.setItem('bioQuizV2',explicitReset?'{}':encoded);
            if(localStorage.getItem('bioQuizV2')===(explicitReset?'{}':encoded))localStorage.removeItem('bioQuiz');
            if(typeof window.resetQuiz==='function')window.resetQuiz=()=>{answers={};localStorage.setItem('bioQuizV2','{}');if(localStorage.getItem('bioQuizV2')==='{}')localStorage.removeItem('bioQuiz');renderQuiz();};
          }catch(_){}
        },{once:true});
        """;

    private async Task FinalizeCockpitHostReadyAsync(StudyTabContext context)
    {
        context.Lifecycle = CockpitHostLifecycle.Ready;
        HideCockpitRecoveryAction(context);
        if (context.ViewRole != CockpitViewRole.Primary || _cockpitState is null || !_cockpitStateRegistry.SupportsResource(context.Subject.ResourceId)) return;
        if (context.NeedsLegacyStateAdoption || !_cockpitState.HasAuthoritativeState(context.Subject.ResourceId))
        {
            await CaptureCockpitStateSnapshotAsync(context, migratedFromProfile: true);
            context.NeedsLegacyStateAdoption = false;
        }
    }

    private async Task<bool> CaptureCockpitStateSnapshotAsync(StudyTabContext context, bool migratedFromProfile = false)
    {
        if (_cockpitState is null || !_cockpitStateRegistry.SupportsResource(context.Subject.ResourceId)) return true;
        if (!IsCurrentPrimaryCockpitWriter(context)) return false;
        if (!context.DocumentHealthy) return false;
        var epoch = CaptureRuntimeMutationEpoch();
        var resourceId = context.Subject.ResourceId;
        var sourceVersion = context.Subject.ExpectedSha256;
        var generation = context.ContentGeneration;
        var webView = context.WebView;
        try
        {
            var keys = JsonSerializer.Serialize(_cockpitStateRegistry.AllowedKeysFor(resourceId));
            var script = """
                (()=>{const keys=__KEYS__,out={};for(const key of keys){try{const v=localStorage.getItem(key);if(v!==null)out[key]=v}catch(_){}}return JSON.stringify(out);})();
                """.Replace("__KEYS__", keys);
            var raw = await webView.CoreWebView2!.ExecuteScriptAsync(script);
            if (!IsRuntimeMutationCurrent(epoch, context)
                || !IsCurrentPrimaryCockpitWriter(context)
                || !context.DocumentHealthy
                || !ReferenceEquals(webView, context.WebView)
                || context.ContentGeneration != generation
                || !context.Subject.ResourceId.Equals(resourceId, StringComparison.OrdinalIgnoreCase)
                || !context.Subject.ExpectedSha256.Equals(sourceVersion, StringComparison.OrdinalIgnoreCase)) return false;
            var json = JsonSerializer.Deserialize<string>(raw);
            if (string.IsNullOrWhiteSpace(json)) return false;
            var values = JsonSerializer.Deserialize<Dictionary<string, string>>(json);
            if (values is null) return false;
            _cockpitState.ReplaceResource(resourceId, sourceVersion, values, migratedFromProfile);
            ScheduleCockpitStateSave();
            return true;
        }
        catch (Exception ex)
        {
            LogStudyEvent(context, "cockpit-state-capture-failed", ex.Message);
            return false;
        }
    }

    private async Task<int> FlushOpenPrimaryCockpitStateAsync()
    {
        if (_suspendCockpitStatePersistenceUntilRestart) return 0;
        var failures = 0;
        foreach (var context in _studyTabs.Values.Where(x => x.ViewRole == CockpitViewRole.Primary).ToList())
            if (!await CaptureCockpitStateSnapshotAsync(context)) failures++;
        return failures;
    }

    private void HandleCockpitStateWebMessage(StudyTabContext context, string text)
    {
        if (_cockpitState is null || !IsCurrentPrimaryCockpitWriter(context)) return;
        try
        {
            var message = JsonSerializer.Deserialize<CockpitStateMessage>(text, LocationJsonOptions);
            if (message is null || !message.Type.Equals("pathfinder-cockpit-state", StringComparison.OrdinalIgnoreCase)) return;
            if (!message.ResourceId.Equals(context.Subject.ResourceId, StringComparison.OrdinalIgnoreCase)) return;
            if (!message.SourceVersion.Equals(context.Subject.ExpectedSha256, StringComparison.OrdinalIgnoreCase)) return;
            if (message.Action.Equals("set", StringComparison.OrdinalIgnoreCase))
            {
                if (!_cockpitState.ApplyChange(message.ResourceId, message.SourceVersion, message.Key, message.Value)) return;
            }
            else if (message.Action.Equals("remove", StringComparison.OrdinalIgnoreCase))
            {
                if (!_cockpitState.ApplyChange(message.ResourceId, message.SourceVersion, message.Key, null)) return;
            }
            else return;
            ScheduleCockpitStateSave();
        }
        catch { }
    }

    private void ScheduleCockpitStateSave()
    {
        if (_suspendCockpitStatePersistenceUntilRestart || _cockpitState is null) return;
        _cockpitStateSaveCts?.Cancel();
        var cts = _cockpitStateSaveCts = new CancellationTokenSource();
        var epoch = CaptureRuntimeMutationEpoch();
        _ = SaveCockpitStateAfterDelayAsync(cts, epoch);
    }

    private async Task SaveCockpitStateAfterDelayAsync(CancellationTokenSource owner, long epoch)
    {
        try
        {
            await Task.Delay(350, owner.Token);
            if (owner.IsCancellationRequested || owner != _cockpitStateSaveCts || _cockpitState is null || _suspendCockpitStatePersistenceUntilRestart || !IsRuntimeMutationCurrent(epoch)) return;
            QueuePersistenceFailureNotice(_cockpitState.Save(), "Cockpit study state");
        }
        catch (OperationCanceledException) { }
    }

    private async Task ApplyCockpitHostPresentationAsync(StudyTabContext context, ThemeChoice theme)
    {
        await ApplyThemeToWebViewAsync(context.WebView, theme);
        if (context.WebView.CoreWebView2 is null) return;
        if (context.Subject.ResourceId is not ("allergy-immunology" or "ent-ophthalmology" or "poisoning-environmental" or "general-principles-misc")) return;
        if (IsSystemHighContrast) return;
        const string css = """
            header{background:var(--panel)!important;color:var(--ink)!important;border-bottom:1px solid var(--line)!important}
            .eyebrow{color:var(--accent)!important}.sub,.small{color:var(--muted)!important}
            .bar{background:color-mix(in srgb,var(--bg) 94%,transparent)!important;border-color:var(--line)!important}
            input,select,button{background:var(--panel)!important;color:var(--ink)!important;border-color:var(--line)!important}
            button.active{background:var(--accent)!important;color:#fff!important;border-color:var(--accent)!important}
            .opt.correct{border-color:var(--good)!important;background:color-mix(in srgb,var(--good) 24%,var(--panel))!important;color:var(--ink)!important;box-shadow:inset 4px 0 0 var(--good)!important}
            .opt.correct::after{content:"✓ Correct";float:right;margin-left:10px;font-weight:800;color:var(--good)!important}
            .opt.wrong{border-color:var(--bad)!important;background:color-mix(in srgb,var(--bad) 20%,var(--panel))!important;color:var(--ink)!important;box-shadow:inset 4px 0 0 var(--bad)!important}
            .opt.wrong::after{content:"✕ Your choice";float:right;margin-left:10px;font-weight:800;color:var(--bad)!important}
            .notice,.pill,.tag,.explain{background:var(--p2)!important;color:var(--ink)!important;border-color:var(--line)!important}
            .label,.arrow{color:var(--accent)!important}.deeper{background:color-mix(in srgb,var(--good) 24%,var(--panel))!important;color:var(--ink)!important}.trap{background:color-mix(in srgb,var(--warn) 16%,var(--panel))!important;color:var(--ink)!important}
            """;
        var script = """
            (()=>{let s=document.getElementById('nivareq-w3-compat-theme');if(!s){s=document.createElement('style');s.id='nivareq-w3-compat-theme';document.head.appendChild(s)}s.textContent=__CSS__;})();
            """.Replace("__CSS__", JsonSerializer.Serialize(css));
        try { await context.WebView.CoreWebView2.ExecuteScriptAsync(script); } catch { }
    }

    private void ShowCockpitRecoveryAction(StudyTabContext context)
    {
        if (context.RecoveryButton is null)
        {
            context.RecoveryButton = new Button { Margin = new Thickness(28, 82, 28, 0), HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Top };
            context.RecoveryButton.Click += async (_, _) =>
            {
                if (context.LastProcessFailureKind.Equals("BrowserProcessExited", StringComparison.OrdinalIgnoreCase))
                {
                    Close();
                    return;
                }
                await RecoverCockpitHostAsync(context);
            };
        }
        context.RecoveryButton.Content = context.LastProcessFailureKind.Equals("BrowserProcessExited", StringComparison.OrdinalIgnoreCase)
            ? "Close Pathfinder to restart"
            : "Reload cockpit safely";
        if (context.RecoveryButton.Parent is null)
        {
            var grid = context.WebView.Parent as Grid ?? context.Tab.Content as Grid;
            if (grid is not null)
            {
                Grid.SetRow(context.RecoveryButton, 1);
                grid.Children.Add(context.RecoveryButton);
            }
        }
        context.RecoveryButton.Visibility = Visibility.Visible;
    }

    private void HideCockpitRecoveryAction(StudyTabContext context)
    {
        if (context.RecoveryButton is not null) context.RecoveryButton.Visibility = Visibility.Collapsed;
    }

    private async Task RecoverCockpitHostAsync(StudyTabContext context)
    {
        if (context.WebView.CoreWebView2 is null || context.RecoveryAttempts >= 3) return;
        if (context.LastProcessFailureKind.Equals("BrowserProcessExited", StringComparison.OrdinalIgnoreCase))
        {
            ShowStudyError(context, "The WebView2 browser process exited. This controller is no longer a safe source of state. Close Pathfinder and reopen it to create a fresh browser environment.");
            ShowCockpitRecoveryAction(context);
            return;
        }
        context.RecoveryAttempts++;
        context.Lifecycle = CockpitHostLifecycle.Recovering;
        context.DocumentHealthy = false;
        context.CaptureAuthorityReady = false;
        HideCockpitRecoveryAction(context);
        context.Status.Visibility = Visibility.Collapsed;
        // Never snapshot a document after ProcessFailed. Canonical provider state is the recovery
        // authority; an invalid/empty failed document must not erase it.
        try { await NavigateStudyTabAsync(context, context.Subject); }
        catch (Exception ex)
        {
            context.Lifecycle = CockpitHostLifecycle.Failed;
            ShowStudyError(context, "Safe cockpit reload failed: " + ex.Message);
            ShowCockpitRecoveryAction(context);
        }
    }

    private async Task<string> CaptureLiveSelectionTextAsync(StudyTabContext context, string? fallback = null)
    {
        var selected = "";
        if (context.WebView.CoreWebView2 is not null)
        {
            try
            {
                // Selection.toString() is authoritative for the actual DOM range and is more
                // reliable than ContextMenuTarget.SelectionText for multi-block selections.
                // Keep Journal plain text, preserve meaningful line breaks, normalize only CRLF
                // and non-breaking spaces, and retain the existing 12,000-character safety cap.
                const string script = @"(()=>{const clean=v=>String(v||'').replace(/\r\n?/g,'\n').replace(/\u00a0/g,' ').slice(0,12000);const current=clean(window.getSelection?.()?.toString?.()||'');const snap=window.__nivareqSelectionSnapshot;const cached=snap&&Date.now()-Number(snap.at||0)<4000?clean(snap.text):'';return cached.length>current.length?cached:current;})()";
                var raw = await context.WebView.CoreWebView2.ExecuteScriptAsync(script);
                selected = (JsonSerializer.Deserialize<string>(raw) ?? "").Trim();
            }
            catch { }
        }
        if (selected.Length == 0) selected = (fallback ?? "").Trim();
        if (selected.Length > 12000) selected = selected[..12000];
        return selected;
    }

    private async Task<SourceActionDraft?> CaptureSourceActionDraftAsync(StudyTabContext context, string? selectedTextOverride = null, bool preferLiveSelection = false)
    {
        if (context.WebView.CoreWebView2 is null) return null;
        var location = context.ViewRole == CockpitViewRole.Primary
            ? await CaptureStrictSourceLocationAsync(context)
            : context.LastKnownLocation;
        var selected = preferLiveSelection
            ? await CaptureLiveSelectionTextAsync(context, selectedTextOverride)
            : selectedTextOverride is null
                ? await CaptureLiveSelectionTextAsync(context)
                : selectedTextOverride.Trim();
        if (selected.Length > 12000) selected = selected[..12000];
        return new SourceActionDraft
        {
            ResourceId = context.Subject.ResourceId,
            SourceVersion = context.Subject.ExpectedSha256.ToLowerInvariant(),
            Location = location is null ? null : CloneLocationV2(location),
            SelectedText = selected,
            CapturedUtc = DateTimeOffset.UtcNow
        };
    }

    private sealed class CockpitStateMessage
    {
        public string Type { get; set; } = "";
        public string ResourceId { get; set; } = "";
        public string SourceVersion { get; set; } = "";
        public string Action { get; set; } = "";
        public string Key { get; set; } = "";
        public string? Value { get; set; }
    }
}
