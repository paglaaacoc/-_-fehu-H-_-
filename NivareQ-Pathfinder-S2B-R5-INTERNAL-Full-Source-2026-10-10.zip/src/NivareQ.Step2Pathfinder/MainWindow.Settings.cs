using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using NivareQ.Step2Pathfinder.Models;
using NivareQ.Step2Pathfinder.Services;
using Windows.Storage;

namespace NivareQ.Step2Pathfinder;

public sealed partial class MainWindow
{
    private string _activeSettingsSection = "general";

    private static readonly (string Id, string Label)[] SettingsSections =
    [
        ("general", "General"),
        ("appearance", "Appearance"),
        ("accessibility", "Accessibility & display"),
        ("data", "Data, backup & reset"),
        ("session", "Session & navigation"),
        ("workspace", "Workspace & Split View"),
        ("about", "About & integrity")
    ];

    private void OpenAppSurfaceSafe(string id, string title, Func<UIElement> contentFactory)
    {
        try
        {
            OpenAppSurface(id, title, contentFactory());
        }
        catch (Exception ex)
        {
            OpenAppSurface(id + "-problem", title + " problem", MakeScrollableStack(
                MakeHeading(title + " could not open."),
                MakeBody(ex.Message),
                MakeBody("This is a Pathfinder app-surface error. Return to study and try again.")));
        }
    }

    private void OpenAppSurface(string id, string title, UIElement content)
    {
        if (AppSurfaceHost.Visibility != Visibility.Visible && Tabs.SelectedItem is TabViewItem current)
            _tabBeforeAppSurface = current;

        _activeAppSurfaceId = id;
        AppSurfaceTitle.Text = title;
        AppSurfaceContent.Content = PrepareShellContent(content);
        Tabs.Visibility = Visibility.Collapsed;
        AppSurfaceHost.Visibility = Visibility.Visible;
        UpdateNavigationButtons();
        QueuePersistenceFailureNotice(SaveCurrentSession(), "Session state");
    }

    private void CloseAppSurface(bool restorePreviousTab)
    {
        if (AppSurfaceHost.Visibility != Visibility.Visible) return;
        AppSurfaceContent.Content = null;
        AppSurfaceHost.Visibility = Visibility.Collapsed;
        Tabs.Visibility = Visibility.Visible;
        _activeAppSurfaceId = "";

        if (restorePreviousTab && _tabBeforeAppSurface is not null && Tabs.TabItems.Contains(_tabBeforeAppSurface))
            Tabs.SelectedItem = _tabBeforeAppSurface;
        _tabBeforeAppSurface = null;
        UpdateNavigationButtons();
    }

    private void CloseAppSurfaceButton_Click(object sender, RoutedEventArgs e)
        => CloseAppSurface(restorePreviousTab: true);

    private void SettingsButton_Click(object sender, RoutedEventArgs e) => OpenSettings("general");

    private void OpenSettings(string sectionId)
    {
        _activeSettingsSection = SettingsSections.Any(x => x.Id.Equals(sectionId, StringComparison.OrdinalIgnoreCase))
            ? sectionId
            : "general";
        OpenAppSurface("settings", "Settings", CreateSettingsView(_activeSettingsSection));
    }

    private UIElement CreateSettingsView(string initialSection)
    {
        var root = new Grid { HorizontalAlignment = HorizontalAlignment.Stretch, VerticalAlignment = VerticalAlignment.Stretch };
        root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(230) });
        root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

        var nav = new StackPanel { Padding = new Thickness(16, 18, 10, 18), Spacing = 4 };
        nav.Children.Add(new TextBlock
        {
            Text = "SETTINGS",
            FontSize = 10.5,
            CharacterSpacing = 90,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            Opacity = 0.72,
            Margin = new Thickness(8, 0, 8, 7)
        });

        var content = new ContentControl
        {
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            VerticalContentAlignment = VerticalAlignment.Stretch
        };
        Grid.SetColumn(content, 1);

        var sectionButtons = new Dictionary<string, Button>(StringComparer.OrdinalIgnoreCase);
        void ShowSection(string id)
        {
            var normalized = SettingsSections.Any(x => x.Id.Equals(id, StringComparison.OrdinalIgnoreCase)) ? id : "general";
            _activeSettingsSection = normalized;
            content.Content = CreateSettingsSection(normalized);
            foreach (var pair in sectionButtons)
                pair.Value.FontWeight = pair.Key.Equals(normalized, StringComparison.OrdinalIgnoreCase)
                    ? Microsoft.UI.Text.FontWeights.SemiBold
                    : Microsoft.UI.Text.FontWeights.Normal;
        }

        foreach (var section in SettingsSections)
        {
            var id = section.Id;
            var button = new Button
            {
                Content = section.Label,
                HorizontalAlignment = HorizontalAlignment.Stretch,
                HorizontalContentAlignment = HorizontalAlignment.Left,
                MinHeight = 40,
                Padding = new Thickness(10, 7, 10, 7),
                Tag = id
            };
            Microsoft.UI.Xaml.Automation.AutomationProperties.SetName(button, section.Label + " settings");
            button.Click += (_, _) => ShowSection(id);
            sectionButtons[id] = button;
            nav.Children.Add(button);
        }

        var navScroller = new ScrollViewer
        {
            Content = nav,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto
        };
        root.Children.Add(navScroller);
        root.Children.Add(content);

        root.SizeChanged += (_, e) =>
        {
            // Surface/portrait friendliness: a narrow Settings view becomes a compact
            // top selector instead of retaining a wide desktop rail.
            if (e.NewSize.Width >= 760)
            {
                root.ColumnDefinitions[0].Width = new GridLength(230);
                navScroller.MaxHeight = double.PositiveInfinity;
            }
            else
            {
                root.ColumnDefinitions[0].Width = new GridLength(168);
            }
        };

        ShowSection(initialSection);
        return root;
    }

    private UIElement CreateSettingsSection(string id)
        => id.ToLowerInvariant() switch
        {
            "appearance" => CreateAppearanceSettingsView(),
            "accessibility" => CreateAccessibilityView(),
            "data" => CreateDataSettingsView(),
            "session" => CreateSessionSettingsView(),
            "workspace" => CreateWorkspaceSettingsView(),
            "about" => CreateAboutSettingsView(),
            _ => CreateGeneralSettingsView()
        };

    private UIElement CreateGeneralSettingsView()
    {
        var stack = new StackPanel { Spacing = 14, MaxWidth = 940, HorizontalAlignment = HorizontalAlignment.Left };
        stack.Children.Add(MakeHeading("General"));
        stack.Children.Add(MakeLead("Pathfinder's app-level preferences live here; study resources remain ordinary study tabs."));
        stack.Children.Add(MakeCard("Shell taxonomy",
            "Study resources open as study tabs. Search, Glossary and Journal are tool workspaces. My Study, Settings and Guide are app surfaces rather than closable study tabs. Study planning/time estimates live in My Study rather than occupying permanent top-bar space."));
        stack.Children.Add(MakePersonalStudySettingsCard());
        stack.Children.Add(MakeCard("Quick controls",
            "The top theme selector and Aa shortcut remain available for fast access. They use the same saved Settings preferences."));
        return WrapScrollableStack(stack);
    }

    private UIElement CreateAppearanceSettingsView()
    {
        var stack = new StackPanel { Spacing = 14, MaxWidth = 940, HorizontalAlignment = HorizontalAlignment.Left };
        stack.Children.Add(MakeHeading("Appearance"));
        stack.Children.Add(MakeLead("Choose the Pathfinder shell/theme presentation. The top-bar selector remains a quick shortcut to the same setting. Sixteen themes are available, including three additional OLED-focused variants for low-light study."));

        var cardStack = new StackPanel { Spacing = 10 };
        cardStack.Children.Add(new TextBlock
        {
            Text = "Display theme",
            FontSize = 17,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            IsTextSelectionEnabled = true
        });
        var combo = new ComboBox
        {
            ItemsSource = _themes.Registry.Themes,
            DisplayMemberPath = "Name",
            SelectedItem = SelectedTheme(),
            MinWidth = 240,
            MinHeight = 44,
            HorizontalAlignment = HorizontalAlignment.Left
        };
        combo.SelectionChanged += (_, _) =>
        {
            if (combo.SelectedItem is ThemeChoice choice)
                ThemeCombo.SelectedItem = choice;
        };
        cardStack.Children.Add(combo);
        cardStack.Children.Add(new TextBlock
        {
            Text = "Daytime comfort: Parchment, Glacier, Sage Day and Sunlit Apricot soften the reading field without sacrificing contrast. Evening comfort: Dark, Ocean, Forest, Amber, Aurora, Ember Glow and Twilight Bloom provide varied low-light options. OLED Black, OLED Pure, OLED Cyan and OLED Amber use near-black or true-black surfaces for OLED-friendly study. Windows High Contrast temporarily takes visual priority while active.",
            TextWrapping = TextWrapping.Wrap,
            Opacity = .70,
            IsTextSelectionEnabled = true
        });
        var card = new Border { Child = cardStack, Padding = new Thickness(16), CornerRadius = new CornerRadius(12), BorderThickness = new Thickness(1) };
        RegisterThemedSurface(card);
        stack.Children.Add(card);
        return WrapScrollableStack(stack);
    }

    private UIElement CreateSessionSettingsView()
    {
        var stack = new StackPanel { Spacing = 14, MaxWidth = 940, HorizontalAlignment = HorizontalAlignment.Left };
        stack.Children.Add(MakeHeading("Session & navigation"));
        stack.Children.Add(MakeLead("Control how Pathfinder resumes without changing medical content."));
        stack.Children.Add(MakeSessionRestoreCard());
        stack.Children.Add(MakeCard("One primary cockpit per resource",
            "Ordinary navigation reuses one primary interactive cockpit for each resource. Opening an already-open resource in a new tab creates a read-only reference view for study state. Split View can arrange these views beside a different interactive cockpit or a tool workspace."));
        stack.Children.Add(MakeCard("Saved locations",
            "Resume, bookmarks, Search source jumps and one-level Return use source-aware saved locations. Exact source targets do not fall back to guessed positions."));
        return WrapScrollableStack(stack);
    }

    private UIElement CreateWorkspaceSettingsView()
    {
        var stack = new StackPanel { Spacing = 14, MaxWidth = 940, HorizontalAlignment = HorizontalAlignment.Left };
        stack.Children.Add(MakeHeading("Workspace & Split View"));
        stack.Children.Add(MakeLead("Split View is a native two-pane Windows workspace with a deliberate, optional secondary slot."));
        stack.Children.Add(MakeCard("Static secondary workspace",
            "Opening Split View may leave the second pane empty. Show beside deliberately parks one open cockpit or tool there and hides that tab from the main tab strip while it is parked. Ordinary main-tab/library navigation never replaces or swaps the parked view. Return to tabs restores the exact same tab; ⇄ Swap is the deliberate way to exchange panes."));
        stack.Children.Add(MakeCard("What can go side-by-side",
            "Two different primary cockpits may both remain fully interactive (for example Cardiology + Renal). The same resource still has only one interactive primary; an additional same-resource cockpit is state-read-only. Search, Glossary, Journal and verified read-only source views can also participate. Exact read-only source previews restore as an empty secondary slot after restart rather than guessing a source location."));
        var restoreSplit = new CheckBox
        {
            Content = "Restore my Split View workspace when Pathfinder restarts",
            IsChecked = _settings.RestoreSplitWorkspace,
            MinHeight = 40
        };
        restoreSplit.Checked += (_, _) => { _settings.RestoreSplitWorkspace = true; QueuePersistenceFailureNotice(SaveCurrentSession(), "Split workspace preference"); };
        restoreSplit.Unchecked += (_, _) => { _settings.RestoreSplitWorkspace = false; QueuePersistenceFailureNotice(SaveCurrentSession(), "Split workspace preference"); };
        stack.Children.Add(restoreSplit);
        stack.Children.Add(MakeCard("Adaptive Surface behavior",
            "Drag the divider with mouse or touch to resize; double-click/tap the divider to reset to 50/50. Ctrl+Alt+S opens or closes Split View. At narrow portrait/window widths Pathfinder temporarily collapses to one pane without discarding the saved Split View assignment; the second pane returns automatically when width is available again."));
        return WrapScrollableStack(stack);
    }

    private UIElement CreateAboutSettingsView()
    {
        var stack = new StackPanel { Spacing = 14, MaxWidth = 940, HorizontalAlignment = HorizontalAlignment.Left };
        stack.Children.Add(MakeHeading("About & integrity"));
        stack.Children.Add(MakeLead("NivareQ Step 2 Pathfinder"));
        stack.Children.Add(MakeCard("Version", "1.2.2 S1 TEST — unaccepted Scratchpad candidate"));
        stack.Children.Add(MakeCard("Study library",
            "Pathfinder includes a curated Step 2 study library. Packaged study resources are integrity-checked as part of the release process."));
        stack.Children.Add(MakeCard("Windows data root", PathfinderPaths.AppDataRoot));
        stack.Children.Add(MakeCard("Publisher", "A NivareQ™ project."));
        return WrapScrollableStack(stack);
    }

    private UIElement CreateDataSettingsView()
    {
        var stack = new StackPanel { Spacing = 14, MaxWidth = 940, HorizontalAlignment = HorizontalAlignment.Left };
        stack.Children.Add(MakeHeading("Data, backup & reset"));
        stack.Children.Add(MakeLead("Pathfinder keeps a complete Windows backup of your saved study state. Destructive reset is never allowed without a fresh verified backup created in the same flow."));

        var actions = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        actions.Children.Add(MakeActionButton("Create backup", async (_, _) => await BackupPersonalDataAsync()));
        actions.Children.Add(MakeActionButton("Restore backup", async (_, _) => await RestorePersonalDataAsync()));
        actions.SizeChanged += (_, e) => actions.Orientation = e.NewSize.Width < 560 ? Orientation.Vertical : Orientation.Horizontal;
        stack.Children.Add(actions);

        stack.Children.Add(MakeCard("Backup compatibility",
            "Windows may contain richer native state than mobile or PWA versions. Supported fields transfer where possible, while additional Windows data is preserved rather than silently discarded."));

        var resetCardStack = new StackPanel { Spacing = 10 };
        resetCardStack.Children.Add(new TextBlock
        {
            Text = "Destructive reset",
            FontSize = 17,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            IsTextSelectionEnabled = true
        });
        resetCardStack.Children.Add(new TextBlock
        {
            Text = "Choose what you want to reset. Pathfinder first requires a new backup, reads it back, and verifies it before any destructive reset can run. If backup creation or verification fails or is cancelled, reset does not proceed.",
            FontSize = 14,
            Opacity = .78,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });
        resetCardStack.Children.Add(MakeActionButton("Reset Pathfinder data…", async (_, _) => await BeginDestructiveResetAsync()));
        var resetCard = new Border { Child = resetCardStack, Padding = new Thickness(16), CornerRadius = new CornerRadius(12), BorderThickness = new Thickness(1) };
        RegisterThemedSurface(resetCard);
        stack.Children.Add(resetCard);
        return WrapScrollableStack(stack);
    }

    private async Task BeginDestructiveResetAsync()
    {
        try
        {
            await BeginDestructiveResetCoreAsync();
        }
        catch (Exception ex)
        {
            await ShowPersonalMessageAsync("Reset could not start", "Pathfinder did not change any reset state. " + ex.Message);
        }
    }

    private async Task BeginDestructiveResetCoreAsync()
    {
        var scopePicker = new ComboBox { MinWidth = 420, MinHeight = 44, SelectedIndex = 0 };
        scopePicker.Items.Add("Session/view state only");
        scopePicker.Items.Add("Study/progress state");
        scopePicker.Items.Add("Personal My Study data");
        scopePicker.Items.Add("All Pathfinder user data");

        var explainer = new TextBlock
        {
            Text = "Session/view: open-tab/session records, recent subjects and saved resume positions.\n\nStudy/progress: manual subject progress, cockpit review/quiz/mode state, and UWorld Selector reported counts.\n\nPersonal My Study: favorites, recents, progress, bookmarks, positions and Journal notes.\n\nAll user data: settings + My Study + Journal + UWorld Selector + cockpit state + preserved cross-platform extension state. Installed app/study content and the WebView2 runtime/cache are not deleted.",
            TextWrapping = TextWrapping.Wrap,
            MaxWidth = 640,
            IsTextSelectionEnabled = true
        };
        var body = new StackPanel { Spacing = 10 };
        body.Children.Add(scopePicker);
        body.Children.Add(explainer);

        var choose = new ContentDialog
        {
            XamlRoot = RootGrid.XamlRoot,
            Title = "Choose reset scope",
            Content = body,
            PrimaryButtonText = "Continue to required backup",
            CloseButtonText = "Cancel",
            DefaultButton = ContentDialogButton.Close
        };
        if (await choose.ShowAsync() != ContentDialogResult.Primary) return;

        var scope = scopePicker.SelectedIndex;
        var backup = await CreateCanonicalBackupFileAsync(
            $"NivareQ-Step2-Pathfinder-PreReset-{DateTime.Now:yyyy-MM-dd-HHmmss}",
            verifyAfterWrite: true);
        if (backup.File is null)
        {
            await ShowPersonalMessageAsync("Reset cancelled", "No verified backup was created, so Pathfinder did not permit the destructive reset to continue.");
            return;
        }

        var confirm = new ContentDialog
        {
            XamlRoot = RootGrid.XamlRoot,
            Title = "Backup verified · reset now?",
            Content = new TextBlock
            {
                Text = $"Fresh backup verified:\n{backup.File.Path}\n\nReset scope: {scopePicker.SelectedItem}\n\nThis operation is destructive. The backup above is the recovery point.",
                TextWrapping = TextWrapping.Wrap,
                MaxWidth = 640,
                IsTextSelectionEnabled = true
            },
            PrimaryButtonText = "Reset now",
            CloseButtonText = "Cancel",
            DefaultButton = ContentDialogButton.Close
        };
        if (await confirm.ShowAsync() != ContentDialogResult.Primary) return;

        await ApplyDestructiveResetAsync(scope);
    }

    private async Task ApplyDestructiveResetAsync(int scope)
    {
        if (_cockpitState is null) throw new InvalidOperationException("Cockpit state provider is not initialized.");
        var nextSettings = CloneShellSettings(_settings);
        var nextPersonal = PersonalStudyService.Deserialize(PersonalStudyService.Serialize(_personal.State));
        var nextExtensions = BackupExtensionStore.Clone(_backupExtensions.State);
        var nextCockpitState = CockpitStateService.Clone(_cockpitState.State);
        var nextJournal = _journal.ExportState();
        var nextSelector = _uworldSelector.ExportState();

        switch (scope)
        {
            case 0: // session/view
                nextSettings.LastSessionTabs = [];
                nextSettings.LastSelectedTabIndex = 0;
                nextSettings.LastWorkspaceSplitEnabled = false;
                nextSettings.LastWorkspaceSecondaryKind = "";
                nextSettings.LastWorkspaceSecondaryId = "";
                nextSettings.LastWorkspaceSplitRatio = 0.5;
                nextPersonal.RecentSubjects.Clear();
                nextPersonal.PositionsBySlug.Clear();
                break;
            case 1: // study/progress
                nextPersonal.ProgressBySlug.Clear();
                nextSelector = UWorldSelectorService.NewState();
                nextPersonal.ShowProgress = false;
                nextCockpitState = new CockpitStateEnvelope();
                foreach (var resourceId in _cockpitStateRegistry.ResourceIds)
                {
                    var subject = _catalog.Resolve(resourceId);
                    if (subject is null) continue;
                    nextCockpitState.Resources[resourceId] = new CockpitResourceState
                    {
                        ResourceId = resourceId, SourceVersion = subject.ExpectedSha256.ToLowerInvariant(), UpdatedUtc = DateTimeOffset.UtcNow
                    };
                }
                break;
            case 2: // personal study + Journal
                nextPersonal = new PersonalStudyState();
                nextJournal = new JournalState();
                break;
            case 3: // full canonical user data
                nextSettings = new ShellSettings();
                nextSelector = UWorldSelectorService.NewState();
                nextPersonal = new PersonalStudyState();
                nextJournal = new JournalState();
                nextExtensions = new PreservedBackupExtensionState();
                nextCockpitState = new CockpitStateEnvelope();
                foreach (var resourceId in _cockpitStateRegistry.ResourceIds)
                {
                    var subject = _catalog.Resolve(resourceId);
                    if (subject is null) continue;
                    nextCockpitState.Resources[resourceId] = new CockpitResourceState
                    {
                        ResourceId = resourceId, SourceVersion = subject.ExpectedSha256.ToLowerInvariant(), UpdatedUtc = DateTimeOffset.UtcNow
                    };
                }
                break;
            default:
                throw new InvalidOperationException("Unknown reset scope.");
        }

        AdvanceRuntimeMutationEpoch("reset-commit");
        var previousDeferSession = _deferSessionSaveUntilRestart;
        var previousPositionSuspend = _suspendCockpitPositionPersistenceUntilRestart;
        var previousStateSuspend = _suspendCockpitStatePersistenceUntilRestart;
        _deferSessionSaveUntilRestart = true;
        _suspendCockpitPositionPersistenceUntilRestart = true;
        _suspendCockpitStatePersistenceUntilRestart = true;
        _personalSaveCts?.Cancel();
        _cockpitStateSaveCts?.Cancel();

        var commit = RestoreTransactionService.Commit(new Dictionary<string, string>
        {
            [PathfinderPaths.SettingsPath] = SettingsService.Serialize(nextSettings),
            [PathfinderPaths.PersonalStudyPath] = PersonalStudyService.Serialize(nextPersonal),
            [PathfinderPaths.BackupExtensionsPath] = _backupExtensions.Serialize(nextExtensions),
            [PathfinderPaths.CockpitStatePath] = _cockpitState.Serialize(nextCockpitState),
            [PathfinderPaths.JournalSnapshotPath] = JournalService.SerializeState(nextJournal),
            [PathfinderPaths.JournalLogPath] = JournalService.EmptyOperationLog,
            [PathfinderPaths.UWorldSelectorStatePath] = _uworldSelector.SerializeState(nextSelector)
        });
        if (!commit.Success)
        {
            if (!RestoreTransactionService.MutationsBlocked)
            {
                _deferSessionSaveUntilRestart = previousDeferSession;
                _suspendCockpitPositionPersistenceUntilRestart = previousPositionSuspend;
                _suspendCockpitStatePersistenceUntilRestart = previousStateSuspend;
            }
            var heading = RestoreTransactionService.MutationsBlocked ? "Reset stopped — recovery required" : "Reset failed safely";
            var body = RestoreTransactionService.MutationsBlocked
                ? "Pathfinder could not complete the reset and rollback was incomplete. Persistence is blocked so unresolved recovery evidence cannot be overwritten. Restart Pathfinder and use the preserved recovery/backup evidence.\n\n" + commit.Error
                : "Pathfinder could not transactionally commit the reset. The reset was rolled back; use the verified pre-reset backup if needed.\n\n" + commit.Error;
            await ShowPersonalMessageAsync(heading, body);
            return;
        }

        CopyShellSettings(nextSettings, _settings);
        _personal.ReplaceInMemory(nextPersonal);
        _backupExtensions.ReplaceInMemory(nextExtensions);
        _cockpitState.ReplaceInMemory(nextCockpitState);
        _journal.ReplaceInMemory(nextJournal);
        _journalEditorSession = null;
        _uworldSelector.ReplaceInMemory(nextSelector);
        RestoreTransactionService.BlockMutationsUntilRestart("A destructive reset completed successfully. Restart Pathfinder before making further study-state changes so pre-reset views cannot mutate the reset state.");
        _deferSessionSaveUntilRestart = true;
        _suspendCockpitPositionPersistenceUntilRestart = true;
        _suspendCockpitStatePersistenceUntilRestart = true;
        _personalSaveCts?.Cancel();

        SelectSavedTheme();
        await ApplyThemeToAllWebViewsAsync(SelectedTheme());
        RebuildSubjectGroups(SubjectSearchBox.Text);
        RefreshMyStudyTab();
        RefreshJournalWorkspace();
        RefreshUWorldSelectorWorkspace();

        await ShowPersonalMessageAsync(
            "Reset complete",
            "The selected Pathfinder data was reset after a fresh verified backup was created. Restart Pathfinder now to complete the reset cleanly.");
    }

    private void ShowStudyTimeFlyout(FrameworkElement anchor)
    {
        var host = new Grid
        {
            Width = Math.Min(720, Math.Max(480, RootGrid.ActualWidth * 0.55)),
            Height = Math.Min(720, Math.Max(420, RootGrid.ActualHeight * 0.72))
        };
        host.Children.Add(CreateStudyTimeView());
        var flyout = new Flyout
        {
            Content = host,
            Placement = Microsoft.UI.Xaml.Controls.Primitives.FlyoutPlacementMode.BottomEdgeAlignedRight
        };
        flyout.ShowAt(anchor);
    }
}
