using System.Text.Json;
using Microsoft.UI.Xaml.Controls;
using NivareQ.Step2Pathfinder.Models;

namespace NivareQ.Step2Pathfinder;

public sealed partial class MainWindow
{
    private async Task<SearchDestinationResolution?> ResolveSearchDestinationAsync(
        WebView2 webView,
        SubjectEntry subject,
        UniversalSearchResult result,
        Func<bool>? isCurrent = null)
    {
        if (webView.CoreWebView2 is null) return null;
        if (!result.SubjectSlug.Equals(subject.ResourceId, StringComparison.OrdinalIgnoreCase))
            return new SearchDestinationResolution { Found = false, Reason = "ownership" };
        if (!string.IsNullOrWhiteSpace(result.SourceVersion)
            && !result.SourceVersion.Equals(subject.ExpectedSha256, StringComparison.OrdinalIgnoreCase))
            return new SearchDestinationResolution { Found = false, Reason = "stale-source-version" };

        var script = SearchDestinationResolverTemplate
            .Replace("__NEEDLE__", JsonSerializer.Serialize(result.Needle))
            .Replace("__QUERY__", JsonSerializer.Serialize(result.Query))
            .Replace("__TERMS__", JsonSerializer.Serialize(result.HighlightTerms))
            .Replace("__CONTEXT_HINT__", JsonSerializer.Serialize(result.ContextHint))
            .Replace("__CONTEXT_BEFORE__", JsonSerializer.Serialize(result.ContextBefore))
            .Replace("__CONTEXT_AFTER__", JsonSerializer.Serialize(result.ContextAfter))
            .Replace("__OCCURRENCE__", result.SourceOccurrence.ToString())
            .Replace("__OCCURRENCE_COUNT__", Math.Max(1, result.SourceOccurrenceCount).ToString())
            .Replace("__EXACT__", result.IsExactPhrase ? "true" : "false")
            .Replace("__ALLOW_SEARCH_ASSIST__", subject.Number is >= 19 and <= 22 ? "false" : "true")
            .Replace("__SCHEMA_VERSION__", LocationSchemaVersion.ToString())
            .Replace("__RESOURCE_ID__", JsonSerializer.Serialize(subject.ResourceId))
            .Replace("__SOURCE_VERSION__", JsonSerializer.Serialize(subject.ExpectedSha256.ToLowerInvariant()))
            .Replace("__MAX_CONTEXT__", MaxLocationContext.ToString());

        for (var attempt = 0; attempt < 8; attempt++)
        {
            if (isCurrent is not null && !isCurrent()) return new SearchDestinationResolution { Found = false, Reason = "stale-request" };
            try
            {
                var raw = await webView.CoreWebView2.ExecuteScriptAsync(script);
                if (isCurrent is not null && !isCurrent()) return new SearchDestinationResolution { Found = false, Reason = "stale-request" };
                var json = JsonSerializer.Deserialize<string>(raw);
                if (!string.IsNullOrWhiteSpace(json))
                {
                    var resolved = JsonSerializer.Deserialize<SearchDestinationResolution>(json, LocationJsonOptions);
                    if (resolved?.Found == true) return resolved;
                    if (resolved is not null && !resolved.Reason.Equals("not-found", StringComparison.OrdinalIgnoreCase)) return resolved;
                }
            }
            catch
            {
                // Dynamic cockpit rendering can briefly race the first probe. The bounded retry
                // window below is deliberate; source identity is validated before every probe.
            }

            if (attempt < 7)
            {
                await Task.Delay(attempt < 2 ? 120 : 220);
                if (isCurrent is not null && !isCurrent()) return new SearchDestinationResolution { Found = false, Reason = "stale-request" };
            }
        }

        return new SearchDestinationResolution { Found = false, Reason = "not-found" };
    }

    private const string SearchDestinationResolverTemplate = """
        (() => {
          const normalize = s => (s || '')
            .normalize('NFD').replace(/[\u0300-\u036f]/g,'')
            .replace(/[\u2010-\u2015\-\/|]+/g,' ')
            .replace(/\u00a0/g,' ')
            .replace(/[^\p{L}\p{N}]+/gu,' ')
            .replace(/\s+/g,' ').trim().toLowerCase();

          const rawNeedle = __NEEDLE__;
          const rawQuery = __QUERY__;
          const rawTerms = __TERMS__;
          const rawContextHint = __CONTEXT_HINT__;
          const rawContextBefore = __CONTEXT_BEFORE__;
          const rawContextAfter = __CONTEXT_AFTER__;
          const sourceOccurrence = __OCCURRENCE__;
          const sourceOccurrenceCount = __OCCURRENCE_COUNT__;
          const exactRequested = __EXACT__;
          const allowSearchAssist = __ALLOW_SEARCH_ASSIST__;
          const schemaVersion = __SCHEMA_VERSION__;
          const resourceId = __RESOURCE_ID__;
          const sourceVersion = __SOURCE_VERSION__;
          const maxContext = __MAX_CONTEXT__;
          const needle = normalize(rawNeedle);
          const query = normalize(rawQuery);
          const contextHint = normalize(rawContextHint);
          const contextBefore = normalize(rawContextBefore);
          const contextAfter = normalize(rawContextAfter);
          const contextTerms = Array.from(new Set(contextHint.split(' ').filter(x => x.length >= 4))).slice(0,36);
          const terms = Array.from(new Set((rawTerms || []).map(normalize).filter(x => x.length >= 2)));
          const primary = needle || terms[0] || query;
          const hasWhole = (text, term) => !!term && (` ${text} `).includes(` ${term} `);
          const hasMatch = (text, term, requireWhole=false) => requireWhole ? hasWhole(text, term) : text.includes(term);
          if (!primary && terms.length === 0 && !query) return JSON.stringify({found:false, reason:'empty'});

          const internalSearch = document.querySelector(
            'input#search, input[type="search"], input[aria-label*="search" i], input[placeholder*="search" i], input[placeholder*="find" i]'
          );
          const excluded = el => !!el.closest('script,style,noscript,svg,template');
          const visible = el => {
            const style = getComputedStyle(el);
            return style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0' &&
              !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
          };
          const semanticSelector = [
            'article','section','details','summary','main','aside',
            '.topic','.card','.module','.panel','.box','.item','.result','.question','.pattern','.qcard','.source',
            '[data-topic]','[data-id]','[data-section]',
            'tr','li','blockquote','p','h1','h2','h3','h4','h5','h6','div'
          ].join(',');

          const score = el => {
            const text = normalize(el.textContent || '');
            if (!text) return null;
            const hasNeedle = !!primary && hasMatch(text, primary, exactRequested && primary===query);
            const hasQuery = !!query && hasMatch(text, query, exactRequested);
            const termHits = terms.reduce((n,t) => n + (hasWhole(text,t) ? 1 : 0), 0);
            const contextHits = contextTerms.reduce((n,t) => n + (text.includes(t) ? 1 : 0), 0);
            const hasAllTerms = terms.length > 0 && termHits === terms.length;
            if (!hasNeedle && !hasQuery && termHits === 0) return null;

            let value = 0;
            if (exactRequested && hasQuery) value += 200000;
            if (hasNeedle) value += 110000;
            if (hasAllTerms) value += 65000;
            value += termHits * 9000;
            value += Math.min(contextHits, 16) * 1800;
            if (contextHint && text.includes(contextHint)) value += 50000;
            if (visible(el)) value += 12000;
            const lengthPenalty = Math.min(text.length * 2, 60000);
            value -= lengthPenalty;
            if (el.matches('main,body')) value -= 90000;
            let depth = 0, node = el;
            while (node && node !== document.body && depth < 40) { depth++; node = node.parentElement; }
            value += depth * 20;
            if (el.matches('article,section,details,.topic,.card,.module,.panel,.box,[data-topic],[data-section],.qcard,.source')) value += 6500;
            if (el.matches('p,li,tr,blockquote,h1,h2,h3,h4,h5,h6,summary')) value += 1500;
            return {el, value, textLength:text.length, contextHits, text};
          };

          const rankCandidates = () => Array.from(document.querySelectorAll(semanticSelector))
            .filter(el => !excluded(el))
            .map(score).filter(Boolean)
            .sort((a,b) => b.value - a.value || b.contextHits - a.contextHits || a.textLength - b.textLength);

          const unitSelector = [
            'article','details','.topic','.card','.module','.panel','.box','.item','.result','.question','.pattern','.qcard','.source',
            '[data-topic]','[data-id]','[data-section]','tr','li','blockquote'
          ].join(',');

          const words = s => (s || '').split(' ').filter(Boolean);
          const grams = (items,n) => {
            const result = [];
            for (let i=0;i+n<=items.length;i++) result.push(items.slice(i,i+n).join(' '));
            return result;
          };
          const overlapCount = (left,right) => {
            if (!left.length || !right.length) return 0;
            const set = new Set(right);
            return left.reduce((n,x) => n + (set.has(x) ? 1 : 0), 0);
          };
          const alignmentScore = (domBefore,domAfter) => {
            const db = words(domBefore), da = words(domAfter);
            const sb = words(contextBefore), sa = words(contextAfter);
            const sbTail = sb.slice(-28), dbTail = db.slice(-34);
            const saHead = sa.slice(0,36), daHead = da.slice(0,44);
            let value = 0;
            value += overlapCount(grams(sbTail,3), grams(dbTail,3)) * 24;
            value += overlapCount(grams(saHead,3), grams(daHead,3)) * 24;
            value += overlapCount(grams(sbTail,2), grams(dbTail,2)) * 9;
            value += overlapCount(grams(saHead,2), grams(daHead,2)) * 9;
            value += overlapCount(Array.from(new Set(sbTail.filter(x => x.length >= 4))), Array.from(new Set(dbTail))) * 2;
            value += overlapCount(Array.from(new Set(saHead.filter(x => x.length >= 4))), Array.from(new Set(daHead))) * 2;
            let suffix = 0;
            for (let i=1;i<=Math.min(sbTail.length,dbTail.length,14);i++) {
              if (sbTail[sbTail.length-i] !== dbTail[dbTail.length-i]) break;
              suffix++;
            }
            let prefix = 0;
            for (let i=0;i<Math.min(saHead.length,daHead.length,14);i++) {
              if (saHead[i] !== daHead[i]) break;
              prefix++;
            }
            value += (suffix + prefix) * 18;
            return value;
          };
          const findWholeOccurrences = (text,term) => {
            const found = [];
            if (!text || !term) return found;
            let at = 0;
            while (at < text.length && found.length < 64) {
              const index = text.indexOf(term,at);
              if (index < 0) break;
              const end = index + term.length;
              if ((index === 0 || text[index-1] === ' ') && (end >= text.length || text[end] === ' ')) found.push(index);
              at = index + Math.max(1,term.length);
            }
            return found;
          };
          const commonAncestor = (left,right) => {
            if (!left) return right;
            if (!right) return left;
            const seen = new Set();
            for (let n=left;n;n=n.parentElement) seen.add(n);
            for (let n=right;n;n=n.parentElement) if (seen.has(n)) return n;
            return left;
          };
          const renderedTextMap = () => {
            const walker = document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,{
              acceptNode(node) {
                const parent = node.parentElement;
                if (!parent || excluded(parent)) return NodeFilter.FILTER_REJECT;
                return normalize(node.nodeValue || '') ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
              }
            });
            let text = '';
            const spans = [];
            let node;
            while ((node = walker.nextNode())) {
              const value = normalize(node.nodeValue || '');
              if (!value) continue;
              if (text) text += ' ';
              const start = text.length;
              text += value;
              spans.push({start,end:text.length,el:node.parentElement});
            }
            const elementForRange = (start,end) => {
              const hits = spans.filter(x => x.end > start && x.start < end);
              if (!hits.length) return null;
              let el = hits[0].el;
              for (const hit of hits.slice(1)) el = commonAncestor(el,hit.el);
              return el;
            };
            return {text,elementForRange};
          };
          const chooseExactTarget = items => {
            if (!exactRequested || !query) return {target:items[0]?.el || null, ambiguous:false};
            const rendered = renderedTextMap();
            const positions = findWholeOccurrences(rendered.text,query);
            if (!positions.length) return {target:null, ambiguous:false};
            const candidates = positions.map((index,domOccurrence) => {
              const leaf = rendered.elementForRange(index,index + query.length);
              if (!leaf) return null;
              const before = rendered.text.slice(Math.max(0,index-220),index);
              const after = rendered.text.slice(index + query.length,Math.min(rendered.text.length,index + query.length + 340));
              const unit = leaf.closest?.(unitSelector) || leaf;
              const inside = items.filter(c => c.el === unit || unit.contains(c.el));
              const target = inside[0]?.el || unit || leaf;
              return {target,unit,alignment:alignmentScore(before,after),domOccurrence};
            }).filter(Boolean).sort((a,b) => b.alignment - a.alignment || a.domOccurrence - b.domOccurrence);
            if (!candidates.length) return {target:null, ambiguous:false};
            if (candidates.length === 1) return {target:candidates[0].target, ambiguous:false};
            const top = candidates[0], second = candidates[1];
            if (top.unit === second.unit) return {target:top.target, ambiguous:false};
            const lead = top.alignment - second.alignment;
            if ((top.alignment >= 12 && lead >= 8) || (top.alignment >= 45 && lead >= 4))
              return {target:top.target, ambiguous:false};
            return {target:null, ambiguous:true};
          };

          let ranked = rankCandidates();
          let choice = chooseExactTarget(ranked);
          if (choice.ambiguous) return JSON.stringify({found:false, reason:'ambiguous-occurrence', sourceOccurrence, sourceOccurrenceCount});
          let target = choice.target;

          if (!target) {
            const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
              acceptNode(node) {
                const parent = node.parentElement;
                if (!parent || excluded(parent)) return NodeFilter.FILTER_REJECT;
                const t = normalize(node.nodeValue || '');
                const ok = (primary && hasMatch(t,primary,exactRequested && primary===query)) || (query && hasMatch(t,query,exactRequested)) || terms.some(x => hasWhole(t,x));
                return ok ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
              }
            });
            const node = walker.nextNode();
            target = node?.parentElement || null;
          }

          // Search assist is a bounded fallback only. W2C R2 explicitly disables it for
          // resources 19-22 because their native search field filters away the rest of the
          // cockpit; source navigation must reveal/scroll/highlight without changing mode.
          if (!target && allowSearchAssist && internalSearch) {
            const searchValue = exactRequested && query ? rawQuery : (rawNeedle || rawQuery);
            if (searchValue && internalSearch.value !== searchValue) {
              internalSearch.value = searchValue;
              internalSearch.dispatchEvent(new Event('input', {bubbles:true}));
              internalSearch.dispatchEvent(new Event('change', {bubbles:true}));
            }
            ranked = rankCandidates();
            choice = chooseExactTarget(ranked);
            if (choice.ambiguous) return JSON.stringify({found:false, reason:'ambiguous-occurrence', sourceOccurrence, sourceOccurrenceCount});
            target = choice.target;
          }

          if (!target) return JSON.stringify({found:false, reason:'not-found'});

          let ancestor = target.parentElement;
          while (ancestor) {
            if (ancestor.tagName === 'DETAILS' && !ancestor.open) ancestor.open = true;
            ancestor = ancestor.parentElement;
          }
          if (target.tagName === 'DETAILS' && !target.open) target.open = true;

          target.scrollIntoView({block:'center', inline:'nearest', behavior:'auto'});
          const oldOutline = target.style.outline;
          const oldOffset = target.style.outlineOffset;
          const oldTransition = target.style.transition;
          target.style.transition = 'outline-color .15s ease';
          target.style.outline = '3px solid var(--accent, Highlight)';
          target.style.outlineOffset = '5px';
          setTimeout(() => {
            target.style.outline = oldOutline;
            target.style.outlineOffset = oldOffset;
            target.style.transition = oldTransition;
          }, 2600);

          const pathFor = (a,t) => {
            if (!a || !t) return '';
            if (a === t) return '.';
            const parts = [];
            let n = t;
            while (n && n !== a && parts.length < 80) {
              const p = n.parentElement;
              if (!p) return '';
              const children = [...p.children], idx = children.indexOf(n);
              if (idx < 0) return '';
              parts.unshift(`${String(n.tagName || '').toLowerCase()}:${idx}`);
              n = p;
            }
            return n === a ? parts.join('/').slice(0,1400) : '';
          };
          let anchor = target;
          while (anchor && anchor !== document.body && !anchor.id) anchor = anchor.parentElement;
          if (!anchor) anchor = document.body;
          const anchorTop = (anchor.getBoundingClientRect?.().top || 0) + scrollY;
          const targetTop = (target.getBoundingClientRect?.().top || 0) + scrollY;
          const details = [];
          let detailNode = target;
          while (detailNode && detailNode !== document.body) {
            if (detailNode.tagName === 'DETAILS' && detailNode.open && detailNode.id) details.push(detailNode.id);
            detailNode = detailNode.parentElement;
          }
          const location = {
            schemaVersion,
            resourceId,
            sourceVersion,
            purpose:'source',
            anchor:anchor.id || '',
            targetId:target.id || '',
            targetPath:pathFor(anchor,target),
            context:normalize(target.textContent || '').slice(0,maxContext),
            offsetY:scrollY-anchorTop,
            targetOffsetY:scrollY-targetTop,
            hash:window.location.hash || '',
            scrollX:scrollX || 0,
            scrollY:scrollY || 0,
            openDetails:details.slice(0,30),
            updatedUtc:new Date().toISOString()
          };
          return JSON.stringify({found:true, reason:'resolved', sourceOccurrence, tag:target.tagName, text:(target.textContent || '').trim().slice(0,180), location});
        })();
        """;

    private sealed class SearchDestinationResolution
    {
        public bool Found { get; set; }
        public string Reason { get; set; } = "";
        public string Tag { get; set; } = "";
        public string Text { get; set; } = "";
        public StudyLocationState? Location { get; set; }
    }
}
