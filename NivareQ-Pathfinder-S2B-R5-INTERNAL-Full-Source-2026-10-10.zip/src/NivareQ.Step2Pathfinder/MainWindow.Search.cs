using System.Text.Json;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Documents;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using NivareQ.Step2Pathfinder.Models;
using NivareQ.Step2Pathfinder.Services;

namespace NivareQ.Step2Pathfinder;

public sealed partial class MainWindow
{
    private TextBox? _universalSearchBox;
    private StackPanel? _universalSearchResults;
    private TextBlock? _universalSearchStatus;

    private UIElement CreateUniversalSearchView()
    {
        EnsureUniversalSearchIndex();

        var stack = new StackPanel
        {
            Spacing = 14,
            MaxWidth = 1120,
            HorizontalAlignment = HorizontalAlignment.Left
        };
        stack.Children.Add(MakeHeading("Search all cockpits"));
        stack.Children.Add(MakeLead("Find a concept across the full Step 2 study library. Exact phrases rank first; normalized spelling/punctuation and curated medical aliases work without fuzzy guessing."));

        var box = new TextBox
        {
            PlaceholderText = "Search a diagnosis, abbreviation, finding, treatment, mechanism…",
            MinWidth = 420,
            MaxWidth = 900,
            Height = 44,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            IsSpellCheckEnabled = true
        };
        _universalSearchBox = box;

        var actions = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        actions.Children.Add(MakeActionButton("Open medical glossary", (_, _) => OpenGlossary(box.Text.Trim())));
        stack.Children.Add(actions);

        var status = new TextBlock
        {
            Text = $"Ready · {_universalSearch.DocumentCount} study cockpits · {_glossary.Count} glossary entries · {_uworldSelector.Recipes.Count} UWorld Selector recipes",
            FontSize = 12,
            Opacity = .68,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        };
        _universalSearchStatus = status;

        var results = new StackPanel { Spacing = 10 };
        _universalSearchResults = results;

        box.TextChanged += (_, _) => RefreshUniversalSearchResults(box.Text, results, status);
        stack.Children.Add(box);
        stack.Children.Add(status);
        stack.Children.Add(results);

        var view = WrapScrollableStack(stack);
        view.Loaded += (_, _) => box.Focus(FocusState.Programmatic);
        return view;
    }

    private void EnsureUniversalSearchIndex()
    {
        if (_universalSearch.IsBuilt) return;
        _universalSearch.Build(_catalog.Entries, _glossary);
    }

    private void RefreshUniversalSearchResults(string query, StackPanel results, TextBlock status)
    {
        results.Children.Clear();
        var trimmed = query.Trim();
        if (trimmed.Length < 2)
        {
            status.Text = $"Type at least 2 characters · {_universalSearch.DocumentCount} study cockpits · {_glossary.Count} glossary entries · {_uworldSelector.Recipes.Count} UWorld Selector recipes";
            return;
        }

        IReadOnlyList<UniversalSearchResult> matches;
        IReadOnlyList<GlossaryEntry> glossaryMatches;
        IReadOnlyList<UWorldSelectorRecipe> selectorMatches;
        try
        {
            matches = _universalSearch.Search(trimmed, 50);
            glossaryMatches = _glossary.Search(trimmed, 12);
            selectorMatches = _uworldSelector.Search(trimmed, "").Take(12).ToList();
        }
        catch (Exception ex)
        {
            status.Text = "Search could not be completed: " + ex.Message;
            return;
        }

        var exact = matches.Where(x => x.IsExactPhrase).ToList();
        var other = matches.Where(x => !x.IsExactPhrase).ToList();
        if (matches.Count == 0 && glossaryMatches.Count == 0 && selectorMatches.Count == 0)
        {
            status.Text = "No matching cockpit, glossary entry, or UWorld Selector recipe found. Windows proofing remains available from the search box for spelling suggestions.";
            return;
        }

        var statusParts = new List<string>();
        var matchingCockpits = matches.Select(x => x.SubjectSlug).Distinct(StringComparer.OrdinalIgnoreCase).Count();
        if (matchingCockpits > 0) statusParts.Add($"{matchingCockpits} matching cockpit{(matchingCockpits == 1 ? "" : "s")}");
        if (exact.Count > 0) statusParts.Add($"{exact.Count} exact source match{(exact.Count == 1 ? "" : "es")}");
        if (glossaryMatches.Count > 0) statusParts.Add($"{glossaryMatches.Count} glossary match{(glossaryMatches.Count == 1 ? "" : "es")}");
        if (selectorMatches.Count > 0) statusParts.Add($"{selectorMatches.Count} Selector recipe match{(selectorMatches.Count == 1 ? "" : "es")}");
        status.Text = string.Join(" · ", statusParts);
        if (matches.Count == 0 && glossaryMatches.Count > 0 && selectorMatches.Count == 0)
            status.Text += " · Tip: continue typing the full glossary term, or search its abbreviation, to find relevant cockpit locations.";

        if (exact.Count > 0)
        {
            results.Children.Add(MakeSearchSectionHeading("Exact match"));
            foreach (var result in exact)
                results.Children.Add(MakeUniversalSearchResultCard(result));
        }

        if (glossaryMatches.Count > 0)
        {
            results.Children.Add(MakeSearchSectionHeading("Medical glossary"));
            foreach (var entry in glossaryMatches)
                results.Children.Add(MakeGlossarySearchCard(entry, trimmed));
        }

        if (selectorMatches.Count > 0)
        {
            results.Children.Add(MakeSearchSectionHeading("UWorld Selector"));
            foreach (var recipe in selectorMatches)
                results.Children.Add(MakeUWorldSelectorSearchCard(recipe));
        }

        if (other.Count > 0)
        {
            results.Children.Add(MakeSearchSectionHeading(exact.Count > 0 ? "Other matches" : "Cockpit matches"));
            foreach (var result in other)
                results.Children.Add(MakeUniversalSearchResultCard(result));
        }
    }

    private static TextBlock MakeSearchSectionHeading(string text) => new()
    {
        Text = text,
        FontSize = 14,
        FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
        Opacity = .78,
        Margin = new Thickness(2, 6, 0, 0),
        IsTextSelectionEnabled = true
    };

    private Border MakeUniversalSearchResultCard(UniversalSearchResult result)
    {
        var stack = new StackPanel { Spacing = 7 };
        var title = new TextBlock
        {
            Text = result.SubjectNumber >= 0 ? $"{result.SubjectNumber:00}  {result.SubjectTitle}" : result.SubjectTitle,
            FontSize = 17,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        };
        ApplyTextHighlights(title, result.HighlightTerms, result.IsExactPhrase);
        stack.Children.Add(title);
        if (result.MatchedByAlias && !string.IsNullOrWhiteSpace(result.AliasLabel))
        {
            stack.Children.Add(new TextBlock
            {
                Text = $"Matched glossary alias: {result.AliasLabel}",
                FontSize = 11.5,
                Opacity = .68,
                TextWrapping = TextWrapping.Wrap,
                IsTextSelectionEnabled = true
            });
        }
        stack.Children.Add(MakeHighlightedText(result.Snippet, result.HighlightTerms, result.IsExactPhrase));
        var actions = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        actions.Children.Add(MakeActionButton("Preview source", async (_, _) => await PreviewUniversalSearchResultAsync(result)));
        actions.Children.Add(MakeActionButton("Go to cockpit", async (_, _) => await GoToUniversalSearchResultAsync(result)));
        stack.Children.Add(actions);

        var card = new Border
        {
            Child = stack,
            Padding = new Thickness(14),
            CornerRadius = new CornerRadius(12),
            BorderThickness = new Thickness(1)
        };
        RegisterThemedSurface(card);
        return card;
    }

    private Border MakeGlossarySearchCard(GlossaryEntry entry, string query)
    {
        var stack = new StackPanel { Spacing = 6 };
        var line = new TextBlock
        {
            Text = entry.DisplayLine,
            FontSize = 16,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            TextWrapping = TextWrapping.Wrap,
            MaxWidth = 980,
            IsTextSelectionEnabled = true
        };
        ApplyTextHighlights(line, [query, entry.Term]);
        stack.Children.Add(line);
        if (!string.IsNullOrWhiteSpace(entry.Note))
            stack.Children.Add(new TextBlock { Text = entry.Note, FontSize = 12, Opacity = .72, TextWrapping = TextWrapping.Wrap, IsTextSelectionEnabled = true });
        stack.Children.Add(MakeActionButton("Open glossary entry", (_, _) => OpenGlossary(entry.Term)));
        var card = new Border { Child = stack, Padding = new Thickness(12), CornerRadius = new CornerRadius(10), BorderThickness = new Thickness(1) };
        RegisterThemedSurface(card);
        return card;
    }

    private TextBlock MakeHighlightedText(string text, IEnumerable<string> terms, bool wholeTermsOnly = false)
    {
        var block = new TextBlock
        {
            Text = text,
            FontSize = 13,
            Opacity = .86,
            TextWrapping = TextWrapping.Wrap,
            MaxWidth = 980,
            IsTextSelectionEnabled = true
        };
        ApplyTextHighlights(block, terms, wholeTermsOnly);
        return block;
    }

    private void ApplyTextHighlights(TextBlock block, IEnumerable<string> terms, bool wholeTermsOnly = false)
    {
        var ranges = SearchNormalization.FindDisplayRanges(block.Text, terms, wholeTermsOnly);
        if (ranges.Count == 0) return;

        var highlighter = new TextHighlighter();
        if (_shellResourceBrushes.TryGetValue("AccentFillColorDefaultBrush", out var accentBrush))
            highlighter.Background = accentBrush;
        if (_shellResourceBrushes.TryGetValue("TextFillColorPrimaryBrush", out var fgBrush))
            highlighter.Foreground = fgBrush;
        foreach (var range in ranges)
            highlighter.Ranges.Add(new TextRange { StartIndex = range.Start, Length = range.Length });
        block.TextHighlighters.Add(highlighter);
    }

    private async Task GoToUniversalSearchResultAsync(UniversalSearchResult result)
    {
        var subject = _catalog.Entries.FirstOrDefault(x => x.ResourceId.Equals(result.SubjectSlug, StringComparison.OrdinalIgnoreCase));
        if (subject is null) return;

        var existing = FindPrimaryStudyContext(subject.ResourceId);
        if (existing is null)
        {
            // First-open source jumps should be reversible when this cockpit already has
            // a canonical saved resume position. Pass that resume point separately from
            // the search destination; WebNavigationCompleted arms the one-level Return
            // only after the strict source jump succeeds.
            var savedResume = CloneLocation(_personal.PositionFor(subject.ResourceId));
            await CreateStudyTabAsync(subject, false, savedResume, result);
            return;
        }

        var previousLocation = await CapturePositionAsync(existing);
        var previousView = await CaptureTemporaryCockpitViewAsync(existing);
        Tabs.SelectedItem = existing.Tab;
        // Source navigation always starts from the full cockpit. This is especially
        // important for resources 19-22, whose native search box hides non-matching
        // cards. The previous filter is retained in previousView for one-level Return.
        await ClearCockpitSearchFilterAsync(existing);
        var request = BeginLocationRequest(existing, "search-go-to-cockpit");
        if (!await JumpToSearchResultAsync(existing, result, request))
        {
            await RestoreTemporaryCockpitViewAsync(existing, previousView);
            if (previousLocation is not null)
            {
                await Task.Delay(120);
                var rollbackRequest = BeginLocationRequest(existing, "search-jump-rollback");
                await ApplyPathfinderLocationAsync(existing, previousLocation, rollbackRequest, persistResume: true);
            }
            await ShowPersonalMessageAsync("Source could not be opened", "Pathfinder could not resolve this search result against the verified cockpit source. Your previous study view was restored.");
            return;
        }

        if (previousLocation is not null)
            ArmSourceJumpReturn(existing, previousLocation, previousView);
    }

    private async Task<bool> JumpToSearchResultAsync(StudyTabContext context, UniversalSearchResult result, long request)
    {
        if (context.WebView.CoreWebView2 is null || !IsLocationRequestCurrent(context, request)) return false;
        context.CaptureAuthorityReady = false;
        var resolved = await ResolveSearchDestinationAsync(
            context.WebView,
            context.Subject,
            result,
            () => IsLocationRequestCurrent(context, request));
        if (!IsLocationRequestCurrent(context, request))
        {
            context.CaptureAuthorityReady = true;
            return false;
        }

        if (resolved?.Found != true)
        {
            LogStudyEvent(context, "search-source-rejected", resolved?.Reason ?? "not-found");
            context.CaptureAuthorityReady = true;
            return false;
        }

        context.CaptureAuthorityReady = true;
        await CapturePositionAsync(context);
        return true;
    }

    private void UniversalSearchButton_Click(object sender, RoutedEventArgs e)
    {
        OpenSpecialTabSafe("Search", CreateUniversalSearchView);
        _universalSearchBox?.Focus(FocusState.Programmatic);
    }

    private void OpenUniversalSearchFor(string query)
    {
        var value = (query ?? "").Trim();
        if (value.Length == 0) return;
        OpenSpecialTabSafe("Search", CreateUniversalSearchView);
        if (_universalSearchBox is null) return;
        _universalSearchBox.Text = value;
        // Programmatic prefill can occur immediately after a Search tab is created/selected,
        // before WinUI has delivered the TextChanged refresh. Render results explicitly so the
        // user never sees a populated query with a stale "Ready"/empty result surface.
        if (_universalSearchResults is not null && _universalSearchStatus is not null)
            RefreshUniversalSearchResults(value, _universalSearchResults, _universalSearchStatus);
        _universalSearchBox.Focus(FocusState.Programmatic);
        _universalSearchBox.SelectAll();
    }

    private async Task SearchCockpitSelectionAsync(StudyTabContext context, string fallbackSelection)
    {
        var selected = await CaptureLiveSelectionTextAsync(context, fallbackSelection);
        if (selected.Length == 0) return;
        OpenUniversalSearchFor(selected);
    }

    private async Task SearchCockpitSelectionSnapshotAsync(StudyTabContext context, string fallbackSelection, Task<string>? contextSelectionSnapshot)
    {
        var selected = fallbackSelection;
        if (contextSelectionSnapshot is not null)
        {
            try
            {
                var snap = await contextSelectionSnapshot;
                if (!string.IsNullOrWhiteSpace(snap)) selected = snap;
            }
            catch { }
        }
        if (selected.Length == 0) selected = await CaptureLiveSelectionTextAsync(context, fallbackSelection);
        if (selected.Length == 0) return;
        if (selected.Length > 12000) selected = selected[..12000];
        OpenUniversalSearchFor(selected);
    }

    private void SearchAccelerator_Invoked(KeyboardAccelerator sender, KeyboardAcceleratorInvokedEventArgs args)
    {
        UniversalSearchButton_Click(this, new RoutedEventArgs());
        args.Handled = true;
    }
}
