/* S2-B R5 INTERNAL / NOT LIVE: the U1 staging page draft and save/ACK contract.
 * Native wire cells use {text,strokesJson}, not the S1 editor's {text,strokes}.
 * A dropped ACK is ambiguous: recover by a verified native read, not a blind write.
 */
(function (root, factory) {
  'use strict';
  const Coordinator = factory();
  if (typeof module === 'object' && module.exports) module.exports = Coordinator;
  else root.NivareQNotesDraftCoordinator = Coordinator;
})(typeof globalThis === 'object' ? globalThis : this, function () {
  'use strict';
  const protocol = 'nivareq.notes.page-save.v1';
  function copy(value) { return JSON.parse(JSON.stringify(value)); }
  function nonempty(value) { return typeof value === 'string' && value.length > 0 && value.length <= 160; }
  function revision(value) { return Number.isSafeInteger(value) && value >= 0; }
  function snapshot(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value) ||
        !['blank','ruled','triple'].includes(value.guide) ||
        !Number.isInteger(value.spacing) || value.spacing < 20 || value.spacing > 100 ||
        !Array.isArray(value.cells) || ![1,2,4].includes(value.cells.length) ||
        !Array.isArray(value.images || []))
      throw new TypeError('Invalid page snapshot.');
    const cells = value.cells.map(cell => {
      if (!cell || typeof cell.text !== 'string' || cell.text.length > 120000)
        throw new TypeError('Invalid writing-space text.');
      let strokesJson;
      if (Array.isArray(cell.strokes)) strokesJson = JSON.stringify(cell.strokes);
      else if (typeof cell.strokesJson === 'string') strokesJson = cell.strokesJson;
      else throw new TypeError('Missing strokes on Notes page.');
      let strokes;
      try { strokes = JSON.parse(strokesJson); } catch (_) { throw new TypeError('Invalid ink JSON.'); }
      if (!Array.isArray(strokes) || strokes.length > 25000)
        throw new TypeError('Invalid ink collection.');
      // The native store performs the authoritative per-stroke validation.
      return {text:cell.text, strokesJson:JSON.stringify(strokes)};
    });
    const images = value.images || [];
    if (images.length > 2000 || !images.every(im => im && nonempty(im.id) && im.id.length <= 100 &&
        Number.isInteger(im.cellIndex) && im.cellIndex >= 0 && im.cellIndex < cells.length &&
        typeof im.sha256 === 'string' && /^[0-9a-f]{64}$/.test(im.sha256) &&
        ['x','y','width','height'].every(k => typeof im[k] === 'number' && Number.isFinite(im[k]) &&
          im[k] >= (k === 'width' || k === 'height' ? Number.EPSILON : 0) && im[k] <= 1) &&
        im.x + im.width <= 1.000001 && im.y + im.height <= 1.000001 &&
        Number.isInteger(im.zIndex) && im.zIndex >= -10000 && im.zIndex <= 10000))
      throw new TypeError('Invalid image reference.');
    // Match native ReadPage's stable ORDER BY z_index,id, including DTO key order.
    // An ACK must not be rejected solely because callers supplied equal images
    // in a different array or property-insertion order.
    const canonicalImages = images.map(im => ({id:im.id,cellIndex:im.cellIndex,
      sha256:im.sha256,x:im.x,y:im.y,width:im.width,height:im.height,zIndex:im.zIndex}));
    canonicalImages.sort((a,b) => a.zIndex - b.zIndex || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
    return copy({guide:value.guide, spacing:value.spacing, cells, images:canonicalImages});
  }
  function matchesPage(a,b) { return JSON.stringify(snapshot(a)) === JSON.stringify(snapshot(b)); }
  class NotesDraftCoordinator {
    constructor({write, probe = null, release = null, onStatus = () => {}}) {
      if (typeof write !== 'function' || (probe !== null && typeof probe !== 'function') ||
          (release !== null && typeof release !== 'function') || typeof onStatus !== 'function')
        throw new TypeError('The Notes page transport and status callback are required.');
      this._write = write;
      this._probe = probe;
      this._release = release;
      this._onStatus = onStatus;
      this._current = null;
      this._navigationInProgress = false;
    }
    get status() {
      const c = this._current;
      return c ? Object.freeze({noteId:c.noteId, pageId:c.pageId, revision:c.revision,
        pending:c.dirtySequence !== c.savedSequence || !!c.inflight || !!c.uncertain || !!c.releasing,
        inflight:!!c.inflight, transitioning:!!c.releasing, needsReconciliation:!!c.uncertain,
        error:c.error ? String(c.error.message || c.error) : null}) : null;
    }
    get draft() { return this._current ? copy(this._current.draft) : null; }
    _emit() {
      try { this._onStatus(this.status); } catch (_) { /* UI repaint must not mutate ACK truth */ }
    }
    _prepare({sessionId,noteId,pageId,persistedRevision,page}) {
      if (![sessionId,noteId,pageId].every(nonempty) || !revision(persistedRevision))
        throw new TypeError('Invalid native page-session authority.');
      return {sessionId,noteId,pageId,revision:persistedRevision,
        dirtySequence:0,savedSequence:0,draft:snapshot(page),inflight:null,error:null,uncertain:null,releasing:false};
    }
    open(session) {
      if (this._current)
        throw new Error('Notes page already open; use the ACK-and-release switching gate.');
      this._current = this._prepare(session);
      this._emit();
    }
    edit(page) {
      const c = this._current;
      if (!c) throw new Error('No Notes page is open.');
      if (c.releasing) throw new Error('Notes editor is frozen during native session release; edit was not accepted.');
      c.draft = snapshot(page);
      c.dirtySequence++;
      this._emit();
    }
    async _reconcile(c) {
      const failed = c.uncertain;
      if (!failed) return;
      if (!this._probe)
        throw new Error('Notes save outcome is unknown; a verified native read is required before retry.');
      const probe = await this._probe({protocol,sessionId:failed.sessionId,
        noteId:failed.noteId,pageId:failed.pageId});
      if (!probe || probe.protocol !== protocol || probe.sessionId !== failed.sessionId ||
          probe.noteId !== failed.noteId || probe.pageId !== failed.pageId ||
          !revision(probe.persistedRevision))
        throw new Error('Native Notes recovery read did not match the page authority.');
      if (probe.persistedRevision === failed.expectedRevision + 1) {
        if (!matchesPage(probe.page,failed.page))
          throw new Error('Notes save conflict: the committed page differs; manual recovery is required.');
        c.revision = probe.persistedRevision;
        c.savedSequence = failed.sequence;
        c.uncertain = null;
        c.error = null;
      } else if (probe.persistedRevision === failed.expectedRevision) {
        // Failed before commit. The newer draft may now be written under the old CAS.
        c.uncertain = null;
        c.error = null;
      } else {
        throw new Error('Notes recovery revision conflict; draft retained for manual review.');
      }
      this._emit();
    }
    async flush({retry=false} = {}) {
      const c = this._current;
      if (!c) throw new Error('No Notes page is open.');
      if (c.releasing) throw new Error('Notes page is being released; no new save may start.');
      if (c.error && !retry) throw c.error;
      if (c.inflight) await c.inflight;
      if (retry && c.uncertain) {
        try { await this._reconcile(c); }
        catch (error) { c.error = error; this._emit(); throw error; }
      }
      if (retry && !c.uncertain) c.error = null;
      while (c.savedSequence < c.dirtySequence || c.inflight || c.uncertain) {
        if (c.error) throw c.error;
        if (c.uncertain) throw new Error('Notes recovery required before writing.');
        if (c.inflight) { await c.inflight; continue; }
        const seq = c.dirtySequence;
        const packet = Object.freeze({protocol, sessionId:c.sessionId,sequence:seq,
          noteId:c.noteId,pageId:c.pageId,expectedRevision:c.revision,page:copy(c.draft)});
        const work = Promise.resolve().then(() => this._write(packet)).then(ack => {
          if (this._current !== c || !ack || ack.protocol !== protocol ||
              ack.sessionId !== packet.sessionId || ack.sequence !== packet.sequence ||
              ack.noteId !== packet.noteId || ack.pageId !== packet.pageId ||
              !revision(ack.persistedRevision) || ack.persistedRevision !== packet.expectedRevision + 1)
            throw new Error('Notes save acknowledgement did not match the pending page write.');
          c.revision = ack.persistedRevision;
          c.savedSequence = seq;
          c.error = null;
          c.uncertain = null;
          this._emit();
        }).catch(error => {
          c.error = error instanceof Error ? error : new Error(String(error));
          // Fail-closed even if a native write MAY have committed. All uncertain
          // outcomes require read/compare, including a malformed ACK.
          c.uncertain = packet;
          this._emit();
          throw c.error;
        });
        c.inflight = work;
        this._emit();
        try { await work; }
        finally { if (c.inflight === work) c.inflight = null; this._emit(); }
      }
      return true;
    }
    async _releaseCurrent(c) {
      if (!this._release)
        throw new Error('Native Notes session-release acknowledgement is required before navigation.');
      await this._release({protocol,sessionId:c.sessionId,noteId:c.noteId,pageId:c.pageId,
        lastAcknowledgedSequence:c.savedSequence,lastAcknowledgedRevision:c.revision});
    }
    // Transition fence: a user edit arriving after the final flush but while
    // release is awaiting the native ACK must NEVER be silently dropped.
    // During release the editor is frozen and the UI must disable input until
    // a confirmed release or a fail-closed return to the current page.
    async _transition(next, isClose) {
      const c = this._current;
      if (!c) {
        if (isClose) return;
        throw new Error('No Notes page is open.');
      }
      if (this._navigationInProgress)
        throw new Error('Another Notes navigation is already in progress.');
      this._navigationInProgress = true;
      try {
        // Edits are still allowed while saves are in flight. If another edit
        // lands between final flush and this continuation, retry the flush.
        while (true) {
          await this.flush();
          if (this._current !== c) throw new Error('Notes page ownership changed during navigation.');
          if (c.dirtySequence !== c.savedSequence || c.inflight || c.uncertain)
            continue;
          c.releasing = true; // synchronous fence before the first release await
          this._emit();
          try {
            await this._releaseCurrent(c);
          } catch (error) {
            // Failed or uncertain release preserves the entire current draft.
            // It is not permission to open the destination page.
            c.releasing = false;
            c.error = error instanceof Error ? error : new Error(String(error));
            this._emit();
            throw c.error;
          }
          this._current = isClose ? null : next;
          this._emit();
          return true;
        }
      } finally {
        this._navigationInProgress = false;
      }
    }
    async switchTo(nextSession) {
      const next = this._prepare(nextSession); // reject malformed destination before touching current page
      return this._transition(next, false);
    }
    async close() {
      return this._transition(null, true);
    }
  }
  NotesDraftCoordinator.protocol = protocol;
  return NotesDraftCoordinator;
});
