using Microsoft.UI;
using Microsoft.UI.Windowing;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using NivareQ.Step2Pathfinder.Models;
using NivareQ.Step2Pathfinder.Services;
using Windows.UI.ViewManagement;

namespace NivareQ.Step2Pathfinder;

public sealed partial class MainWindow
{
    private readonly AccessibilitySettings _windowsAccessibilitySettings = new();
    private readonly UISettings _windowsUiSettings = new();

    private bool IsSystemHighContrast
    {
        get
        {
            try { return _windowsAccessibilitySettings.HighContrast; }
            catch { return false; }
        }
    }

    private bool WindowsAnimationsEnabled
    {
        get
        {
            try { return _windowsUiSettings.AnimationsEnabled; }
            catch { return true; }
        }
    }

    private bool ShouldReduceMotion => _settings.ReduceMotion || !WindowsAnimationsEnabled;

    private void InitializeAccessibilityCompatibility()
    {
        try { _windowsAccessibilitySettings.HighContrastChanged += WindowsAccessibilitySettings_HighContrastChanged; }
        catch { }
        Closed += AccessibilityCompatibility_Closed;
    }

    private void AccessibilityCompatibility_Closed(object sender, WindowEventArgs args)
    {
        try { _windowsAccessibilitySettings.HighContrastChanged -= WindowsAccessibilitySettings_HighContrastChanged; }
        catch { }
    }

    private void WindowsAccessibilitySettings_HighContrastChanged(AccessibilitySettings sender, object args)
    {
        RootGrid.DispatcherQueue.TryEnqueue(async () =>
        {
            ApplyThemeToShell(SelectedTheme());
            RebuildSubjectGroups(SubjectSearchBox.Text);
            await ApplyThemeToAllWebViewsAsync(SelectedTheme());
            RefreshAccessibilityTab();
        });
    }

    private UIElement CreateAccessibilityView()
    {
        var stack = new StackPanel { Spacing = 14, MaxWidth = 940, HorizontalAlignment = HorizontalAlignment.Left };
        stack.Children.Add(MakeHeading("Accessibility & display"));
        stack.Children.Add(MakeLead("Keep the normal Pathfinder experience, and turn on only the extra aids you want."));

        var systemState = IsSystemHighContrast ? "ON" : "off";
        var motionState = WindowsAnimationsEnabled ? "animations enabled" : "reduced motion requested";
        stack.Children.Add(MakeCard("Windows compatibility · always on",
            $"Windows High Contrast is currently {systemState}. Windows reports {motionState}. Pathfinder preserves native keyboard focus/navigation, screen-reader names, Windows DPI/scaling, and WebView2 touch/pinch/pan behavior. These foundations are not disabled by the switches below."));

        var themeCardStack = new StackPanel { Spacing = 8 };
        themeCardStack.Children.Add(new TextBlock
        {
            Text = "Display theme",
            FontSize = 17,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });
        themeCardStack.Children.Add(new TextBlock
        {
            Text = "The same Pathfinder theme selector is available here so it remains reachable when the top bar is very narrow. Windows High Contrast temporarily takes visual priority while it is active.",
            FontSize = 14,
            Opacity = .78,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });
        var themeChoice = new ComboBox
        {
            ItemsSource = _themes.Registry.Themes,
            DisplayMemberPath = "Name",
            SelectedItem = SelectedTheme(),
            MinWidth = 220,
            MinHeight = 44,
            HorizontalAlignment = HorizontalAlignment.Left
        };
        Microsoft.UI.Xaml.Automation.AutomationProperties.SetName(themeChoice, "Pathfinder display theme");
        themeChoice.SelectionChanged += (_, _) =>
        {
            if (themeChoice.SelectedItem is ThemeChoice choice)
                ThemeCombo.SelectedItem = choice;
        };
        themeCardStack.Children.Add(themeChoice);
        var themeCard = new Border { Child = themeCardStack, Padding = new Thickness(16), CornerRadius = new CornerRadius(12), BorderThickness = new Thickness(1) };
        RegisterThemedSurface(themeCard);
        stack.Children.Add(themeCard);

        var aids = new StackPanel { Spacing = 12 };
        aids.Children.Add(new TextBlock
        {
            Text = "Optional aids",
            FontSize = 17,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });
        aids.Children.Add(new TextBlock
        {
            Text = "All three are off by default. Changes are saved locally and can be reversed at any time.",
            FontSize = 14,
            Opacity = .78,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });

        var strongFocus = new ToggleSwitch
        {
            Header = "Stronger keyboard focus inside study cockpits",
            OffContent = "Off",
            OnContent = "On",
            IsOn = _settings.StrongFocusIndicators,
            MinHeight = 44
        };
        strongFocus.Toggled += async (_, _) =>
        {
            _settings.StrongFocusIndicators = strongFocus.IsOn;
            QueuePersistenceFailureNotice(SettingsService.Save(_settings), "Accessibility setting");
            await RefreshAccessibilityPresentationAsync();
        };
        aids.Children.Add(strongFocus);

        var reduceMotion = new ToggleSwitch
        {
            Header = "Reduce motion inside study cockpits",
            OffContent = "Off",
            OnContent = "On",
            IsOn = _settings.ReduceMotion,
            MinHeight = 44
        };
        reduceMotion.Toggled += async (_, _) =>
        {
            _settings.ReduceMotion = reduceMotion.IsOn;
            QueuePersistenceFailureNotice(SettingsService.Save(_settings), "Accessibility setting");
            await RefreshAccessibilityPresentationAsync();
        };
        aids.Children.Add(reduceMotion);
        aids.Children.Add(new TextBlock
        {
            Text = "Pathfinder also respects the Windows animation setting automatically; this switch lets you force reduced motion even when Windows animations are enabled.",
            FontSize = 12,
            Opacity = .68,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });

        var spacing = new ToggleSwitch
        {
            Header = "More spacious study text",
            OffContent = "Off",
            OnContent = "On",
            IsOn = _settings.ComfortableReadingSpacing,
            MinHeight = 44
        };
        spacing.Toggled += async (_, _) =>
        {
            _settings.ComfortableReadingSpacing = spacing.IsOn;
            QueuePersistenceFailureNotice(SettingsService.Save(_settings), "Accessibility setting");
            await RefreshAccessibilityPresentationAsync();
        };
        aids.Children.Add(spacing);
        aids.Children.Add(new TextBlock
        {
            Text = "Adds modest line spacing to reading-heavy paragraphs and lists without changing the original study content.",
            FontSize = 12,
            Opacity = .68,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });

        var reset = MakeActionButton("Turn all optional aids off", async (_, _) =>
        {
            _settings.StrongFocusIndicators = false;
            _settings.ReduceMotion = false;
            _settings.ComfortableReadingSpacing = false;
            QueuePersistenceFailureNotice(SettingsService.Save(_settings), "Accessibility setting");
            await RefreshAccessibilityPresentationAsync();
        });
        aids.Children.Add(reset);

        var aidCard = new Border { Child = aids, Padding = new Thickness(16), CornerRadius = new CornerRadius(12), BorderThickness = new Thickness(1) };
        RegisterThemedSurface(aidCard);
        stack.Children.Add(aidCard);

        stack.Children.Add(MakeCard("Keyboard-only use", "Tab and Shift+Tab move through Pathfinder controls; arrow keys work in standard lists and selectors. Ctrl+K opens Universal Search, Ctrl+Shift+A opens this page, Alt+Left/Right navigate the active study tab, Ctrl+W closes a tab, Ctrl+Shift+T reopens one, and F11 toggles full screen."));
        stack.Children.Add(MakeCard("Scaling & narrow windows", "Pathfinder uses Windows/WinUI scaling rather than its own fake DPI system. Secondary top-bar commands collapse at narrow widths but remain reachable from Home or this page. No medical cockpit file is rewritten for scaling."));
        stack.Children.Add(MakeCard("Touch", "Pathfinder does not add custom pinch, pan, or zoom handlers. Native Edge/WebView2 touch behavior is preserved."));

        return WrapScrollableStack(stack);
    }

    private async Task RefreshAccessibilityPresentationAsync()
    {
        ApplyThemeToShell(SelectedTheme());
        await ApplyThemeToAllWebViewsAsync(SelectedTheme());
        RefreshAccessibilityTab();
    }

    private void RefreshAccessibilityTab()
    {
        // W2D: accessibility is a Settings section. Refresh the active Settings
        // surface rather than recreating a utility tab.
        if (_activeAppSurfaceId.Equals("settings", StringComparison.OrdinalIgnoreCase) &&
            AppSurfaceHost.Visibility == Visibility.Visible)
        {
            AppSurfaceContent.Content = PrepareShellContent(CreateSettingsView(_activeSettingsSection));
        }
    }

    private Windows.UI.Color SystemUiColor(UIColorType type, Windows.UI.Color fallback)
    {
        try { return _windowsUiSettings.GetColorValue(type); }
        catch { return fallback; }
    }

    private void ApplySystemHighContrastShell()
    {
        var background = SystemUiColor(UIColorType.Background, Colors.Black);
        var foreground = SystemUiColor(UIColorType.Foreground, Colors.White);
        var accent = SystemUiColor(UIColorType.Accent, foreground);

        RootGrid.RequestedTheme = ElementTheme.Default;
        var bgBrush = new SolidColorBrush(background);
        var accentBrush = new SolidColorBrush(accent);
        RootGrid.Background = bgBrush;
        ShellSplit.Background = bgBrush;
        MainContentHost.Background = bgBrush;
        Tabs.Background = bgBrush;
        AppSurfaceHost.Background = bgBrush;
        TopBar.Background = bgBrush;
        PaneBorder.Background = bgBrush;
        AppSurfaceHeader.Background = bgBrush;
        TopBar.BorderBrush = accentBrush;
        PaneBorder.BorderBrush = accentBrush;
        AppSurfaceHeader.BorderBrush = accentBrush;

        foreach (var key in new[]
        {
            "CardBackgroundFillColorDefaultBrush", "TabViewBackground", "TabViewItemHeaderBackground", "TabViewButtonBackground", "TabViewScrollButtonBackground",
            "TabViewItemHeaderBackgroundSelected", "TabViewItemHeaderBackgroundPointerOver", "TabViewItemHeaderDragBackground", "TabViewButtonBackgroundPointerOver", "TabViewScrollButtonBackgroundPointerOver"
        }) SetShellResourceBrush(key, background);

        foreach (var key in new[]
        {
            "TextFillColorPrimaryBrush", "TextFillColorSecondaryBrush", "TextFillColorTertiaryBrush", "SystemControlForegroundBaseHighBrush",
            "TabViewItemHeaderForeground", "TabViewItemHeaderForegroundSelected", "TabViewItemHeaderForegroundPointerOver", "TabViewItemHeaderForegroundPressed",
            "TabViewItemHeaderCloseButtonForeground", "TabViewItemHeaderCloseButtonForegroundSelected", "TabViewItemHeaderCloseButtonForegroundPointerOver",
            "TabViewButtonForeground", "TabViewButtonForegroundPointerOver", "TabViewScrollButtonForeground", "TabViewScrollButtonForegroundPointerOver"
        }) SetShellResourceBrush(key, foreground);

        foreach (var key in new[]
        {
            "CardStrokeColorDefaultBrush", "AccentFillColorDefaultBrush", "AccentTextFillColorPrimaryBrush", "TabViewBorderBrush", "TabViewItemSeparator",
            "TabViewItemBorderBrush", "TabViewSelectedItemBorderBrush", "ScrollBarThumbFill", "ScrollBarThumbBackground", "ScrollBarPanningThumbBackground",
            "ScrollBarThumbBackgroundThemeBrush", "ScrollBarThumbBorderThemeBrush", "ScrollBarThumbFillPointerOver", "ScrollBarThumbFillPressed",
            "ScrollBarThumbPointerOverBackgroundThemeBrush", "ScrollBarThumbPressedBackgroundThemeBrush"
        }) SetShellResourceBrush(key, accent);

        foreach (var surface in _themedSurfaces)
        {
            surface.Background = new SolidColorBrush(background);
            surface.BorderBrush = new SolidColorBrush(accent);
        }

        if (_appWindow is not null && AppWindowTitleBar.IsCustomizationSupported())
        {
            var titleBar = _appWindow.TitleBar;
            titleBar.BackgroundColor = background;
            titleBar.ForegroundColor = foreground;
            titleBar.InactiveBackgroundColor = background;
            titleBar.InactiveForegroundColor = foreground;
            titleBar.ButtonBackgroundColor = background;
            titleBar.ButtonForegroundColor = foreground;
            titleBar.ButtonInactiveBackgroundColor = background;
            titleBar.ButtonInactiveForegroundColor = foreground;
            titleBar.ButtonHoverBackgroundColor = accent;
            titleBar.ButtonHoverForegroundColor = foreground;
            titleBar.ButtonPressedBackgroundColor = accent;
            titleBar.ButtonPressedForegroundColor = foreground;
        }
    }
}
