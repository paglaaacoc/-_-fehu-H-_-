using Microsoft.UI.Windowing;
using Microsoft.UI.Xaml;

namespace NivareQ.Step2Pathfinder;

public sealed partial class MainWindow
{
    private long _runtimeMutationEpoch;
    private bool _runtimeClosing;
    private bool _journalCloseBlockedByDirtyDraft;

    private long CaptureRuntimeMutationEpoch() => Interlocked.Read(ref _runtimeMutationEpoch);

    private long AdvanceRuntimeMutationEpoch(string reason)
    {
        var next = Interlocked.Increment(ref _runtimeMutationEpoch);
        try
        {
            Directory.CreateDirectory(Services.PathfinderPaths.AppDataRoot);
            lock (DiagnosticLock)
                File.AppendAllText(Services.PathfinderPaths.DiagnosticsPath, $"{DateTimeOffset.Now:O}\tshell\tmutation-epoch\t{next}:{reason}{Environment.NewLine}");
        }
        catch { }
        return next;
    }

    private bool IsRuntimeMutationCurrent(long epoch)
        => !_runtimeClosing
           && epoch == Interlocked.Read(ref _runtimeMutationEpoch)
           && !Services.RestoreTransactionService.MutationsBlocked;

    private bool IsRuntimeMutationCurrent(long epoch, StudyTabContext context)
        => IsRuntimeMutationCurrent(epoch)
           && context.Lifecycle != Models.CockpitHostLifecycle.Closed
           && _studyTabs.TryGetValue(context.Tab, out var registered)
           && ReferenceEquals(registered, context);

    private void InitializeRuntimeRepairGuards()
    {
        if (_appWindow is not null) _appWindow.Closing += AppWindow_Closing;
    }

    private void AppWindow_Closing(AppWindow sender, AppWindowClosingEventArgs args)
    {
        // WinUI window close itself is synchronous. Do not begin an async modal prompt from this
        // event: cancel first, bring the existing inline editor forward, and let the user use the
        // already-established Save/Cancel controls. A second close succeeds only after the draft
        // is no longer dirty.
        if (JournalEditorIsDirty())
        {
            args.Cancel = true;
            _journalCloseBlockedByDirtyDraft = true;
            RootGrid.DispatcherQueue.TryEnqueue(() =>
            {
                OpenJournal();
                RenderJournalInlineEditor();
            });
            return;
        }

        _runtimeClosing = true;
        AdvanceRuntimeMutationEpoch("window-closing");
    }
    private void RetireStudyContext(StudyTabContext context, string reason)
    {
        if (context.Lifecycle == Models.CockpitHostLifecycle.Closed) return;
        context.Lifecycle = Models.CockpitHostLifecycle.Closed;
        context.DocumentHealthy = false;
        context.CaptureAuthorityReady = false;
        context.ContentGeneration++;
        CancelLocationRequests(context, reason);
        try
        {
            if (context.DocumentCreatedScriptId is not null && context.WebView.CoreWebView2 is not null)
                context.WebView.CoreWebView2.RemoveScriptToExecuteOnDocumentCreated(context.DocumentCreatedScriptId);
        }
        catch { }
        context.DocumentCreatedScriptId = null;
        try
        {
            if (context.RecoveryButton?.Parent is Microsoft.UI.Xaml.Controls.Grid parent)
                parent.Children.Remove(context.RecoveryButton);
        }
        catch { }
        context.RecoveryButton = null;
        try { context.WebView.Close(); } catch { }
    }

}
