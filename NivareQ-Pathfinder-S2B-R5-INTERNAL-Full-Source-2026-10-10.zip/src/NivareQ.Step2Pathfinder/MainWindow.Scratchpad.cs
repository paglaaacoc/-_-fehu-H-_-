using System.Text;
using System.Text.Json;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.Web.WebView2.Core;
using NivareQ.Step2Pathfinder.Services;

namespace NivareQ.Step2Pathfinder;

// S1 TEST CANDIDATE ONLY. This tool never participates in cockpit source identity,
// cockpit WebView2 events, source navigation, or medical-content rendering.
public sealed partial class MainWindow
{
    private const string ScratchpadExtensionKey = "nivareq.scratchpad.v1";
    private const string ScratchpadHost = "scratchpad.pathfinder.invalid";
    private const string ScratchpadPageUrl = "https://scratchpad.pathfinder.invalid/index.html";
    private const int ScratchpadMaxBytes = 12 * 1024 * 1024;
    private WebView2? _scratchpadWeb;
    private bool _scratchpadInitializing;

    private void ScratchpadButton_Click(object sender, RoutedEventArgs e)
        => OpenSpecialTabSafe("Scratchpad", CreateScratchpadView);

    private UIElement CreateScratchpadView()
    {
        var web = new WebView2
        {
            HorizontalAlignment = HorizontalAlignment.Stretch,
            VerticalAlignment = VerticalAlignment.Stretch
        };
        _scratchpadWeb = web;
        web.Loaded += ScratchpadWeb_Loaded;
        return web;
    }

    private async void ScratchpadWeb_Loaded(object sender, RoutedEventArgs e)
    {
        if (sender is not WebView2 web || web.CoreWebView2 is not null || _scratchpadInitializing) return;
        _scratchpadInitializing = true;
        try
        {
            var assetDir = Path.Combine(AppContext.BaseDirectory, "ScratchpadAssets");
            if (!File.Exists(Path.Combine(assetDir, "index.html")))
                throw new FileNotFoundException("Scratchpad UI assets are missing from this build.");
            await web.EnsureCoreWebView2Async(await GetWebEnvironmentAsync());
            if (!ReferenceEquals(_scratchpadWeb, web)) return;
            web.CoreWebView2.Settings.AreDevToolsEnabled = false;
            web.CoreWebView2.Settings.AreHostObjectsAllowed = false;
            web.CoreWebView2.Settings.IsWebMessageEnabled = true;
            web.CoreWebView2.SetVirtualHostNameToFolderMapping(ScratchpadHost, assetDir, CoreWebView2HostResourceAccessKind.DenyCors);
            web.CoreWebView2.NavigationStarting += (_, args) =>
            {
                if (!args.Uri.Equals(ScratchpadPageUrl, StringComparison.OrdinalIgnoreCase)) args.Cancel = true;
            };
            web.CoreWebView2.NewWindowRequested += (_, args) => { args.Handled = true; };
            web.CoreWebView2.WebMessageReceived += (_, args) => HandleScratchpadMessage(web, args);
            web.CoreWebView2.Navigate(ScratchpadPageUrl);
        }
        catch (Exception ex)
        {
            PersistenceHealth.Report("Scratchpad startup", ex.Message);
            await ShowPersonalMessageAsync("Scratchpad could not open", "No scratchpad data was changed. " + ex.Message);
        }
        finally { _scratchpadInitializing = false; }
    }

    private void HandleScratchpadMessage(WebView2 web, CoreWebView2WebMessageReceivedEventArgs args)
    {
        if (!ReferenceEquals(web, _scratchpadWeb) || web.CoreWebView2 is null ||
            !args.Source.Equals(ScratchpadPageUrl, StringComparison.OrdinalIgnoreCase)) return;
        try
        {
            using var message = JsonDocument.Parse(args.WebMessageAsJson);
            var root = message.RootElement;
            var action = root.GetProperty("type").GetString();
            if (action == "ready")
            {
                if (TryReadScratchpad(out var existing, out var readError))
                    PostScratchpadMessage(web, new { type = "load", state = existing });
                else
                    PostScratchpadMessage(web, new { type = "load-error", message = readError });
                PostScratchpadTheme(web, SelectedTheme());
            }
            else if (action == "save")
            {
                var seq = root.GetProperty("seq").GetInt32();
                var state = root.GetProperty("state");
                var success = TryWriteScratchpad(state.GetRawText(), out var error);
                PostScratchpadMessage(web, new { type = "saved", seq, ok = success, message = success ? "" : error });
            }
        }
        catch (Exception ex)
        {
            PersistenceHealth.Report("Scratchpad bridge", "Rejected malformed scratchpad message: " + ex.Message);
            PostScratchpadMessage(web, new { type = "save-error", message = "A malformed Scratchpad message was rejected; no data was saved." });
        }
    }

    // Scratchpad owns its CSS variables. Deliberately do not inject cockpit CSS:
    // medical WebView styling is unrelated, and writing paper remains light.
    private void PostScratchpadTheme(WebView2 web, NivareQ.Step2Pathfinder.Models.ThemeChoice theme)
    {
        PostScratchpadMessage(web, new
        {
            type = "theme",
            palette = new
            {
                shell = theme.ShellBackground,
                surface = theme.ShellPanel,
                ink = theme.ShellForeground,
                muted = theme.ShellMuted,
                outline = theme.ShellBorder,
                accent = theme.ShellAccent
            }
        });
    }

    private static void PostScratchpadMessage(WebView2 web, object payload)
    {
        try { web.CoreWebView2?.PostWebMessageAsJson(JsonSerializer.Serialize(payload)); }
        catch (Exception ex) { PersistenceHealth.Report("Scratchpad bridge", ex.Message); }
    }

    private bool TryReadScratchpad(out JsonElement? state, out string error)
    {
        state = null;
        error = "";
        if (!_backupExtensions.State.Values.TryGetValue(ScratchpadExtensionKey, out var stored)) return true;
        try
        {
            ValidateScratchpadDocument(stored);
            state = stored.Clone();
            return true;
        }
        catch (Exception ex)
        {
            error = "Saved Scratchpad content could not be validated. It has been left untouched. " + ex.Message;
            PersistenceHealth.Report("Scratchpad", error);
            return false;
        }
    }

    private bool TryWriteScratchpad(string rawJson, out string error)
    {
        error = "";
        try
        {
            if (Encoding.UTF8.GetByteCount(rawJson) > ScratchpadMaxBytes)
                throw new InvalidDataException("Scratchpad collection exceeds its 12 MB safety limit. Split or simplify large pages.");
            using var parsed = JsonDocument.Parse(rawJson);
            ValidateScratchpadDocument(parsed.RootElement);
            var previous = _backupExtensions.State.Values.TryGetValue(ScratchpadExtensionKey, out var old) ? old.Clone() : (JsonElement?)null;
            _backupExtensions.State.Values[ScratchpadExtensionKey] = parsed.RootElement.Clone();
            var result = _backupExtensions.Save();
            if (!result.Success)
            {
                if (previous is { } prior) _backupExtensions.State.Values[ScratchpadExtensionKey] = prior;
                else _backupExtensions.State.Values.Remove(ScratchpadExtensionKey);
                throw new IOException(result.Error);
            }
            return true;
        }
        catch (Exception ex)
        {
            error = ex.Message;
            PersistenceHealth.Report("Scratchpad save", error);
            return false;
        }
    }

    // Explicit allowlist validation: the browser does not get to write arbitrary
    // opaque JSON into Pathfinder's native canonical-backup extension store.
    private static void ValidateScratchpadDocument(JsonElement data)
    {
        if (data.ValueKind != JsonValueKind.Object || data.GetProperty("schemaVersion").GetInt32() != 1)
            throw new InvalidDataException("Unsupported Scratchpad schema.");
        if (Encoding.UTF8.GetByteCount(data.GetRawText()) > ScratchpadMaxBytes)
            throw new InvalidDataException("Scratchpad data exceeds 12 MB.");
        BoundedString(data, "activePadId", 64);
        var pads = data.GetProperty("pads");
        if (pads.ValueKind != JsonValueKind.Array || pads.GetArrayLength() < 1 || pads.GetArrayLength() > 80)
            throw new InvalidDataException("Too many scratchpads (limit 80).");
        var knownPadIds = new HashSet<string>(StringComparer.Ordinal);
        foreach (var pad in pads.EnumerateArray())
        {
            var padId = BoundedString(pad, "id", 64);
            if (padId.Length == 0 || !knownPadIds.Add(padId)) throw new InvalidDataException("Invalid or duplicate Scratchpad identifier.");
            BoundedString(pad, "title", 120);
            BoundedString(pad, "activePageId", 64);
            var pages = pad.GetProperty("pages");
            if (pages.ValueKind != JsonValueKind.Array || pages.GetArrayLength() < 1 || pages.GetArrayLength() > 100)
                throw new InvalidDataException("Too many pages (limit 100 per pad).");
            var knownPageIds = new HashSet<string>(StringComparer.Ordinal);
            foreach (var page in pages.EnumerateArray())
            {
                var pageId = BoundedString(page, "id", 64);
                if (pageId.Length == 0 || !knownPageIds.Add(pageId)) throw new InvalidDataException("Invalid or duplicate page identifier.");
                var guide = BoundedString(page, "guide", 16);
                if (guide != "blank" && guide != "ruled" && guide != "triple")
                    throw new InvalidDataException("Unknown line-guide template.");
                var spacing = page.GetProperty("spacing").GetInt32();
                if (spacing < 20 || spacing > 100) throw new InvalidDataException("Invalid line spacing.");
                var cells = page.GetProperty("cells");
                if (cells.ValueKind != JsonValueKind.Array || (cells.GetArrayLength() != 1 && cells.GetArrayLength() != 2 && cells.GetArrayLength() != 4))
                    throw new InvalidDataException("Scratchpad supports one, two, or four writing spaces.");
                foreach (var cell in cells.EnumerateArray())
                {
                    BoundedString(cell, "text", 120000);
                    var strokes = cell.GetProperty("strokes");
                    if (strokes.ValueKind != JsonValueKind.Array || strokes.GetArrayLength() > 25000)
                        throw new InvalidDataException("The page has too many ink strokes.");
                    foreach (var stroke in strokes.EnumerateArray())
                    {
                        var color = BoundedString(stroke, "color", 16);
                        if (color != "#142235" && color != "#2563eb" && color != "#b91c1c" && color != "#047857")
                            throw new InvalidDataException("Unsupported ink color.");
                        var width = stroke.GetProperty("width").GetDouble();
                        if (!double.IsFinite(width) || width < 1 || width > 12)
                            throw new InvalidDataException("Invalid ink width.");
                        var points = stroke.GetProperty("points");
                        if (points.ValueKind != JsonValueKind.Array || points.GetArrayLength() == 0 || points.GetArrayLength() > 4000)
                            throw new InvalidDataException("Invalid ink stroke points.");
                        foreach (var point in points.EnumerateArray())
                        {
                            if (point.ValueKind != JsonValueKind.Array || point.GetArrayLength() != 2) throw new InvalidDataException("Invalid ink point.");
                            var x = point[0].GetDouble();
                            var y = point[1].GetDouble();
                            if (!double.IsFinite(x) || !double.IsFinite(y) || x < 0 || x > 1 || y < 0 || y > 1)
                                throw new InvalidDataException("Invalid ink coordinates.");
                        }
                    }
                }
            }
            if (!knownPageIds.Contains(pad.GetProperty("activePageId").GetString() ?? ""))
                throw new InvalidDataException("The active Scratchpad page is missing.");
        }
        if (!knownPadIds.Contains(data.GetProperty("activePadId").GetString() ?? ""))
            throw new InvalidDataException("The active Scratchpad is missing.");
    }

    private static string BoundedString(JsonElement element, string name, int maxLength)
    {
        var value = element.GetProperty(name).GetString() ?? "";
        if (value.Length > maxLength) throw new InvalidDataException($"Scratchpad {name} exceeds {maxLength} characters.");
        return value;
    }

    private async Task<bool> FlushScratchpadBeforeLeavingAsync()
    {
        if (_scratchpadWeb?.CoreWebView2 is null) return true;
        try
        {
            // Capture pending edits synchronously from the renderer, independent of the
            // HTML debounce/ack clock. This is used by tab close and canonical backup.
            var scriptResult = await _scratchpadWeb.CoreWebView2.ExecuteScriptAsync(
                "window.pathfinderScratchpadExport ? JSON.stringify(window.pathfinderScratchpadExport()) : null");
            if (scriptResult == "null") return true; // not yet initialized; no new data
            var serialized = JsonSerializer.Deserialize<string>(scriptResult);
            string error = "";
            if (serialized is null || !TryWriteScratchpad(serialized, out error))
            {
                await ShowPersonalMessageAsync("Scratchpad was not saved", "Pathfinder kept Scratchpad open and did not continue. " + (serialized is null ? "The page did not return valid state." : error));
                return false;
            }
            return true;
        }
        catch (Exception ex)
        {
            await ShowPersonalMessageAsync("Scratchpad capture failed", "No data was intentionally changed. Leave Scratchpad open and retry. " + ex.Message);
            return false;
        }
    }
}
