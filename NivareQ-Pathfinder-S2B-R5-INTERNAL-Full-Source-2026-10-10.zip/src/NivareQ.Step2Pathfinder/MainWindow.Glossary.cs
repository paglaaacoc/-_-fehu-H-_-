using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.Web.WebView2.Core;
using NivareQ.Step2Pathfinder.Models;

namespace NivareQ.Step2Pathfinder;

public sealed partial class MainWindow
{
    private TextBox? _glossarySearchBox;

    private UIElement CreateGlossaryView(string initialQuery = "")
    {
        var stack = new StackPanel
        {
            Spacing = 12,
            MaxWidth = 1120,
            HorizontalAlignment = HorizontalAlignment.Left
        };
        stack.Children.Add(MakeHeading("Medical abbreviation glossary"));
        stack.Children.Add(MakeLead("Quick expansions and deterministic aliases from across the Pathfinder study library. Ambiguous abbreviations show every curated meaning; Pathfinder does not guess from context."));

        var box = new TextBox
        {
            PlaceholderText = "Search GCS, SJS, H. pylori, pulmonary embolism…",
            MinWidth = 420,
            MaxWidth = 900,
            Height = 44,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            IsSpellCheckEnabled = true,
            Text = initialQuery ?? ""
        };
        _glossarySearchBox = box;

        var status = new TextBlock { FontSize = 12, Opacity = .68, TextWrapping = TextWrapping.Wrap, IsTextSelectionEnabled = true };
        var results = new StackPanel { Spacing = 8 };
        void Refresh()
        {
            results.Children.Clear();
            var q = box.Text.Trim();
            List<GlossaryEntry> matches;
            if (q.Length == 0)
            {
                matches = _glossary.Entries.Take(80).ToList();
                status.Text = $"{_glossary.Count} curated entries · showing the first {matches.Count} alphabetically";
            }
            else if (q.Length == 1 && char.IsLetter(q[0]))
            {
                matches = _glossary.BrowseByInitial(q[0]).ToList();
                status.Text = matches.Count == 0
                    ? $"No glossary entries beginning with {char.ToUpperInvariant(q[0])}."
                    : $"{matches.Count} glossary entr{(matches.Count == 1 ? "y" : "ies")} beginning with {char.ToUpperInvariant(q[0])}";
            }
            else
            {
                matches = _glossary.Search(q, 100).ToList();
                status.Text = matches.Count == 0 ? "No glossary match." : $"{matches.Count} glossary match{(matches.Count == 1 ? "" : "es")}";
            }
            foreach (var entry in matches)
                results.Children.Add(MakeGlossaryEntryCard(entry));
        }

        box.TextChanged += (_, _) => Refresh();
        stack.Children.Add(box);
        stack.Children.Add(status);
        stack.Children.Add(results);
        Refresh();

        var view = WrapScrollableStack(stack);
        view.Loaded += (_, _) => box.Focus(FocusState.Programmatic);
        return view;
    }

    private Border MakeGlossaryEntryCard(GlossaryEntry entry)
    {
        var stack = new StackPanel { Spacing = 5 };
        stack.Children.Add(new TextBlock
        {
            Text = entry.DisplayLine,
            FontSize = 16,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });
        if (entry.Aliases.Count > 0)
            stack.Children.Add(new TextBlock { Text = "Also: " + string.Join(" · ", entry.Aliases), FontSize = 12, Opacity = .76, TextWrapping = TextWrapping.Wrap, IsTextSelectionEnabled = true });
        if (!string.IsNullOrWhiteSpace(entry.Note))
            stack.Children.Add(new TextBlock { Text = entry.Note, FontSize = 12, Opacity = .78, TextWrapping = TextWrapping.Wrap, IsTextSelectionEnabled = true });
        if (entry.Subjects.Count > 0)
        {
            var subjectNames = entry.Subjects
                .Select(slug => _catalog.Entries.FirstOrDefault(x => x.Slug.Equals(slug, StringComparison.OrdinalIgnoreCase))?.Title ?? slug)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .Take(8)
                .ToList();
            stack.Children.Add(new TextBlock
            {
                Text = "Found in: " + string.Join(" · ", subjectNames) + (entry.Subjects.Count > subjectNames.Count ? " · …" : ""),
                FontSize = 11.5,
                Opacity = .62,
                TextWrapping = TextWrapping.Wrap,
                IsTextSelectionEnabled = true
            });
        }

        var card = new Border { Child = stack, Padding = new Thickness(12), CornerRadius = new CornerRadius(10), BorderThickness = new Thickness(1) };
        RegisterThemedSurface(card);
        return card;
    }

    private void OpenGlossary(string query = "")
    {
        CloseAppSurface(restorePreviousTab: false);
        var existing = Tabs.TabItems.OfType<TabViewItem>().FirstOrDefault(x => Equals(x.Tag, "shell:Glossary"));
        if (existing is not null)
        {
            Tabs.SelectedItem = existing;
            if (_glossarySearchBox is not null)
            {
                _glossarySearchBox.Text = query;
                _glossarySearchBox.Focus(FocusState.Programmatic);
                _glossarySearchBox.SelectAll();
            }
            return;
        }
        OpenSpecialTab("Glossary", CreateGlossaryView(query));
    }

    private void AddGlossaryContextMenu(StudyTabContext context, CoreWebView2ContextMenuRequestedEventArgs args)
    {
        try
        {
            var selection = (args.ContextMenuTarget.SelectionText ?? "").Trim();
            if (selection.Length == 0) return;
            if (selection.Length > 120) selection = selection[..120].Trim();

            var env = context.WebView.CoreWebView2?.Environment;
            if (env is null) return;
            var parent = env.CreateContextMenuItem("Pathfinder Glossary", null, CoreWebView2ContextMenuItemKind.Submenu);
            var exact = _glossary.FindExact(selection).Take(8).ToList();

            if (exact.Count > 0)
            {
                foreach (var entry in exact)
                {
                    var label = entry.DisplayLine;
                    var item = env.CreateContextMenuItem(label, null, CoreWebView2ContextMenuItemKind.Command);
                    item.CustomItemSelected += (_, _) => RootGrid.DispatcherQueue.TryEnqueue(() => OpenGlossary(entry.Term));
                    parent.Children.Add(item);
                }
            }
            else
            {
                var none = env.CreateContextMenuItem("No exact glossary match", null, CoreWebView2ContextMenuItemKind.Command);
                none.IsEnabled = false;
                parent.Children.Add(none);
            }

            var open = env.CreateContextMenuItem($"Open glossary for “{selection}”…", null, CoreWebView2ContextMenuItemKind.Command);
            open.CustomItemSelected += (_, _) => RootGrid.DispatcherQueue.TryEnqueue(() => OpenGlossary(selection));
            parent.Children.Add(open);

            args.MenuItems.Insert(args.MenuItems.Count, parent);
            // Deliberately do not set Handled=true: the normal Edge/WebView2 menu remains intact.
        }
        catch
        {
            // Glossary lookup must never interfere with the native WebView2 context menu.
        }
    }
}
