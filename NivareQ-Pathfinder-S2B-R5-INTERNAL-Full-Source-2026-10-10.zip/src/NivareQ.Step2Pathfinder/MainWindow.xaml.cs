using System.Text.Json;
using Microsoft.UI;
using Microsoft.UI.Input;
using Microsoft.UI.Windowing;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.Web.WebView2.Core;
using NivareQ.Step2Pathfinder.Models;
using NivareQ.Step2Pathfinder.Services;
using Windows.Foundation;
using Windows.Graphics;
using Windows.System;
using Windows.UI.Core;
using WinRT.Interop;

namespace NivareQ.Step2Pathfinder;

public sealed partial class MainWindow : Window
{
    private readonly ContentCatalogService _catalog = new();
    private readonly StudyTimeService _studyTimes = new();
    private readonly ThemeService _themes = new();
    private readonly RuntimeContentService _runtimeContent = new();
    private readonly UniversalSearchService _universalSearch = new();
    private readonly GlossaryService _glossary = new();
    private readonly Dictionary<TabViewItem, StudyTabContext> _studyTabs = [];
    private readonly List<Border> _themedSurfaces = [];
    private readonly Dictionary<string, SolidColorBrush> _shellResourceBrushes = new(StringComparer.Ordinal);
    private readonly ShellSettings _settings = SettingsService.Load();
    private readonly Stack<ClosedStudyTabSnapshot> _recentlyClosedStudyTabs = [];
    private Task<CoreWebView2Environment>? _environmentTask;
    private TabViewItem? _homeTab;
    private TabViewItem? _tabBeforeAppSurface;
    private string _activeAppSurfaceId = "";
    private SubjectEntry? _contextSubject;
    private bool _suppressThemeEvent;
    private bool _compactChrome;
    private bool _focusMode;
    private bool _paneWasOpenBeforeFocus = true;
    private bool _paneWasOpenBeforeFullScreen = true;
    private bool _isFullScreen;
    private bool _sessionStartupComplete;
    private AppWindow? _appWindow;
    private static readonly object DiagnosticLock = new();
    private double? _pendingLibraryPointerVerticalOffset;

    public MainWindow()
    {
        InitializeComponent();
        ConfigureWindow();
        InitializeRuntimeRepairGuards();
        try
        {
            _catalog.Load();
            _studyTimes.Load();
            _themes.Load();
            _uworldSelector.Load();
            InitializeAccessibilityCompatibility();
            _glossary.Load();
            InitializePersonalStudyFeatures();
            AttachStudyTimes();
            ThemeCombo.ItemsSource = _themes.Registry.Themes;
            SelectSavedTheme();
            RebuildSubjectGroups("");
            CreateHomeTab();
            RootGrid.Loaded += RootGrid_Loaded;
        }
        catch (Exception ex)
        {
            CreateFatalHome(ex);
        }
    }

    private void ConfigureWindow()
    {
        try
        {
            var hwnd = WindowNative.GetWindowHandle(this);
            var id = Win32Interop.GetWindowIdFromWindow(hwnd);
            _appWindow = AppWindow.GetFromWindowId(id);
            _appWindow.Resize(new SizeInt32(1440, 900));
            _appWindow.SetIcon(Path.Combine(AppContext.BaseDirectory, "Assets", "Pathfinder.ico"));
        }
        catch { /* default window remains usable */ }
    }

    private void AttachStudyTimes()
    {
        foreach (var entry in _catalog.Entries)
        {
            if (_studyTimes.BySlug.TryGetValue(entry.Slug, out var estimate))
                entry.StudyTimeBase = "≈ " + StudyTimeService.FormatRange(estimate.StandardMinMinutes, estimate.StandardMaxMinutes);
        }
    }

    private void RebuildSubjectGroups(string query)
    {
        ApplyPersonalDecorationsToSubjects();
        var q = query.Trim();
        var filtered = _catalog.Entries.Where(x =>
            q.Length == 0 ||
            x.Title.Contains(q, StringComparison.OrdinalIgnoreCase) ||
            x.Subtitle.Contains(q, StringComparison.OrdinalIgnoreCase) ||
            x.Phase.Contains(q, StringComparison.OrdinalIgnoreCase))
            .ToList();

        // W2D intentionally avoids ListView virtualization for the bounded 25-resource
        // library. This makes group boundaries/layout deterministic and removes the
        // late-library bring-into-view/measurement collapse seen around resources 19+
        // and Extras & Reference.
        SubjectsPanel.Children.Clear();
        foreach (var group in filtered
                     .GroupBy(StudyGroupLabel)
                     .Select(g => new { Key = g.Key, Items = g.OrderByDescending(x => x.IsFavorite).ThenBy(x => x.Number).ToList() }))
        {
            SubjectsPanel.Children.Add(CreateSubjectGroupHeader(group.Key));
            var selectorInserted = false;
            foreach (var subject in group.Items)
            {
                SubjectsPanel.Children.Add(CreateSubjectLibraryButton(subject));
                if (group.Key == "EXTRAS & REFERENCE"
                    && subject.ResourceId.Equals("extra-clinical-recall-library", StringComparison.OrdinalIgnoreCase)
                    && UWorldSelectorMatchesLibraryQuery(q))
                {
                    SubjectsPanel.Children.Add(CreateUWorldSelectorLibraryButton());
                    selectorInserted = true;
                }
            }
            if (group.Key == "EXTRAS & REFERENCE" && !selectorInserted && UWorldSelectorMatchesLibraryQuery(q))
                SubjectsPanel.Children.Add(CreateUWorldSelectorLibraryButton());
        }
        if (!filtered.Any(x => StudyGroupLabel(x) == "EXTRAS & REFERENCE") && UWorldSelectorMatchesLibraryQuery(q))
        {
            SubjectsPanel.Children.Add(CreateSubjectGroupHeader("EXTRAS & REFERENCE"));
            SubjectsPanel.Children.Add(CreateUWorldSelectorLibraryButton());
        }
    }

    private bool UWorldSelectorMatchesLibraryQuery(string query)
    {
        if (string.IsNullOrWhiteSpace(query)) return true;
        var q = query.Trim();
        return "UWorld Selector".Contains(q, StringComparison.OrdinalIgnoreCase)
               || "Native manual Unused-only recipe tracker".Contains(q, StringComparison.OrdinalIgnoreCase)
               || _uworldSelector.Recipes.Any(x => x.Title.Contains(q, StringComparison.OrdinalIgnoreCase)
                                                   || x.Subjects.Any(y => y.Contains(q, StringComparison.OrdinalIgnoreCase))
                                                   || x.Systems.Any(y => y.Contains(q, StringComparison.OrdinalIgnoreCase)));
    }

    private UIElement CreateSubjectGroupHeader(string label)
    {
        var grid = new Grid { Margin = new Thickness(6, 15, 6, 5) };
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(4) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

        grid.Children.Add(new Border
        {
            Width = 3,
            CornerRadius = new CornerRadius(2),
            Background = SidebarAccentBrush(),
            Margin = new Thickness(0, 1, 0, 1)
        });

        var stack = new StackPanel { Margin = new Thickness(9, 0, 0, 0) };
        Grid.SetColumn(stack, 1);
        stack.Children.Add(new TextBlock
        {
            Text = label,
            FontSize = 10.5,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            CharacterSpacing = 90,
            Opacity = 0.82,
            TextWrapping = TextWrapping.Wrap
        });
        stack.Children.Add(new Border
        {
            Height = 1,
            Margin = new Thickness(0, 5, 0, 0),
            Background = SidebarBorderBrush(),
            Opacity = 0.75
        });
        grid.Children.Add(stack);
        return grid;
    }

    private Button CreateSubjectLibraryButton(SubjectEntry subject)
    {
        var card = new Border
        {
            MinHeight = 62,
            Margin = new Thickness(4, 3, 4, 3),
            Padding = new Thickness(10, 9, 10, 9),
            CornerRadius = new CornerRadius(10),
            BorderThickness = new Thickness(1),
            Background = new SolidColorBrush(Colors.Transparent),
            BorderBrush = SidebarBorderBrush(),
            HorizontalAlignment = HorizontalAlignment.Stretch
        };

        var grid = new Grid { ColumnSpacing = 10, HorizontalAlignment = HorizontalAlignment.Stretch };
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(4) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

        grid.Children.Add(new Border
        {
            Width = 3,
            CornerRadius = new CornerRadius(2),
            Background = SidebarAccentBrush()
        });

        var text = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Spacing = 2 };
        Grid.SetColumn(text, 1);
        text.Children.Add(new TextBlock
        {
            Text = subject.DisplayTitle,
            TextWrapping = TextWrapping.Wrap,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            FontSize = 14
        });
        text.Children.Add(new TextBlock
        {
            Text = subject.Subtitle,
            TextWrapping = TextWrapping.Wrap,
            Opacity = 0.62,
            FontSize = 11
        });
        grid.Children.Add(text);

        var timeBorder = new Border
        {
            VerticalAlignment = VerticalAlignment.Center,
            Padding = new Thickness(7, 3, 7, 3),
            CornerRadius = new CornerRadius(8),
            Background = SidebarPanelBrush(),
            MaxWidth = 100
        };
        Grid.SetColumn(timeBorder, 2);
        timeBorder.Child = new TextBlock
        {
            Text = subject.StudyTimeShort,
            Opacity = 0.72,
            FontSize = 10.5,
            TextWrapping = TextWrapping.Wrap,
            TextAlignment = TextAlignment.Center
        };
        grid.Children.Add(timeBorder);
        card.Child = grid;

        var button = new Button
        {
            Tag = subject,
            Content = card,
            Background = new SolidColorBrush(Colors.Transparent),
            BorderThickness = new Thickness(0),
            Padding = new Thickness(0),
            Margin = new Thickness(0),
            HorizontalAlignment = HorizontalAlignment.Stretch,
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            AllowFocusOnInteraction = false, // pointer/touch must not trigger ScrollViewer BringIntoView jumps; keyboard tab focus remains available.
            MinHeight = 0
        };
        Microsoft.UI.Xaml.Automation.AutomationProperties.SetName(button, $"Open {subject.Title}");
        button.Click += SubjectLibraryButton_Click;
        button.PointerPressed += SubjectLibraryButton_PointerPressed;
        button.RightTapped += SubjectLibraryButton_RightTapped;
        return button;
    }

    private Brush SidebarAccentBrush()
    {
        if (IsSystemHighContrast)
            return new SolidColorBrush(SystemUiColor(Windows.UI.ViewManagement.UIColorType.Accent, Colors.White));
        return TryBrush(SelectedTheme().ShellAccent, out var brush) ? brush : new SolidColorBrush(Colors.Teal);
    }

    private Brush SidebarBorderBrush()
    {
        if (IsSystemHighContrast)
            return new SolidColorBrush(SystemUiColor(Windows.UI.ViewManagement.UIColorType.Accent, Colors.White));
        return TryBrush(SelectedTheme().ShellBorder, out var brush) ? brush : new SolidColorBrush(Colors.Gray);
    }

    private Brush SidebarPanelBrush()
    {
        if (IsSystemHighContrast)
            return new SolidColorBrush(SystemUiColor(Windows.UI.ViewManagement.UIColorType.Background, Colors.Black));
        return TryBrush(SelectedTheme().ShellPanel, out var brush) ? brush : new SolidColorBrush(Colors.Transparent);
    }

    private static string StudyGroupLabel(SubjectEntry entry)
    {
        if (entry.IsExtra) return "EXTRAS & REFERENCE";
        if (entry.Number <= 1) return "START HERE";
        if (entry.Phase.Equals("Core subject sequence", StringComparison.OrdinalIgnoreCase)) return "CORE SUBJECT SEQUENCE";
        if (entry.Phase.Equals("Cross-cutting exam domains", StringComparison.OrdinalIgnoreCase)) return "CROSS-CUTTING EXAM DOMAINS";
        if (entry.Phase.Equals("Residual UWorld coverage", StringComparison.OrdinalIgnoreCase)) return "SUPPLEMENTAL COVERAGE";
        return entry.Phase.ToUpperInvariant();
    }

    private void CreateHomeTab()
    {
        _homeTab = new TabViewItem { Header = "Home", IsClosable = false, MinHeight = 44, Content = PrepareShellContent(CreateHomeView()) };
        Tabs.TabItems.Add(_homeTab);
        Tabs.SelectedItem = _homeTab;
        UpdateNavigationButtons();
    }

    private async void RootGrid_Loaded(object sender, RoutedEventArgs e)
    {
        RootGrid.Loaded -= RootGrid_Loaded;
        try
        {
            if (_settings.RestoreLastSession)
            {
                await RestoreLastSessionAsync();
                await RestoreSplitWorkspaceSessionAsync();
            }
        }
        finally
        {
            _sessionStartupComplete = true;
            SaveCurrentSession();
            await ShowPendingPersistenceNoticesAsync();
        }
    }

    private async Task RestoreLastSessionAsync()
    {
        var savedTabs = _settings.LastSessionTabs.ToList();
        var selectedIndex = _settings.LastSelectedTabIndex;
        var restoredTabs = new List<TabViewItem>();

        foreach (var saved in savedTabs)
        {
            TabViewItem? restored = null;
            if (saved.Kind.Equals("study", StringComparison.OrdinalIgnoreCase))
            {
                var subject = _catalog.Resolve(saved.Id);
                if (subject is not null)
                {
                    var before = Tabs.TabItems.OfType<TabViewItem>().ToHashSet();
                    var savedLocation = _personal.PositionFor(subject.ResourceId);
                    if (savedLocation is null && saved.HasLocation)
                    {
                        savedLocation = new StudyLocationState
                        {
                            SchemaVersion = 1, ResourceId = subject.ResourceId, SourceVersion = subject.ExpectedSha256, Purpose = "resume",
                            Hash = saved.Hash ?? "", ScrollX = saved.ScrollX, ScrollY = saved.ScrollY, UpdatedUtc = DateTimeOffset.UtcNow
                        };
                    }
                    await CreateStudyTabAsync(subject, saved.IsPinned, savedLocation);
                    restored = Tabs.TabItems.OfType<TabViewItem>().FirstOrDefault(x => !before.Contains(x))
                               ?? _studyTabs.FirstOrDefault(x => x.Value.Subject.ResourceId.Equals(subject.ResourceId, StringComparison.OrdinalIgnoreCase) && x.Value.ViewRole == CockpitViewRole.Primary).Key;
                }
            }
            else if (saved.Kind.Equals("shell", StringComparison.OrdinalIgnoreCase))
            {
                if (saved.Id.Equals("Search", StringComparison.OrdinalIgnoreCase)) OpenSpecialTab("Search", CreateUniversalSearchView());
                else if (saved.Id.Equals("Glossary", StringComparison.OrdinalIgnoreCase)) OpenSpecialTab("Glossary", CreateGlossaryView());
                else if (saved.Id.Equals("Journal", StringComparison.OrdinalIgnoreCase)) OpenSpecialTab("Journal", CreateJournalView());
                else if (saved.Id.Equals("UWorld Selector", StringComparison.OrdinalIgnoreCase)) OpenSpecialTab("UWorld Selector", CreateUWorldSelectorView());
                else if (saved.Id.Equals("Scratchpad", StringComparison.OrdinalIgnoreCase)) OpenSpecialTab("Scratchpad", CreateScratchpadView());
                restored = Tabs.TabItems.OfType<TabViewItem>().FirstOrDefault(x => x.Tag is string tag && tag.Equals("shell:" + saved.Id, StringComparison.OrdinalIgnoreCase));
            }
            if (restored is not null && !restoredTabs.Contains(restored)) restoredTabs.Add(restored);
        }

        if (restoredTabs.Count == 0) return;
        var safeIndex = Math.Clamp(selectedIndex, 0, restoredTabs.Count - 1);
        Tabs.SelectedItem = restoredTabs[safeIndex];
    }

    private PersistenceWriteResult SaveCurrentSession()
    {
        if (!_sessionStartupComplete || _deferSessionSaveUntilRestart) return PersistenceWriteResult.Ok(PathfinderPaths.SettingsPath);

        var tabs = new List<SessionTabState>();
        var selectedSavedIndex = 0;
        foreach (var item in Tabs.TabItems.OfType<TabViewItem>())
        {
            if (item == _homeTab) continue;
            if (_studyTabs.TryGetValue(item, out var study))
            {
                if (study.ViewRole != CockpitViewRole.Primary) continue; // read-only reference tabs are not ordinary session tabs; Split View persists their secondary identity separately.
                var location = study.LastKnownLocation ?? _personal.PositionFor(study.Subject.Slug);
                if (ReferenceEquals(Tabs.SelectedItem, item)) selectedSavedIndex = tabs.Count;
                tabs.Add(new SessionTabState
                {
                    Kind = "study",
                    Id = study.Subject.Slug,
                    IsPinned = study.IsPinned,
                    HasLocation = location is not null,
                    Hash = location?.Hash ?? "",
                    ScrollX = location?.ScrollX ?? 0,
                    ScrollY = location?.ScrollY ?? 0
                });
                continue;
            }

            if (item.Tag is string tag && tag.StartsWith("shell:", StringComparison.Ordinal))
            {
                if (ReferenceEquals(Tabs.SelectedItem, item)) selectedSavedIndex = tabs.Count;
                tabs.Add(new SessionTabState { Kind = "shell", Id = tag[6..] });
            }
        }

        _settings.LastSessionTabs = tabs;
        _settings.LastSelectedTabIndex = Math.Max(0, selectedSavedIndex);
        CaptureSplitWorkspaceSessionState();
        return SettingsService.Save(_settings);
    }

    private void CreateFatalHome(Exception ex)
    {
        _homeTab = new TabViewItem
        {
            Header = "Startup problem",
            IsClosable = false,
            MinHeight = 44,
            Content = MakeScrollableStack([
                MakeHeading("Pathfinder could not load the study library."),
                MakeBody(ex.Message),
                MakeBody($"Expected study-library folder: {PathfinderPaths.ContentRoot}")
            ])
        };
        Tabs.TabItems.Add(_homeTab);
        Tabs.SelectedItem = _homeTab;
    }

    private UIElement CreateHomeView()
    {
        var stack = new StackPanel { Spacing = 18, MaxWidth = 1080, HorizontalAlignment = HorizontalAlignment.Left };

        var hero = new Border
        {
            Padding = new Thickness(24, 22, 24, 22),
            CornerRadius = new CornerRadius(18),
            BorderThickness = new Thickness(1)
        };
        var heroStack = new StackPanel { Spacing = 10 };
        heroStack.Children.Add(new TextBlock
        {
            Text = "NIVAREQ  •  STEP 2 PATHFINDER",
            FontSize = 12,
            CharacterSpacing = 90,
            Opacity = .70,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            IsTextSelectionEnabled = true
        });
        heroStack.Children.Add(MakeHeading("Study with a map, not a pile."));
        heroStack.Children.Add(MakeLead("A focused Windows workspace for your USMLE® Step 2 CK study cockpits."));
        heroStack.Children.Add(MakeBody("Open a subject, keep several study tabs available, switch themes, use full screen when you want more room, and move between learning and question practice without losing your place."));

        var actions = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        actions.Children.Add(MakeActionButton("Start with Strategy", async (_, _) => await OpenBySlugAsync("strategy", false)));
        actions.Children.Add(MakeActionButton("Search all cockpits", (_, _) => OpenSpecialTabSafe("Search", CreateUniversalSearchView)));
        actions.Children.Add(MakeActionButton("Medical glossary", (_, _) => OpenGlossary()));
        actions.Children.Add(MakeActionButton("Journal", (_, _) => OpenJournal()));
        actions.Children.Add(MakeActionButton("UWorld Selector", (_, _) => OpenUWorldSelector()));
        actions.Children.Add(MakeActionButton("My Study", (_, _) => OpenAppSurfaceSafe("my-study", "My Study", CreateMyStudyView)));
        actions.Children.Add(MakeActionButton("Settings", (_, _) => OpenSettings("general")));
        actions.Children.Add(MakeActionButton("Accessibility", (_, _) => OpenSettings("accessibility")));
        actions.Children.Add(MakeActionButton("Study guide", (_, _) => OpenAppSurfaceSafe("guide", "Guide", CreateGuideView)));
        actions.SizeChanged += (_, e) => actions.Orientation = e.NewSize.Width < 760 ? Orientation.Vertical : Orientation.Horizontal;
        heroStack.Children.Add(actions);
        hero.Child = heroStack;
        RegisterThemedSurface(hero);
        stack.Children.Add(hero);
        stack.Children.Add(MakeHomeStudySnapshotCard());

        var cards = new Grid { ColumnSpacing = 12, RowSpacing = 12 };
        cards.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        cards.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        cards.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        cards.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        cards.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        cards.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        var navCard = MakeCard("Fast navigation", "Click or tap a subject to study it. Right-click, touch-and-hold, Ctrl+click, or middle-click when you want a separate tab. Back and Forward follow the active study tab.");
        var touchCard = MakeCard("Comfortable on touch", "Pinch to zoom and pan naturally on a touchscreen. Full screen is available when you want a larger reading surface.");
        var safetyCard = MakeCard("Pick up where you left off", "Pathfinder can reopen the tabs that were open the last time you used it and return each cockpit to its saved reading position. You can turn session restore on or off in Settings → Session & navigation.");
        cards.Children.Add(navCard); cards.Children.Add(touchCard); cards.Children.Add(safetyCard);

        void ArrangeHomeCards(double width)
        {
            var stacked = width < 780;
            cards.ColumnDefinitions[0].Width = new GridLength(1, GridUnitType.Star);
            cards.ColumnDefinitions[1].Width = stacked ? new GridLength(0) : new GridLength(1, GridUnitType.Star);
            cards.ColumnDefinitions[2].Width = stacked ? new GridLength(0) : new GridLength(1, GridUnitType.Star);
            Grid.SetColumn(navCard, 0); Grid.SetRow(navCard, 0);
            Grid.SetColumn(touchCard, stacked ? 0 : 1); Grid.SetRow(touchCard, stacked ? 1 : 0);
            Grid.SetColumn(safetyCard, stacked ? 0 : 2); Grid.SetRow(safetyCard, stacked ? 2 : 0);
        }
        ArrangeHomeCards(1080);
        cards.SizeChanged += (_, e) => ArrangeHomeCards(e.NewSize.Width);
        stack.Children.Add(cards);

        stack.Children.Add(MakeCard("Pathfinder themes", "Sixteen themes are available. Daytime reading options include Light, Parchment, Glacier, Sage Day, and Sunlit Apricot. Evening options include Dark, Ocean, Forest, Amber, Aurora, Ember Glow, and Twilight Bloom. OLED Black, OLED Pure, OLED Cyan, and OLED Amber provide OLED-friendly low-light palettes. The selected Pathfinder theme also styles the study cockpit."));
        stack.Children.Add(MakeCard("Suggested workflow", "First pass in Pathfinder → targeted UWorld or AMBOSS questions → review incorrect/guessed/slow items → return only to the weak Pathfinder module → later mixed blocks. The Guide app surface explains the full workflow."));
        stack.Children.Add(MakeBody("© 2026 NivareQ™. NivareQ Step 2 Pathfinder is an independent study tool and is not affiliated with or endorsed by FSMB, NBME, or the USMLE® program."));
        return WrapScrollableStack(stack);
    }

    private UIElement CreateGuideView()
    {
        var stack = new StackPanel { Spacing = 14, MaxWidth = 1020, HorizontalAlignment = HorizontalAlignment.Left };
        stack.Children.Add(MakeHeading("Pathfinder Study Manual"));
        stack.Children.Add(MakeLead("How to operate Pathfinder, understand the cockpit controls, and turn the material into active Step 2 learning rather than passive reading."));

        stack.Children.Add(MakeCard("START HERE · The basic learning loop", "1) Open one subject. 2) Use its orientation tools (Start / Decoder / Study map / Question moves when present). 3) Learn the core Topics in the complete mode. 4) Close the loop with Patterns, Drills, or Practice without looking up the answer first. 5) Do a targeted UWorld or AMBOSS block. 6) Review incorrect, guessed, and unusually slow questions. 7) Return only to the exact weak Pathfinder topic. 8) Re-test later with Recall/Rapid review and eventually mixed blocks."));
        stack.Children.Add(MakeCard("How to approach a NEW or weak subject", "Begin with the cockpit's Full Study / Full / Full Repair mode. Spend a few minutes on Start, Decoder, Study map, or Question moves so you know the subject's decision structure before memorizing details. Then work through Topics actively: before reading the next line, ask yourself what diagnosis, test, treatment, complication, or next step you expect. Use Patterns and specialized sections to learn how similar choices are separated. Finish with Drills or Practice closed-book."));
        stack.Children.Add(MakeCard("How to approach a subject you already know", "Do not automatically reread the whole cockpit. Start with 60-second Recall / Recall only, Rapid review, Focused, or A-priority mode. If recall is clean, move to questions. If a question exposes a gap, use the cockpit's own navigation/search to return to that exact concept. Full Study is there when the underlying map genuinely needs rebuilding."));
        stack.Children.Add(MakeCard("How to use active recall inside a cockpit", "Treat headings, patterns, algorithms, and question prompts as cues. Pause before revealing or reading the answer and say the next step out loud or in your head. For management topics, force yourself to name the immediate next action before reading further. For differential questions, state what feature separates the leading choices. Retrieval is the task; rereading is the repair step after retrieval fails."));

        stack.Children.Add(MakeHeading("What the cockpit controls mean"));
        stack.Children.Add(MakeCard("Start", "The cockpit's orientation/home section. Use it to understand what the subject resource contains and where to begin."));
        stack.Children.Add(MakeCard("Decoder / Question moves", "A decision-making layer: how to translate a vignette into the kind of answer the question is asking for. Use this early in a first pass and again when you notice that you know facts but still miss 'next best step' questions."));
        stack.Children.Add(MakeCard("Study map", "The subject's structure. Use it to see the sequence and relationships between major topic groups before diving into details."));
        stack.Children.Add(MakeCard("Topics", "The main teaching body. This is where the complete subject content lives. On a true first pass, this is the core of your study session."));
        stack.Children.Add(MakeCard("Patterns", "Recognition and discrimination rules. Use these to separate look-alike diagnoses, tests, and management choices. They are especially useful immediately before or after question-bank work."));
        stack.Children.Add(MakeCard("Specialized recognition sections", "Some cockpits add sections such as ECG, Murmurs, Localize, Signs, Formula lab, Screening, Bias, Abstracts, or Calculators. These are purpose-built skill areas. Practice them actively rather than reading them once."));
        stack.Children.Add(MakeCard("One-step deeper", "Second-order reasoning beyond simple recognition. Use it after the basic topic is understood to practice what happens next: confirmation, complication, management, or a related inference."));
        stack.Children.Add(MakeCard("Drills / Practice", "Original retrieval practice built into the cockpit. Answer before revealing feedback. Use these drills as a bridge from learning to application, not as a substitute for UWorld, AMBOSS, CMS forms, NBMEs, or official materials."));
        stack.Children.Add(MakeCard("Rapid review / Cram", "Compressed consolidation. Best after you have already learned the material, before a question block, or during later review. It is not meant to replace a first pass when the subject is weak."));
        stack.Children.Add(MakeCard("Sources", "Reference/provenance material. You usually do not need to study the source list itself. Use it when you want to understand where a rule came from or verify a time-sensitive point."));
        stack.Children.Add(MakeCard("Full Study / Full / Full Repair", "Show the complete teaching layer. Use for first learning, rebuilding a weak subject, or repairing a broad gap."));
        stack.Children.Add(MakeCard("60-second Recall / Recall only", "A retrieval-oriented compressed view. Use after a first pass, on a later day, or before questions to see what you can produce without rereading everything."));
        stack.Children.Add(MakeCard("Focused / Focused A-priority", "A cockpit-level high-priority filter for tighter study. Use when time is limited or when you need the most test-relevant decision points."));
                stack.Children.Add(MakeCard("Print", "Some supplemental cockpits include a Print control. Use it when you specifically want a paper/PDF study copy. Printing does not change the stored cockpit."));

        stack.Children.Add(MakeHeading("Using Pathfinder with UWorld or AMBOSS"));
        stack.Children.Add(MakeCard("Native UWorld Selector", "Extras & Reference now includes a native UWorld Selector directly below Clinical Recall Library. It is a manual planning/tracking tool: use Question mode Standard + Status Unused ONLY, then report the current Unused count yourself. Unknown is different from zero. The selector covers Pathfinder’s complete recipe set. Pathfinder never connects to or reads your UWorld account. The printable UWorld Checkbox Selector PDF remains available as a separate reference resource."));
        stack.Children.Add(MakeCard("Phase 1 · Learn the map", "For a weak or new subject, complete enough of the Pathfinder cockpit that you can explain the major diagnostic and management pathways. Do not wait for perfect memorization before starting questions."));
        stack.Children.Add(MakeCard("Phase 2 · Targeted questions", "Do a subject/system-matched UWorld or AMBOSS block. Around 20–40 questions is a practical block size when your schedule allows, but the exact number matters less than doing the questions actively. Commit to an answer before opening explanations."));
        stack.Children.Add(MakeCard("Phase 3 · Review three categories", "Review incorrect questions, questions you guessed correctly, and questions that took unusually long. A correct answer reached by shaky reasoning is still a useful learning signal."));
        stack.Children.Add(MakeCard("Phase 4 · Diagnose WHY you missed it", "Ask whether the miss was a knowledge gap, a recognition/discrimination problem, or a process error such as answering the wrong question. Then return to the relevant Pathfinder component: Topics for missing knowledge, Patterns/Decoder for discrimination, Question moves for process, or Drills for retrieval."));
        stack.Children.Add(MakeCard("Phase 5 · Close the loop", "After reviewing the explanation, state the corrected rule in your own words without looking. Then navigate back to the precise Pathfinder section and verify it. Avoid rereading an entire cockpit because of one missed item."));
        stack.Children.Add(MakeCard("Phase 6 · Transition to mixed blocks", "Use targeted blocks while building the subject map. As subjects become familiar, increasingly use mixed timed blocks so you must identify the domain yourself. Repeated weaknesses found in mixed blocks should send you back to a targeted Pathfinder repair, not a full restart."));

        stack.Children.Add(MakeHeading("A practical repeat schedule"));
        stack.Children.Add(MakeCard("Same day", "First pass or focused repair → a targeted question block → review misses/guesses → short Pathfinder lookup of exposed gaps."));
        stack.Children.Add(MakeCard("1–3 days later", "Use Recall/Rapid review and a small repeat set of questions or your normal scheduled block. The goal is to retrieve the decision rules again, not simply recognize that you have seen the page before."));
        stack.Children.Add(MakeCard("Later", "Shift toward mixed questions, CMS/NBME-style assessment, and short targeted returns to Pathfinder. Mature subjects should require less full rereading and more retrieval/application."));
        stack.Children.Add(MakeCard("If you are short on time", "Use My Study → Study planning & time estimates as a rough planning aid, then prioritize Recall/Rapid review, Focused/A-priority views, Patterns, and question-bank work. If a subject is fundamentally weak, do not force an artificial quick pass just to meet the estimate."));

        stack.Children.Add(MakeHeading("Pathfinder app controls"));
        stack.Children.Add(MakeSessionRestoreCard());
        stack.Children.Add(MakePersonalStudySettingsCard());
        stack.Children.Add(MakeCard("Accessibility & compatibility", "Use the Aa button or Ctrl+Shift+A to jump directly to Settings → Accessibility & display for optional focus, motion, and reading-spacing aids. Windows High Contrast, normal keyboard navigation, screen-reader names, Windows scaling, and native touch behavior remain compatibility foundations and do not need a special mode."));
        stack.Children.Add(MakeCard("Subject library", "The sidebar is grouped into Start Here, Core Subject Sequence, Cross-Cutting Exam Domains, Supplemental Coverage, and Extras & Reference. Every subject is its own bordered card/tile inside the group so the library scans as distinct study targets instead of a wall of text. Normal click/tap opens the subject in the current study tab. Right-click, touch-and-hold, middle-click, or Ctrl+click can request a new internal tab; if that same study resource is already open, Pathfinder activates its primary tab instead of creating a duplicate."));
        stack.Children.Add(MakeCard("Search all cockpits", "Use the ⌕ button or Ctrl+K to search the complete study library at once. Literal exact terms/phrases require normalized term boundaries, so a query such as ARDS does not become an exact hit inside an unrelated longer word. Exact source occurrences appear first and are highlighted; lower-ranked partial fallback can still surface useful fragments without labeling them exact. Search comparison is safely normalized for capitalization, accents/diacritics, common hyphens/dashes/separators, and whitespace. Curated medical aliases can connect an equivalent full name to the literal source term. No fuzzy or semantic guessing is used."));
        stack.Children.Add(MakeCard("Medical abbreviation glossary", "Pathfinder includes a shell-owned curated glossary/index of abbreviations and deterministic aliases found across the 23 study cockpits. Search it from Universal Search or the Medical glossary view. Type a single letter to browse abbreviations beginning with that letter; with 2+ characters the normal broad glossary search remains active. Glossary card text is selectable/copyable. Ambiguous abbreviations show every curated meaning instead of guessing which one applies."));
        stack.Children.Add(MakeCard("Right-click glossary lookup", "Inside a cockpit, select an abbreviation or term and right-click. The normal Edge/WebView2 context menu remains intact and gains a Pathfinder Glossary submenu. Exact glossary matches display their expansion immediately; choose one or Open glossary… for the full entry. Pathfinder does not analyze the surrounding sentence to choose a meaning—the student uses the context."));
        stack.Children.Add(MakeCard("Windows spelling/proofing", "The Universal Search and Glossary search fields keep native Windows proofing enabled. Misspelled medical words can show the normal red underline and Windows Proofing suggestions. Pathfinder keeps search matching deliberate rather than silently guessing at unrelated terms."));
        stack.Children.Add(MakeCard("Journal", "Journal is Pathfinder's multi-entry notes workspace. Create General notes, or use From Study/Add note to Journal to capture the source subject, exact source location when available, and selected cockpit text. Search scans the full title, body, and subject; filters separate All, General, and per-cockpit notes; and Backup/Restore includes Journal state. Older Personal subject notes are imported once into Journal; bookmark notes remain attached to bookmarks."));
        stack.Children.Add(MakeCard("Tabs", "Keep a few study resources or tool workspaces such as Search, Glossary, Journal or UWorld Selector open while studying. My Study, Settings and Guide are app surfaces rather than ordinary tabs. Right-click a study tab to pin it, bookmark the current place, reopen the most recently closed tab, close other tabs, or close tabs to the right. Ctrl+Shift+T walks backward through up to 10 recently closed study tabs and restores each tab's saved reading position. Each study tab has its own Back/Forward history."));
        stack.Children.Add(MakeCard("Back / Forward / Home", "Back and Forward apply to the active study tab. Home returns to the Pathfinder overview."));
        stack.Children.Add(MakeCard("One Pathfinder window", "Pathfinder runs as a single Windows instance. If you launch it again while it is already open, Windows redirects that launch to the existing Pathfinder window instead of creating a second process that could compete for the same local study state."));
        stack.Children.Add(MakeCard("Themes", "All thirteen themes style both Pathfinder and the study cockpit. Daytime: Light, Parchment, Glacier, Sage Day, Sunlit Apricot. Evening/night: Dark, OLED Black, Ocean, Forest, Amber, Aurora, Ember Glow, Twilight Bloom. Ember Glow is intentionally warmer/brighter than Amber; Twilight Bloom keeps low-light reading colorful rather than gloomy. Windows High Contrast still takes priority when active."));
        stack.Children.Add(MakeCard("Touch and zoom", "Pinch to zoom around the gesture and pan while zoomed. Touch navigation is designed to feel natural without extra controls."));
        stack.Children.Add(MakeCard("Full screen", "Use the ⛶ button or F11 for a true Windows full-screen study view. The app bar disappears, the tab strip moves to the very top, and your open study tabs remain available. On a touch tablet, a small floating ⤡ button remains in the top-right corner; keyboard users can press Esc or F11 to leave full screen."));
        stack.Children.Add(MakeCard("Study planning", "My Study → Study planning & time estimates contains the rough planning ranges. Quick = orientation/rapid pass, Standard = active first pass, Deep = slower study with more pausing/self-testing. Treat the ranges as planning aids, not deadlines."));
        stack.Children.Add(MakeCard("Progress", "Cockpit progress and saved state continue across normal app use on the same Windows profile."));

        stack.Children.Add(MakeHeading("Keyboard, mouse & touch shortcuts"));
        stack.Children.Add(MakeCard("Keyboard", "Ctrl+K = Universal Search · Ctrl+Shift+A = Accessibility & display · Ctrl+Alt+S = open/close Split View · Ctrl+Shift+T = reopen recently closed study tabs (repeat to walk backward through the stack) · Ctrl+W = close current tab · Ctrl+T = Home/new-tab entry point · Alt+Left = Back · Alt+Right = Forward · F11 = enter/leave full screen · Esc = leave full screen."));
        stack.Children.Add(MakeCard("Mouse", "Normal click = open in current unpinned study tab · Ctrl+click / middle-click / Open in new tab = open a different resource in a new tab, or activate the existing primary tab when that resource is already open · right-click a subject = subject actions · right-click a study tab = pin/bookmark/reopen/close-management actions · select cockpit text then right-click = native WebView2 menu plus Journal capture, Pathfinder Glossary, Search selection in Pathfinder, and mapped UWorld Selector tools."));
        stack.Children.Add(MakeCard("Split View", "Use ◫ Split or Ctrl+Alt+S to open/close an optional second workspace; it may stay empty until you deliberately choose Show beside. A parked beside view keeps running but its tab is hidden from the main strip, and ordinary main-tab/library clicks do not replace or auto-swap it. Return to tabs restores that exact tab, including read-only source-preview tabs; ⇄ Swap deliberately exchanges panes. Drag the divider to resize; double-click/tap it to return to a 50/50 split. Search, Glossary and Journal can participate like other tool workspaces."));
        stack.Children.Add(MakeCard("Touch", "Tap = normal activation · touch-and-hold a subject = context menu/new-tab options · pinch = native WebView2 zoom · pan while zoomed = native WebView2 panning · drag the Split View divider to resize · double-tap the divider for 50/50 · full-screen exit remains available from the small floating control when the app bar is hidden."));

        stack.Children.Add(MakeHeading("What NOT to do"));
        stack.Children.Add(MakeCard("Do not make Pathfinder another passive textbook", "If you can scroll for a long time without making yourself answer, predict, compare, or explain anything, stop and switch to recall or questions."));
        stack.Children.Add(MakeCard("Do not chase every source citation", "Use the teaching layer to learn. Sources are there for provenance and verification, not as a second syllabus you must memorize."));
        stack.Children.Add(MakeCard("Do not let one miss restart an entire subject", "Question-bank misses should trigger a targeted repair. Rebuild the whole cockpit only when the underlying framework is broadly weak."));
        stack.Children.Add(MakeCard("Do not treat estimates as performance targets", "Study-time ranges are rough. A difficult subject can legitimately take longer; a familiar one can take less."));

        stack.Children.Add(MakeBody("UWorld and AMBOSS are referenced descriptively. Pathfinder is independent and is not affiliated with or endorsed by those services, FSMB, NBME, or the USMLE® program."));
        return WrapScrollableStack(stack);
    }

    private UIElement CreateStudyTimeView()
    {
        var stack = new StackPanel { Spacing = 10, MaxWidth = 1050, HorizontalAlignment = HorizontalAlignment.Left };
        stack.Children.Add(MakeHeading("Time to study"));
        stack.Children.Add(MakeLead(_studyTimes.Data.Disclaimer));
        stack.Children.Add(MakeBody("These are rough planning estimates based on resource length and practice volume. Use them as ranges, not deadlines."));

        if (TryGetStudyTimeTotals(out var quick, out var standardMin, out var standardMax, out var deepMin, out var deepMax))
        {
            stack.Children.Add(MakeCard("Whole-suite rough totals",
                $"Quick: {StudyTimeService.FormatMinutes(quick)} · Standard: {StudyTimeService.FormatRange(standardMin, standardMax)} · Deep: {StudyTimeService.FormatRange(deepMin, deepMax)}"));
        }

        foreach (var e in _studyTimes.Data.Items)
        {
            stack.Children.Add(MakeCard(e.Title,
                $"Quick ≈ {StudyTimeService.FormatMinutes(e.QuickMinutes)}   |   Standard ≈ {StudyTimeService.FormatRange(e.StandardMinMinutes, e.StandardMaxMinutes)}   |   Deep ≈ {StudyTimeService.FormatRange(e.DeepMinMinutes, e.DeepMaxMinutes)}"));
        }
        stack.Children.Add(MakeBody(_studyTimes.Data.Formula));
        return WrapScrollableStack(stack);
    }

    private bool TryGetStudyTimeTotals(out int quick, out int standardMin, out int standardMax, out int deepMin, out int deepMax)
    {
        quick = standardMin = standardMax = deepMin = deepMax = 0;
        var totals = _studyTimes.Data.Totals;
        return totals.TryGetValue("quickMinutes", out quick)
            && totals.TryGetValue("standardMinMinutes", out standardMin)
            && totals.TryGetValue("standardMaxMinutes", out standardMax)
            && totals.TryGetValue("deepMinMinutes", out deepMin)
            && totals.TryGetValue("deepMaxMinutes", out deepMax);
    }

    private static ScrollViewer WrapScrollableStack(StackPanel stack)
    {
        stack.Padding = new Thickness(28, 24, 28, 60);
        return new ScrollViewer
        {
            Content = stack,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto
        };
    }

    private static ScrollViewer MakeScrollableStack(params UIElement[] elements)
    {
        var stack = new StackPanel { Spacing = 12, Padding = new Thickness(28, 24, 28, 60) };
        foreach (var element in elements) stack.Children.Add(element);
        return new ScrollViewer { Content = stack, HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
    }

    private static TextBlock MakeHeading(string text) => new() { Text = text, FontSize = 32, FontWeight = Microsoft.UI.Text.FontWeights.SemiBold, TextWrapping = TextWrapping.Wrap, IsTextSelectionEnabled = true };
    private static TextBlock MakeLead(string text) => new() { Text = text, FontSize = 18, Opacity = .78, TextWrapping = TextWrapping.Wrap, MaxWidth = 900, IsTextSelectionEnabled = true };
    private static TextBlock MakeBody(string text) => new() { Text = text, FontSize = 14, Opacity = .82, TextWrapping = TextWrapping.Wrap, MaxWidth = 930, IsTextSelectionEnabled = true };

    private Border MakeSessionRestoreCard()
    {
        var stack = new StackPanel { Spacing = 8 };
        stack.Children.Add(new TextBlock
        {
            Text = "Continue where you left off",
            FontSize = 17,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });
        stack.Children.Add(new TextBlock
        {
            Text = "Useful after an accidental close: Pathfinder can reopen your study-resource and tool-workspace tabs, preserve pinned study tabs, and return study cockpits to their saved reading positions. App surfaces such as Settings/Guide are opened on demand rather than restored as tabs.",
            FontSize = 14,
            Opacity = .78,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });
        var restore = new CheckBox
        {
            Content = "Reopen my last tabs when Pathfinder starts",
            IsChecked = _settings.RestoreLastSession,
            MinHeight = 36
        };
        restore.Checked += (_, _) =>
        {
            _settings.RestoreLastSession = true;
            QueuePersistenceFailureNotice(SaveCurrentSession(), "Session state");
        };
        restore.Unchecked += (_, _) =>
        {
            _settings.RestoreLastSession = false;
            QueuePersistenceFailureNotice(SaveCurrentSession(), "Session state");
        };
        stack.Children.Add(restore);
        stack.Children.Add(new TextBlock
        {
            Text = "Tip: Ctrl+Shift+T reopens the newest closed study tab. My Study keeps a short recently-closed list for the current session.",
            FontSize = 12,
            Opacity = .68,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });

        var card = new Border
        {
            Child = stack,
            Padding = new Thickness(16),
            CornerRadius = new CornerRadius(12),
            BorderThickness = new Thickness(1)
        };
        RegisterThemedSurface(card);
        return card;
    }

    private Border MakeCard(string title, string body)
    {
        var s = new StackPanel { Spacing = 6 };
        s.Children.Add(new TextBlock { Text = title, FontSize = 17, FontWeight = Microsoft.UI.Text.FontWeights.SemiBold, TextWrapping = TextWrapping.Wrap, IsTextSelectionEnabled = true });
        s.Children.Add(new TextBlock { Text = body, FontSize = 14, Opacity = .78, TextWrapping = TextWrapping.Wrap, IsTextSelectionEnabled = true });
        var card = new Border { Child = s, Padding = new Thickness(16), CornerRadius = new CornerRadius(12), BorderThickness = new Thickness(1) };
        RegisterThemedSurface(card);
        return card;
    }

    private void RegisterThemedSurface(Border surface)
    {
        _themedSurfaces.Add(surface);
        if (ThemeCombo.SelectedItem is ThemeChoice theme) ApplySurfaceTheme(surface, theme);
    }

    private void ApplySurfaceTheme(Border surface, ThemeChoice theme)
    {
        if (IsSystemHighContrast)
        {
            surface.Background = new SolidColorBrush(SystemUiColor(Windows.UI.ViewManagement.UIColorType.Background, Colors.Black));
            surface.BorderBrush = new SolidColorBrush(SystemUiColor(Windows.UI.ViewManagement.UIColorType.Accent, Colors.White));
            return;
        }
        if (TryBrush(theme.ShellPanel, out var panel)) surface.Background = panel;
        if (TryBrush(theme.ShellBorder, out var border)) surface.BorderBrush = border;
    }

    private static Button MakeActionButton(string label, RoutedEventHandler handler)
    {
        var b = new Button { Content = label, MinHeight = 44, Padding = new Thickness(14, 8, 14, 8) };
        b.Click += handler;
        return b;
    }

    private async Task<CoreWebView2Environment> GetWebEnvironmentAsync()
    {
        Directory.CreateDirectory(PathfinderPaths.WebViewDataRoot);
        _environmentTask ??= CreateWebEnvironmentAsync();
        return await _environmentTask;
    }

    private static async Task<CoreWebView2Environment> CreateWebEnvironmentAsync()
    {
        return await CoreWebView2Environment.CreateWithOptionsAsync(
            null,
            PathfinderPaths.WebViewDataRoot,
            new CoreWebView2EnvironmentOptions());
    }

    private async Task OpenBySlugAsync(string slug, bool newTab)
    {
        var entry = _catalog.Resolve(slug);
        if (entry is not null) await OpenSubjectAsync(entry, newTab);
    }

    private async Task OpenSubjectAsync(SubjectEntry subject, bool newTab, bool explicitSecondary = false)
    {
        CloseAppSurface(restorePreviousTab: false);
        if (FindPrimaryStudyContext(subject.ResourceId) is { } alreadyOpen)
        {
            if (!explicitSecondary && TryHandleAlreadyParkedBeside(alreadyOpen.Tab))
            {
                ClosePaneIfOverlay();
                return;
            }
            if (newTab && explicitSecondary && subject.ContentType.Equals("html", StringComparison.OrdinalIgnoreCase))
            {
                await CaptureCockpitStateSnapshotAsync(alreadyOpen);
                var sourceLocation = await CaptureStrictSourceLocationAsync(alreadyOpen) ?? alreadyOpen.LastKnownLocation;
                await CreateStudyTabAsync(subject, false, sourceLocation, null, CockpitViewRole.ReadOnlySecondary);
            }
            else
            {
                Tabs.SelectedItem = alreadyOpen.Tab;
            }
            ClosePaneIfOverlay();
            return;
        }

        if (subject.ContentType.Equals("pdf", StringComparison.OrdinalIgnoreCase) || subject.IsExtra)
            newTab = true; // Extras never destroy the user's active study subject.

        if (!newTab && Tabs.SelectedItem is TabViewItem active && _studyTabs.TryGetValue(active, out var existing) && existing.ViewRole == CockpitViewRole.Primary && !existing.IsPinned)
        {
            await CaptureCockpitStateSnapshotAsync(existing);
            await CapturePositionAsync(existing);
            CancelLocationRequests(existing, "resource-replaced");
            existing.PendingRestore = null;
            existing.PendingSearchResult = null;
            await NavigateStudyTabAsync(existing, subject);
            ClosePaneIfOverlay();
            return;
        }

        await CreateStudyTabAsync(subject);
        ClosePaneIfOverlay();
    }

    private async Task CreateStudyTabAsync(SubjectEntry subject, bool isPinned = false, StudyLocationState? restoreOverride = null, UniversalSearchResult? searchResult = null, CockpitViewRole viewRole = CockpitViewRole.Primary)
    {
        if (viewRole == CockpitViewRole.Primary && FindPrimaryStudyContext(subject.ResourceId) is { } existingPrimary)
        {
            Tabs.SelectedItem = existingPrimary.Tab;
            return;
        }

        var web = new WebView2
        {
            HorizontalAlignment = HorizontalAlignment.Stretch,
            VerticalAlignment = VerticalAlignment.Stretch,
            Visibility = Visibility.Visible,
            Opacity = 1
        };
        Microsoft.UI.Xaml.Automation.AutomationProperties.SetName(web, $"{subject.Title} study cockpit");
        Microsoft.UI.Xaml.Automation.AutomationProperties.SetHelpText(web, "Embedded Pathfinder study content. Use Tab and Shift+Tab for interactive controls; browser zoom and touch gestures remain native.");
        var grid = new Grid
        {
            HorizontalAlignment = HorizontalAlignment.Stretch,
            VerticalAlignment = VerticalAlignment.Stretch
        };
        // Native host chrome gets its own row. The source-return bar must never overlay
        // a cockpit's sticky navigation/content surface.
        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        var ring = new ProgressRing { IsActive = true, Width = 36, Height = 36, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
        var status = new TextBlock
        {
            TextWrapping = TextWrapping.Wrap,
            Margin = new Thickness(28),
            MaxWidth = 900,
            Visibility = Visibility.Collapsed,
            HorizontalAlignment = HorizontalAlignment.Left,
            VerticalAlignment = VerticalAlignment.Top,
            IsTextSelectionEnabled = true
        };
        var returnButton = new Button { Content = "Return to previous position" };
        var returnBar = new InfoBar
        {
            IsOpen = false,
            Visibility = Visibility.Collapsed,
            Severity = InfoBarSeverity.Informational,
            IsClosable = true,
            Title = "Source jump",
            Message = "Your previous study position is available.",
            ActionButton = returnButton,
            Margin = new Thickness(8, 6, 8, 4),
            HorizontalAlignment = HorizontalAlignment.Stretch,
            VerticalAlignment = VerticalAlignment.Top
        };
        Grid.SetRow(returnBar, 0);
        Grid.SetRow(web, 1);
        Grid.SetRow(ring, 1);
        Grid.SetRow(status, 1);
        grid.Children.Add(returnBar);
        grid.Children.Add(web);
        grid.Children.Add(ring);
        grid.Children.Add(status);
        var tab = new TabViewItem { Header = subject.Title, IsClosable = true, MinHeight = 44, Content = grid };
        var context = new StudyTabContext(subject, web, tab, ring, status, returnBar)
        {
            ViewRole = viewRole,
            Lifecycle = CockpitHostLifecycle.Created,
            IsPinned = viewRole == CockpitViewRole.Primary && isPinned,
            PendingRestore = searchResult is null ? restoreOverride : null,
            PendingSearchReturnLocation = searchResult is null ? null : CloneLocation(restoreOverride),
            LastKnownLocation = restoreOverride,
            PendingSearchResult = searchResult
        };
        if (viewRole == CockpitViewRole.ReadOnlySecondary)
        {
            returnBar.Title = "Read-only reference view";
            returnBar.Message = "This reference cockpit can scroll, zoom, select and copy, but it does not save study progress. The primary cockpit is the view that saves progress.";
            returnBar.ActionButton = null;
            returnBar.IsClosable = false;
            returnBar.Visibility = Visibility.Visible;
            returnBar.IsOpen = true;
        }
        returnButton.Click += async (_, _) => await ReturnToPreviousStudyPositionAsync(context);
        ConfigureStudyTabPersonalFeatures(context);
        web.Loaded += (_, _) => LogStudyEvent(context, "xaml-loaded", $"{web.ActualWidth:0}x{web.ActualHeight:0}; visibility={web.Visibility}; opacity={web.Opacity:0.##}");
        web.Unloaded += (_, _) => LogStudyEvent(context, "xaml-unloaded", $"{web.ActualWidth:0}x{web.ActualHeight:0}");
        web.SizeChanged += (_, e) =>
        {
            if (e.NewSize.Width < 2 || e.NewSize.Height < 2 || e.PreviousSize.Width < 2 || e.PreviousSize.Height < 2)
                LogStudyEvent(context, "xaml-size", $"{e.PreviousSize.Width:0}x{e.PreviousSize.Height:0} -> {e.NewSize.Width:0}x{e.NewSize.Height:0}");
        };
        _studyTabs[tab] = context;
        Tabs.TabItems.Add(tab);
        Tabs.SelectedItem = tab;
        QueuePersistenceFailureNotice(SaveCurrentSession(), "Session state");

        var initializationEpoch = CaptureRuntimeMutationEpoch();
        try
        {
            context.Lifecycle = CockpitHostLifecycle.Initializing;
            var env = await GetWebEnvironmentAsync();
            if (!IsRuntimeMutationCurrent(initializationEpoch, context)) return;
            await web.EnsureCoreWebView2Async(env);
            if (!IsRuntimeMutationCurrent(initializationEpoch, context)) return;
            // Public release: preserve the native WebView2 context menu, but do not expose
            // developer tooling/Inspect to students.
            web.CoreWebView2.Settings.AreDevToolsEnabled = false;
            web.CoreWebView2.NavigationStarting += (_, e) => WebNavigationStarting(context, e);
            web.CoreWebView2.NavigationCompleted += (_, e) => WebNavigationCompleted(context, e);
            web.CoreWebView2.ContentLoading += (_, _) => LogStudyEvent(context, "content-loading", web.CoreWebView2.Source ?? "");
            web.CoreWebView2.DOMContentLoaded += (_, _) => LogStudyEvent(context, "dom-content-loaded", web.CoreWebView2.Source ?? "");
            web.CoreWebView2.SourceChanged += (_, _) => LogStudyEvent(context, "source-changed", web.CoreWebView2.Source ?? "");
            web.CoreWebView2.HistoryChanged += (_, _) => { UpdateNavigationButtons(); UpdateSecondaryWorkspaceChrome(); };
            web.CoreWebView2.NewWindowRequested += (_, e) => WebNewWindowRequested(context, e);
            web.CoreWebView2.WebMessageReceived += (_, e) => HandleStudyWebMessage(context, e);
            web.CoreWebView2.ContextMenuRequested += (_, e) =>
            {
                // Snapshot the actual DOM selection as soon as WebView2 opens the context menu.
                // Waiting until a custom command is clicked can let the browser/context-menu
                // interaction collapse or narrow a multi-block selection. The task starts the
                // ExecuteScriptAsync request immediately and is awaited only if the user invokes
                // a selection-dependent Pathfinder action.
                Task<string>? contextSelectionSnapshot = null;
                if (e.ContextMenuTarget.HasSelection)
                {
                    var fallbackSelection = (e.ContextMenuTarget.SelectionText ?? "").Trim();
                    if (fallbackSelection.Length > 12000) fallbackSelection = fallbackSelection[..12000];
                    contextSelectionSnapshot = CaptureLiveSelectionTextAsync(context, fallbackSelection);
                }
                AddJournalContextMenu(context, e, contextSelectionSnapshot);
                AddGlossaryContextMenu(context, e);
                AddPathfinderToolsContextMenu(context, e, contextSelectionSnapshot);
            };
            web.CoreWebView2.ProcessFailed += (_, e) =>
            {
                context.Lifecycle = CockpitHostLifecycle.Failed;
                context.DocumentHealthy = false;
                context.CaptureAuthorityReady = false;
                context.LastProcessFailureKind = e.ProcessFailedKind.ToString();
                CancelLocationRequests(context, "process-failed");
                LogStudyEvent(context, "process-failed", context.LastProcessFailureKind);
                var browserExited = context.LastProcessFailureKind.Equals("BrowserProcessExited", StringComparison.OrdinalIgnoreCase);
                ShowStudyError(context, browserExited
                    ? $"The embedded browser process exited ({e.ProcessFailedKind}). This view cannot be safely reloaded in place. Close Pathfinder and reopen it; your saved study state will be restored in a fresh browser environment."
                    : $"The embedded study renderer stopped unexpectedly ({e.ProcessFailedKind}). Use Reload cockpit safely below; Pathfinder will recreate the study view from your saved state without using the failed page as a source of progress.");
                ShowCockpitRecoveryAction(context);
            };
            LogStudyEvent(context, "webview-ready", "Pathfinder cockpit theme adapter enabled");
            // INTENTIONAL: no custom pinch/zoom/pan handlers and no zoom-setting overrides.
            // Native Edge/WebView2 touch behavior is preserved as requested.
            await NavigateStudyTabAsync(context, subject);
        }
        catch (Exception ex)
        {
            ShowStudyError(context, "Unable to initialize the study view: " + ex.Message);
        }
    }

    private async Task NavigateStudyTabAsync(StudyTabContext context, SubjectEntry subject)
    {
        if (context.WebView.CoreWebView2 is null)
            throw new InvalidOperationException("The WebView2 study surface is not initialized.");

        var target = _runtimeContent.Prepare(subject);
        context.ContentGeneration++;
        context.Lifecycle = CockpitHostLifecycle.Navigating;
        context.CaptureAuthorityReady = false;
        context.DocumentHealthy = false;
        context.LastProcessFailureKind = "";
        CancelLocationRequests(context, "navigate-resource");
        ClearSourceJumpReturn(context);
        context.Subject = subject;
        Microsoft.UI.Xaml.Automation.AutomationProperties.SetName(context.WebView, $"{subject.Title} study cockpit");
        if (context.PendingSearchResult is null && context.ViewRole == CockpitViewRole.Primary)
            context.PendingRestore ??= _personal.PositionFor(subject.ResourceId);
        else if (context.PendingSearchResult is not null)
            context.PendingRestore = null;
        context.LastKnownLocation = context.PendingRestore;
        UpdateStudyTabHeader(context);
        if (context.ViewRole == CockpitViewRole.Primary) TouchRecentSubject(subject);
        QueuePersistenceFailureNotice(SaveCurrentSession(), "Session state");
        context.Loading.IsActive = true;
        context.Loading.Visibility = Visibility.Visible;
        context.Status.Visibility = Visibility.Collapsed;

        // Each cockpit receives a short, reserved .invalid virtual origin backed by a
        // byte-identical runtime copy. This avoids fragile deep Windows paths, keeps
        // browser storage isolated per cockpit, and preserves the bundled medical files.
        var host = context.ViewRole == CockpitViewRole.Primary
            ? target.Host
            : $"r{subject.Number:D3}-{context.ViewId.ToString("N")[..10]}{PathfinderPaths.InternalHostSuffix}";
        context.ContentHost = host;
        context.WebView.CoreWebView2.SetVirtualHostNameToFolderMapping(
            host,
            target.Folder,
            CoreWebView2HostResourceAccessKind.DenyCors);
        await PrepareCockpitDocumentBridgeAsync(context);
        var baseUri = new Uri($"https://{host}/{Uri.EscapeDataString(Path.GetFileName(target.LocalFile))}");
        LogStudyEvent(context, "navigate-request", baseUri.AbsoluteUri);
        var navigationUri = NavigationUriWithSavedHash(baseUri, context.PendingRestore);
        context.WebView.CoreWebView2.Navigate(navigationUri.AbsoluteUri);
    }

    private async void WebNavigationCompleted(StudyTabContext context, CoreWebView2NavigationCompletedEventArgs e)
    {
        context.Loading.IsActive = false;
        context.Loading.Visibility = Visibility.Collapsed;

        if (!e.IsSuccess)
        {
            context.Lifecycle = CockpitHostLifecycle.Failed;
            context.DocumentHealthy = false;
            context.CaptureAuthorityReady = false;
            LogStudyEvent(context, "navigation-failed", e.WebErrorStatus.ToString());
            ShowStudyError(context, $"The cockpit could not be displayed ({e.WebErrorStatus}). Use Reload cockpit safely below. If it repeats, send the exact message together with: {PathfinderPaths.DiagnosticsPath}");
            ShowCockpitRecoveryAction(context);
            return;
        }

        context.Status.Visibility = Visibility.Collapsed;
        var presenterFixed = EnsureTabContentPresenterStretch();
        LogStudyEvent(context, "navigation-completed", context.WebView.CoreWebView2?.Source ?? "");
        LogStudyEvent(context, "layout-guard", $"tabContentPresenterStretch={presenterFixed}; web={context.WebView.ActualWidth:0}x{context.WebView.ActualHeight:0}; tabs={Tabs.ActualWidth:0}x{Tabs.ActualHeight:0}");
        RefreshTabIdentityFromSource(context);
        UpdateStudyTabHeader(context);
        UpdateNavigationButtons();
        await ApplyCockpitHostPresentationAsync(context, SelectedTheme());
        if (context.PendingRestore is { } pending)
        {
            await RestoreStudyLocationAsync(context, pending);
            context.PendingRestore = null;
        }
        await InstallPositionBridgeAsync(context);
        if (context.PendingSearchResult is { } searchResult)
        {
            var returnLocation = context.PendingSearchReturnLocation;
            var request = BeginLocationRequest(context, "search");
            var jumped = await JumpToSearchResultAsync(context, searchResult, request);
            context.PendingSearchResult = null;
            context.PendingSearchReturnLocation = null;
            if (jumped && returnLocation is not null)
            {
                ArmSourceJumpReturn(context, returnLocation, null);
            }
            else if (!jumped && returnLocation is not null)
            {
                var rollbackRequest = BeginLocationRequest(context, "search-first-open-rollback");
                await ApplyPathfinderLocationAsync(context, returnLocation, rollbackRequest, persistResume: true);
            }
        }
        context.DocumentHealthy = true;
        await FinalizeCockpitHostReadyAsync(context);
        context.CaptureAuthorityReady = context.ViewRole == CockpitViewRole.Primary;
        if (context.ViewRole == CockpitViewRole.Primary) _ = CapturePositionAsync(context);
    }

    private void ShowStudyError(StudyTabContext context, string message)
    {
        context.Loading.IsActive = false;
        context.Loading.Visibility = Visibility.Collapsed;
        context.Status.Text = message;
        context.Status.Visibility = Visibility.Visible;
    }

    private void RefreshTabIdentityFromSource(StudyTabContext context)
    {
        var source = context.WebView.CoreWebView2?.Source;
        if (!Uri.TryCreate(source, UriKind.Absolute, out var uri)) return;
        var match = _runtimeContent.SubjectForHost(uri.Host);
        if (match is null) return;
        context.Subject = match;
        UpdateStudyTabHeader(context);
    }

    private async void WebNavigationStarting(StudyTabContext context, CoreWebView2NavigationStartingEventArgs e)
    {
        LogStudyEvent(context, "navigation-starting", e.Uri ?? "");
        if (!Uri.TryCreate(e.Uri, UriKind.Absolute, out var uri)) return;

        if (_runtimeContent.IsInternalHost(uri.Host))
        {
            var targetSubject = _runtimeContent.SubjectForHost(uri.Host);
            if (targetSubject is null || targetSubject.ResourceId.Equals(context.Subject.ResourceId, StringComparison.OrdinalIgnoreCase))
                return;

            // Browser Back/Forward can otherwise move this WebView to a different cockpit host
            // without passing through NavigateStudyTabAsync, leaving generation and Primary
            // ownership behind. Cancel cross-resource history and re-enter the canonical route.
            e.Cancel = true;
            try
            {
                if (context.ViewRole == CockpitViewRole.Primary
                    && FindPrimaryStudyContext(targetSubject.ResourceId) is { } existingPrimary
                    && !ReferenceEquals(existingPrimary, context))
                {
                    Tabs.SelectedItem = existingPrimary.Tab;
                    return;
                }

                if (context.ViewRole == CockpitViewRole.Primary && context.DocumentHealthy)
                {
                    await CaptureCockpitStateSnapshotAsync(context);
                    await CapturePositionAsync(context);
                }
                await NavigateStudyTabAsync(context, targetSubject);
            }
            catch (Exception ex)
            {
                ShowStudyError(context, "Pathfinder could not safely follow browser history to the other cockpit: " + ex.Message);
            }
            return;
        }

        if (uri.Scheme.Equals("about", StringComparison.OrdinalIgnoreCase)) return;
        e.Cancel = true;
        try { await Launcher.LaunchUriAsync(uri); } catch { }
    }

    private async void WebNewWindowRequested(StudyTabContext context, CoreWebView2NewWindowRequestedEventArgs e)
    {
        e.Handled = true;
        if (!Uri.TryCreate(e.Uri, UriKind.Absolute, out var uri)) return;
        if (_runtimeContent.IsInternalHost(uri.Host))
        {
            var subject = _runtimeContent.SubjectForHost(uri.Host) ?? context.Subject;
            await OpenSubjectAsync(subject, true, true);
        }
        else
        {
            try { await Launcher.LaunchUriAsync(uri); } catch { }
        }
    }

    private async Task ApplyThemeToAllWebViewsAsync(ThemeChoice theme)
    {
        foreach (var ctx in _studyTabs.Values)
            if (ctx.WebView.CoreWebView2 is not null) await ApplyCockpitHostPresentationAsync(ctx, theme);
        if (_scratchpadWeb?.CoreWebView2 is not null)
            PostScratchpadTheme(_scratchpadWeb, theme);
    }

    private async Task ApplyThemeToWebViewAsync(WebView2 web, ThemeChoice theme)
    {
        if (web.CoreWebView2 is null) return;

        // Runtime-only presentation adapter. It never writes to the frozen medical HTML.
        // In Windows High Contrast, custom Pathfinder palette CSS is deliberately withheld so
        // Edge/WebView2 can expose the user's forced-color scheme instead of fighting it.
        var css = "";
        if (IsSystemHighContrast)
        {
            css += "@media (forced-colors: active){html,body,*{forced-color-adjust:auto;}}";
        }
        else
        {
            var track = theme.ShellBackground ?? (theme.IsDark ? "#000000" : "#FFFFFF");
            var thumb = theme.ShellBorder ?? theme.ShellMuted ?? theme.ShellAccent ?? "#808080";
            var hover = theme.ShellAccent ?? thumb;
            var scrollbarCss = $"html,*{{scrollbar-color:{thumb} {track};}}" +
                               $"::-webkit-scrollbar-track{{background:{track}!important;}}" +
                               $"::-webkit-scrollbar-thumb{{background:{thumb}!important;border:2px solid {track}!important;border-radius:999px!important;}}" +
                               $"::-webkit-scrollbar-thumb:hover{{background:{hover}!important;}}";
            css += (theme.ContentCss ?? "") + scrollbarCss;
        }

        if (ShouldReduceMotion)
            css += "*,*::before,*::after{scroll-behavior:auto!important;transition-duration:.001ms!important;transition-delay:0s!important;animation-duration:.001ms!important;animation-delay:0s!important;animation-iteration-count:1!important;}";
        if (_settings.StrongFocusIndicators)
            css += ":focus-visible{outline:3px solid Highlight!important;outline-offset:3px!important;box-shadow:0 0 0 1px Canvas!important;}";
        if (_settings.ComfortableReadingSpacing)
            css += "p,li,td,th,dd,blockquote{line-height:1.65!important;}p,li,dd{letter-spacing:.01em;}";

        var cssJson = JsonSerializer.Serialize(css);
        var js = $$"""
            (() => {
              let el=document.getElementById('nivareq-pathfinder-shell-theme');
              if(el) el.remove();
              if(!document.documentElement.lang) document.documentElement.lang='en';
              const css={{cssJson}};
              if(css) { el=document.createElement('style'); el.id='nivareq-pathfinder-shell-theme'; el.textContent=css; document.head.appendChild(el); }
            })()
            """;
        try { await web.CoreWebView2.ExecuteScriptAsync(js); } catch { }
    }

    private ThemeChoice SelectedTheme() => ThemeCombo.SelectedItem as ThemeChoice ?? _themes.DefaultTheme;

    private static void LogStudyEvent(StudyTabContext context, string stage, string detail)
    {
        try
        {
            Directory.CreateDirectory(PathfinderPaths.AppDataRoot);
            var safeDetail = (detail ?? "").Replace("\r", " ").Replace("\n", " ");
            var line = $"{DateTimeOffset.Now:O}\t{context.Subject.Slug}\t{stage}\t{safeDetail}{Environment.NewLine}";
            lock (DiagnosticLock) File.AppendAllText(PathfinderPaths.DiagnosticsPath, line);
        }
        catch { /* diagnostics must never interfere with studying */ }
    }

    private void SelectSavedTheme()
    {
        _suppressThemeEvent = true;
        var selected = _themes.Registry.Themes.FirstOrDefault(t => t.Id.Equals(_settings.ThemeId, StringComparison.OrdinalIgnoreCase)) ?? _themes.DefaultTheme;
        ThemeCombo.SelectedItem = selected;
        ApplyThemeToShell(selected);
        _suppressThemeEvent = false;
    }

    private void ApplyThemeToShell(ThemeChoice theme)
    {
        if (IsSystemHighContrast)
        {
            ApplySystemHighContrastShell();
            return;
        }

        RootGrid.RequestedTheme = theme.IsDark ? ElementTheme.Dark : ElementTheme.Light;

        if (TryBrush(theme.ShellBackground, out var bg))
        {
            RootGrid.Background = bg;
            ShellSplit.Background = bg;
            MainContentHost.Background = bg;
            Tabs.Background = bg;
            AppSurfaceHost.Background = bg;
            SetShellResourceBrush("CardBackgroundFillColorDefaultBrush", theme.ShellBackground);

            SetShellResourceBrush("TabViewBackground", theme.ShellBackground);
            SetShellResourceBrush("TabViewItemHeaderBackground", theme.ShellBackground);
            SetShellResourceBrush("TabViewButtonBackground", theme.ShellBackground);
            SetShellResourceBrush("TabViewScrollButtonBackground", theme.ShellBackground);

            SetShellResourceBrush("ScrollBarBackground", theme.ShellBackground);
            SetShellResourceBrush("ScrollBarTrackFill", theme.ShellBackground);
            SetShellResourceBrush("ScrollBarTrackFillPointerOver", theme.ShellBackground);
            SetShellResourceBrush("ScrollBarTrackStroke", theme.ShellBackground);
            SetShellResourceBrush("ScrollBarTrackStrokePointerOver", theme.ShellBackground);
        }
        if (TryBrush(theme.ShellPanel, out var panel))
        {
            TopBar.Background = panel;
            PaneBorder.Background = panel;
            AppSurfaceHeader.Background = panel;

            SetShellResourceBrush("TabViewItemHeaderBackgroundSelected", theme.ShellPanel);
            SetShellResourceBrush("TabViewItemHeaderBackgroundPointerOver", theme.ShellPanel);
            SetShellResourceBrush("TabViewItemHeaderDragBackground", theme.ShellPanel);
            SetShellResourceBrush("TabViewButtonBackgroundPointerOver", theme.ShellPanel);
            SetShellResourceBrush("TabViewScrollButtonBackgroundPointerOver", theme.ShellPanel);
        }
        if (TryBrush(theme.ShellBorder, out var border))
        {
            TopBar.BorderBrush = border;
            PaneBorder.BorderBrush = border;
            AppSurfaceHeader.BorderBrush = border;
            SetShellResourceBrush("CardStrokeColorDefaultBrush", theme.ShellBorder);

            SetShellResourceBrush("TabViewBorderBrush", theme.ShellBorder);
            SetShellResourceBrush("TabViewItemSeparator", theme.ShellBorder);
            SetShellResourceBrush("TabViewItemBorderBrush", theme.ShellBorder);
            SetShellResourceBrush("TabViewItemHeaderBackgroundPressed", theme.ShellBorder);
            SetShellResourceBrush("TabViewButtonBackgroundPressed", theme.ShellBorder);
            SetShellResourceBrush("TabViewScrollButtonBackgroundPressed", theme.ShellBorder);

            SetShellResourceBrush("ScrollBarThumbFill", theme.ShellBorder);
            SetShellResourceBrush("ScrollBarThumbBackground", theme.ShellBorder);
            SetShellResourceBrush("ScrollBarPanningThumbBackground", theme.ShellBorder);
            SetShellResourceBrush("ScrollBarThumbBackgroundThemeBrush", theme.ShellBorder);
            SetShellResourceBrush("ScrollBarThumbBorderThemeBrush", theme.ShellBorder);
        }
        if (TryBrush(theme.ShellForeground, out var fg))
        {
            SetShellResourceBrush("TextFillColorPrimaryBrush", theme.ShellForeground);
            SetShellResourceBrush("SystemControlForegroundBaseHighBrush", theme.ShellForeground);

            SetShellResourceBrush("TabViewItemHeaderForegroundSelected", theme.ShellForeground);
            SetShellResourceBrush("TabViewItemHeaderCloseButtonForeground", theme.ShellForeground);
            SetShellResourceBrush("TabViewItemHeaderCloseButtonForegroundSelected", theme.ShellForeground);
            SetShellResourceBrush("TabViewItemHeaderCloseButtonForegroundPointerOver", theme.ShellForeground);
            SetShellResourceBrush("TabViewButtonForeground", theme.ShellForeground);
            SetShellResourceBrush("TabViewButtonForegroundPointerOver", theme.ShellForeground);
        }
        if (TryBrush(theme.ShellMuted, out var muted))
        {
            SetShellResourceBrush("TextFillColorSecondaryBrush", theme.ShellMuted);
            SetShellResourceBrush("TextFillColorTertiaryBrush", theme.ShellMuted);

            SetShellResourceBrush("TabViewItemHeaderForeground", theme.ShellMuted);
            SetShellResourceBrush("TabViewItemHeaderForegroundPointerOver", theme.ShellForeground ?? theme.ShellMuted);
            SetShellResourceBrush("TabViewItemHeaderForegroundPressed", theme.ShellForeground ?? theme.ShellMuted);
            SetShellResourceBrush("TabViewScrollButtonForeground", theme.ShellMuted);
            SetShellResourceBrush("TabViewScrollButtonForegroundPointerOver", theme.ShellForeground ?? theme.ShellMuted);
        }
        if (TryBrush(theme.ShellAccent, out var accent))
        {
            SetShellResourceBrush("AccentFillColorDefaultBrush", theme.ShellAccent);
            SetShellResourceBrush("AccentTextFillColorPrimaryBrush", theme.ShellAccent);

            SetShellResourceBrush("TabViewSelectedItemBorderBrush", theme.ShellAccent);
            SetShellResourceBrush("ScrollBarThumbFillPointerOver", theme.ShellAccent);
            SetShellResourceBrush("ScrollBarThumbFillPressed", theme.ShellAccent);
            SetShellResourceBrush("ScrollBarThumbPointerOverBackgroundThemeBrush", theme.ShellAccent);
            SetShellResourceBrush("ScrollBarThumbPressedBackgroundThemeBrush", theme.ShellAccent);
        }

        foreach (var surface in _themedSurfaces) ApplySurfaceTheme(surface, theme);
        ApplyThemeToTitleBar(theme);
    }

    private void SetShellResourceBrush(string key, string? value)
    {
        if (!TryColor(value, out var color)) return;
        SetShellResourceBrush(key, color);
    }

    private void SetShellResourceBrush(string key, Windows.UI.Color color)
    {
        if (_shellResourceBrushes.TryGetValue(key, out var brush))
        {
            // Keep the same brush object alive so controls holding a ThemeResource
            // reference repaint immediately when switching between custom themes.
            brush.Color = color;
            return;
        }

        brush = new SolidColorBrush(color);
        _shellResourceBrushes[key] = brush;
        RootGrid.Resources[key] = brush;
    }

    private void ApplyThemeToTitleBar(ThemeChoice theme)
    {
        if (_appWindow is null || !AppWindowTitleBar.IsCustomizationSupported()) return;
        if (!TryColor(theme.ShellPanel, out var panel) || !TryColor(theme.ShellForeground, out var foreground)) return;

        var muted = TryColor(theme.ShellMuted, out var m) ? m : foreground;
        var border = TryColor(theme.ShellBorder, out var b) ? b : panel;
        var accent = TryColor(theme.ShellAccent, out var a) ? a : border;
        var titleBar = _appWindow.TitleBar;
        titleBar.BackgroundColor = panel;
        titleBar.ForegroundColor = foreground;
        titleBar.InactiveBackgroundColor = panel;
        titleBar.InactiveForegroundColor = muted;
        titleBar.ButtonBackgroundColor = panel;
        titleBar.ButtonForegroundColor = foreground;
        titleBar.ButtonInactiveBackgroundColor = panel;
        titleBar.ButtonInactiveForegroundColor = muted;
        titleBar.ButtonHoverBackgroundColor = border;
        titleBar.ButtonHoverForegroundColor = foreground;
        titleBar.ButtonPressedBackgroundColor = accent;
        titleBar.ButtonPressedForegroundColor = foreground;
    }

    private static void ApplyBrush(Panel panel, string? value, Action<Panel, Brush> setter) { if (TryBrush(value, out var b)) setter(panel, b); }
    private static void ApplyBrush(Border border, string? value, Action<Border, Brush> setter) { if (TryBrush(value, out var b)) setter(border, b); }
    private static bool TryBrush(string? value, out SolidColorBrush brush)
    {
        brush = new SolidColorBrush(Colors.Transparent);
        if (!TryColor(value, out var color)) return false;
        brush = new SolidColorBrush(color);
        return true;
    }

    private static bool TryColor(string? value, out Windows.UI.Color color)
    {
        color = Colors.Transparent;
        if (string.IsNullOrWhiteSpace(value) || value.Length != 7 || value[0] != '#') return false;
        try
        {
            color = Microsoft.UI.ColorHelper.FromArgb(255, Convert.ToByte(value.Substring(1, 2), 16), Convert.ToByte(value.Substring(3, 2), 16), Convert.ToByte(value.Substring(5, 2), 16));
            return true;
        }
        catch { return false; }
    }

    private async void ThemeCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressThemeEvent || ThemeCombo.SelectedItem is not ThemeChoice theme) return;
        ApplyThemeToShell(theme);
        EnsureTabContentPresenterStretch();
        _settings.ThemeId = theme.Id; QueuePersistenceFailureNotice(SettingsService.Save(_settings), "Theme setting");
        RebuildSubjectGroups(SubjectSearchBox.Text);
        await ApplyThemeToAllWebViewsAsync(theme);
    }

    private async void SubjectLibraryButton_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not Button { Tag: SubjectEntry subject }) return;
        var preservedOffset = _pendingLibraryPointerVerticalOffset;
        _pendingLibraryPointerVerticalOffset = null;
        var state = InputKeyboardSource.GetKeyStateForCurrentThread(VirtualKey.Control);
        var ctrl = (state & CoreVirtualKeyStates.Down) == CoreVirtualKeyStates.Down;
        await OpenSubjectAsync(subject, ctrl, ctrl);
        if (preservedOffset is { } offset && ShellSplit.IsPaneOpen)
            RestoreSubjectLibraryOffset(offset);
    }

    private async void SubjectLibraryButton_PointerPressed(object sender, PointerRoutedEventArgs e)
    {
        if (sender is not Button { Tag: SubjectEntry subject } button) return;
        var point = e.GetCurrentPoint(button);
        if (!point.Properties.IsMiddleButtonPressed)
        {
            // Pointer/touch activation can focus a late-library button and trigger an
            // automatic bring-into-view after the content/tab switch. Preserve the exact
            // viewport before that shell transition; keyboard navigation retains normal
            // focus/bring-into-view semantics.
            _pendingLibraryPointerVerticalOffset = SubjectsScrollViewer.VerticalOffset;
            return;
        }
        e.Handled = true;
        var offset = SubjectsScrollViewer.VerticalOffset;
        await OpenSubjectAsync(subject, true, true);
        if (ShellSplit.IsPaneOpen) RestoreSubjectLibraryOffset(offset);
    }

    private void RestoreSubjectLibraryOffset(double offset)
    {
        if (double.IsNaN(offset) || double.IsInfinity(offset)) return;
        var target = Math.Max(0, offset);
        SubjectsScrollViewer.ChangeView(null, target, null, disableAnimation: true);
        DispatcherQueue.TryEnqueue(Microsoft.UI.Dispatching.DispatcherQueuePriority.Low, () =>
        {
            if (ShellSplit.IsPaneOpen)
                SubjectsScrollViewer.ChangeView(null, target, null, disableAnimation: true);
        });
    }

    private void SubjectLibraryButton_RightTapped(object sender, RightTappedRoutedEventArgs e)
    {
        if (sender is not Button { Tag: SubjectEntry subject } button) return;
        _contextSubject = subject;
        var flyout = new MenuFlyout();
        var open = new MenuFlyoutItem { Text = "Open" };
        open.Click += async (_, _) => await OpenSubjectAsync(subject, false);
        var newTab = new MenuFlyoutItem { Text = "Open in new tab" };
        newTab.Click += async (_, _) => await OpenSubjectAsync(subject, true, true);
        flyout.Items.Add(open);
        flyout.Items.Add(newTab);
        AppendSubjectPersonalMenuItems(flyout, subject);
        flyout.ShowAt(button);
        e.Handled = true;
    }

    private void SubjectSearchBox_TextChanged(object sender, TextChangedEventArgs e)
        => RebuildSubjectGroups(SubjectSearchBox.Text);

    private void BackButton_Click(object sender, RoutedEventArgs e)
    {
        if (AppSurfaceHost.Visibility == Visibility.Visible)
        {
            CloseAppSurface(restorePreviousTab: true);
            return;
        }
        var ctx = ActiveStudyTab();
        if (ctx?.WebView.CoreWebView2?.CanGoBack == true) ctx.WebView.CoreWebView2.GoBack();
    }

    private void ForwardButton_Click(object sender, RoutedEventArgs e)
    {
        if (AppSurfaceHost.Visibility == Visibility.Visible) return;
        var ctx = ActiveStudyTab();
        if (ctx?.WebView.CoreWebView2?.CanGoForward == true) ctx.WebView.CoreWebView2.GoForward();
    }

    private void HomeButton_Click(object sender, RoutedEventArgs e)
    {
        CloseAppSurface(restorePreviousTab: false);
        if (_homeTab is not null) Tabs.SelectedItem = _homeTab;
        ShellSplit.IsPaneOpen = true;
    }
    private void PaneToggleButton_Click(object sender, RoutedEventArgs e) => ShellSplit.IsPaneOpen = !ShellSplit.IsPaneOpen;
    private void GuideButton_Click(object sender, RoutedEventArgs e) => OpenAppSurfaceSafe("guide", "Guide", CreateGuideView);
    private void AccessibilityButton_Click(object sender, RoutedEventArgs e) => OpenSettings("accessibility");

    private void FocusButton_Click(object sender, RoutedEventArgs e)
    {
        _focusMode = !_focusMode;
        if (_focusMode)
        {
            _paneWasOpenBeforeFocus = ShellSplit.IsPaneOpen;
            ShellSplit.IsPaneOpen = false;
            PaneToggleButton.Visibility = Visibility.Collapsed;
            GuideButton.Visibility = Visibility.Collapsed;
            AppSubtitleText.Visibility = Visibility.Collapsed;
            FocusButton.Content = _compactChrome ? "▣" : "Exit focus";
        }
        else
        {
            PaneToggleButton.Visibility = Visibility.Visible;
            AppSubtitleText.Visibility = _compactChrome ? Visibility.Collapsed : Visibility.Visible;
            UpdateResponsiveChromeVisibility(RootGrid.ActualWidth);
            FocusButton.Content = _compactChrome ? "▣" : "▣ Focus";
            if (RootGrid.ActualWidth >= 900) ShellSplit.IsPaneOpen = _paneWasOpenBeforeFocus;
        }
    }
    private void FullScreenButton_Click(object sender, RoutedEventArgs e) => ToggleFullScreen();
    private void FullScreenExitButton_Click(object sender, RoutedEventArgs e) => ExitFullScreen();

    private void ToggleFullScreen()
    {
        if (_isFullScreen) ExitFullScreen();
        else EnterFullScreen();
    }

    private void EnterFullScreen()
    {
        if (_appWindow is null || _isFullScreen) return;
        try
        {
            _paneWasOpenBeforeFullScreen = ShellSplit.IsPaneOpen;
            ShellSplit.IsPaneOpen = false;
            _appWindow.SetPresenter(AppWindowPresenterKind.FullScreen);
            _isFullScreen = true;
            TopBar.Visibility = Visibility.Collapsed;
            TopBarRow.Height = new GridLength(0);
            FullScreenExitButton.Visibility = Visibility.Visible;
        }
        catch { /* retain normal-window mode if presenter change is unavailable */ }
    }

    private void ExitFullScreen()
    {
        if (_appWindow is null || !_isFullScreen) return;
        try
        {
            _appWindow.SetPresenter(AppWindowPresenterKind.Default);
            _isFullScreen = false;
            TopBarRow.Height = new GridLength(58);
            TopBar.Visibility = Visibility.Visible;
            FullScreenExitButton.Visibility = Visibility.Collapsed;
            if (!_focusMode && RootGrid.ActualWidth >= 900) ShellSplit.IsPaneOpen = _paneWasOpenBeforeFullScreen;
        }
        catch { }
    }

    private void AccessibilityAccelerator_Invoked(KeyboardAccelerator sender, KeyboardAcceleratorInvokedEventArgs args)
    {
        OpenSettings("accessibility");
        args.Handled = true;
    }

    private void FullScreenAccelerator_Invoked(KeyboardAccelerator sender, KeyboardAcceleratorInvokedEventArgs args)
    {
        ToggleFullScreen();
        args.Handled = true;
    }

    private void EscapeAccelerator_Invoked(KeyboardAccelerator sender, KeyboardAcceleratorInvokedEventArgs args)
    {
        if (!_isFullScreen) return;
        ExitFullScreen();
        args.Handled = true;
    }

    private void Tabs_Loaded(object sender, RoutedEventArgs e) => EnsureTabContentPresenterStretch();

    private bool EnsureTabContentPresenterStretch()
    {
        var presenter = FindNamedDescendant<ContentPresenter>(Tabs, "TabContentPresenter");
        if (presenter is null && Tabs.SelectedItem is TabViewItem selected && selected.Content is not null)
            presenter = FindContentPresenterForContent(Tabs, selected.Content);
        if (presenter is null) return false;
        presenter.HorizontalContentAlignment = HorizontalAlignment.Stretch;
        presenter.VerticalContentAlignment = VerticalAlignment.Stretch;
        return true;
    }

    private static T? FindNamedDescendant<T>(DependencyObject root, string name) where T : FrameworkElement
    {
        var count = VisualTreeHelper.GetChildrenCount(root);
        for (var i = 0; i < count; i++)
        {
            var child = VisualTreeHelper.GetChild(root, i);
            if (child is T typed && typed.Name == name) return typed;
            if (FindNamedDescendant<T>(child, name) is { } nested) return nested;
        }
        return null;
    }

    private static ContentPresenter? FindContentPresenterForContent(DependencyObject root, object content)
    {
        var count = VisualTreeHelper.GetChildrenCount(root);
        for (var i = 0; i < count; i++)
        {
            var child = VisualTreeHelper.GetChild(root, i);
            if (child is ContentPresenter presenter && ReferenceEquals(presenter.Content, content)) return presenter;
            if (FindContentPresenterForContent(child, content) is { } nested) return nested;
        }
        return null;
    }

    private void Tabs_AddTabButtonClick(TabView sender, object args)
    {
        CloseAppSurface(restorePreviousTab: false);
        if (_homeTab is not null) Tabs.SelectedItem = _homeTab;
        ShellSplit.IsPaneOpen = true;
        SubjectSearchBox.Focus(FocusState.Programmatic);
    }

    private void OpenSpecialTabSafe(string title, Func<UIElement> contentFactory)
    {
        CloseAppSurface(restorePreviousTab: false);
        var existing = Tabs.TabItems.OfType<TabViewItem>().FirstOrDefault(x => Equals(x.Tag, "shell:" + title));
        if (existing is not null) { if (TryHandleAlreadyParkedBeside(existing)) return; Tabs.SelectedItem = existing; return; }

        try
        {
            OpenSpecialTab(title, contentFactory());
        }
        catch (Exception ex)
        {
            OpenSpecialTab(title + " problem", MakeScrollableStack(
                MakeHeading(title + " could not open."),
                MakeBody(ex.Message),
                MakeBody("This is a Pathfinder app error. Close the tab and try again.")));
        }
    }

    private void OpenSpecialTab(string title, UIElement content)
    {
        var existing = Tabs.TabItems.OfType<TabViewItem>().FirstOrDefault(x => Equals(x.Tag, "shell:" + title));
        if (existing is not null) { if (TryHandleAlreadyParkedBeside(existing)) return; Tabs.SelectedItem = existing; return; }
        var tab = new TabViewItem { Header = title, IsClosable = true, MinHeight = 44, Content = PrepareShellContent(content), Tag = "shell:" + title };
        ConfigureShellTabWorkspaceFeatures(tab);
        Tabs.TabItems.Add(tab); Tabs.SelectedItem = tab;
        QueuePersistenceFailureNotice(SaveCurrentSession(), "Session state");
    }

    private async void Tabs_TabCloseRequested(TabView sender, TabViewTabCloseRequestedEventArgs args)
    {
        if (args.Tab is TabViewItem tab) await CloseTabItemAsync(tab, true);
    }

    private void Tabs_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        HandleSplitPrimarySelectionChanged();
        EnsureTabContentPresenterStretch();
        UpdateNavigationButtons();
        if (ActiveStudyTab() is { } ctx)
        {
            _journalLastStudyTab = ctx.Tab;
            LogStudyEvent(ctx, "tab-selected", $"{ctx.WebView.ActualWidth:0}x{ctx.WebView.ActualHeight:0}; visibility={ctx.WebView.Visibility}; opacity={ctx.WebView.Opacity:0.##}; source={ctx.WebView.CoreWebView2?.Source ?? ""}");
        }
        QueuePersistenceFailureNotice(SaveCurrentSession(), "Session state");
    }

    private StudyTabContext? FindPrimaryStudyContext(string resourceId)
        => _studyTabs.Values.FirstOrDefault(x => x.ViewRole == CockpitViewRole.Primary && x.Subject.ResourceId.Equals(resourceId, StringComparison.OrdinalIgnoreCase));

    private StudyTabContext? ActiveStudyTab() => Tabs.SelectedItem is TabViewItem t && _studyTabs.TryGetValue(t, out var ctx) ? ctx : null;

    private void UpdateNavigationButtons()
    {
        if (AppSurfaceHost.Visibility == Visibility.Visible)
        {
            BackButton.IsEnabled = true; // returns to the underlying study/tool workspace
            ForwardButton.IsEnabled = false;
            return;
        }
        var ctx = ActiveStudyTab();
        BackButton.IsEnabled = ctx?.WebView.CoreWebView2?.CanGoBack == true;
        ForwardButton.IsEnabled = ctx?.WebView.CoreWebView2?.CanGoForward == true;
    }

    private void ClosePaneIfOverlay() { if (ShellSplit.DisplayMode == SplitViewDisplayMode.Overlay) ShellSplit.IsPaneOpen = false; }

    private void RootGrid_SizeChanged(object sender, SizeChangedEventArgs e)
    {
        if (e.NewSize.Width < 900)
        {
            ShellSplit.DisplayMode = SplitViewDisplayMode.Overlay;
            if (e.PreviousSize.Width >= 900 || _focusMode) ShellSplit.IsPaneOpen = false;
        }
        else
        {
            ShellSplit.DisplayMode = SplitViewDisplayMode.Inline;
            if (_focusMode) ShellSplit.IsPaneOpen = false;
            else if (e.PreviousSize.Width < 900) ShellSplit.IsPaneOpen = true;
        }
        var compact = e.NewSize.Width < 760;
        if (compact != _compactChrome)
        {
            _compactChrome = compact;
            AppTitleText.Visibility = compact ? Visibility.Collapsed : Visibility.Visible;
            AppSubtitleText.Visibility = compact || _focusMode ? Visibility.Collapsed : Visibility.Visible;
            FocusButton.Content = _focusMode ? (compact ? "▣" : "Exit focus") : (compact ? "▣" : "▣ Focus");
            FocusButton.MinWidth = compact ? 44 : 92;
            FullScreenButton.Width = 44;
            GuideButton.Content = compact ? "?" : "? Guide";
            GuideButton.MinWidth = compact ? 44 : 92;
            SplitWorkspaceButton.MinWidth = compact ? 44 : 82;
            if (!_splitWorkspaceActive) SplitWorkspaceButton.Content = compact ? "◫" : "◫ Split";
            ThemeCombo.MinWidth = compact ? 112 : 132;
        }
        UpdateResponsiveChromeVisibility(e.NewSize.Width);
        ApplySplitWorkspaceLayout();
        EnsureTabContentPresenterStretch();
    }

    private void UpdateResponsiveChromeVisibility(double width)
    {
        if (_focusMode) return;
        var hideSecondary = width < 650;
        var hideTheme = width < 540;
        GuideButton.Visibility = hideSecondary ? Visibility.Collapsed : Visibility.Visible;
        ThemeCombo.Visibility = hideTheme ? Visibility.Collapsed : Visibility.Visible;
    }

    private void BackAccelerator_Invoked(KeyboardAccelerator sender, KeyboardAcceleratorInvokedEventArgs args) { BackButton_Click(this, new RoutedEventArgs()); args.Handled = true; }
    private void ForwardAccelerator_Invoked(KeyboardAccelerator sender, KeyboardAcceleratorInvokedEventArgs args) { ForwardButton_Click(this, new RoutedEventArgs()); args.Handled = true; }
    private async void CloseTabAccelerator_Invoked(KeyboardAccelerator sender, KeyboardAcceleratorInvokedEventArgs args)
    {
        if (AppSurfaceHost.Visibility == Visibility.Visible)
        {
            CloseAppSurface(restorePreviousTab: true);
        }
        else if (Tabs.SelectedItem is TabViewItem t && t != _homeTab)
        {
            await CloseTabItemAsync(t, true);
        }
        args.Handled = true;
    }

    private async void ReopenClosedTabAccelerator_Invoked(KeyboardAccelerator sender, KeyboardAcceleratorInvokedEventArgs args)
    {
        await ReopenNewestClosedStudyAsync();
        args.Handled = true;
    }

    private void NewTabAccelerator_Invoked(KeyboardAccelerator sender, KeyboardAcceleratorInvokedEventArgs args)
    {
        CloseAppSurface(restorePreviousTab: false);
        if (_homeTab is not null) Tabs.SelectedItem = _homeTab;
        ShellSplit.IsPaneOpen = true;
        args.Handled = true;
    }

    private sealed class StudyTabContext
    {
        public StudyTabContext(SubjectEntry subject, WebView2 webView, TabViewItem tab, ProgressRing loading, TextBlock status, InfoBar sourceReturnBar)
        {
            Subject = subject;
            WebView = webView;
            Tab = tab;
            Loading = loading;
            Status = status;
            SourceReturnBar = sourceReturnBar;
        }
        public SubjectEntry Subject { get; set; }
        public Guid ViewId { get; } = Guid.NewGuid();
        public CockpitViewRole ViewRole { get; set; } = CockpitViewRole.Primary;
        public CockpitHostLifecycle Lifecycle { get; set; } = CockpitHostLifecycle.Created;
        public string ContentHost { get; set; } = "";
        public string? DocumentCreatedScriptId { get; set; }
        public bool NeedsLegacyStateAdoption { get; set; }
        public int RecoveryAttempts { get; set; }
        public Button? RecoveryButton { get; set; }
        public WebView2 WebView { get; }
        public TabViewItem Tab { get; }
        public ProgressRing Loading { get; }
        public TextBlock Status { get; }
        public bool IsPinned { get; set; }
        public long ContentGeneration { get; set; }
        public long LocationRequestVersion { get; set; }
        public string ActiveLocationReason { get; set; } = "";
        public bool CaptureAuthorityReady { get; set; }
        public bool DocumentHealthy { get; set; }
        public string LastProcessFailureKind { get; set; } = "";
        public List<string> LastRevealSnapshot { get; set; } = [];
        public StudyLocationState? PendingRestore { get; set; }
        public StudyLocationState? LastKnownLocation { get; set; }
        public UniversalSearchResult? PendingSearchResult { get; set; }
        public StudyLocationState? PendingSearchReturnLocation { get; set; }
        public InfoBar SourceReturnBar { get; }
        public StudyLocationState? SourceJumpReturnLocation { get; set; }
        public TemporaryCockpitViewState? SourceJumpReturnView { get; set; }
    }
}
