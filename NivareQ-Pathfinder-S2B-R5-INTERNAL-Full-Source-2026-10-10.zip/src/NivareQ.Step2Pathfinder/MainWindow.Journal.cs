using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.Web.WebView2.Core;
using NivareQ.Step2Pathfinder.Models;
using NivareQ.Step2Pathfinder.Services;

namespace NivareQ.Step2Pathfinder;

public sealed partial class MainWindow
{
    private string? _journalFilterSlug;
    private string _journalQuery = "";
    private int _journalResultLimit = 100;
    private TabViewItem? _journalLastStudyTab;
    private Grid? _journalWorkspaceRoot;
    private StackPanel? _journalInlineEditorHost;
    private Action? _journalRenderResults;
    private Action? _journalRefreshFilters;
    private JournalEditorSession? _journalEditorSession;

    private sealed class JournalEditorSession
    {
        public string ExistingId { get; init; } = "";
        public string Slug { get; init; } = "";
        public string SourceVersion { get; init; } = "";
        public StudyLocationState? SourceLocation { get; init; }
        public SubjectEntry? Subject { get; init; }
        public DateTimeOffset CreatedUtc { get; init; } = DateTimeOffset.UtcNow;
        public bool OriginalTimestampKnown { get; init; } = true;
        public bool SelectedTextCopied { get; init; }
        public string BaselineTitle { get; init; } = "";
        public string BaselineBody { get; init; } = "";
        public string DraftTitle { get; set; } = "";
        public string DraftBody { get; set; } = "";
    }

    private void InitializeJournalFeatures()
    {
        _journal.Load();
        MigrateLegacyPersonalNotesIntoJournal();
    }

    private void MigrateLegacyPersonalNotesIntoJournal()
    {
        if (_personal.State.SubjectNotes.Count == 0) return;

        // Released Personal notes remain in personal-study.json as an inactive W4 rollback
        // compatibility shadow. Journal owns durable migration markers because W4 does not know
        // about or rewrite Journal files; this prevents a note deliberately deleted in W5 from
        // being resurrected merely because the user temporarily rolled back. Each migration is a
        // single append-only Journal operation containing both the note and marker.
        var migratedIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var migratedSlugs = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var pair in _personal.State.SubjectNotes.Where(x => !string.IsNullOrWhiteSpace(x.Value)))
        {
            var marker = pair.Key.Trim();
            if (_journal.IsLegacyPersonalMigrated(marker)) continue;

            var subject = _catalog.Resolve(pair.Key);
            var id = LegacyPersonalJournalId(pair.Key);
            var existing = _journal.Find(id);
            var entry = existing ?? new JournalEntry
            {
                Id = id,
                Title = subject?.Title ?? $"Imported Personal note · {pair.Key}",
                Body = pair.Value,
                Slug = subject?.ResourceId ?? "",
                SourceVersion = subject?.ExpectedSha256.ToLowerInvariant() ?? "",
                SourceLocation = null,
                OriginalTimestampKnown = false,
                CreatedUtc = DateTimeOffset.UtcNow,
                UpdatedUtc = DateTimeOffset.UtcNow
            };
            var result = _journal.MigrateLegacyPersonal(entry, marker);
            if (!result.Success)
            {
                PersistenceHealth.Report("Journal migration", $"Personal note '{pair.Key}' could not be migrated yet: {result.Error}");
                return;
            }
            migratedIds.Add(id);
            migratedSlugs.Add(marker);
        }

        if (migratedIds.Count == 0) return;
        var compact = _journal.Compact();
        if (!compact.Success)
        {
            // The append-only migration operation is already durable and atomic as a logical
            // note+marker pair, so compaction can safely retry later without remigrating.
            PersistenceHealth.Report("Journal migration", "Personal notes were migrated into the durable Journal operation log, but snapshot compaction could not complete yet: " + compact.Error);
            return;
        }

        try
        {
            var verified = JournalService.DeserializeState(File.ReadAllText(PathfinderPaths.JournalSnapshotPath));
            var verifiedIds = verified.Entries.Select(x => x.Id).ToHashSet(StringComparer.OrdinalIgnoreCase);
            var verifiedMarkers = verified.LegacyPersonalMigrationSlugs.ToHashSet(StringComparer.OrdinalIgnoreCase);
            if (!migratedIds.All(verifiedIds.Contains) || !migratedSlugs.All(verifiedMarkers.Contains))
                PersistenceHealth.Report("Journal migration", "Journal migration verification did not find every imported Personal note and marker. Older compatibility data remains retained for recovery.");
        }
        catch (Exception ex)
        {
            PersistenceHealth.Report("Journal migration", "Journal migration could not be read back for verification. Older compatibility data remains retained for recovery. " + ex.Message);
        }
    }

    private static string LegacyPersonalJournalId(string resourceId)
        => "legacy-personal-" + resourceId.Trim().ToLowerInvariant();

    private void JournalButton_Click(object sender, RoutedEventArgs e) => OpenJournal();

    private TabViewItem? FindJournalTab()
        => Tabs.TabItems.OfType<TabViewItem>().FirstOrDefault(x => Equals(x.Tag, "shell:Journal"));

    private bool IsJournalWorkspaceVisible()
    {
        var tab = FindJournalTab();
        return tab is not null && (ReferenceEquals(Tabs.SelectedItem, tab) || IsTabParkedBeside(tab));
    }

    private void OpenJournal(string? filterSlug = null)
    {
        CloseAppSurface(restorePreviousTab: false);
        if (ActiveStudyTab() is { } active) _journalLastStudyTab = active.Tab;
        if (filterSlug is not null) _journalFilterSlug = filterSlug;

        var existing = FindJournalTab();
        if (existing is not null)
        {
            RefreshJournalWorkspace(existing);
            if (TryHandleAlreadyParkedBeside(existing)) return;
            Tabs.SelectedItem = existing;
            return;
        }

        OpenSpecialTab("Journal", CreateJournalView());
    }

    private bool JournalRootBelongsTo(TabViewItem tab)
        => _journalWorkspaceRoot is not null
           && (ReferenceEquals(tab.Content, _journalWorkspaceRoot)
               || (IsTabParkedBeside(tab) && ReferenceEquals(_splitSecondaryOriginalContent, _journalWorkspaceRoot)));

    private void RefreshJournalWorkspace(TabViewItem? knownTab = null)
    {
        var tab = knownTab ?? FindJournalTab();
        if (tab is null) return;

        // Do not replace the currently presented Journal visual tree. W5 R2 persisted a save
        // correctly but replacing the selected TabViewItem.Content could leave WinUI presenting
        // the old tree until the tab was closed/reopened. R3 refreshes the live hosts in place.
        if (JournalRootBelongsTo(tab) && _journalRenderResults is not null)
        {
            _journalRefreshFilters?.Invoke();
            _journalRenderResults();
            RenderJournalInlineEditor();
            return;
        }

        var content = PrepareShellContent(CreateJournalView());
        if (IsTabParkedBeside(tab))
        {
            _splitSecondaryOriginalContent = content;
            SecondaryWorkspaceContent.Content = content;
            UpdateSecondaryWorkspaceChrome();
        }
        else
        {
            tab.Content = content;
        }
    }

    private UIElement CreateJournalView()
    {
        var root = new Grid { HorizontalAlignment = HorizontalAlignment.Stretch, VerticalAlignment = VerticalAlignment.Stretch };
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

        var intro = new StackPanel { Spacing = 9, Margin = new Thickness(20, 18, 20, 8), MaxWidth = 1100, HorizontalAlignment = HorizontalAlignment.Left };
        intro.Children.Add(MakeHeading("Journal"));
        intro.Children.Add(MakeLead("General notes and cockpit-linked notes in one searchable Windows workspace."));
        var actionRow = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        actionRow.Children.Add(MakeActionButton("New general note", async (_, _) => await EditJournalEntryAsync(null, null, null)));
        actionRow.Children.Add(MakeActionButton("From current Study", async (_, _) => await CreateJournalNoteFromCurrentStudyAsync()));
        actionRow.SizeChanged += (_, e) => actionRow.Orientation = e.NewSize.Width < 540 ? Orientation.Vertical : Orientation.Horizontal;
        intro.Children.Add(actionRow);
        root.Children.Add(intro);

        var editorHost = new StackPanel
        {
            Spacing = 8,
            Margin = new Thickness(20, 4, 20, 12),
            MaxWidth = 1100,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            Visibility = Visibility.Collapsed
        };
        Grid.SetRow(editorHost, 1);
        root.Children.Add(editorHost);

        var controls = new Grid { Margin = new Thickness(20, 4, 20, 10), ColumnSpacing = 8 };
        controls.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        controls.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        var search = new TextBox
        {
            PlaceholderText = "Search Journal title, full note text, or cockpit…",
            Text = _journalQuery,
            MinHeight = 42,
            MinWidth = 260
        };
        var filter = new ComboBox { MinHeight = 42, MinWidth = 220 };
        Grid.SetColumn(filter, 1);
        controls.Children.Add(search);
        controls.Children.Add(filter);
        Grid.SetRow(controls, 2);
        root.Children.Add(controls);

        var resultsHost = new StackPanel { Spacing = 10, MaxWidth = 1100, HorizontalAlignment = HorizontalAlignment.Left };
        var scroll = new ScrollViewer
        {
            Content = resultsHost,
            Padding = new Thickness(20, 2, 20, 24),
            HorizontalScrollMode = ScrollMode.Disabled,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            VerticalScrollMode = ScrollMode.Enabled,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto
        };
        Grid.SetRow(scroll, 3);
        root.Children.Add(scroll);

        var refreshingFilter = false;
        void RefreshFilters()
        {
            refreshingFilter = true;
            try
            {
                filter.Items.Clear();
                var filterChoices = BuildJournalFilterChoices();
                foreach (var choice in filterChoices)
                {
                    var item = new ComboBoxItem { Content = choice.Label, Tag = choice.SlugMarker };
                    filter.Items.Add(item);
                    if (JournalFilterEquals(_journalFilterSlug, choice.SlugMarker)) filter.SelectedItem = item;
                }
                if (filter.SelectedItem is null && filter.Items.Count > 0) filter.SelectedIndex = 0;
            }
            finally { refreshingFilter = false; }
        }

        void Render()
        {
            resultsHost.Children.Clear();
            var matches = FilterJournalEntries().ToList();
            resultsHost.Children.Add(new TextBlock
            {
                Text = $"{matches.Count:N0} {(matches.Count == 1 ? "note" : "notes")}",
                FontSize = 12,
                Opacity = .68,
                IsTextSelectionEnabled = true
            });
            if (matches.Count == 0)
            {
                resultsHost.Children.Add(MakeBody(_journal.Count == 0
                    ? "Journal is empty. Create a General note or capture one from a study cockpit."
                    : "No Journal notes match the current search/filter."));
                return;
            }

            foreach (var entry in matches.Take(_journalResultLimit)) resultsHost.Children.Add(MakeJournalCard(entry));
            if (matches.Count > _journalResultLimit)
            {
                var more = MakeActionButton($"Load more ({matches.Count - _journalResultLimit:N0} remaining)", (_, _) =>
                {
                    _journalResultLimit += 100;
                    Render();
                });
                resultsHost.Children.Add(more);
            }
        }

        search.TextChanged += (_, _) =>
        {
            _journalQuery = search.Text ?? "";
            _journalResultLimit = 100;
            Render();
        };
        filter.SelectionChanged += (_, _) =>
        {
            if (refreshingFilter) return;
            if (filter.SelectedItem is ComboBoxItem selected)
            {
                _journalFilterSlug = DecodeJournalFilterTag(selected.Tag as string);
                _journalResultLimit = 100;
                Render();
            }
        };

        _journalWorkspaceRoot = root;
        _journalInlineEditorHost = editorHost;
        _journalRenderResults = Render;
        _journalRefreshFilters = RefreshFilters;
        RefreshFilters();
        RenderJournalInlineEditor();
        Render();
        return root;
    }

    private sealed record JournalFilterChoice(string Label, string SlugMarker);

    private SubjectEntry? ResolveJournalSubject(string? slug)
    {
        if (string.IsNullOrWhiteSpace(slug)) return null;
        if (slug.Equals(UWorldSelectorService.ResourceId, StringComparison.OrdinalIgnoreCase)) return UWorldSelectorJournalSubject();
        return _catalog.Resolve(slug);
    }

    private List<JournalFilterChoice> BuildJournalFilterChoices()
    {
        var allEntries = _journal.Entries;
        var choices = new List<JournalFilterChoice>
        {
            new($"All notes ({allEntries.Count:N0})", "__all__"),
            new($"General ({allEntries.Count(x => string.IsNullOrWhiteSpace(x.Slug)):N0})", "__general__")
        };
        var represented = _journal.RepresentedSlugs
            .Select(ResolveJournalSubject)
            .Where(x => x is not null)
            .Cast<SubjectEntry>()
            .OrderBy(x => x.Number)
            .ThenBy(x => x.Title, StringComparer.OrdinalIgnoreCase);
        choices.AddRange(represented.Select(x => new JournalFilterChoice($"{x.Title} ({allEntries.Count(e => e.Slug.Equals(x.ResourceId, StringComparison.OrdinalIgnoreCase)):N0})", x.ResourceId)));
        return choices;
    }

    private static bool JournalFilterEquals(string? filterSlug, string marker)
    {
        if (marker == "__all__") return filterSlug is null;
        if (marker == "__general__") return filterSlug == "";
        return filterSlug is not null && filterSlug.Equals(marker, StringComparison.OrdinalIgnoreCase);
    }

    private static string? DecodeJournalFilterTag(string? marker)
        => marker == "__all__" ? null : marker == "__general__" ? "" : marker;

    private IEnumerable<JournalEntry> FilterJournalEntries()
        => _journal.Query(_journalQuery, _journalFilterSlug, slug => ResolveJournalSubject(slug)?.Title ?? slug);

    private Border MakeJournalCard(JournalEntry entry)
    {
        var body = new StackPanel { Spacing = 7 };
        var title = string.IsNullOrWhiteSpace(entry.Title) ? "Untitled note" : entry.Title;
        body.Children.Add(new TextBlock
        {
            Text = title,
            FontSize = 17,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });
        var subject = string.IsNullOrWhiteSpace(entry.Slug) ? null : ResolveJournalSubject(entry.Slug);
        var owner = subject is null ? "General" : subject.Title;
        var sourceSuffix = entry.SourceLocation is null ? "" : " · exact source link";
        body.Children.Add(new TextBlock
        {
            Text = entry.OriginalTimestampKnown
                ? $"{owner}{sourceSuffix} · updated {entry.UpdatedUtc.ToLocalTime():g}"
                : $"{owner}{sourceSuffix} · imported note · original date unavailable",
            FontSize = 12,
            Opacity = .68,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });
        if (!string.IsNullOrWhiteSpace(entry.Body))
        {
            var preview = entry.Body.Trim();
            if (preview.Length > 420) preview = preview[..420] + "…";
            body.Children.Add(new TextBlock
            {
                Text = preview,
                FontSize = 14,
                Opacity = .84,
                TextWrapping = TextWrapping.Wrap,
                IsTextSelectionEnabled = true,
                MaxHeight = 190
            });
        }

        var row = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        if (subject is not null)
            row.Children.Add(MakeActionButton(entry.SourceLocation is null ? "Open cockpit" : "Open source", async (_, _) => await OpenJournalSourceAsync(entry)));
        row.Children.Add(MakeActionButton("Edit", async (_, _) => await EditJournalEntryAsync(entry, null, subject)));
        row.Children.Add(MakeActionButton("Delete", async (_, _) => await DeleteJournalEntryAsync(entry)));
        row.SizeChanged += (_, e) => row.Orientation = e.NewSize.Width < 460 ? Orientation.Vertical : Orientation.Horizontal;
        body.Children.Add(row);

        var card = new Border { Child = body, Padding = new Thickness(14), CornerRadius = new CornerRadius(12), BorderThickness = new Thickness(1) };
        RegisterThemedSurface(card);
        return card;
    }

    private StudyTabContext? ResolveJournalStudyContext()
    {
        if (ActiveStudyTab() is { } active)
        {
            _journalLastStudyTab = active.Tab;
            return active;
        }
        if (_splitSecondaryTab is not null && _studyTabs.TryGetValue(_splitSecondaryTab, out var beside))
        {
            _journalLastStudyTab = beside.Tab;
            return beside;
        }
        if (_journalLastStudyTab is not null && _studyTabs.TryGetValue(_journalLastStudyTab, out var remembered))
            return remembered;
        return null;
    }

    private void AddJournalContextMenu(StudyTabContext context, CoreWebView2ContextMenuRequestedEventArgs args, Task<string>? contextSelectionSnapshot = null)
    {
        try
        {
            // Only the canonical interactive cockpit can capture a fresh strict source position.
            // Read-only source/reference views remain selection/copy surfaces and never pretend to
            // own a new Journal source identity.
            if (context.ViewRole != CockpitViewRole.Primary) return;
            var env = context.WebView.CoreWebView2?.Environment;
            if (env is null) return;

            // WebView2 only defines SelectionText when HasSelection is true.  In particular,
            // ordinary page/text right-clicks can expose the native context menu with no selection;
            // never query SelectionText on that path or the custom Journal item can be skipped.
            var hasSelection = args.ContextMenuTarget.HasSelection;
            var selected = "";
            if (hasSelection)
            {
                selected = (args.ContextMenuTarget.SelectionText ?? "").Trim();
                if (selected.Length > 12000) selected = selected[..12000];
            }
            var label = hasSelection ? "Add selection to Journal…" : "Add current place to Journal…";
            var item = env.CreateContextMenuItem(label, null, CoreWebView2ContextMenuItemKind.Command);
            var selectedForAction = selected;
            var hadSelection = hasSelection;
            item.CustomItemSelected += (_, _) => RootGrid.DispatcherQueue.TryEnqueue(() =>
            {
                _ = CreateJournalNoteFromContextMenuAsync(context, selectedForAction, hadSelection, contextSelectionSnapshot);
            });
            args.MenuItems.Insert(args.MenuItems.Count, item);
            // Keep the normal Edge/WebView2 context menu. This is one additional Pathfinder action.
        }
        catch
        {
            // Journal capture must never break the native WebView2 context menu.
        }
    }

    private async Task CreateJournalNoteFromContextMenuAsync(StudyTabContext context, string fallbackSelection, bool hadSelection, Task<string>? contextSelectionSnapshot)
    {
        // Use the selection snapshot initiated at ContextMenuRequested time. This preserves the
        // complete DOM range across multiple paragraphs/list items before clicking the custom
        // command can alter the browser selection. WebView2 SelectionText remains fallback only.
        var selected = fallbackSelection;
        if (hadSelection && contextSelectionSnapshot is not null)
        {
            try
            {
                var snap = await contextSelectionSnapshot;
                if (!string.IsNullOrWhiteSpace(snap)) selected = snap;
            }
            catch { }
        }
        if (selected.Length > 12000) selected = selected[..12000];
        await CreateJournalNoteFromStudyAsync(context, hadSelection ? selected : "", preferLiveSelection: false);
    }

    private async Task CreateJournalNoteFromCurrentStudyAsync()
    {
        var context = ResolveJournalStudyContext();
        if (context is null)
        {
            await ShowPersonalMessageAsync("Open a study cockpit first", "Journal can create a source-linked note from an open study cockpit. General notes are always available.");
            return;
        }
        await CreateJournalNoteFromStudyAsync(context);
    }

    private async Task CreateJournalNoteFromStudyAsync(StudyTabContext context, string? selectedTextOverride = null, bool preferLiveSelection = false)
    {
        _journalLastStudyTab = context.Tab;
        var draft = await CaptureSourceActionDraftAsync(context, selectedTextOverride, preferLiveSelection);
        if (draft is null)
        {
            var fallback = new ContentDialog
            {
                XamlRoot = RootGrid.XamlRoot,
                Title = "Could not capture the study source",
                Content = new TextBlock
                {
                    Text = "The cockpit is not ready for a verified source-linked Journal note yet. Pathfinder will not invent a source link. You can try again later or create a General note now.",
                    TextWrapping = TextWrapping.Wrap,
                    MaxWidth = 620,
                    IsTextSelectionEnabled = true
                },
                PrimaryButtonText = "Create General note",
                CloseButtonText = "Cancel",
                DefaultButton = ContentDialogButton.Close
            };
            if (await fallback.ShowAsync() == ContentDialogResult.Primary)
                await EditJournalEntryAsync(null, null, null);
            return;
        }
        await EditJournalEntryAsync(null, draft, context.Subject);
    }

    private JournalEditorSession CreateJournalEditorSession(JournalEntry? existing, SourceActionDraft? draft, SubjectEntry? sourceSubject)
    {
        var slug = existing?.Slug ?? draft?.ResourceId ?? "";
        var subject = sourceSubject ?? (string.IsNullOrWhiteSpace(slug) ? null : _catalog.Resolve(slug));
        var location = existing?.SourceLocation ?? draft?.Location;
        var sourceVersion = existing?.SourceVersion ?? draft?.SourceVersion ?? (subject?.ExpectedSha256.ToLowerInvariant() ?? "");
        var baselineTitle = existing?.Title ?? (subject is null ? "" : subject.Title + " note");
        var baselineBody = existing?.Body ?? draft?.SelectedText ?? "";
        return new JournalEditorSession
        {
            ExistingId = existing?.Id ?? "",
            Slug = slug,
            SourceVersion = sourceVersion,
            SourceLocation = location is null ? null : CloneLocation(location),
            Subject = subject,
            CreatedUtc = existing?.CreatedUtc ?? DateTimeOffset.UtcNow,
            OriginalTimestampKnown = existing?.OriginalTimestampKnown ?? true,
            SelectedTextCopied = draft is not null && !string.IsNullOrWhiteSpace(draft.SelectedText),
            BaselineTitle = baselineTitle,
            BaselineBody = baselineBody,
            DraftTitle = baselineTitle,
            DraftBody = baselineBody
        };
    }

    private bool JournalEditorIsDirty()
        => _journalEditorSession is { } session
           && (!string.Equals(session.DraftTitle, session.BaselineTitle, StringComparison.Ordinal)
               || !string.Equals(session.DraftBody, session.BaselineBody, StringComparison.Ordinal));

    private async Task<bool> ConfirmDiscardJournalDraftAsync()
    {
        if (_journalEditorSession is null || !JournalEditorIsDirty()) return true;
        var discard = new ContentDialog
        {
            XamlRoot = RootGrid.XamlRoot,
            Title = "Discard unsaved Journal changes?",
            Content = new TextBlock { Text = "Your typed changes have not been saved. Discard them, or keep editing this draft.", TextWrapping = TextWrapping.Wrap, MaxWidth = 560 },
            PrimaryButtonText = "Discard changes",
            CloseButtonText = "Keep editing",
            DefaultButton = ContentDialogButton.Close
        };
        return await discard.ShowAsync() == ContentDialogResult.Primary;
    }

    private void ClearJournalEditorSession()
    {
        _journalEditorSession = null;
        _journalCloseBlockedByDirtyDraft = false;
        RenderJournalInlineEditor();
    }

    private async Task EditJournalEntryAsync(JournalEntry? existing, SourceActionDraft? draft, SubjectEntry? sourceSubject)
    {
        if (IsJournalWorkspaceVisible() && _journalInlineEditorHost is not null)
        {
            if (_journalEditorSession is not null && !await ConfirmDiscardJournalDraftAsync()) return;
            _journalEditorSession = CreateJournalEditorSession(existing, draft, sourceSubject);
            RenderJournalInlineEditor();
            return;
        }
        await EditJournalEntryPopupAsync(existing, draft, sourceSubject);
    }

    private void RenderJournalInlineEditor()
    {
        var host = _journalInlineEditorHost;
        if (host is null) return;
        host.Children.Clear();
        var session = _journalEditorSession;
        if (session is null)
        {
            host.Visibility = Visibility.Collapsed;
            return;
        }

        host.Visibility = Visibility.Visible;
        var panel = new StackPanel { Spacing = 8 };
        if (_journalCloseBlockedByDirtyDraft)
        {
            panel.Children.Add(new TextBlock
            {
                Text = "Pathfinder kept this window open because this Journal draft has unsaved changes. Save the note or Cancel and discard the draft, then close Pathfinder again.",
                FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
                TextWrapping = TextWrapping.Wrap,
                IsTextSelectionEnabled = true
            });
        }
        panel.Children.Add(new TextBlock
        {
            Text = string.IsNullOrWhiteSpace(session.ExistingId) ? "New Journal note" : "Edit Journal note",
            FontSize = 17,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            TextWrapping = TextWrapping.Wrap
        });
        panel.Children.Add(new TextBlock
        {
            Text = session.Subject is null
                ? "General note"
                : session.SourceLocation is null ? $"Linked to {session.Subject.Title}" : $"Linked to exact source in {session.Subject.Title}",
            FontSize = 12,
            Opacity = .72,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });

        var title = new TextBox
        {
            Text = session.DraftTitle,
            PlaceholderText = "Note title (required)",
            MaxLength = JournalService.MaxTitleLength,
            MinHeight = 42
        };
        var note = new TextBox
        {
            Text = session.DraftBody,
            PlaceholderText = "Write your note…",
            AcceptsReturn = true,
            TextWrapping = TextWrapping.Wrap,
            MinHeight = 180,
            MaxLength = JournalService.MaxBodyLength
        };
        ScrollViewer.SetVerticalScrollBarVisibility(note, ScrollBarVisibility.Auto);
        title.TextChanged += (_, _) => session.DraftTitle = title.Text ?? "";
        note.TextChanged += (_, _) => session.DraftBody = note.Text ?? "";
        panel.Children.Add(title);
        panel.Children.Add(note);
        if (session.SelectedTextCopied)
            panel.Children.Add(new TextBlock { Text = "Selected cockpit text was copied into the note body. Editing this note never changes the original study content.", FontSize = 12, Opacity = .68, TextWrapping = TextWrapping.Wrap });

        var status = new TextBlock { FontSize = 12, Opacity = .78, TextWrapping = TextWrapping.Wrap, Visibility = Visibility.Collapsed, IsTextSelectionEnabled = true };
        panel.Children.Add(status);
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        var save = MakeActionButton("Save note", async (_, _) =>
        {
            session.DraftTitle = title.Text ?? "";
            session.DraftBody = note.Text ?? "";
            await SaveJournalInlineEditorAsync(status);
        });
        var cancel = MakeActionButton("Cancel", async (_, _) =>
        {
            session.DraftTitle = title.Text ?? "";
            session.DraftBody = note.Text ?? "";
            if (!await ConfirmDiscardJournalDraftAsync()) return;
            ClearJournalEditorSession();
        });
        buttons.Children.Add(save);
        buttons.Children.Add(cancel);
        buttons.SizeChanged += (_, e) => buttons.Orientation = e.NewSize.Width < 360 ? Orientation.Vertical : Orientation.Horizontal;
        panel.Children.Add(buttons);

        var border = new Border { Child = panel, Padding = new Thickness(14), CornerRadius = new CornerRadius(12), BorderThickness = new Thickness(1) };
        RegisterThemedSurface(border);
        host.Children.Add(border);
        RootGrid.DispatcherQueue.TryEnqueue(() =>
        {
            if (string.IsNullOrWhiteSpace(session.DraftTitle)) title.Focus(FocusState.Programmatic);
            else note.Focus(FocusState.Programmatic);
        });
    }

    private async Task SaveJournalInlineEditorAsync(TextBlock status)
    {
        var session = _journalEditorSession;
        if (session is null) return;
        var titleValue = session.DraftTitle.Trim();
        if (titleValue.Length == 0)
        {
            status.Text = "Title required. Your draft is still here.";
            status.Visibility = Visibility.Visible;
            return;
        }

        var entry = new JournalEntry
        {
            Id = string.IsNullOrWhiteSpace(session.ExistingId) ? Guid.NewGuid().ToString("N") : session.ExistingId,
            Title = titleValue,
            Body = session.DraftBody,
            Slug = session.Slug,
            SourceVersion = session.SourceVersion,
            SourceLocation = session.SourceLocation is null ? null : CloneLocation(session.SourceLocation),
            OriginalTimestampKnown = session.OriginalTimestampKnown,
            CreatedUtc = session.CreatedUtc,
            UpdatedUtc = DateTimeOffset.UtcNow
        };
        var write = _journal.Upsert(entry);
        if (!write.Success)
        {
            status.Text = "Journal note was not saved. Your draft remains here. " + write.Error;
            status.Visibility = Visibility.Visible;
            return;
        }

        _journalEditorSession = null;
        _journalCloseBlockedByDirtyDraft = false;
        RenderJournalInlineEditor();
        _journalRefreshFilters?.Invoke();
        _journalRenderResults?.Invoke();
        RefreshMyStudyTab();
        await Task.CompletedTask;
    }

    private async Task EditJournalEntryPopupAsync(JournalEntry? existing, SourceActionDraft? draft, SubjectEntry? sourceSubject)
    {
        var session = CreateJournalEditorSession(existing, draft, sourceSubject);
        var draftTitle = session.DraftTitle;
        var draftBody = session.DraftBody;

        while (true)
        {
            var title = new TextBox
            {
                Text = draftTitle,
                PlaceholderText = "Note title (required)",
                MaxLength = JournalService.MaxTitleLength,
                MinHeight = 42
            };
            var note = new TextBox
            {
                Text = draftBody,
                PlaceholderText = "Write your note…",
                AcceptsReturn = true,
                TextWrapping = TextWrapping.Wrap,
                MinHeight = 260,
                MaxLength = JournalService.MaxBodyLength
            };
            ScrollViewer.SetVerticalScrollBarVisibility(note, ScrollBarVisibility.Auto);
            var stack = new StackPanel { Spacing = 9, MinWidth = 560, MaxWidth = 720 };
            stack.Children.Add(new TextBlock
            {
                Text = session.Subject is null
                    ? "General note"
                    : session.SourceLocation is null ? $"Linked to {session.Subject.Title}" : $"Linked to exact source in {session.Subject.Title}",
                FontSize = 12,
                Opacity = .72,
                TextWrapping = TextWrapping.Wrap,
                IsTextSelectionEnabled = true
            });
            stack.Children.Add(title);
            stack.Children.Add(note);
            if (session.SelectedTextCopied)
                stack.Children.Add(new TextBlock { Text = "Selected cockpit text was copied into the note body. Editing this note never changes the original study content.", FontSize = 12, Opacity = .68, TextWrapping = TextWrapping.Wrap });

            var dialog = new ContentDialog
            {
                XamlRoot = RootGrid.XamlRoot,
                Title = string.IsNullOrWhiteSpace(session.ExistingId) ? "New Journal note" : "Edit Journal note",
                Content = stack,
                PrimaryButtonText = "Save note",
                CloseButtonText = "Cancel",
                DefaultButton = ContentDialogButton.Primary
            };
            var dialogResult = await dialog.ShowAsync();
            draftTitle = title.Text ?? "";
            draftBody = note.Text ?? "";

            if (dialogResult != ContentDialogResult.Primary)
            {
                var dirty = !string.Equals(draftTitle, session.BaselineTitle, StringComparison.Ordinal)
                            || !string.Equals(draftBody, session.BaselineBody, StringComparison.Ordinal);
                if (!dirty) return;

                var discard = new ContentDialog
                {
                    XamlRoot = RootGrid.XamlRoot,
                    Title = "Discard unsaved Journal changes?",
                    Content = new TextBlock { Text = "Your typed changes have not been saved. Discard them, or keep editing this draft.", TextWrapping = TextWrapping.Wrap, MaxWidth = 560 },
                    PrimaryButtonText = "Discard changes",
                    CloseButtonText = "Keep editing",
                    DefaultButton = ContentDialogButton.Close
                };
                if (await discard.ShowAsync() == ContentDialogResult.Primary) return;
                continue;
            }

            var titleValue = draftTitle.Trim();
            if (titleValue.Length == 0)
            {
                await ShowPersonalMessageAsync("Title required", "Journal notes require a title. Your draft is still here; add a title and save again.");
                continue;
            }

            var entry = new JournalEntry
            {
                Id = string.IsNullOrWhiteSpace(session.ExistingId) ? Guid.NewGuid().ToString("N") : session.ExistingId,
                Title = titleValue,
                Body = draftBody,
                Slug = session.Slug,
                SourceVersion = session.SourceVersion,
                SourceLocation = session.SourceLocation is null ? null : CloneLocation(session.SourceLocation),
                OriginalTimestampKnown = session.OriginalTimestampKnown,
                CreatedUtc = session.CreatedUtc,
                UpdatedUtc = DateTimeOffset.UtcNow
            };
            var write = _journal.Upsert(entry);
            if (!write.Success)
            {
                await ShowPersonalMessageAsync("Journal note was not saved", "Pathfinder did not report success because local Journal persistence failed. Your draft remains in the editor and can be retried or copied elsewhere.\n\n" + write.Error);
                continue;
            }

            RefreshJournalWorkspace();
            RefreshMyStudyTab();
            return;
        }
    }

    private async Task DeleteJournalEntryAsync(JournalEntry entry)
    {
        var dialog = new ContentDialog
        {
            XamlRoot = RootGrid.XamlRoot,
            Title = "Delete Journal note?",
            Content = new TextBlock { Text = string.IsNullOrWhiteSpace(entry.Title) ? "This note will be removed." : $"“{entry.Title}” will be removed.", TextWrapping = TextWrapping.Wrap },
            PrimaryButtonText = "Delete",
            CloseButtonText = "Cancel",
            DefaultButton = ContentDialogButton.Close
        };
        if (await dialog.ShowAsync() != ContentDialogResult.Primary) return;
        var write = _journal.Delete(entry.Id);
        if (!write.Success)
        {
            await ShowPersonalMessageAsync("Journal note was not deleted", write.Error);
            return;
        }
        if (_journalEditorSession is { } editor && editor.ExistingId.Equals(entry.Id, StringComparison.OrdinalIgnoreCase))
        {
            _journalEditorSession = null;
            RenderJournalInlineEditor();
        }
        _journalRefreshFilters?.Invoke();
        _journalRenderResults?.Invoke();
        RefreshMyStudyTab();
    }

    private async Task OpenJournalSourceAsync(JournalEntry entry)
    {
        if (entry.Slug.Equals(UWorldSelectorService.ResourceId, StringComparison.OrdinalIgnoreCase))
        {
            if (!string.IsNullOrWhiteSpace(entry.SourceVersion)
                && !entry.SourceVersion.Equals(_uworldSelector.SourceVersion, StringComparison.OrdinalIgnoreCase))
            {
                await ShowPersonalMessageAsync("Selector source version changed", "Pathfinder will not silently redirect this Journal source link to a different UWorld Selector recipe contract.");
                return;
            }
            var recipeId = NormalizeUWorldRecipeTarget(entry.SourceLocation);
            if (entry.SourceLocation is not null && string.IsNullOrWhiteSpace(recipeId))
            {
                await ShowPersonalMessageAsync("Selector source is unavailable", "This Journal note no longer resolves to one of the 26 accepted UWorld Selector recipe IDs.");
                return;
            }

            CloseAppSurface(restorePreviousTab: false);
            var journalTabForSelector = FindJournalTab();
            var journalBesideSelector = journalTabForSelector is not null && IsTabParkedBeside(journalTabForSelector);
            OpenUWorldSelector(string.IsNullOrWhiteSpace(recipeId) ? null : recipeId);
            var selectorTab = FindUWorldSelectorTab();
            if (selectorTab is null) return;

            if (journalBesideSelector)
            {
                if (!IsTabParkedBeside(selectorTab)) Tabs.SelectedItem = selectorTab;
                return;
            }
            if (journalTabForSelector is not null && Tabs.TabItems.Contains(journalTabForSelector))
            {
                Tabs.SelectedItem = journalTabForSelector;
                await ShowTabBesideAsync(selectorTab);
                return;
            }
            Tabs.SelectedItem = selectorTab;
            return;
        }

        var subject = _catalog.Resolve(entry.Slug);
        if (subject is null)
        {
            await ShowPersonalMessageAsync("Source is unavailable", "This Journal note refers to a study source that is not available in this Pathfinder installation.");
            return;
        }
        if (!string.IsNullOrWhiteSpace(entry.SourceVersion) && !entry.SourceVersion.Equals(subject.ExpectedSha256, StringComparison.OrdinalIgnoreCase))
        {
            await ShowPersonalMessageAsync("Source version changed", "Pathfinder will not silently redirect this exact Journal source link to different study content.");
            return;
        }

        if (entry.SourceLocation is null)
        {
            await OpenSubjectAsync(subject, true);
            return;
        }

        CloseAppSurface(restorePreviousTab: false);
        var journalTab = FindJournalTab();
        var journalIsBeside = journalTab is not null && IsTabParkedBeside(journalTab);
        var sourceTab = await CreateReadOnlySourceTabForLocationAsync(subject, CloneLocation(entry.SourceLocation));
        if (sourceTab is null)
        {
            await ShowPersonalMessageAsync("Source could not open", "Pathfinder could not create the verified read-only source view. Your Journal note was not changed.");
            return;
        }

        if (journalIsBeside)
        {
            // The Journal already occupies the static secondary slot. The exact read-only source
            // becomes the main view; ordinary split navigation leaves Journal parked beside it.
            return;
        }

        if (journalTab is not null && Tabs.TabItems.Contains(journalTab))
        {
            Tabs.SelectedItem = journalTab;
            await ShowTabBesideAsync(sourceTab);
            return;
        }

        Tabs.SelectedItem = sourceTab;
    }

    private JournalState BuildJournalRestoreTarget(BackupImportPlan plan)
    {
        var target = plan.ReplaceJournal ? JournalService.CloneState(plan.Journal) : _journal.ExportState();
        if (plan.PersonalStudy.SubjectNotes.Count == 0) return target;
        var byId = target.Entries.ToDictionary(x => x.Id, StringComparer.OrdinalIgnoreCase);
        foreach (var pair in plan.PersonalStudy.SubjectNotes.Where(x => !string.IsNullOrWhiteSpace(x.Value)))
        {
            var marker = pair.Key.Trim();
            if (target.LegacyPersonalMigrationSlugs.Contains(marker, StringComparer.OrdinalIgnoreCase)) continue;

            var subject = _catalog.Resolve(pair.Key);
            var id = LegacyPersonalJournalId(pair.Key);
            if (!byId.ContainsKey(id))
            {
                var migrated = new JournalEntry
                {
                    Id = id,
                    Title = subject?.Title ?? $"Imported Personal note · {pair.Key}",
                    Body = pair.Value,
                    Slug = subject?.ResourceId ?? "",
                    SourceVersion = subject?.ExpectedSha256.ToLowerInvariant() ?? "",
                    OriginalTimestampKnown = false,
                    CreatedUtc = DateTimeOffset.UtcNow,
                    UpdatedUtc = DateTimeOffset.UtcNow
                };
                target.Entries.Add(migrated);
                byId[id] = migrated;
            }
            if (!target.LegacyPersonalMigrationSlugs.Contains(marker, StringComparer.OrdinalIgnoreCase)) target.LegacyPersonalMigrationSlugs.Add(marker);
        }
        target.UpdatedUtc = DateTimeOffset.UtcNow;
        return JournalService.CloneState(target);
    }
}
