CURRENT CORRECTED REUSABLE PACKAGES — MEDICAL CORRECTION R1

This directory contains the reusable corrected packages that already existed in the frozen R2 payload shape.
For subjects touched again by Medical Correction R1, those existing current package copies were refreshed to match the corrected live cockpit.

No new pkg/p ZIPs were added, so the authoritative payload remains exactly 132 files. Subjects without an existing pkg/p package use the corrected live canonical cockpit as authority; their historical package remains only under pkg/o.

IMPORTANT: ../o/ is historical rollback/original provenance and is intentionally byte-for-byte unchanged. Never treat pkg/o as the current corrected teaching payload.

See meta/R2-PATCH-README.txt and the build-level Medical Correction R1 report for the current correction lineage.
