STEP 2 CK 2026 — R2 LINEAGE + MEDICAL CORRECTION R1

The physical R2 directory is retained for Windows compatibility. The current logical medical revision is W8-MEDICAL-CORRECTION-R1 (2026-10-05).

HISTORICAL R2 CORRECTION
------------------------
The September 24, 2026 R2 content-correctness patch remains part of the lineage. Its historical audit and regression-QC files are retained.

CURRENT MEDICAL CORRECTION R1
-----------------------------
Basis: completed GPT-6.1 Sol final medical audit, successor DEV reconciliation, and GPT-6 Astra MAX narrow challenge.
- 22 audited findings addressed: 4 MUST-fix-before-Stable + 18 SHOULD-fix-before-Stable.
- GI deep-completion: 14 approved optional high-value One-step-deeper additions, plus the release-relevant GI corrections/additions.
- The optional acute-pancreatitis-dx deeper proposal was intentionally omitted after Astra MAX found it duplicative of existing teaching.
- Corrected numbered live cockpits: 02, 05, 06, 07, 08, 09, 10, 12, 13, 14, 15, 21.
- Corrected extras: Clinical Recall Library and UWorld Checkbox Selector.

PACKAGE PRESERVATION
--------------------
pkg/o is historical rollback/original provenance and remains byte-for-byte unchanged.
No new pkg/p files were added. Existing current corrected package slots were refreshed only where applicable (05, 07, 08, 12, 14). Subjects without an existing pkg/p slot use their corrected live canonical cockpit as current authority while pkg/o remains historical only.

SCOPE
-----
No Windows runtime, UI, Journal, Search, Split View, storage schema, study-state keys, topic/question IDs, or answer-key behavior is intentionally changed by this medical correction.

See the build-level Medical Correction R1 implementation/QC records and current SHA manifests for exact accounting.
