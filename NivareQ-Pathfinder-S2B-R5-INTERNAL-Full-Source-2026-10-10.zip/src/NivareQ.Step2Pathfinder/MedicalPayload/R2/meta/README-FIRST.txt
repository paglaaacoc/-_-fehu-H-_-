STEP 2 CK 2026 — PATHFINDER MEDICAL PAYLOAD — MEDICAL CORRECTION R1

CURRENT STATUS
--------------
This is the medically corrected current payload prepared from the owner-accepted W8 Closure R1 baseline after the final GPT-6.1 Sol audit, DEV reconciliation, and GPT-6 Astra MAX narrow challenge.

The live canonical cockpits contain the bounded Medical Correction R1 changes only. No Windows runtime, Journal, shell-feature, storage-schema, navigation behavior, study-state key, or answer-key redesign is part of this payload correction.

PRESERVATION MODEL
------------------
Keep this entire folder together.
- c/ and x/ contain the current live canonical study resources.
- pkg/o contains historical rollback/original ZIP archives and is intentionally byte-for-byte unchanged from W8 Closure R1.
- pkg/p contains only the reusable corrected-package slots that already existed in the frozen 132-file R2 payload; applicable existing copies were refreshed where their subject was corrected again. No new pkg/p files were added.
- meta/NAVIGATION-MANIFEST.json and SHA256SUMS.txt describe the current corrected payload.

The physical folder name remains R2 for compatibility with the accepted Windows runtime path contract. Integrity metadata identifies the current logical revision as W8-MEDICAL-CORRECTION-R1.

Educational Step 2 CK study material; not patient-specific medical advice.
