/* Pathfinder Scratchpad S1 — self-contained, no third-party code, no network. */
(() => {
'use strict';
const $ = id => document.getElementById(id);
const ui = Object.fromEntries(['app','padSelect','pageSelect','guideSelect','spacingSelect','spacesSelect','sheets','saveStatus','retrySave','typeMode','drawMode','inkTools','penTool','eraserTool','inkColor','inkWidth','undoInk','redoInk','clearInk','clearPage','modeHint','addPad','renamePad','deletePad','addPage','deletePage','blockingError','errorDetails'].map(k => [k,$(k)]));
let state=null, mode='type', tool='pen', loaded=false, revision=0, sentRevision=0, inflight=0, nextSequence=1, timer=0, lastFailed=false;
let activeStroke=null, activeCanvas=null, activeCellIndex=-1;
let undoStack=[], redoStack=[];
const bridge = window.chrome?.webview;
// Never use arbitrary messages as CSS: the native bridge supplies only the six
// theme colors and they must remain ordinary 6-digit hex values.
function applyTheme(palette){
 if(!palette||typeof palette!=='object')return;
 const keys=['shell','surface','ink','muted','outline','accent'];
 for(const key of keys){const v=palette[key];if(typeof v==='string'&&/^#[0-9a-fA-F]{6}$/.test(v))document.documentElement.style.setProperty('--'+key,v);}
}
// The editor scrolls; the paper does not. Move guides with the editor's text.
// Text 17px, line-height=spacing, top padding 5px -> baseline ~= spacing/2+10.
// Position each guide 3px below that baseline, then offset by scrollTop.
function alignGuide(sheet,area,spacing){
 const baselineOffset=13-spacing/2;
 sheet.style.backgroundPositionY=Math.round(baselineOffset-area.scrollTop)+'px';
}

function uid(){return (globalThis.crypto?.randomUUID?.() ?? String(Date.now())+'-'+Math.random().toString(36).slice(2));}
function makeCell(){return {text:'',strokes:[]};}
function makePage(){return {id:uid(),guide:'ruled',spacing:32,cells:[makeCell()]};}
function makePad(title){const p=makePage();return {id:uid(),title,activePageId:p.id,pages:[p]};}
function initialState(){const pad=makePad('My first scratchpad');return {schemaVersion:1,activePadId:pad.id,pads:[pad]};}
const pad=()=>state?.pads.find(x=>x.id===state.activePadId)??state?.pads[0];
const page=()=>pad()?.pages.find(x=>x.id===pad().activePageId)??pad()?.pages[0];
function markDirty(){if(!loaded)return;revision++;status('Unsaved changes','pending');clearTimeout(timer);timer=setTimeout(sendSave,300);}
function status(message,kind){ui.saveStatus.textContent=message;ui.saveStatus.dataset.status=kind;ui.retrySave.hidden=kind!=='error';}
function sendSave(){if(!loaded||inflight||!bridge)return;clearTimeout(timer);inflight=nextSequence++;sentRevision=revision;status('Saving…','pending');bridge.postMessage({type:'save',seq:inflight,state});}
function setMode(next){mode=next;ui.app.dataset.mode=next;ui.typeMode.setAttribute('aria-pressed',String(next==='type'));ui.drawMode.setAttribute('aria-pressed',String(next==='draw'));ui.inkTools.hidden=next!=='draw';ui.modeHint.textContent=next==='type'?'Type or paste into any space. Use Ctrl+C / Ctrl+V / Ctrl+Z as usual. Your drawing stays visible.':'Draw with mouse, finger or pen. Eraser removes strokes; text stays intact. Switch to Type to edit text.';renderCells();}
function setTool(next){tool=next;ui.penTool.setAttribute('aria-pressed',String(next==='pen'));ui.eraserTool.setAttribute('aria-pressed',String(next==='eraser'));}
function renderControls(){const currentPad=pad();const currentPage=page();ui.padSelect.replaceChildren();for(const p of state.pads){const opt=new Option(p.title,p.id);ui.padSelect.add(opt);}ui.padSelect.value=currentPad.id;ui.pageSelect.replaceChildren();currentPad.pages.forEach((p,i)=>ui.pageSelect.add(new Option('Page '+(i+1),p.id)));ui.pageSelect.value=currentPage.id;ui.guideSelect.value=currentPage.guide;ui.spacingSelect.value=String(currentPage.spacing);ui.spacesSelect.value=String(currentPage.cells.length);ui.deletePad.disabled=state.pads.length<=1;ui.deletePage.disabled=currentPad.pages.length<=1;}
function render(){if(!loaded)return;renderControls();renderCells();}
function renderCells(){if(!loaded)return;const currentPage=page();
 const previousOffsets=ui.sheets.dataset.pageId===currentPage.id ? [...ui.sheets.querySelectorAll('textarea.editor')].map(x=>x.scrollTop) : [];
 ui.sheets.replaceChildren();ui.sheets.dataset.pageId=currentPage.id;ui.sheets.dataset.spaces=String(currentPage.cells.length);currentPage.cells.forEach((cell,index)=>{
 const container=document.createElement('article');container.className='space';
 const head=document.createElement('div');head.className='spacehead';head.textContent=currentPage.cells.length===1?'Writing space':`Writing space ${index+1}`;
 const sheet=document.createElement('div');sheet.className='sheet '+currentPage.guide;sheet.style.setProperty('--line-spacing',currentPage.spacing+'px');sheet.style.setProperty('--triple-spacing',(currentPage.spacing*3)+'px');
 const area=document.createElement('textarea');area.className='editor';area.setAttribute('aria-label',`Writing space ${index+1} text`);area.setAttribute('spellcheck','true');area.setAttribute('placeholder',mode==='type'?'Type or paste here…':'');area.value=cell.text;area.readOnly=mode==='draw';
 area.addEventListener('input',()=>{cell.text=area.value;alignGuide(sheet,area,currentPage.spacing);markDirty();});
 area.addEventListener('scroll',()=>alignGuide(sheet,area,currentPage.spacing),{passive:true});
 const canvas=document.createElement('canvas');canvas.className='ink';canvas.setAttribute('aria-label',`Writing space ${index+1} ink layer`);canvas.dataset.index=index;
 canvas.addEventListener('pointerdown',e=>down(e,index,canvas));canvas.addEventListener('pointermove',e=>move(e,canvas));canvas.addEventListener('pointerup',e=>up(e,canvas));canvas.addEventListener('pointercancel',()=>cancelStroke());
 sheet.append(area,canvas);container.append(head,sheet);ui.sheets.append(container);
 area.scrollTop=previousOffsets[index]??0;
 alignGuide(sheet,area,currentPage.spacing);
 requestAnimationFrame(()=>{alignGuide(sheet,area,currentPage.spacing);redraw(canvas,cell);});
 });}
function pointOf(event,canvas){const r=canvas.getBoundingClientRect();return [Math.max(0,Math.min(1,(event.clientX-r.left)/r.width)),Math.max(0,Math.min(1,(event.clientY-r.top)/r.height))];}
function drawStroke(ctx,s,w,h){const points=s.points;if(!points?.length)return;ctx.lineWidth=s.width;ctx.strokeStyle=s.color;ctx.fillStyle=s.color;ctx.lineJoin='round';ctx.lineCap='round';ctx.beginPath();ctx.moveTo(points[0][0]*w,points[0][1]*h);if(points.length===1){ctx.arc(points[0][0]*w,points[0][1]*h,Math.max(1,s.width/2),0,Math.PI*2);ctx.fill();return;}for(const p of points.slice(1))ctx.lineTo(p[0]*w,p[1]*h);ctx.stroke();}
function redraw(canvas,cell){if(!canvas.isConnected)return;const r=canvas.getBoundingClientRect();const ratio=Math.min(window.devicePixelRatio||1,3);const w=Math.max(1,r.width),h=Math.max(1,r.height);canvas.width=Math.round(w*ratio);canvas.height=Math.round(h*ratio);const ctx=canvas.getContext('2d');ctx.setTransform(ratio,0,0,ratio,0,0);ctx.clearRect(0,0,w,h);for(const s of cell.strokes)drawStroke(ctx,s,w,h);if(activeCanvas===canvas&&activeStroke)drawStroke(ctx,activeStroke,w,h);}
function redrawAll(){for(const c of ui.sheets.querySelectorAll('canvas.ink')){const index=Number(c.dataset.index);redraw(c,page().cells[index]);}}
function eraseAt(cell,index,point){let nearest=-1,dist=.00032;cell.strokes.forEach((s,i)=>{for(const p of s.points){const dx=(p[0]-point[0]);const dy=(p[1]-point[1]);const delta=dx*dx+dy*dy;if(delta<dist){dist=delta;nearest=i;}}});if(nearest>=0){const removed=cell.strokes.splice(nearest,1)[0];undoStack.push({pageId:page().id,cellIndex:index,kind:'erase',stroke:removed,at:nearest});redoStack=[];markDirty();}}
function down(e,index,canvas){if(mode!=='draw'||!loaded)return;if(e.button!==0&&e.pointerType==='mouse')return;const cell=page().cells[index];const p=pointOf(e,canvas);canvas.setPointerCapture(e.pointerId);activeCanvas=canvas;activeCellIndex=index;if(tool==='eraser'){eraseAt(cell,index,p);redraw(canvas,cell);return;}activeStroke={color:ui.inkColor.value,width:Number(ui.inkWidth.value),points:[p]};redraw(canvas,cell);}
function move(e,canvas){if(canvas!==activeCanvas)return;if(tool==='eraser'){eraseAt(page().cells[activeCellIndex],activeCellIndex,pointOf(e,canvas));redraw(canvas,page().cells[activeCellIndex]);return;}if(!activeStroke)return;const p=pointOf(e,canvas);const prev=activeStroke.points.at(-1);if(prev&&Math.abs(prev[0]-p[0])+Math.abs(prev[1]-p[1])<.001)return;if(activeStroke.points.length<4000)activeStroke.points.push(p);redraw(canvas,page().cells[activeCellIndex]);}
function up(e,canvas){if(canvas!==activeCanvas)return;if(activeStroke){const cell=page().cells[activeCellIndex];const final=activeStroke;cell.strokes.push(final);undoStack.push({pageId:page().id,cellIndex:activeCellIndex,kind:'add',stroke:final});redoStack=[];markDirty();}activeStroke=null;activeCanvas=null;activeCellIndex=-1;redraw(canvas,page().cells[Number(canvas.dataset.index)]);}
function cancelStroke(){activeCanvas=null;activeStroke=null;activeCellIndex=-1;redrawAll();}
function applyInkHistory(record,backwards){const target=page();if(record.pageId!==target.id)return false;const cell=target.cells[record.cellIndex];if(!cell)return false;const adding=(record.kind==='add')!==backwards;if(adding){const idx=record.kind==='erase'?Math.min(record.at,cell.strokes.length):cell.strokes.length;cell.strokes.splice(idx,0,record.stroke);}else{const idx=cell.strokes.indexOf(record.stroke);if(idx<0)return false;cell.strokes.splice(idx,1);}return true;}
function undo(){const op=undoStack.pop();if(!op)return;if(applyInkHistory(op,true)){redoStack.push(op);markDirty();redrawAll();}}
function redo(){const op=redoStack.pop();if(!op)return;if(applyInkHistory(op,false)){undoStack.push(op);markDirty();redrawAll();}}
function resetHistory(){undoStack=[];redoStack=[];}
function renameSafe(name){return (name||'').trim().slice(0,120);}
function bind(){
 ui.addPad.onclick=()=>{if(state.pads.length>=80){alert('Maximum of 80 scratchpads.');return;}const name=renameSafe(prompt('New scratchpad name','New scratchpad'));if(!name)return;const p=makePad(name);state.pads.push(p);state.activePadId=p.id;resetHistory();markDirty();render();};
 ui.renamePad.onclick=()=>{const name=renameSafe(prompt('Rename scratchpad',pad().title));if(!name)return;pad().title=name;markDirty();renderControls();};
 ui.deletePad.onclick=()=>{if(state.pads.length<=1)return;if(!confirm('Delete this scratchpad and all its pages? This cannot be undone. Create a backup first if needed.'))return;state.pads=state.pads.filter(x=>x.id!==pad().id);state.activePadId=state.pads[0].id;resetHistory();markDirty();render();};
 ui.padSelect.onchange=()=>{state.activePadId=ui.padSelect.value;resetHistory();markDirty();render();};
 ui.pageSelect.onchange=()=>{pad().activePageId=ui.pageSelect.value;resetHistory();markDirty();render();};
 ui.addPage.onclick=()=>{if(pad().pages.length>=100){alert('Maximum of 100 pages per pad.');return;}const next=makePage();pad().pages.push(next);pad().activePageId=next.id;resetHistory();markDirty();render();};
 ui.deletePage.onclick=()=>{if(pad().pages.length<=1)return;if(!confirm('Delete this page, including typing and ink? This cannot be undone.'))return;const current=page();pad().pages=pad().pages.filter(x=>x.id!==current.id);pad().activePageId=pad().pages[0].id;resetHistory();markDirty();render();};
 ui.guideSelect.onchange=()=>{page().guide=ui.guideSelect.value;markDirty();renderCells();};
 ui.spacingSelect.onchange=()=>{page().spacing=Number(ui.spacingSelect.value);markDirty();renderCells();};
 ui.spacesSelect.onchange=()=>{const cells=page().cells;const wanted=Number(ui.spacesSelect.value);if(wanted<cells.length&&cells.slice(wanted).some(x=>x.text||x.strokes.length)&&!confirm('Reducing spaces will remove writing in the extra spaces. Continue?')){ui.spacesSelect.value=String(cells.length);return;}page().cells=wanted<=cells.length?cells.slice(0,wanted):cells.concat(Array.from({length:wanted-cells.length},makeCell));resetHistory();markDirty();renderCells();};
 ui.typeMode.onclick=()=>setMode('type');ui.drawMode.onclick=()=>setMode('draw');ui.penTool.onclick=()=>setTool('pen');ui.eraserTool.onclick=()=>setTool('eraser');ui.undoInk.onclick=undo;ui.redoInk.onclick=redo;
 ui.clearInk.onclick=()=>{if(!page().cells.some(c=>c.strokes.length)||!confirm('Erase all handwriting on this page? Typed text and writing guides will remain.'))return;page().cells.forEach(c=>c.strokes=[]);resetHistory();markDirty();redrawAll();};
 ui.clearPage.onclick=()=>{if(!confirm('Clear all typed text and ink from every writing space on this page? This cannot be undone.'))return;page().cells.forEach(c=>{c.text='';c.strokes=[];});resetHistory();markDirty();renderCells();};
 ui.retrySave.onclick=()=>{if(!inflight)sendSave();};
 window.addEventListener('resize',()=>{clearTimeout(window._scratchpadResizeTimer);window._scratchpadResizeTimer=setTimeout(redrawAll,80);});
 window.addEventListener('keydown',e=>{if(mode==='draw'&&(e.ctrlKey||e.metaKey)&&!e.shiftKey&&e.key.toLowerCase()==='z'){e.preventDefault();undo();}if(mode==='draw'&&(e.ctrlKey||e.metaKey)&&(e.key.toLowerCase()==='y'||e.shiftKey&&e.key.toLowerCase()==='z')){e.preventDefault();redo();}});
 window.addEventListener('pagehide',()=>{if(loaded&&revision>0&&bridge)bridge.postMessage({type:'save',seq:nextSequence++,state});});
}
function load(message){if(message.type==='load-error'){ui.blockingError.hidden=false;ui.errorDetails.textContent=message.message;status('Unable to load','error');return;}if(message.type==='load'){state=message.state??initialState();loaded=true;bind();setMode('type');render();status(message.state?'Saved':'New scratchpad','saved');if(!message.state)markDirty();}}
function onNativeMessage(evt){const msg=evt.data;if(!msg||typeof msg!=='object')return;if(msg.type==='theme'){applyTheme(msg.palette);return;}if(msg.type==='load'||msg.type==='load-error'){if(!loaded)load(msg);return;}if(msg.type==='save-error'){inflight=0;status(msg.message||'Save failed','error');return;}if(msg.type==='saved'&&msg.seq===inflight){inflight=0;if(!msg.ok){status('Save failed: '+(msg.message||'Storage error'),'error');lastFailed=true;return;}lastFailed=false;if(revision>sentRevision){status('Unsaved changes','pending');sendSave();}else status('Saved locally','saved');}}
if(bridge){bridge.addEventListener('message',onNativeMessage);bridge.postMessage({type:'ready'});}else{ui.blockingError.hidden=false;ui.errorDetails.textContent='Scratchpad requires Pathfinder Windows. Open it from the native app to enable safe storage.';status('Not connected','error');}
window.pathfinderScratchpadExport=()=>loaded?state:null;
})();
