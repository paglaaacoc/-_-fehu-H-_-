using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using Windows.ApplicationModel.DataTransfer;

namespace NivareQ.Step2Pathfinder;

public sealed partial class MainWindow
{
    // WinUI's default TextCommandBarFlyout can render with a popup-root theme that
    // disagrees with Pathfinder's custom shell theme. Use the same native MenuFlyout
    // family that already renders correctly for Pathfinder tab menus, while preserving
    // the expected Copy / Select all behavior for selectable shell text.
    private UIElement PrepareShellContent(UIElement content)
    {
        if (content is FrameworkElement root)
        {
            void OnLoaded(object sender, RoutedEventArgs args)
            {
                root.Loaded -= OnLoaded;
                ApplyShellTextSelectionMenus(root);
            }

            root.Loaded += OnLoaded;
        }
        return content;
    }

    private static void ApplyShellTextSelectionMenus(DependencyObject root)
    {
        if (root is TextBlock text && text.IsTextSelectionEnabled)
        {
            text.ContextFlyout = CreateShellTextMenu(text);
            text.SelectionFlyout = CreateShellTextMenu(text);
        }

        var count = VisualTreeHelper.GetChildrenCount(root);
        for (var i = 0; i < count; i++)
            ApplyShellTextSelectionMenus(VisualTreeHelper.GetChild(root, i));
    }

    private static MenuFlyout CreateShellTextMenu(TextBlock text)
    {
        var flyout = new MenuFlyout();
        var copy = new MenuFlyoutItem { Text = "Copy", KeyboardAcceleratorTextOverride = "Ctrl+C" };
        var selectAll = new MenuFlyoutItem { Text = "Select all", KeyboardAcceleratorTextOverride = "Ctrl+A" };

        flyout.Opening += (_, _) => copy.IsEnabled = !string.IsNullOrEmpty(text.SelectedText);
        copy.Click += (_, _) =>
        {
            if (string.IsNullOrEmpty(text.SelectedText)) return;
            try
            {
                var package = new DataPackage();
                package.SetText(text.SelectedText);
                Clipboard.SetContent(package);
            }
            catch
            {
                // Copy is a convenience command. A clipboard failure must never affect
                // the study surface or persistence/runtime state.
            }
        };
        selectAll.Click += (_, _) => text.SelectAll();

        flyout.Items.Add(copy);
        flyout.Items.Add(selectAll);
        return flyout;
    }
}
