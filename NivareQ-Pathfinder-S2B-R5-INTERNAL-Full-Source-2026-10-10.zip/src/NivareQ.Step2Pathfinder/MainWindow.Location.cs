using System.Text.Json;
using Microsoft.Web.WebView2.Core;
using NivareQ.Step2Pathfinder.Models;
using NivareQ.Step2Pathfinder.Services;

namespace NivareQ.Step2Pathfinder;

public sealed partial class MainWindow
{
    private const int LocationSchemaVersion = PathfinderLocation.CurrentSchemaVersion;
    private const int MaxLocationContext = 420;

    private long BeginLocationRequest(StudyTabContext context, string reason)
    {
        var request = ++context.LocationRequestVersion;
        context.ActiveLocationReason = reason;
        LogStudyEvent(context, "location-request", $"{request}:{reason}");
        return request;
    }

    private static bool IsLocationRequestCurrent(StudyTabContext context, long request)
        => request > 0 && context.LocationRequestVersion == request;

    private void CancelLocationRequests(StudyTabContext context, string reason)
    {
        context.LocationRequestVersion++;
        context.ActiveLocationReason = "";
        LogStudyEvent(context, "location-cancel", reason);
    }

    private SourceLocationValidationResult ValidateStrictSourceLocation(StudyTabContext context, PathfinderLocation location)
    {
        if (location.SchemaVersion != LocationSchemaVersion)
            return SourceLocationValidationResult.Fail("unsupported-version", "This saved source uses an unsupported Pathfinder location version.");
        if (!location.Purpose.Equals("source", StringComparison.OrdinalIgnoreCase))
            return SourceLocationValidationResult.Fail("wrong-purpose", "This location is not a strict source reference.");
        if (string.IsNullOrWhiteSpace(location.ResourceId) || !location.ResourceId.Equals(context.Subject.ResourceId, StringComparison.OrdinalIgnoreCase))
            return SourceLocationValidationResult.Fail("ownership", "This saved source does not belong to the open cockpit.");
        if (string.IsNullOrWhiteSpace(location.SourceVersion))
            return SourceLocationValidationResult.Fail("missing-source-version", "This saved source has no verifiable cockpit source identity.");
        if (string.IsNullOrWhiteSpace(context.Subject.ExpectedSha256))
            return SourceLocationValidationResult.Fail("unverified-current-source", "Pathfinder cannot verify the currently loaded cockpit bytes.");
        if (!location.SourceVersion.Equals(context.Subject.ExpectedSha256, StringComparison.OrdinalIgnoreCase))
            return SourceLocationValidationResult.Fail("stale-source", "This saved source belongs to a different version of this cockpit. Pathfinder will not guess a replacement location.");
        if (!location.HasDurableTarget)
            return SourceLocationValidationResult.Fail("missing-target-identity", "This saved source has no durable target identity.");
        return SourceLocationValidationResult.Pass();
    }

    private async Task<StudyLocationState?> CapturePositionAsync(StudyTabContext context)
    {
        if (context.ViewRole != CockpitViewRole.Primary) return context.LastKnownLocation;
        if (_suspendCockpitPositionPersistenceUntilRestart)
            return context.LastKnownLocation ?? _personal.PositionFor(context.Subject.ResourceId);
        if (!context.CaptureAuthorityReady || !context.DocumentHealthy || context.WebView.CoreWebView2 is null)
            return context.LastKnownLocation ?? _personal.PositionFor(context.Subject.ResourceId);

        var epoch = CaptureRuntimeMutationEpoch();
        var generation = context.ContentGeneration;
        var resourceId = context.Subject.ResourceId;
        var sourceVersion = context.Subject.ExpectedSha256;
        try
        {
            var location = await CapturePathfinderLocationAsync(context, "resume");
            if (location is null) return context.LastKnownLocation ?? _personal.PositionFor(resourceId);
            if (!IsRuntimeMutationCurrent(epoch, context)
                || _suspendCockpitPositionPersistenceUntilRestart
                || !context.DocumentHealthy
                || context.ContentGeneration != generation
                || !context.Subject.ResourceId.Equals(resourceId, StringComparison.OrdinalIgnoreCase)
                || !context.Subject.ExpectedSha256.Equals(sourceVersion, StringComparison.OrdinalIgnoreCase))
                return context.LastKnownLocation ?? _personal.PositionFor(resourceId);
            context.LastKnownLocation = location;
            _personal.SetPosition(resourceId, location);
            SchedulePersonalSave();
            return location;
        }
        catch
        {
            return context.LastKnownLocation ?? _personal.PositionFor(resourceId);
        }
    }

    private async Task<StudyLocationState?> CaptureStrictSourceLocationAsync(StudyTabContext context)
    {
        if (context.ViewRole != CockpitViewRole.Primary) return context.LastKnownLocation;
        if (context.WebView.CoreWebView2 is null || !context.CaptureAuthorityReady) return null;
        return await CapturePathfinderLocationAsync(context, "source");
    }

    private async Task<StudyLocationState?> CapturePathfinderLocationAsync(StudyTabContext context, string purpose)
    {
        if (context.WebView.CoreWebView2 is null) return null;
        var resourceId = JsonSerializer.Serialize(context.Subject.ResourceId);
        var sourceVersion = JsonSerializer.Serialize(context.Subject.ExpectedSha256.ToLowerInvariant());
        var purposeJson = JsonSerializer.Serialize(purpose.Equals("source", StringComparison.OrdinalIgnoreCase) ? "source" : "resume");
        var script = """
            (() => {
              const schema=__SCHEMA_VERSION__;
              const resourceId=__RESOURCE_ID__;
              const sourceVersion=__SOURCE_VERSION__;
              const purpose=__PURPOSE__;
              const maxContext=__MAX_CONTEXT__;
              const normalize=s=>(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[\u2010-\u2015\-\/|]+/g,' ').replace(/\u00a0/g,' ').replace(/[^\p{L}\p{N}]+/gu,' ').replace(/\s+/g,' ').trim().toLowerCase();
              const meaningful=(el)=>el?.closest?.('article,section,details,summary,.topic,.card,.module,.panel,.box,.item,.question,.pattern,[data-topic],[data-id],[data-section],tr,li,blockquote,p,h1,h2,h3,h4,h5,h6')||el;
              const px=Math.max(1,Math.min(innerWidth-2,Math.round(innerWidth*.48)));
              const py=Math.max(1,Math.min(innerHeight-2,Math.round(Math.min(180,innerHeight*.28))));
              const stack=document.elementsFromPoint?document.elementsFromPoint(px,py):[];
              let chosen=stack.find(el=>!el.closest?.('nav,.nav,.navin,header.sticky,button,input,select,textarea'))||stack[0]||document.body;
              chosen=meaningful(chosen)||document.body;
              let anchor=chosen;
              while(anchor&&anchor!==document.body&&!anchor.id)anchor=anchor.parentElement;
              if(!anchor)anchor=document.body;
              if(purpose!=='source'&&!anchor.id)anchor=document.querySelector('main[id],section[id],header[id]')||document.body;
              const pathFor=(a,t)=>{if(!a||!t)return'';if(a===t)return'.';const parts=[];let n=t;while(n&&n!==a&&parts.length<80){const p=n.parentElement;if(!p)return'';const children=[...p.children],idx=children.indexOf(n);if(idx<0)return'';parts.unshift(`${String(n.tagName||'').toLowerCase()}:${idx}`);n=p}return n===a?parts.join('/').slice(0,1400):''};
              const anchorTop=(anchor.getBoundingClientRect?.().top||0)+scrollY;
              const targetTop=(chosen.getBoundingClientRect?.().top||0)+scrollY;
              const details=[];let n=chosen;while(n&&n!==document.body){if(n.tagName==='DETAILS'&&n.open&&n.id)details.push(n.id);n=n.parentElement}
              return JSON.stringify({type:'pathfinder-location-v2',schemaVersion:schema,resourceId,sourceVersion,purpose,anchor:anchor.id||'',targetId:chosen.id||'',targetPath:pathFor(anchor,chosen),context:normalize(chosen.textContent||'').slice(0,maxContext),offsetY:scrollY-anchorTop,targetOffsetY:scrollY-targetTop,hash:location.hash||'',scrollX:scrollX||0,scrollY:scrollY||0,openDetails:details.slice(0,30),updatedUtc:new Date().toISOString()});
            })();
            """
            .Replace("__SCHEMA_VERSION__", LocationSchemaVersion.ToString())
            .Replace("__RESOURCE_ID__", resourceId)
            .Replace("__SOURCE_VERSION__", sourceVersion)
            .Replace("__PURPOSE__", purposeJson)
            .Replace("__MAX_CONTEXT__", MaxLocationContext.ToString());
        var raw = await context.WebView.CoreWebView2.ExecuteScriptAsync(script);
        var json = JsonSerializer.Deserialize<string>(raw);
        if (string.IsNullOrWhiteSpace(json)) return null;
        var message = JsonSerializer.Deserialize<LocationMessage>(json, LocationJsonOptions);
        return message?.ToStudyLocation();
    }

    private async Task InstallPositionBridgeAsync(StudyTabContext context)
    {
        if (context.ViewRole != CockpitViewRole.Primary || context.WebView.CoreWebView2 is null) return;
        var resourceId = JsonSerializer.Serialize(context.Subject.ResourceId);
        var sourceVersion = JsonSerializer.Serialize(context.Subject.ExpectedSha256.ToLowerInvariant());
        var generation = context.ContentGeneration;
        var script = """
            (() => {
              const generation=__GENERATION__;
              if(window.__nivareqPathfinderLocationBridge===generation)return;
              window.__nivareqPathfinderLocationBridge=generation;
              const resourceId=__RESOURCE_ID__,sourceVersion=__SOURCE_VERSION__,schema=__SCHEMA_VERSION__,maxContext=__MAX_CONTEXT__;
              const normalize=s=>(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[\u2010-\u2015\-\/|]+/g,' ').replace(/\u00a0/g,' ').replace(/[^\p{L}\p{N}]+/gu,' ').replace(/\s+/g,' ').trim().toLowerCase();
              const meaningful=(el)=>el?.closest?.('article,section,details,summary,.topic,.card,.module,.panel,.box,.item,.question,.pattern,[data-topic],[data-id],[data-section],tr,li,blockquote,p,h1,h2,h3,h4,h5,h6')||el;
              const pathFor=(a,t)=>{if(!a||!t)return'';if(a===t)return'.';const parts=[];let n=t;while(n&&n!==a&&parts.length<80){const p=n.parentElement;if(!p)return'';const children=[...p.children],idx=children.indexOf(n);if(idx<0)return'';parts.unshift(`${String(n.tagName||'').toLowerCase()}:${idx}`);n=p}return n===a?parts.join('/').slice(0,1400):''};
              let timer=0;
              const send=()=>{try{
                const px=Math.max(1,Math.min(innerWidth-2,Math.round(innerWidth*.48))),py=Math.max(1,Math.min(innerHeight-2,Math.round(Math.min(180,innerHeight*.28))));
                const stack=document.elementsFromPoint?document.elementsFromPoint(px,py):[];let chosen=stack.find(el=>!el.closest?.('nav,.nav,.navin,header.sticky,button,input,select,textarea'))||stack[0]||document.body;chosen=meaningful(chosen)||document.body;
                let anchor=chosen;while(anchor&&anchor!==document.body&&!anchor.id)anchor=anchor.parentElement;if(!anchor)anchor=document.body;if(!anchor.id)anchor=document.querySelector('main[id],section[id],header[id]')||document.body;
                const anchorTop=(anchor.getBoundingClientRect?.().top||0)+scrollY,targetTop=(chosen.getBoundingClientRect?.().top||0)+scrollY;
                const details=[];let n=chosen;while(n&&n!==document.body){if(n.tagName==='DETAILS'&&n.open&&n.id)details.push(n.id);n=n.parentElement}
                chrome.webview.postMessage(JSON.stringify({type:'pathfinder-location-v2',generation,schemaVersion:schema,resourceId,sourceVersion,purpose:'resume',anchor:anchor.id||'',targetId:chosen.id||'',targetPath:pathFor(anchor,chosen),context:normalize(chosen.textContent||'').slice(0,maxContext),offsetY:scrollY-anchorTop,targetOffsetY:scrollY-targetTop,hash:location.hash||'',scrollX:scrollX||0,scrollY:scrollY||0,openDetails:details.slice(0,30),updatedUtc:new Date().toISOString()}));
              }catch(_){}};
              const queue=()=>{clearTimeout(timer);timer=setTimeout(send,220)};
              addEventListener('scroll',queue,{passive:true});addEventListener('hashchange',queue);addEventListener('pagehide',send);document.addEventListener('click',queue,true);send();
            })();
            """
            .Replace("__GENERATION__", generation.ToString())
            .Replace("__RESOURCE_ID__", resourceId)
            .Replace("__SOURCE_VERSION__", sourceVersion)
            .Replace("__SCHEMA_VERSION__", LocationSchemaVersion.ToString())
            .Replace("__MAX_CONTEXT__", MaxLocationContext.ToString());
        try { await context.WebView.CoreWebView2.ExecuteScriptAsync(script); } catch { }
    }

    private void HandleStudyWebMessage(StudyTabContext context, CoreWebView2WebMessageReceivedEventArgs e)
    {
        try
        {
            var text = e.TryGetWebMessageAsString();
            using var doc = JsonDocument.Parse(text);
            if (!doc.RootElement.TryGetProperty("type", out var typeElement) || typeElement.ValueKind != JsonValueKind.String) return;
            var type = typeElement.GetString() ?? "";
            if (type.Equals("pathfinder-cockpit-state", StringComparison.OrdinalIgnoreCase))
            {
                HandleCockpitStateWebMessage(context, text);
                return;
            }
            if (!type.Equals("pathfinder-location-v2", StringComparison.OrdinalIgnoreCase)) return;
            if (_suspendCockpitPositionPersistenceUntilRestart || RestoreTransactionService.MutationsBlocked || context.ViewRole != CockpitViewRole.Primary || !context.CaptureAuthorityReady || !_studyTabs.TryGetValue(context.Tab, out var registered) || !ReferenceEquals(registered, context)) return;
            var message = JsonSerializer.Deserialize<LocationMessage>(text, LocationJsonOptions);
            if (message is null) return;
            if (message.Generation != 0 && message.Generation != context.ContentGeneration) return;
            if (!message.ResourceId.Equals(context.Subject.ResourceId, StringComparison.OrdinalIgnoreCase)) return;
            if (!message.SourceVersion.Equals(context.Subject.ExpectedSha256, StringComparison.OrdinalIgnoreCase)) return;
            var location = message.ToStudyLocation();
            if (location is null || location.IsStrictSource) return;
            context.LastKnownLocation = location;
            _personal.SetPosition(context.Subject.ResourceId, location);
            SchedulePersonalSave();
        }
        catch { }
    }

    private async Task RestoreStudyLocationAsync(StudyTabContext context, StudyLocationState? location)
    {
        if (location is null || context.WebView.CoreWebView2 is null) return;
        var request = BeginLocationRequest(context, location.IsStrictSource ? "strict-source" : "resume");
        await ApplyPathfinderLocationAsync(context, location, request, persistResume: context.ViewRole == CockpitViewRole.Primary && !location.IsStrictSource);
    }

    private async Task<bool> RestoreStrictSourceLocationAsync(StudyTabContext context, StudyLocationState location)
    {
        var validation = ValidateStrictSourceLocation(context, location);
        if (!validation.Ok)
        {
            LogStudyEvent(context, "strict-source-rejected", validation.Reason);
            return false;
        }
        var request = BeginLocationRequest(context, "strict-source");
        return await ApplyPathfinderLocationAsync(context, location, request, persistResume: false);
    }

    private async Task<bool> ApplyPathfinderLocationAsync(StudyTabContext context, StudyLocationState location, long request, bool persistResume)
    {
        if (context.WebView.CoreWebView2 is null || !IsLocationRequestCurrent(context, request)) return false;
        var strict = location.IsStrictSource;
        if (strict)
        {
            var validation = ValidateStrictSourceLocation(context, location);
            if (!validation.Ok) return false;
        }

        context.CaptureAuthorityReady = false;
        var effective = CloneLocationV2(location);
        if (!strict)
        {
            effective.Purpose = "resume";
            effective.ResourceId = context.Subject.ResourceId;
            // Resume is intentionally more forgiving than strict source fidelity. If the
            // saved semantic identity belongs to older cockpit bytes, do not apply that
            // semantic target to a newer source; fall back to hash/pixels instead.
            if (string.IsNullOrWhiteSpace(effective.SourceVersion)
                || !effective.SourceVersion.Equals(context.Subject.ExpectedSha256, StringComparison.OrdinalIgnoreCase)
                || effective.SchemaVersion != LocationSchemaVersion)
            {
                effective.SchemaVersion = LocationSchemaVersion;
                effective.SourceVersion = context.Subject.ExpectedSha256.ToLowerInvariant();
                effective.Anchor = "";
                effective.TargetId = "";
                effective.TargetPath = "";
                effective.Context = "";
                effective.OffsetY = 0;
                effective.TargetOffsetY = 0;
                effective.OpenDetails = [];
            }
        }
        var json = JsonSerializer.Serialize(effective, LocationJsonOptions);
        var strictJson = strict ? "true" : "false";
        var script = """
            (() => {
              const request=__REQUEST__;
              if((window.__nivareqLocationRequest||0)>request)return JSON.stringify({ok:false,reason:'stale-request'});
              window.__nivareqLocationRequest=request;
              const loc=__LOCATION_JSON__;
              const strict=__STRICT__;
              const normalize=s=>(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[\u2010-\u2015\-\/|]+/g,' ').replace(/\u00a0/g,' ').replace(/[^\p{L}\p{N}]+/gu,' ').replace(/\s+/g,' ').trim().toLowerCase();
              const fromPath=(anchor,path)=>{if(!anchor||typeof path!=='string')return null;if(path==='.')return anchor;if(!path)return null;let n=anchor;for(const part of path.split('/')){const m=/^([a-z0-9-]+):(\d+)$/i.exec(part);if(!m)return null;const child=n.children?.[Number(m[2])];if(!child||String(child.tagName||'').toLowerCase()!==m[1].toLowerCase())return null;n=child}return n};
              const contextMatches=(target,context)=>{if(!target||!context)return !strict;const needle=normalize(context),text=normalize(target.textContent||'');if(!needle||!text)return false;return context.length>=420?text.startsWith(needle):text===needle};
              const strictCandidates=(root,context)=>{const needle=normalize(context);if(!root||needle.length<6)return[];const sel='article,section,details,summary,.topic,.card,.module,.panel,.box,.item,.question,.pattern,[data-topic],[data-id],[data-section],tr,li,blockquote,p,h1,h2,h3,h4,h5,h6';return [...root.querySelectorAll(sel)].filter(el=>!el.closest('script,style,noscript,template,svg')).filter(el=>{const text=normalize(el.textContent||'');return context.length>=420?text.startsWith(needle):text===needle})};
              const opened=[];const reveal=(target)=>{for(const id of (loc.OpenDetails||loc.openDetails||[])){const d=document.getElementById(id);if(d?.tagName==='DETAILS'&&!d.open){d.open=true;opened.push(id)}}let n=target;while(n){if(n.tagName==='DETAILS'&&!n.open){n.open=true;if(n.id)opened.push(n.id)}n=n.parentElement}};
              const anchorId=loc.Anchor??loc.anchor??'';const targetId=loc.TargetId??loc.targetId??'';const targetPath=loc.TargetPath??loc.targetPath??'';const context=loc.Context??loc.context??'';
              let anchor=anchorId?document.getElementById(anchorId):document.body;if(strict&&anchorId&&!anchor)return JSON.stringify({ok:false,reason:'missing-anchor'});anchor=anchor||document.body;
              let target=targetId?document.getElementById(targetId):null;if(target&&anchor!==target&&!anchor.contains(target))target=null;
              if(!target&&targetPath){const candidate=fromPath(anchor,targetPath);if(candidate&&(!strict||contextMatches(candidate,context)))target=candidate}
              if(!target&&context){if(strict){const candidates=strictCandidates(anchor,context);if(candidates.length>1)return JSON.stringify({ok:false,reason:'ambiguous-context'});target=candidates[0]||null}else{const needle=normalize(context);const all=[...anchor.querySelectorAll('article,section,details,summary,.topic,.card,.module,.panel,.box,.item,.question,.pattern,[data-topic],[data-id],[data-section],tr,li,blockquote,p,h1,h2,h3,h4,h5,h6,div')];target=all.find(el=>normalize(el.textContent||'').includes(needle))||null}}
              if(!target&&!strict)target=anchorId?anchor:null;
              if(target){reveal(target);const top=(target.getBoundingClientRect?.().top||0)+scrollY;const targetOffset=Number(loc.TargetOffsetY??loc.targetOffsetY??0)||0;scrollTo(Number(loc.ScrollX??loc.scrollX??0)||0,Math.max(0,top+targetOffset));return JSON.stringify({ok:true,reason:'target',openedDetails:opened,targetId:target.id||''})}
              if(strict)return JSON.stringify({ok:false,reason:'target-missing'});
              const hash=String(loc.Hash??loc.hash??'');if(hash){let id=hash.replace(/^#/,'');try{id=decodeURIComponent(id)}catch{}const h=document.getElementById(id)||document.getElementsByName(id)[0];if(h){reveal(h);h.scrollIntoView({block:'start',inline:'nearest',behavior:'auto'});return JSON.stringify({ok:true,reason:'hash',openedDetails:opened,targetId:h.id||''})}}
              scrollTo(Number(loc.ScrollX??loc.scrollX??0)||0,Number(loc.ScrollY??loc.scrollY??0)||0);return JSON.stringify({ok:true,reason:'pixel-fallback',openedDetails:opened,targetId:''});
            })();
            """
            .Replace("__REQUEST__", request.ToString())
            .Replace("__LOCATION_JSON__", json)
            .Replace("__STRICT__", strictJson);
        try
        {
            var raw = await context.WebView.CoreWebView2.ExecuteScriptAsync(script);
            if (!IsLocationRequestCurrent(context, request)) return false;
            var resultJson = JsonSerializer.Deserialize<string>(raw);
            var result = string.IsNullOrWhiteSpace(resultJson) ? null : JsonSerializer.Deserialize<LocationApplyResult>(resultJson, LocationJsonOptions);
            if (result?.Ok != true)
            {
                LogStudyEvent(context, strict ? "strict-source-failed" : "location-restore-failed", result?.Reason ?? "unknown");
                context.CaptureAuthorityReady = true;
                return false;
            }

            context.LastRevealSnapshot = result.OpenedDetails ?? [];
            if (persistResume)
            {
                var restored = CloneLocationV2(location);
                restored.Purpose = "resume";
                restored.ResourceId = context.Subject.ResourceId;
                restored.SourceVersion = context.Subject.ExpectedSha256.ToLowerInvariant();
                restored.UpdatedUtc = DateTimeOffset.UtcNow;
                context.LastKnownLocation = restored;
                if (!_suspendCockpitPositionPersistenceUntilRestart && !RestoreTransactionService.MutationsBlocked && IsLocationRequestCurrent(context, request) && _studyTabs.TryGetValue(context.Tab, out var registered) && ReferenceEquals(registered, context) && context.ViewRole == CockpitViewRole.Primary)
                {
                    _personal.SetPosition(context.Subject.ResourceId, restored);
                    SchedulePersonalSave();
                }
            }
            context.CaptureAuthorityReady = true;
            LogStudyEvent(context, strict ? "strict-source-restored" : "location-restored", result.Reason);
            return true;
        }
        catch (Exception ex)
        {
            if (IsLocationRequestCurrent(context, request)) context.CaptureAuthorityReady = true;
            LogStudyEvent(context, "location-restore-exception", ex.Message);
            return false;
        }
    }

    private async Task<TemporaryCockpitViewState?> CaptureTemporaryCockpitViewAsync(StudyTabContext context)
    {
        if (context.WebView.CoreWebView2 is null) return null;
        const string script = """
            (()=>{const input=document.querySelector('input#search,input[type="search"],input[aria-label*="search" i],input[placeholder*="search" i],input[placeholder*="find" i]');return JSON.stringify({searchValue:input?.value??'',openDetails:[...document.querySelectorAll('details[id][open]')].map(x=>x.id).slice(0,200)});})();
            """;
        try
        {
            var raw = await context.WebView.CoreWebView2.ExecuteScriptAsync(script);
            var json = JsonSerializer.Deserialize<string>(raw);
            return string.IsNullOrWhiteSpace(json) ? null : JsonSerializer.Deserialize<TemporaryCockpitViewState>(json, LocationJsonOptions);
        }
        catch { return null; }
    }

    private async Task RestoreTemporaryCockpitViewAsync(StudyTabContext context, TemporaryCockpitViewState? snapshot)
    {
        if (context.WebView.CoreWebView2 is null || snapshot is null) return;
        var json = JsonSerializer.Serialize(snapshot, LocationJsonOptions);
        var script = """
            (()=>{const s=__SNAPSHOT_JSON__,open=new Set(s.OpenDetails||s.openDetails||[]);for(const d of document.querySelectorAll('details[id]'))d.open=open.has(d.id);const input=document.querySelector('input#search,input[type="search"],input[aria-label*="search" i],input[placeholder*="search" i],input[placeholder*="find" i]');if(input&&input.value!==(s.SearchValue??s.searchValue??'')){input.value=s.SearchValue??s.searchValue??'';input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}))}})();
            """
            .Replace("__SNAPSHOT_JSON__", json);
        try { await context.WebView.CoreWebView2.ExecuteScriptAsync(script); } catch { }
    }

    private Uri NavigationUriWithSavedHash(Uri baseUri, StudyLocationState? location)
    {
        if (location is null || string.IsNullOrWhiteSpace(location.Hash)) return baseUri;
        try { return new UriBuilder(baseUri) { Fragment = location.Hash.TrimStart('#') }.Uri; }
        catch { return baseUri; }
    }

    private static StudyLocationState CloneLocationV2(PathfinderLocation source) => new()
    {
        SchemaVersion = source.SchemaVersion <= 0 ? LocationSchemaVersion : source.SchemaVersion,
        ResourceId = source.ResourceId ?? "",
        SourceVersion = source.SourceVersion ?? "",
        Purpose = string.IsNullOrWhiteSpace(source.Purpose) ? "resume" : source.Purpose,
        Anchor = source.Anchor ?? "",
        TargetId = source.TargetId ?? "",
        TargetPath = source.TargetPath ?? "",
        Context = source.Context ?? "",
        OffsetY = source.OffsetY,
        TargetOffsetY = source.TargetOffsetY,
        Hash = source.Hash ?? "",
        ScrollX = source.ScrollX,
        ScrollY = source.ScrollY,
        OpenDetails = (source.OpenDetails ?? []).Take(30).ToList(),
        UpdatedUtc = source.UpdatedUtc
    };

    private static readonly JsonSerializerOptions LocationJsonOptions = new() { PropertyNameCaseInsensitive = true };

    private sealed class LocationMessage
    {
        public string Type { get; set; } = "";
        public long Generation { get; set; }
        public int SchemaVersion { get; set; }
        public string ResourceId { get; set; } = "";
        public string SourceVersion { get; set; } = "";
        public string Purpose { get; set; } = "resume";
        public string Anchor { get; set; } = "";
        public string TargetId { get; set; } = "";
        public string TargetPath { get; set; } = "";
        public string Context { get; set; } = "";
        public double OffsetY { get; set; }
        public double TargetOffsetY { get; set; }
        public string Hash { get; set; } = "";
        public double ScrollX { get; set; }
        public double ScrollY { get; set; }
        public List<string> OpenDetails { get; set; } = [];
        public DateTimeOffset UpdatedUtc { get; set; } = DateTimeOffset.UtcNow;

        public StudyLocationState? ToStudyLocation()
        {
            if (SchemaVersion != LocationSchemaVersion || string.IsNullOrWhiteSpace(ResourceId) || string.IsNullOrWhiteSpace(SourceVersion)) return null;
            return new StudyLocationState
            {
                SchemaVersion = SchemaVersion,
                ResourceId = ResourceId,
                SourceVersion = SourceVersion,
                Purpose = string.IsNullOrWhiteSpace(Purpose) ? "resume" : Purpose,
                Anchor = Anchor ?? "",
                TargetId = TargetId ?? "",
                TargetPath = TargetPath ?? "",
                Context = Context ?? "",
                OffsetY = OffsetY,
                TargetOffsetY = TargetOffsetY,
                Hash = Hash ?? "",
                ScrollX = Math.Max(0, ScrollX),
                ScrollY = Math.Max(0, ScrollY),
                OpenDetails = (OpenDetails ?? []).Where(x => !string.IsNullOrWhiteSpace(x)).Distinct(StringComparer.Ordinal).Take(30).ToList(),
                UpdatedUtc = UpdatedUtc == default ? DateTimeOffset.UtcNow : UpdatedUtc
            };
        }
    }

    private sealed class LocationApplyResult
    {
        public bool Ok { get; set; }
        public string Reason { get; set; } = "";
        public List<string> OpenedDetails { get; set; } = [];
        public string TargetId { get; set; } = "";
    }

    private sealed class TemporaryCockpitViewState
    {
        public string SearchValue { get; set; } = "";
        public List<string> OpenDetails { get; set; } = [];
    }
}
