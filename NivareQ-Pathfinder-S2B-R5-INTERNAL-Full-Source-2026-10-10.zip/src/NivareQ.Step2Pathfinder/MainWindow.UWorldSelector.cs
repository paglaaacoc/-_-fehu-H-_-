using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.Web.WebView2.Core;
using NivareQ.Step2Pathfinder.Models;
using NivareQ.Step2Pathfinder.Services;

namespace NivareQ.Step2Pathfinder;

public sealed partial class MainWindow
{
    private readonly UWorldSelectorService _uworldSelector = new();
    private StackPanel? _uworldSelectorResultsHost;
    private TextBox? _uworldSelectorSearchBox;
    private ComboBox? _uworldSelectorStatusFilter;
    private TextBlock? _uworldSelectorSummary;
    private string? _uworldSelectorPendingRecipeId;
    private readonly Dictionary<string, FrameworkElement> _uworldSelectorRecipeCards = new(StringComparer.OrdinalIgnoreCase);

    private TabViewItem? FindUWorldSelectorTab()
        => Tabs.TabItems.OfType<TabViewItem>().FirstOrDefault(x => Equals(x.Tag, "shell:UWorld Selector"));

    private SubjectEntry UWorldSelectorJournalSubject() => new()
    {
        Number = 0,
        ResourceId = UWorldSelectorService.ResourceId,
        Slug = UWorldSelectorService.ResourceId,
        Title = "UWorld Selector",
        Subtitle = "Native manual UWorld first-pass selector",
        Kind = "tool",
        Phase = "Extras",
        MainPath = "",
        LegacyMainPath = "",
        ExpectedSha256 = _uworldSelector.SourceVersion,
        ContentType = "native-tool",
        IsExtra = true
    };

    private Button CreateUWorldSelectorLibraryButton()
    {
        var card = new Border
        {
            MinHeight = 62,
            Margin = new Thickness(4, 3, 4, 3),
            Padding = new Thickness(10, 9, 10, 9),
            CornerRadius = new CornerRadius(10),
            BorderThickness = new Thickness(1),
            Background = new Microsoft.UI.Xaml.Media.SolidColorBrush(Microsoft.UI.Colors.Transparent),
            BorderBrush = SidebarBorderBrush(),
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        var stack = new StackPanel { Spacing = 3 };
        stack.Children.Add(new TextBlock
        {
            Text = "UWorld Selector",
            FontSize = 16,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            TextWrapping = TextWrapping.Wrap
        });
        stack.Children.Add(new TextBlock
        {
            Text = "Native manual Unused-only recipe tracker · 26 stable recipes",
            FontSize = 12,
            Opacity = .72,
            TextWrapping = TextWrapping.Wrap
        });
        card.Child = stack;
        var button = new Button
        {
            Content = card,
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            Padding = new Thickness(0),
            Margin = new Thickness(0),
            MinHeight = 62
        };
        button.Click += (_, _) => OpenUWorldSelector();
        return button;
    }

    private void OpenUWorldSelector(string? recipeId = null)
    {
        CloseAppSurface(restorePreviousTab: false);
        if (!string.IsNullOrWhiteSpace(recipeId) && _uworldSelector.Recipe(recipeId) is not null)
        {
            _uworldSelectorPendingRecipeId = recipeId;
            // A source/search destination must reveal its recipe even if the already-open
            // Selector currently has a local query/status filter hiding that card.
            if (_uworldSelectorSearchBox is not null && _uworldSelectorSearchBox.Text.Length > 0)
                _uworldSelectorSearchBox.Text = "";
            if (_uworldSelectorStatusFilter is not null && _uworldSelectorStatusFilter.SelectedIndex != 0)
                _uworldSelectorStatusFilter.SelectedIndex = 0;
        }

        var existing = FindUWorldSelectorTab();
        if (existing is null)
        {
            OpenSpecialTab("UWorld Selector", CreateUWorldSelectorView());
            existing = FindUWorldSelectorTab();
        }
        else
        {
            RefreshUWorldSelectorWorkspace();
            if (IsTabParkedBeside(existing)) TryHandleAlreadyParkedBeside(existing);
            else Tabs.SelectedItem = existing;
        }
        QueueUWorldSelectorBringIntoView();
    }

    private IReadOnlyList<UWorldSelectorRecipe> UWorldSelectorRecipesForCockpit(StudyTabContext context)
        => _uworldSelector.Recipes
            .Where(x => !string.IsNullOrWhiteSpace(x.Slug) && x.Slug.Equals(context.Subject.ResourceId, StringComparison.OrdinalIgnoreCase))
            .ToList();

    private void OpenUWorldSelectorForCockpit(StudyTabContext context)
    {
        var mapped = UWorldSelectorRecipesForCockpit(context);
        if (mapped.Count == 0) return;

        // Use one visible navigation rule for every cockpit: populate the Selector's own filter
        // with the stable cockpit slug so the user can see why these recipes are being shown.
        // For a single mapping, also preserve the exact recipe bring-into-view target. Multi-map
        // crossover cockpits naturally show every recipe sharing the same slug.
        OpenUWorldSelector(mapped.Count == 1 ? mapped[0].Id : null);
        if (_uworldSelectorStatusFilter is not null) _uworldSelectorStatusFilter.SelectedIndex = 0;
        if (_uworldSelectorSearchBox is not null) _uworldSelectorSearchBox.Text = context.Subject.ResourceId;
        if (mapped.Count == 1)
        {
            _uworldSelectorPendingRecipeId = mapped[0].Id;
            QueueUWorldSelectorBringIntoView();
        }
    }

    private static CoreWebView2ContextMenuItem? FindNativeMoreToolsSubmenu(IList<CoreWebView2ContextMenuItem> items)
    {
        foreach (var item in items)
        {
            if (item.Kind != CoreWebView2ContextMenuItemKind.Submenu) continue;
            if (string.Equals(item.Name, "moreTools", StringComparison.OrdinalIgnoreCase)) return item;
            var label = (item.Label ?? "").Replace("&", "", StringComparison.Ordinal).Trim();
            if (label.Equals("More tools", StringComparison.OrdinalIgnoreCase)) return item;
        }
        return null;
    }

    private void AddPathfinderToolsContextMenu(StudyTabContext context, CoreWebView2ContextMenuRequestedEventArgs args, Task<string>? contextSelectionSnapshot = null)
    {
        try
        {
            if (context.ViewRole != CockpitViewRole.Primary) return;
            var env = context.WebView.CoreWebView2?.Environment;
            if (env is null) return;

            var nativeMoreTools = FindNativeMoreToolsSubmenu(args.MenuItems);
            var parent = nativeMoreTools ?? env.CreateContextMenuItem("Pathfinder tools", null, CoreWebView2ContextMenuItemKind.Submenu);
            var added = false;

            if (args.ContextMenuTarget.HasSelection)
            {
                var fallback = (args.ContextMenuTarget.SelectionText ?? "").Trim();
                if (fallback.Length > 12000) fallback = fallback[..12000];
                if (fallback.Length > 0)
                {
                    var search = env.CreateContextMenuItem("Search selection in Pathfinder…", null, CoreWebView2ContextMenuItemKind.Command);
                    var capturedFallback = fallback;
                    search.CustomItemSelected += (_, _) => RootGrid.DispatcherQueue.TryEnqueue(() =>
                    {
                        _ = SearchCockpitSelectionSnapshotAsync(context, capturedFallback, contextSelectionSnapshot);
                    });
                    parent.Children.Add(search);
                    added = true;
                }
            }

            if (UWorldSelectorRecipesForCockpit(context).Count > 0)
            {
                var selector = env.CreateContextMenuItem("Open UWorld Selector for this cockpit", null, CoreWebView2ContextMenuItemKind.Command);
                selector.CustomItemSelected += (_, _) => RootGrid.DispatcherQueue.TryEnqueue(() => OpenUWorldSelectorForCockpit(context));
                parent.Children.Add(selector);
                added = true;
            }

            // Prefer the existing native More tools submenu for cleanliness. If a runtime does
            // not expose it safely, add one bounded Pathfinder tools submenu rather than
            // replacing the native context menu. All root Journal/Glossary/native commands stay.
            if (added && nativeMoreTools is null) args.MenuItems.Insert(args.MenuItems.Count, parent);
        }
        catch
        {
            // Context-menu tools are convenience features and must never break WebView2's menu.
        }
    }

    private UIElement CreateUWorldSelectorView()
    {
        var outer = new StackPanel
        {
            Spacing = 14,
            MaxWidth = 1180,
            HorizontalAlignment = HorizontalAlignment.Left
        };
        outer.Children.Add(MakeHeading("UWorld Selector"));
        outer.Children.Add(MakeLead("Manual first-pass recipe tracker. Pathfinder tells you what to select; you report the UWorld Unused count yourself. Unknown is never treated as zero."));

        var ruleCard = MakeCard(
            "First-pass rule",
            "Use Question mode: Standard and Status: Unused ONLY for these recipes. Tutor vs Timed and block size are your choice. Pathfinder does not connect to, read, scrape, or verify a UWorld account.");
        outer.Children.Add(ruleCard);

        var actionRow = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        actionRow.Children.Add(MakeActionButton("Open printable selector PDF", async (_, _) => await OpenUWorldSelectorPdfAsync()));
        actionRow.Children.Add(MakeActionButton("Reset reported counts…", (_, _) => OpenSettings("data")));
        outer.Children.Add(actionRow);

        _uworldSelectorSummary = new TextBlock
        {
            FontSize = 13,
            Opacity = .76,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        };
        outer.Children.Add(_uworldSelectorSummary);

        var filters = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        var search = new TextBox
        {
            PlaceholderText = "Filter recipe, subject, system, or instruction…",
            MinWidth = 360,
            Height = 44,
            IsSpellCheckEnabled = true
        };
        _uworldSelectorSearchBox = search;
        var status = new ComboBox { MinWidth = 190, MinHeight = 44, SelectedIndex = 0 };
        status.Items.Add("All reported states");
        status.Items.Add("Unknown");
        status.Items.Add("Unused remaining");
        status.Items.Add("Verified 0 unused");
        _uworldSelectorStatusFilter = status;
        search.TextChanged += (_, _) => RefreshUWorldSelectorWorkspace();
        status.SelectionChanged += (_, _) => RefreshUWorldSelectorWorkspace();
        filters.Children.Add(search);
        filters.Children.Add(status);
        outer.Children.Add(filters);

        var systems = new Expander { Header = "All 22 UWorld systems used by the final audit" };
        systems.Content = new TextBlock
        {
            Text = string.Join("\n", _uworldSelector.Catalog.AllSystems.Select((x, i) => $"{i + 1}. {x}")),
            FontSize = 13,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true,
            Margin = new Thickness(10)
        };
        outer.Children.Add(systems);

        var results = new StackPanel { Spacing = 10 };
        _uworldSelectorResultsHost = results;
        outer.Children.Add(results);
        RefreshUWorldSelectorWorkspace();

        var view = WrapScrollableStack(outer);
        view.Loaded += (_, _) => QueueUWorldSelectorBringIntoView();
        return view;
    }

    private string UWorldSelectorStatusKey()
        => _uworldSelectorStatusFilter?.SelectedIndex switch
        {
            1 => "unknown",
            2 => "remaining",
            3 => "zero",
            _ => ""
        };

    private void RefreshUWorldSelectorWorkspace()
    {
        var host = _uworldSelectorResultsHost;
        if (host is null) return;
        host.Children.Clear();
        _uworldSelectorRecipeCards.Clear();
        var query = _uworldSelectorSearchBox?.Text ?? "";
        var matches = _uworldSelector.Search(query, UWorldSelectorStatusKey());

        var known = _uworldSelector.State.Reports.Count;
        var zero = _uworldSelector.State.Reports.Values.Count(x => x.Unused == 0);
        var remaining = _uworldSelector.State.Reports.Values.Count(x => x.Unused > 0);
        var unknown = UWorldSelectorService.ExpectedRecipeCount - known;
        var final = _uworldSelector.Report("final-audit");
        if (_uworldSelectorSummary is not null)
        {
            _uworldSelectorSummary.Text = $"Known reports: {known}/26 · verified zero: {zero} · remaining: {remaining} · unknown: {unknown} · final audit: {(final is null ? "Unknown" : final.Unused == 0 ? "0 unused reported" : $"{final.Unused:N0} unused reported")}";
        }

        if (matches.Count == 0)
        {
            host.Children.Add(MakeBody("No Selector recipes match the current search/status filter."));
            return;
        }

        string? group = null;
        foreach (var recipe in matches)
        {
            if (!string.Equals(group, recipe.Group, StringComparison.Ordinal))
            {
                group = recipe.Group;
                host.Children.Add(new TextBlock
                {
                    Text = group,
                    FontSize = 14,
                    FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
                    Opacity = .8,
                    Margin = new Thickness(2, 10, 0, 0),
                    TextWrapping = TextWrapping.Wrap,
                    IsTextSelectionEnabled = true
                });
            }
            var card = MakeUWorldSelectorRecipeCard(recipe);
            _uworldSelectorRecipeCards[recipe.Id] = card;
            host.Children.Add(card);
        }
        QueueUWorldSelectorBringIntoView();
    }

    private Border MakeUWorldSelectorRecipeCard(UWorldSelectorRecipe recipe)
    {
        var stack = new StackPanel { Spacing = 7 };
        stack.Children.Add(new TextBlock
        {
            Text = $"{recipe.Label}  {recipe.Title}",
            FontSize = 17,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });
        stack.Children.Add(new TextBlock
        {
            Text = $"Subject: {string.Join(" + ", recipe.Subjects)}\nSystem: {string.Join(" + ", recipe.Systems)}",
            FontSize = 13,
            Opacity = .78,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });
        stack.Children.Add(new TextBlock
        {
            Text = recipe.How,
            FontSize = 13,
            Opacity = .86,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });

        var report = _uworldSelector.Report(recipe.Id);
        stack.Children.Add(new TextBlock
        {
            Text = report is null
                ? "Report: Unknown"
                : report.Unused == 0
                    ? $"Report: 0 unused · verified {report.ReportedUtc.ToLocalTime():g}"
                    : $"Report: {report.Unused:N0} unused · reported {report.ReportedUtc.ToLocalTime():g}",
            FontSize = 12,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            Opacity = .78,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });

        var count = new TextBox
        {
            PlaceholderText = report is null ? "Unused count (0–100000)" : report.Unused.ToString(),
            Text = report?.Unused.ToString() ?? "",
            MinWidth = 170,
            MaxWidth = 220,
            MinHeight = 42
        };
        var reportRow = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        reportRow.Children.Add(count);
        reportRow.Children.Add(MakeActionButton("Record", async (_, _) => await RecordUWorldSelectorCountAsync(recipe, count)));
        if (report is not null)
            reportRow.Children.Add(MakeActionButton("Clear → Unknown", async (_, _) => await ClearUWorldSelectorCountAsync(recipe)));
        stack.Children.Add(reportRow);

        var actions = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
        if (!string.IsNullOrWhiteSpace(recipe.Slug))
            actions.Children.Add(MakeActionButton("Open cockpit", async (_, _) => await OpenBySlugAsync(recipe.Slug, true)));
        actions.Children.Add(MakeActionButton("Add note to Journal…", async (_, _) => await AddUWorldSelectorRecipeToJournalAsync(recipe)));
        stack.Children.Add(actions);

        var card = new Border
        {
            Child = stack,
            Padding = new Thickness(14),
            CornerRadius = new CornerRadius(12),
            BorderThickness = new Thickness(1)
        };
        card.Tag = recipe.Id;
        RegisterThemedSurface(card);
        return card;
    }

    private async Task RecordUWorldSelectorCountAsync(UWorldSelectorRecipe recipe, TextBox count)
    {
        var raw = (count.Text ?? "").Trim();
        if (!int.TryParse(raw, out var value) || value < 0 || value > UWorldSelectorService.MaxUnusedCount)
        {
            await ShowPersonalMessageAsync("Enter an Unused count", $"Use a whole number from 0 to {UWorldSelectorService.MaxUnusedCount:N0}. Unknown is different from zero; use Clear → Unknown when you do not have a current report.");
            return;
        }
        var write = _uworldSelector.Record(recipe.Id, value);
        QueuePersistenceFailureNotice(write, "UWorld Selector");
        RefreshUWorldSelectorWorkspace();
    }

    private async Task ClearUWorldSelectorCountAsync(UWorldSelectorRecipe recipe)
    {
        var write = _uworldSelector.Clear(recipe.Id);
        QueuePersistenceFailureNotice(write, "UWorld Selector");
        RefreshUWorldSelectorWorkspace();
        await Task.CompletedTask;
    }

    private Task ResetUWorldSelectorReportsAsync()
    {
        OpenSettings("data");
        return Task.CompletedTask;
    }

    private async Task OpenUWorldSelectorPdfAsync()
    {
        var pdf = _catalog.Resolve("extra-uworld-checkbox-selector");
        if (pdf is null)
        {
            await ShowPersonalMessageAsync("Printable selector unavailable", "The printable UWorld Checkbox Selector PDF is not available in this Pathfinder installation.");
            return;
        }
        await OpenSubjectAsync(pdf, true);
    }

    private StudyLocationState UWorldSelectorRecipeLocation(UWorldSelectorRecipe recipe) => new()
    {
        SchemaVersion = PathfinderLocation.CurrentSchemaVersion,
        ResourceId = UWorldSelectorService.ResourceId,
        SourceVersion = _uworldSelector.SourceVersion,
        Purpose = "source",
        Anchor = "recipe-" + recipe.Id,
        TargetId = recipe.Id,
        TargetPath = "recipe/" + recipe.Id,
        Context = $"{recipe.Label} {recipe.Title} · {string.Join(" + ", recipe.Subjects)} · {string.Join(" + ", recipe.Systems)}",
        Hash = "#recipe-" + recipe.Id,
        UpdatedUtc = DateTimeOffset.UtcNow
    };

    private async Task AddUWorldSelectorRecipeToJournalAsync(UWorldSelectorRecipe recipe)
    {
        var draft = new SourceActionDraft
        {
            ResourceId = UWorldSelectorService.ResourceId,
            SourceVersion = _uworldSelector.SourceVersion,
            Location = UWorldSelectorRecipeLocation(recipe),
            SelectedText = "",
            CapturedUtc = DateTimeOffset.UtcNow
        };
        await EditJournalEntryAsync(null, draft, UWorldSelectorJournalSubject());
    }

    private string NormalizeUWorldRecipeTarget(StudyLocationState? location)
    {
        var target = location?.TargetId?.Trim() ?? "";
        if (target.StartsWith("recipe-", StringComparison.OrdinalIgnoreCase)) target = target[7..];
        if (_uworldSelector.Recipe(target) is not null) return target;
        var anchor = location?.Anchor?.Trim().TrimStart('#') ?? "";
        if (anchor.StartsWith("recipe-", StringComparison.OrdinalIgnoreCase)) anchor = anchor[7..];
        return _uworldSelector.Recipe(anchor) is not null ? anchor : "";
    }

    private void QueueUWorldSelectorBringIntoView()
    {
        var target = _uworldSelectorPendingRecipeId;
        if (string.IsNullOrWhiteSpace(target)) return;
        _ = DispatcherQueue.TryEnqueue(Microsoft.UI.Dispatching.DispatcherQueuePriority.Low, () =>
        {
            if (!_uworldSelectorRecipeCards.TryGetValue(target, out var element)) return;
            element.StartBringIntoView(new BringIntoViewOptions { AnimationDesired = !_settings.ReduceMotion, VerticalAlignmentRatio = 0.15 });
            _uworldSelectorPendingRecipeId = null;
        });
    }

    private Border MakeUWorldSelectorSearchCard(UWorldSelectorRecipe recipe)
    {
        var stack = new StackPanel { Spacing = 6 };
        stack.Children.Add(new TextBlock
        {
            Text = $"{recipe.Label}  {recipe.Title}",
            FontSize = 16,
            FontWeight = Microsoft.UI.Text.FontWeights.SemiBold,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });
        var report = _uworldSelector.Report(recipe.Id);
        stack.Children.Add(new TextBlock
        {
            Text = $"UWorld Selector · {string.Join(" + ", recipe.Subjects)} · {string.Join(" + ", recipe.Systems)} · {(report is null ? "Unknown" : report.Unused == 0 ? "0 unused" : $"{report.Unused:N0} unused")}",
            FontSize = 12,
            Opacity = .72,
            TextWrapping = TextWrapping.Wrap,
            IsTextSelectionEnabled = true
        });
        stack.Children.Add(MakeActionButton("Go to Selector recipe", (_, _) => OpenUWorldSelector(recipe.Id)));
        var card = new Border { Child = stack, Padding = new Thickness(12), CornerRadius = new CornerRadius(10), BorderThickness = new Thickness(1) };
        RegisterThemedSurface(card);
        return card;
    }
}
