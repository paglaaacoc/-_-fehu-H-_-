# Scratchpad S1 TEST — CI compiler and installer corrections (R2)
Date: 2026-10-09

Status: UNACCEPTED TEST SOURCE. Windows v1.2.1 Stable remains the only owner-accepted baseline. No PWA or medical-content changes were made.

The supplied S1 candidate was subjected to actual Windows x64/ARM64 .NET 10 CI compilation in the designated temporary public build branch `paglaaacoc/-_-fehu-H-_-`, branch `ci/pathfinder-scratchpad-s1-20261009`.

Three corrections proven necessary for repeatable Windows CI builds were made:

1. `tools/build-scratchpad-s1-locally.ps1`: PowerShell string interpolation `$arch:` -> `${arch}:` (PS parser error).
2. `src/NivareQ.Step2Pathfinder/MainWindow.Scratchpad.cs`: initialize `string error` before the conditional `out error` call, preventing C# CS0165 definite-assignment compilation failure. No medical source touched.
3. `installer/Pathfinder-Installer-Common.iss`: replace Inno Setup 7-only `SetupArchitecture=x64` with backwards-compatible `ArchitecturesInstallIn64BitMode={#ArchitecturesAllowedValue}`; works with CI Inno Setup 6.7.1 while selecting 64-bit installation mode for the respective architecture. The `ArchitecturesAllowed` checks remain unchanged.

The entire original accepted v1.2.1 authority ZIP is preserved byte-for-byte within this package. The 132 medical payload files are unchanged; no accepted cockpit HTML or source-identity hashes were modified. This clean source ZIP applies the same three CI-staging fixes so local one-click builds do not require manual patches.

This pack corrects source/build defects only. Neither GitHub build success nor integrity verification replaces Windows owner testing, backup/restore testing, pen device testing, or explicit release acceptance.

Original S1 candidate input ZIP SHA-256: `282da643d184d4bc3e23e0e65098a367d5461f567175401f6080e3faae6ebc6e` (CI build-only subset).
