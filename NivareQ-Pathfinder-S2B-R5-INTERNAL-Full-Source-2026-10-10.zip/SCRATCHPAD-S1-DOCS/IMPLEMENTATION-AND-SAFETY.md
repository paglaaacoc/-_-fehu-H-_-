# Scratchpad S1 — implementation, isolation and limitations

## Integration
- Only the bottom-left sidebar menu's Guide **launch action** changes to Scratchpad. The unrelated top-toolbar `GuideButton` remains.
- Tool registered as native `shell:Scratchpad` TabView item. Session restore and Split View use existing generic native tab handling. Sidebar study subject ScrollViewer and groups are unchanged.
- Isolated `MainWindow.Scratchpad.cs` partial with an independent WinUI WebView2 pointing to a dedicated local `https://scratchpad.pathfinder.invalid/index.html` mapping under `ScratchpadAssets`. No remote sources, third-party packages, or changes to cockpit rendering bridges.
- Web messages accepted only from the exact mapped local page; explicit data validation, bounded payload and strict local map. HTML uses same-origin CSS/JS and CSP that permits no network connections.

## Data model and save
- `schemaVersion:1; activePadId; pads[]` with each pad containing `id`, `title`, `activePageId`, `pages[]`.
- Each page has independent `guide`, `spacing`, `cells[1|2|4]`; each cell has editable plain `text` and a list of ink `strokes` whose points are normalized [x,y] coordinates.
- Chromium Pointer Events provide natural mouse/touch/pen input. No handwriting recognition or guaranteed palm rejection. Pressure variability is not currently persisted.
- Write-through after short inactivity, with actual C# native `BackupExtensionStore.Save` acknowledgement before displaying 'Saved locally'. Immediate capture on Scratchpad tab close and before a canonical backup.
- Native store key `nivareq.scratchpad.v1` lives inside the preexisting `backup-extensions.json` atomically written provider. No schema upgrade of canonical backup version 7 is necessary; all modern canonical backups round-trip the key as a preserved extension.
- An imported older backup without the S1 key preserves preexisting local Scratchpads and warns during restore confirmation; explicit full canonical reset still clears them. Scoped reset 0–2 leaves this provider untouched, consistent with preserved extensions.
- Native enforced limit 12 MiB per Scratchpad collection, max 80 pads, 100 pages each, max 25k strokes/cell, max 4k points/stroke and 120k characters/cell. On over-limit, save returns explicit failure; no false success acknowledgement.
- Error/corrupt-data behavior: data left untouched and editing blocked rather than replacing with empty documents.

## Intended user-facing capabilities
- Text mode: standard selectable plain-text textarea, native Windows clipboard shortcuts, keyboard undo/redo.
- Drawing mode: ink overlays alongside typed content; pen, eraser, ink colors/weights, ink undo and redo (text's native undo is separate).
- Page templates: blank, ruled, triple handwriting guides, adjustable spacing, 1/2/4 writing spaces. Guides can change without clearing text/ink. Reducing spaces requires confirmation if additional spaces contain content.
- Named pads and multiple pages, page/pad switching, descriptive confirmation before irreversible clearing/deletion.

## Explicit non-goals for S1
- No full rich-text formatting, OCR, handwriting recognition, AI, PDF annotation, cloud sync, or export beyond canonical backup.
- No independent PWA Scratchpad; PWA accepted baseline remains untouched.
- No additional sidebar scrolling fixes and no cockpit HTML/style normalization.
- No medical/education-content changes and no source anchor migration.

## Unverified points
- Actual Windows compilation and WinUI XAML build pipeline, Windows WebView2 pointer/stylus behavior, backup/restore under both canonical and legacy files, app upgrade behavior, and cold-start theme alignment.
- Test full user-data reset to validate S1 retention/clear semantics. Splitting alongside existing study cockpit needs real-device verification.
- Keyboard accessibility: typed content accessible; canvas strokes have descriptive canvas labels but no semantic per-stroke screen-reader representation. This is not a claim of full nonvisual ink editing accessibility.
- Textareas scroll internally while ink overlays stay page-relative; this limited S1 page model is not equivalent to an infinite, flowing rich-document canvas.

## Next step / acceptance
The owner has authorized implementing the bounded S1 concept, not approving this build. Compile and device-test first. Revisions are permitted only within this isolated gate; preserve v1.2.1 for rollback and keep the Public-Impact / Four-Scope gates closed.
