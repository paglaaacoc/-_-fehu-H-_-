# Owner testing — Scratchpad S1 TEST (not accepted)

## Preflight / release boundary
- [ ] Extract ZIP into a separate folder; preserve this package and a fresh verified v1.2.1 canonical backup before using the candidate
- [ ] Build x64 and ARM64 locally with `BUILD-SCRATCHPAD-S1-LOCALLY.cmd`, no GitHub Actions; verify two installers and SHA-256 manifest
- [ ] Prefer testing in a separate Windows account or VM; installed candidate can upgrade your stable app installation
- [ ] Confirm visible identity reads `Version 1.2.2 S1 TEST` and top-bar Guide still works
- [ ] Confirm lower-left menu contains Scratchpad instead of Guide, without changing other buttons or Study Library scroll behavior

## Text, guides, ink
- [ ] Open multiple named pads; rename, switch, delete with confirmation
- [ ] Add/switch/delete multiple pages; close/reopen tab; close/restart app and verify all text/ink returns
- [ ] Type paragraphs, edit, select, Ctrl+C/Ctrl+V, multiline paste, Ctrl+Z in text mode
- [ ] Switch to Draw mode and back without losing typed text or existing ink
- [ ] Mouse drawing; finger and stylus where hardware is available (report each tested device separately)
- [ ] Pen sizes/colors, tap/drag eraser, Ink Undo/Redo; clear ink should preserve text; clear page asks confirmation
- [ ] None/ruled/triple guides, all four spacing choices, 1/2/4 independent writing spaces; switching guides must not erase content
- [ ] Changing 4 spaces to 1 requires confirmation if removed spaces contain data
- [ ] Autosave state says Saved only after native acknowledgement; induce a read-only/nonwritable profile to confirm visible save failure (test account only)

## Native boundaries
- [ ] Open Cardiology cockpit, then Scratchpad in its own tab and beside in Split View. Return to tabs/close without crash or content loss
- [ ] Verify full medical cockpits remain visually unchanged, including special 18 and supplemental 19–22
- [ ] Check Universal Search targeting, Journal, My Study, UWorld Selector, Settings, Guide, Split View, theme switch and window scaling smoke tests
- [ ] Verify sidebar late-selection jump unchanged (S1 intentionally does NOT repair this known defect)

## Backup/restore/reset
- [ ] Create canonical backup after typing/drawing and verify restore into a clean test profile brings Scratchpad data back
- [ ] Restore an old v1.2.1 canonical backup missing Scratchpad: warning must state current Scratchpads are retained; verify they remain
- [ ] Restore an S1 backup to replace existing Scratchpad state and check deterministic pages/pads
- [ ] Run scoped reset 0–2: Scratchpad remains; full canonical reset 3: backup required and Scratchpad cleared only after successful transactional reset/restart
- [ ] Test interrupted restore/recovery behavior in a disposable test profile; no stale Scratchpad view may overwrite restored state

## Build outcome
- Windows x64 compilation: PENDING
- Windows ARM64 compilation: PENDING
- x64 real runtime: PENDING
- ARM64 real runtime: PENDING
- Actual pen/touch hardware: PENDING
- Canonical backup/restore/reset acceptance: PENDING
- Owner final declaration: PENDING — S1 NOT ACCEPTED

Do not promote `1.2.2 S1 TEST` without explicit owner acceptance.
