#!/usr/bin/env python3
"""Headless Chromium UI smoke on Linux. Does not test WinUI/WebView2 or native persistence."""
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

ui=Path(__file__).resolve().parents[1]/'src/NivareQ.Step2Pathfinder/ScratchpadAssets/index.html'
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    ctx=browser.new_context(viewport={'width':1440,'height':900})
    ctx.add_init_script('''
    window.__bridgeMessages=[]; window.__bridgeHandlers=[];
    window.chrome={webview:{
      addEventListener:(event,fn)=>{if(event==='message')window.__bridgeHandlers.push(fn)},
      postMessage:(m)=>{
        window.__bridgeMessages.push(structuredClone(m));
        if(m.type==='ready')setTimeout(()=>window.__bridgeHandlers.forEach(h=>h({data:{type:'load',state:null}})),0);
        if(m.type==='save')setTimeout(()=>window.__bridgeHandlers.forEach(h=>h({data:{type:'saved',seq:m.seq,ok:true,message:''}})),0);
      }
    }};
    ''')
    from mimetypes import guess_type
    def local_asset(route):
        from urllib.parse import urlparse
        requested=Path(urlparse(route.request.url).path).name
        if requested not in ('index.html','scratchpad.js','styles.css'):
            route.fulfill(status=404,body='Not found')
        else:
            route.fulfill(path=str(ui.parent/requested), content_type=guess_type(requested)[0] or 'text/plain')
    ctx.route('https://scratchpad.pathfinder.invalid/**',local_asset)
    page=ctx.new_page()
    errors=[]
    page.on('pageerror',lambda e: errors.append(str(e)))
    # Environment blocks file:// and .invalid navigations. Inject trusted fixture
    # markup/scripts into the blank test page (never used by the application).
    import re
    markup=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]*>','',ui.read_text())
    markup=markup.replace('<script defer src="scratchpad.js"></script>','').replace('<link rel="stylesheet" href="styles.css">','')
    page.set_content(markup)
    page.add_style_tag(content=(ui.parent/'styles.css').read_text())
    page.add_script_tag(content=(ui.parent/'scratchpad.js').read_text())
    page.get_by_role('heading',name='Scratchpad').wait_for()
    page.locator('textarea.editor').wait_for()
    assert page.locator('textarea.editor').count()==1
    page.locator('textarea.editor').fill('ACS versus PE\nChest pain + tachycardia')
    page.wait_for_timeout(600)
    msgs=page.evaluate('window.__bridgeMessages')
    assert any(m.get('type')=='save' and m['state']['pads'][0]['pages'][0]['cells'][0]['text'].startswith('ACS') for m in msgs)
    page.locator('#spacesSelect').select_option('4')
    assert page.locator('textarea.editor').count()==4
    page.locator('textarea.editor').nth(1).fill('My second space')
    page.locator('#guideSelect').select_option('triple')
    assert page.locator('.sheet.triple').count()==4
    page.locator('#spacingSelect').select_option('60')
    page.locator('#drawMode').click()
    assert page.locator('canvas.ink').count()==4
    c=page.locator('canvas.ink').first
    r=c.bounding_box()
    page.mouse.move(r['x']+40,r['y']+40)
    page.mouse.down()
    page.mouse.move(r['x']+80,r['y']+70,steps=8)
    page.mouse.up()
    state=page.evaluate('window.pathfinderScratchpadExport()')
    assert len(state['pads'][0]['pages'][0]['cells'][0]['strokes'])==1
    page.locator('#undoInk').click()
    assert not page.evaluate('window.pathfinderScratchpadExport()')['pads'][0]['pages'][0]['cells'][0]['strokes']
    page.locator('#redoInk').click()
    assert len(page.evaluate('window.pathfinderScratchpadExport()')['pads'][0]['pages'][0]['cells'][0]['strokes'])==1
    page.locator('#typeMode').click()
    assert page.locator('textarea.editor').first.input_value().startswith('ACS')
    page.locator('#addPage').click()
    assert page.locator('#pageSelect option').count()==2
    assert page.locator('textarea.editor').count()==1
    page.locator('#pageSelect').select_option(index=0)
    assert page.locator('textarea.editor').count()==4
    assert page.locator('textarea.editor').nth(1).input_value()=='My second space'
    page.wait_for_timeout(500)
    assert page.locator('#saveStatus').inner_text()=='Saved locally',page.locator('#saveStatus').inner_text()
    assert not errors,errors
    print(json.dumps({'status':'PASS','controls':'typing / 4 spaces / guides / spacing / ink / undo / redo / page switching / autosave ack','bridgeMessages':len(page.evaluate('window.__bridgeMessages'))},indent=2))
    browser.close()
