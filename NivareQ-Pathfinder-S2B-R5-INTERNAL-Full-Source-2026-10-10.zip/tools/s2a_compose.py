from pathlib import Path
base=Path('/mnt/data/pathfinder_s2_work/src/NivareQ.Step2Pathfinder')
scratch=base/'MainWindow.Scratchpad.cs'
s=scratch.read_text()
needle='''            if (action == "ready")
            {
                if (TryReadScratchpad(out var existing, out var readError))
                    PostScratchpadMessage(web, new { type = "load", state = existing });
                else
                    PostScratchpadMessage(web, new { type = "load-error", message = readError });
            }'''
repl='''            if (action == "ready")
            {
                if (TryReadScratchpad(out var existing, out var readError))
                    PostScratchpadMessage(web, new { type = "load", state = existing });
                else
                    PostScratchpadMessage(web, new { type = "load-error", message = readError });
                PostScratchpadTheme(web, SelectedTheme());
            }'''
assert s.count(needle)==1
s=s.replace(needle,repl)
needle='''    private static void PostScratchpadMessage(WebView2 web, object payload)
    {'''
repl='''    // Scratchpad owns its CSS variables. Deliberately do not inject cockpit CSS:
    // medical WebView styling is unrelated, and writing paper remains light.
    private void PostScratchpadTheme(WebView2 web, NivareQ.Step2Pathfinder.Models.ThemeChoice theme)
    {
        PostScratchpadMessage(web, new
        {
            type = "theme",
            palette = new
            {
                shell = theme.ShellBackground,
                surface = theme.ShellPanel,
                ink = theme.ShellForeground,
                muted = theme.ShellMuted,
                outline = theme.ShellBorder,
                accent = theme.ShellAccent
            }
        });
    }

    private static void PostScratchpadMessage(WebView2 web, object payload)
    {'''
assert s.count(needle)==1
s=s.replace(needle,repl)
scratch.write_text(s)
main=base/'MainWindow.xaml.cs'
s=main.read_text()
needle='''    private async Task ApplyThemeToAllWebViewsAsync(ThemeChoice theme)
    {
        foreach (var ctx in _studyTabs.Values)
            if (ctx.WebView.CoreWebView2 is not null) await ApplyCockpitHostPresentationAsync(ctx, theme);
    }'''
repl='''    private async Task ApplyThemeToAllWebViewsAsync(ThemeChoice theme)
    {
        foreach (var ctx in _studyTabs.Values)
            if (ctx.WebView.CoreWebView2 is not null) await ApplyCockpitHostPresentationAsync(ctx, theme);
        if (_scratchpadWeb?.CoreWebView2 is not null)
            PostScratchpadTheme(_scratchpadWeb, theme);
    }'''
assert s.count(needle)==1
s=s.replace(needle,repl)
main.write_text(s)
js=base/'ScratchpadAssets'/'scratchpad.js'
s=js.read_text()
needle='''let undoStack=[], redoStack=[];
const bridge = window.chrome?.webview;'''
repl='''let undoStack=[], redoStack=[];
const bridge = window.chrome?.webview;
// Never use arbitrary messages as CSS: the native bridge supplies only the six
// theme colors and they must remain ordinary 6-digit hex values.
function applyTheme(palette){
 if(!palette||typeof palette!=='object')return;
 const keys=['shell','surface','ink','muted','outline','accent'];
 for(const key of keys){const v=palette[key];if(typeof v==='string'&&/^#[0-9a-fA-F]{6}$/.test(v))document.documentElement.style.setProperty('--'+key,v);}
}
// The editor scrolls; the paper does not. Move guides with the editor's text.
// Text 17px, line-height=spacing, top padding 5px -> baseline ~= spacing/2+10.
// Position each guide 3px below that baseline, then offset by scrollTop.
function alignGuide(sheet,area,spacing){
 const baselineOffset=13-spacing/2;
 sheet.style.backgroundPositionY=Math.round(baselineOffset-area.scrollTop)+'px';
}
'''
assert s.count(needle)==1
s=s.replace(needle,repl)
needle='''function renderCells(){if(!loaded)return;const currentPage=page();ui.sheets.replaceChildren();ui.sheets.dataset.spaces=String(currentPage.cells.length);currentPage.cells.forEach((cell,index)=>{'''
repl='''function renderCells(){if(!loaded)return;const currentPage=page();
 const previousOffsets=ui.sheets.dataset.pageId===currentPage.id ? [...ui.sheets.querySelectorAll('textarea.editor')].map(x=>x.scrollTop) : [];
 ui.sheets.replaceChildren();ui.sheets.dataset.pageId=currentPage.id;ui.sheets.dataset.spaces=String(currentPage.cells.length);currentPage.cells.forEach((cell,index)=>{'''
assert s.count(needle)==1
s=s.replace(needle,repl)
needle='''area.addEventListener('input',()=>{cell.text=area.value;markDirty();});'''
repl='''area.addEventListener('input',()=>{cell.text=area.value;alignGuide(sheet,area,currentPage.spacing);markDirty();});
 area.addEventListener('scroll',()=>alignGuide(sheet,area,currentPage.spacing),{passive:true});'''
assert s.count(needle)==1
s=s.replace(needle,repl)
needle='''sheet.append(area,canvas);container.append(head,sheet);ui.sheets.append(container);
 requestAnimationFrame(()=>redraw(canvas,cell));'''
repl='''sheet.append(area,canvas);container.append(head,sheet);ui.sheets.append(container);
 area.scrollTop=previousOffsets[index]??0;
 alignGuide(sheet,area,currentPage.spacing);
 requestAnimationFrame(()=>{alignGuide(sheet,area,currentPage.spacing);redraw(canvas,cell);});'''
assert s.count(needle)==1
s=s.replace(needle,repl)
needle="function onNativeMessage(evt){const msg=evt.data;if(!msg||typeof msg!=='object')return;if(msg.type==='load'||msg.type==='load-error')"
repl="function onNativeMessage(evt){const msg=evt.data;if(!msg||typeof msg!=='object')return;if(msg.type==='theme'){applyTheme(msg.palette);return;}if(msg.type==='load'||msg.type==='load-error')"
assert s.count(needle)==1
s=s.replace(needle,repl)
js.write_text(s)
css=base/'ScratchpadAssets'/'styles.css'
s=css.read_text()
# Styles outside writing sheets themed, paper remains light; high contrast keep native colors.
s += '''\n/* S2-A owner feedback: shell palette follows Pathfinder; paper is deliberately white.\n   A guide position is provided by JS and follows textarea scrollTop so text does\n   not visually drift through stationary lines. */\n@media (forced-colors:active){\n  :root{color-scheme:light dark}\n  .space,.sheet,textarea.editor{forced-color-adjust:auto}\n  button,select{forced-color-adjust:auto}\n}\n'''
css.write_text(s)
print('S2-A applied: Scratchpad native theme + browser palette + synchronized line guides')
