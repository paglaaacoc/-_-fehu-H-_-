#!/usr/bin/env python3
import asyncio, base64, gzip, html as htmlmod, json, re, unicodedata
from pathlib import Path
from playwright.async_api import async_playwright

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'src' / 'NivareQ.Step2Pathfinder'
SEED_GZIP_B64 = '''H4sIAIrGxmoC/8VdS5PjOI6+769g1LmzNyXXq/u6e5nDxB429rSxB1qiJVZKpJqk7HRNzH9fgJIfWZVl8wF6Imaqnbb0EQBJEABB8B8fbNOLkX/4s/rtQytsY+TkpFYf/vzw5dPzU8OtYP+j5F4Yywf234KbpmdGqFYY0T7953/9Hf7ojLAW3mFWiJbBL/B4y3ZGj8z1gu2r3+vfn9lOw2tWNozPrXS/s//QynGpLNNqODLr+HYQzAnrmFTT7OxvTGnH9ND+ezMbeBU+z67Ro7C/f/jtgxGNNq398Of//gM+Wz2bRvytBaqtM9yJ7gjP/DULc4SvZjsCtHViYjV8rZsFsBEf/nz+529Z71eZ79eZ729C3j/03DHb63lomUwRwC2AKhegjgZgrc7m4meMIEZwPO9geMPAlqqzzGkYrU4YxQf5XSRThbDilY8pAJOR2kgHzbcwRub2yGBiCOMxG5hjMHNSYLkR3LKDdD1QNg2ykQ6mepOI5vQkG8tGDdN7kC8CZjyIrjVyl0Zc47y+ka8AuRcWmVVJQMoeQFZNz1UHHQocTgNvkjpygvdQybH6mcF3Fim0SUADV2wAlQpcwaejnpk+qDTFhUNgnIzoUfXCsFVb0J+pUHYSjeSDOyKbo8V/U6AELCZHNkpgsBMO9b+gmM5+rKay5ifLusz4CY0jbJ9E13aWQBGfJlzV5DgP8EAKzshfBIzHvRQHthU9h97DmZOlKzizs8VV1y+2i7Zo+TFplAqDo4DDGyB8mIK4Whvx1yxNEruoUF9A9tilxvnhkTqBXpQ+eDGZGaYRCA9Nj7tAYE+IJ97MToDV458/4VkxWWnBugHLqEH6mpeiaFUeGiig+jMtge9BxlAJSgPtRTbC/AIzEoagm20GiSF41PTVxHibCLxedj3jCte8jk8ZgrsJFCUxNnEnUV0Gqd1EIDKKaiqgmF5DY8BbPLydB5cz3m8jVWRINRlShpxyR1QAXOS4mgcrvEG2Doy84X4HLX3Ms/aFk83Ed8DyKGM9t6TUvQOYRiENWTm0YPRDogcJzqWx3h9UiwWD8RC9g4WkBQ9MicViBs9MCpNBNUZPOiW/o8uDzcxqjb/kD3CHngYsL5MS86gdGHP8lTlwJt1qiDE5cvS1MtqQe7YbZtkuc1vPjn0Ds5Z1IRZ75KK9dsjEYb62crcT6CKAE5TRTsOHRs4jAzEoYfETdEEGnkIzfMD1HEiHbtTgrOd0oH6VjR50B8ZfY7jtcVBgiAOkDZZ5z9C8zuu/pgcXCd5jYhSmg/fRo5xVy33kMWNc7Ly3bIVgr2xxKMAvPNJpHYu+K0xSjn4w285G5emO/jhpt7rmexxY6Cy2dPT6Z8CXIkEEdfvWKSC1/NjiccOssF4cnaRdZcmWH0u7zAICDKUdl8MMI4t0jbQcNMExKP4QjOkazjRMglbbQGq5aSWqk2sPHWcpzEylHfH7Veb7dez7TImQCRsPUlGApLHDnCbh6GecQKYuX7JBcLOYQnbefhONOy/5+N0Erixoo0makBU5til6xGvi09AFOPBuDXqHxF9DQBgfFn9JHRNZ7rU+BVEv3G8HXCRwTIBGWWQRZDZEtlCM5DRgH5Y+xf+XyKjgTb+0wptlh3PZdiBtoBy1VLoA7bI0LDAODe6IYEAYSTNHKpwlUKB3aXiLiTkZMWjeMr4DKxk/pYFN/dHKBh0P2QF5UqXBQLd1SmMA1/ctdikZEJMO53Eqg35TpVkmXSsaaYOs/XcFfwCD5HjahF3ckp7v0Z2VCv9+wY+jGHXAUAFTcdSKm+Mbhxy3RsaAWGvM21XQ236vlA1ya3gi9bcQwmhYXT62BgqC/LI0nDB6DJ9ku+6GJRFyAyCMggOGZLxfcf4pnoofQTCpY6RDYjshBkuNxxqjD22Alfse7g6Wfe+GwYTXbcCa9/58wtQXIOk4CEwaGBKZvMZJAuAzBrSk495VPW0YLy+BUyyGHTnsXUDvQL6J7aFDeTI0W+g7tepFNY9bYSwRIh1h0UgYhlGL/Rr97pXhtxCUaKbewyUijJA/YlFFw128IW/qLBa3Vg0NUvwgkq8+j2Ue+MmEgPUSExAmnkDTz3BkFEUDpcZBf42TRQIB/TQiiEY5m6ww8DHDzweowXtrwad5dUtKpo+U30UWqtWNkeo6tHb+Dnp9GNacFVhy2y2HaTZoPXn36RzoIGuEntpC/BcUaxL0G5R1bygJ6Eq1Jq4/IahkpJHymAS2qPxlMw4T9s4Zlj6AtedGhm0eBWDT0kfPbRKiT7I/Ly4OPXpQbTMf4GuwWyciUGrakvBA90cte7cx8km4i9DJp16Aq6wxCSA1EJEAUsWAxIUlEoGiKIoKCqThRNGz+tABO5chIGGxgWCkwNhAJF5wbOAGbnSI4AZWStzq5sSJDzwEwuXgEIQhEtHv4uJZMucdsidw7X6M24ZrszScKhInTqelY8XSdR7GmMCeSdctrFi6VhUAD+WOhCskjAHQooWpznjIQB16Gzha3d2Gg5naSeXz1bxyCdRSUaCZaNfrK3L9kol3S0Hd51yqncDjY7N9aqUV3L6x284/svXH6038o2qNHsUlPXM7dyAidAW3AmOZtgnRI0kUlOPrARJ7VKfktfNTWoRisg3TJTG41EQWYDoP8srxf6frEuMd8S0WZKK4fB7SAXmNXMcovELEQMV80GZo/UDypQPCAzNRbdFTXkwWRYWcqVdTtwl6MZ/X59G+PIEVc/r72tCRql2D14sFOhntMAkOv/umJVZ0MB3oGyWMP9w6bn1o3b6EbHmk0VCat0fI7nH9Q9WSP8rsF2s0ou3IhyHA7k0BpwJdNejRJ4xxRSbzd+dzaiw7sc2SvDxGTo/rDaqWYkPS0bBFCKUCPSmYlqtOmMveaUF8KuilhMCyGe8zRoNyQwKVzNvAHW4sbkOKYSgxmx+xzt/dyZg/9HiACcagZD6JxjpunI9rhDAW2XJJTpKwYz2xAIyY5Plfw2GVFugIPHpovV8klJ673mdNYw/RQychXjkWl25KdOji8AuRmwT7TtI8NhGT2R8OmwR1Ot+78I6GHkanDqew1V52SoDKBKnsQV/iudmFBTFpdRyJmyzJQRJ2L9sWcC4J7q0+KItnlNNY/0WWUBNkxL0H+E56OxUOexFiCky7vK2d4dFmBtXsKwbeT3u1x6YHu9Ycn0CZg06D557mN+7o5RFm+U5gmanFMpMjrk7QFIwJcFku/QaMmbZg04/g6oGS+5d0EkWjaf5jLDAF4Lri8MBFKwCR1GNMaK8UD+Vl8xjpU7QS6x1GQZITSKJGTkvmqkQuOn3kindiDClCktMOBXiSbxiiRBL9Qg1wwhnZ2Out3POX7FJlBlUeFmcB46/lbvl7MqJTHGtxgCHUrkmzWAHFj3s8r9d699G/hcU7Qd/vA9RwFFVFeCwnuLJdkoZ+XtPOv8Ytm4GgpMSlgUUutu9iXGIMpxOpa9XI7LU2sDlasgsIoZBc02BjV8o7IAREpEGc16VOYJ0pEA8fGKx7Vwuhj5IGOpFRbZSiOOB0zWT0U3dUT1ssLu3euPvwUzuvJYBOxc7OS1JB6LASB5n4ge4kSSvhW5G/bu2spt80G7d7F4lehtwc1Mjl5QZSuUUmqtESLBQTS1F554BHb+WFQJERlAN0VvFXkVGJ8b1RKu60iVqSMtopzkOWIk5y+kBh859W1POXfh31dxAETKgILOZL7fvwbyHY0DhpBvjqeqa1cV4Zzr9GxhDDQEmJSwOLjTy+h1FunQpsjpbsAkIoJNc02Oiw4W0QAiISFQHlupPUQkG606CTVhk7mw5ef3KGzyN/8prkcmMOVoLF2p5sK/wtWsRwa+AWq0iXQw7bT86DD8qMvtWEV+vLJTfrYwxXnJhlJw6entpC/GfBRi5wN6EwJaZxF208gtM4ZE6J1GzqMEwy0oh5pBcZxSBZMn5eseS8XXK1KFHJKcwCHPipPr3JHsNvT9YZ4cvdhxyqA8R1EXuajPClzLV64uMWr7/Sb44X69mdKkpfrMlOuEe0EXpzAl1TYSsWcXtBS1hEm1ca/fI7OwPErW257T6QsUfLkLK9yOUyBjl19YxoI3UxTWqiFOFlBVJc3AVGY8K6nN5Iafop8WMX8Qjo5DVdwEAA/L/kkz2idrJpkycJpoqCcfMaXum1nSRe3nPJImIKFkgB/8N7PTWukkc24eG2PAH81CQtWkwaVLZkyrfgZZ/VzHKWodWjvzLc1wiT9lS93bff8VEQN0FPcSEZlBNtHvJlsmFFJrAPg2vtxMESKaHIsnGBmMTE0fOahfimqj8uXr5m6dTLQVs99UdacHpS85TfcsDivWjtstwEX9a8lRrTauyT2L6JpQmufLoH92a2KIRTheL4u9slGEMtM7jzY1MJugcUTpFPVpUjnjxTXcBBmTQcKnrqVBz/mYq598AqSrBgNidhLLiQHg4v8k4eUPeAgtn7iw94KTr8c5wCVpYUlGBa9OwwAQHvRd9jrKc7F6BOpSsYMZhGI+3L+WrMJnmI3oYJpga0LzPwfxVgOEdDBFOBVw/67Uq2lTx5SN9EoaGlJkHZhKJIhWV+ebZk7uBURDjB0nHHCXwchv9JZenXEFUCBJOSgJCfUYJpabTayRZfQkNImD0fkns7ACuYLn/IeuC4BcIsH6chucPuImXQxKz8TkjYe3Dh+l108JgP9DZa7Haywc2H5M4Mgwum7oVPgzdtQ7Z14jEo6KgJMII1bM+/c7Pa1KnyuIFREWAEywNvC8ew6KCT1/JfQwRzsn4twVhqLheOYxVXtjN6BFUJjXTg814lLmKgEbw+f5LumLzILb66r47f873A0oz9coPhmk5mBavqwHuQfmU26wlDxjgdV10hXidt8S5iYLPR6T7Hei25fREH0cLqCm4n/Pn5K/vjE/vjj2R6jd76I3Nnt9tX8gi9LuAXqNBzEjTRKocJLB0zjzlm9qiN455IrGi3nQ0WnAAnHAW7DCIG3+g1USy9986xfxgUe5G+xErn2N6yKV2JLsERjreDr5V+8TJ6YB98IMyMW2fiblZKJHtVHHwEv7zhfGthSoKYcXAJRGeKjz7wkqwtTu6Hw9vdQRxKq+uvkgcDB9GYhfBl1q43sYXegf0L3Nku93fgDFjuWMUzuyAE+O50cVALI3sflqP7K+uLr1dt8YzR4Yslrz8x3n7jDW4PgGHnRLqjtsNNM/HqzJIaCsYhyJm36ZbJeuy5M3zqT4PK4H24PhldJ3PPncNLgzAswRo+NMsmXbo5jGzvfGFPmP1gTN1F8pkZ3fFJjuOsfiqnvfzI3vxYEq+KwzNihz2M6RKgTab+OPBXmclzEGYJOusCmJs4zNmAksbMfYDspBYtqO08aQYgVuSINTlipByb3ujl+nlQY1wJrLF8biVPoDHQVTnouhx0pKy59/17uZXO1yinGbeBqFUR1LoI6iZWv9hJmiUXbX0wV7HeA6yoAWtqwE3Keod2L9gJ0kmS5fjXcBUtXE0LlyQ78I2WX7H8CZ9I7I87mJFS3OFG5R49Nga2m3jNo/AOGi1tNSlaZP9OgqvZneYZu/ireQIMhY2eK1PPWYdRi9CLS/LwqOmrifFie1vDr4r5IXTqGxpJRiBXxZDrYsj5ciYXL7lUyYWZJ0Ov3GikdwuqooOq6aAiZdWauaMR1Q2kigypJkOKlNMWI54D+Ot8xIsxMZtbYGxqL12m3CKQq0xkYkIzvVUMwVEFpm6DkVJWU4JFjsJ+HrWBNX35sRXLFmuTKbxA1KoIal0ENVKur2yQ6kXA+tPxceTdoLczljwec6M94cBVKeBIAZ/uYwi/z/W2HbrD/RGsSy6mHm/SZode+y0Ny4Rt+MDzXQa896KVjvtI6il4wnxqiRkJ3LmThdf7XalzWeyQc0J3XB0Fo3eAbjs3IfZ8mM95e1iIlW/D7u+43am4gS083BHGjF8Wl1UmpJjynZjLqabt6UIyZU/V8td76vC1XHfLTmAjSs7646RPnymAf7xjNeo+6JvIG8bZQY88c3B/ApjTqeCeWzbKbo1wSdf0mZr/K4A3vRxaDw0NaSuDKvbdRK2qK5qNmLRxlik+W5GpTauPjFvXw+S+jDrFLfQe+BDHyS478karBk8scTuyRf1wDAvKZUrJ7TwZvcM9e9xssw4e7waQpmoxSyCX9c/A+siHXJiv/rJOteNrr7vezLZnaxg+D7yu3vQ6SGNJ28I0FMdfpVed32aFNiiI1oHSAK0KU5tbye2V6K1UmGIyaoWq92r6o5zFALoMd/D5boooJHqbcpxTW405M7lIn84y8BkbeI0OZgbwYSuVtJmrRv0VVjnZ9KdJcP8ginJPeupdjzcO/XjVD16m+MNv5dAqUrQ6Do2byygCRde2mLPETR7DYaBVCdAi7G+yQcnlSS5LcjlmyXApLKUd7oksJ61OCk2sV4UP3XI27ttsccVrgzI3ijdZZTZJzEFZ6moq+ZbqN2L234yHkmOtJN3LOC4/U7J4eIPtrQWx280+zX03zLI9Jw4vpJxVTxZbRI1mckrLQqFeKCTnomOm6Nh4yGh/yOim0z3iFa+R5cwZ3s3g9Eil0EcFp3CtNgCtHbhp6XRRYov5PJKzUJrCmkrIpTqv7DAsO+QeMIUeMGeyuFCiMdDAd0z1Hvkg8V4N92OTa4jUT1DpbxDdipAz6w9qmI7jYhxlURy/7XALDSNcG3bMjR1guOnzV4/D9NCykGDuLbzPbGuk2DHocCc7nYWFodsvz2fa8sT1zOSOQU/KrdT+LBwWUcYgqs/LyBNiVb8JNzb+8mtMMdTG9CJP+1UfT9NnVhKzInBr0OKOq+uNxjM5Rtoxc2HAmK5ivJ0HGJ6jfhFmiZbngfrQOyZTw6AfhLLsAD25QGcB188Mw+MtE0eRD1avgUxf1K8VWAEdPrLJyBFjvnoSeTOi/vjD9oad/QXOqA2H3CBK7TsOJgduAfju86bmi9KHTKr/wCi/VhqP+xgGMA61Nxa+YduBNy/omGHdP8s+sVEqWOHWCwGwiQGv5PYC9UfeJyMcz/YXN8/Y4QOYzvYgcEuxWwPbRk/O168POfJ4swWcx7v1xMpBG5wHdgIu+8xVcvNx3abRZuurzC3lizMn2AZ3Yj5fdHfuVNicYvqnC8t9D1oxcV+S5kT8/TsBtLRaAcCTUHtptMJqev69Sz7c+gR788T59O7jm6gSmnD6VTbLdeJ8glHIQXT4nc+RtAQ8RDVQnIO6dAOb5G6GteCkYS93ki45DFh6w8kdbt7hFhhuatGN4Lx2K9J2izJVlPLQa5iom6hK9vsjx9gj+WIBznDR5lK488mmfqu+6blpNJrQS0mo/bLFxGen/fF/At6SG6PmrDAvD+iXB/QGBRcwUsGTxNxEf7jsvMBRkB+IXZLulIX/XVyQfAOuwJJAY5bNq2aYKeSU015VoL0HsPQALlBqD+qcB3ETtJVcrKkUruxxhEWy16McBdan2Vv2w8Ql4Ce6kSRORLuU8e+Pk8IgHLs4aZhP5wvADOAXfxdKeh95omAtu1ViXsvyVL6fyvfJY8baY8YWBS/RGwf3MXH7wOpR6QGt79Akzvu4G7bjZjwFz5Zs7qCs2PvQn9gO68dhETl7ynrGBN1uoOjKL8xJpaSbLXO8wf4UnE09+8I+fiWA/4PxUTojJ3dEjcr0XpgWE3h8CNMK+R2L1mHqvxMq7DLZ+31csUHu/EaBAAvYj8qm2V6NUSw7La2j6J1qA+MJz3T4jtnOE1jdDUdWjeiAH8w8VsJiBbGAtLuA9j4xN2+FaebBx35PjqSX51m6LdaV0xMJg1/9krgzQnzHbKRuub5saZC/SN95WB8LDyj52Y9/yHlk+hXPAIHpaY7g5g7L0tpqRzFs62c2qwYsjkZiwRq6iVzXy74T9NtalG0UvuwbBfbHdbdskaJl+BQF7mcwxjAX1ix7cBbPz/gLasVAEZCp3xwmodCWz9eashd8f8TNDehEEjNhU2ORT7BrQCxisUmxdh/RIr75iMYSzC9UxI5tPj0/s5FKMJ/BUZM43s5TmLVH65Uyx2Rgknjh5iub5gHDAfaiQCSe/8CqpK2vkBpwmZXCWfI0GakaOQHW0yhtc9XM+gS7PMHwCTEMa5mpcR6cXEpQ/mubqwo09wCOCLho+MQbrHja+EufHF7+a3SHavt0UyAFJwnNPIib+jHNbEibKdojRfuhqPQpZQ7qEDSxko034NrLvZlYaBjLDlP2QWxjFVFjhXgoRG3Q+k0GXZXo0EcMGgI+lhs2cO9gnWKYZIJ/gGFslzPsfkMH3NBOcReSufCARok4LcNKqV4pJfiHjKKHjJqHzYeHzQECjgAU9Mh2EGv63MiPeMvsbP1112oJoFi+9/ciYBgl6FLTx7RLwC89J8VprMkRNzT9V2ZUlBnj9DK9GsFFp0fROV9ULH5il1cdBAISoy9B22D2zdnMUvrKvfMqCb46EPCT3hohb+X4IKA5fgPoPiZuAH3+GH644j7ix1OgmNsXCuPx83mT54AFbAgQv/6Qic9ZqwLOzwQIE6WpZgNTEL6yjihaVOHpnMlo3/lGtHODUVwMyncUStZX8pn6o5UN3qxrRzEM9lIuSO8YHxrd68WtQgtsi1n/TmO2nnELbQ2QZcSSKs4bImO2uu4pEkR/ZgT3AtZrkgToFgOKFLQmxdivNwzEgMZaD7LSux0FJhbwOd9Lb0QjZMhVWQHAX66kO/IX4W1rLDC3HSjG1eb5tE1CAVZfEev32kIrRAVg/1h5bDmpydUL3jo4GX+SGf8535uG15n428WMP9mET5yG1PnAi1zKLCk+dMLihRIOj090FPbh5svVkJDfL/mzFNh44gcm9m637vQxn9GwHOuhWB6wI8GXk5pC4378iAefZiUVHua45BFzY96dJf/3z3/7f+Ce+fwt/gAA'''
OUT = ROOT / 'artifacts' / 'search-destination-regression.json'

SCRIPT_RE = re.compile(r'<script\b[^>]*>(?P<body>.*?)</script\s*>', re.I | re.S)
STYLE_RE = re.compile(r'<(style|noscript|svg)\b[^>]*>.*?</\1\s*>', re.I | re.S)
JSON_STRING_RE = re.compile(r'"(?:\\.|[^"\\])*"', re.S)
COMMENT_RE = re.compile(r'<!--.*?-->', re.S)
TAG_RE = re.compile(r'<[^>]+>', re.S)

def norm(s: str) -> str:
    out=[]; pending=False
    for ch in s or '':
        wrote=False
        for d in unicodedata.normalize('NFD', ch):
            if unicodedata.category(d) == 'Mn':
                continue
            if d.isalnum():
                if pending and out and out[-1] != ' ':
                    out.append(' ')
                pending=False; out.append(d.lower()); wrote=True
        if not wrote:
            pending=True
    return re.sub(r'\s+', ' ', ''.join(out)).strip()

def extract_visible_text(html: str) -> str:
    script_strings=[]
    for m in SCRIPT_RE.finditer(html):
        for lit in JSON_STRING_RE.findall(m.group('body')):
            try:
                value=json.loads(lit)
                if isinstance(value, str) and value.strip() and len(value) >= 2:
                    script_strings.append(value)
            except Exception:
                pass
    text=SCRIPT_RE.sub(' ', html)
    text=STYLE_RE.sub(' ', text)
    text=COMMENT_RE.sub(' ', text)
    text=re.sub(r'<(br|hr)\b[^>]*>', ' ', text, flags=re.I)
    text=re.sub(r'</(p|div|section|article|li|tr|h[1-6]|table|ul|ol)>\s*', ' ', text, flags=re.I)
    text=TAG_RE.sub(' ', text)
    text=htmlmod.unescape(text)
    if script_strings:
        text += ' ' + ' · '.join(script_strings)
    return re.sub(r'\s+', ' ', text.replace('\u00a0', ' ')).strip()

def occurrences(haystack: str, needle: str):
    found=[]; at=0
    while at < len(haystack):
        i=haystack.find(needle, at)
        if i < 0: break
        end=i+len(needle)
        if (i == 0 or haystack[i-1].isspace()) and (end >= len(haystack) or haystack[end].isspace()):
            found.append(i); at=i+max(1,len(needle))
        else:
            at=i+1
        if len(found) >= 32: break
    return found

def resolver_template() -> str:
    text=(SRC/'MainWindow.SearchDestination.cs').read_text(encoding='utf-8')
    m=re.search(r'private const string SearchDestinationResolverTemplate = """\n(?P<body>.*?)\n\s*""";', text, re.S)
    if not m: raise RuntimeError('resolver template not found')
    return m.group('body')

def script_for(template: str, query: str, before: str, after: str, hint: str, occurrence: int, count: int, resource_id='fixture', source_version='0'*64, allow_search_assist=False):
    values={
        '__NEEDLE__': json.dumps(query), '__QUERY__': json.dumps(query), '__TERMS__': json.dumps([query]),
        '__CONTEXT_HINT__': json.dumps(hint), '__CONTEXT_BEFORE__': json.dumps(before), '__CONTEXT_AFTER__': json.dumps(after),
        '__OCCURRENCE__': str(occurrence), '__OCCURRENCE_COUNT__': str(max(1,count)), '__EXACT__': 'true',
        '__ALLOW_SEARCH_ASSIST__': 'true' if allow_search_assist else 'false', '__SCHEMA_VERSION__': '2',
        '__RESOURCE_ID__': json.dumps(resource_id), '__SOURCE_VERSION__': json.dumps(source_version.lower()), '__MAX_CONTEXT__': '420'
    }
    out=template
    for k,v in values.items(): out=out.replace(k,v)
    if re.search(r'__[A-Z0-9_]+__', out): raise RuntimeError('unresolved resolver placeholder')
    return out

async def run_case(page, template, *, query, before, after, hint=None, occurrence=0, count=1, resource_id='fixture', source_version='0'*64, allow_search_assist=False):
    js=script_for(template, query, before, after, hint or f'{before} {query} {after}', occurrence, count, resource_id, source_version, allow_search_assist)
    raw=await page.evaluate(js)
    return json.loads(raw) if isinstance(raw,str) and raw else None

async def synthetic_tests(page, template):
    tests=[]
    async def one(name, html, query, before, after, expect_found=None, expect_reason=None, expect_text=None):
        await page.set_content(html, wait_until='load'); await page.wait_for_timeout(30)
        r=await run_case(page, template, query=query, before=before, after=after)
        ok=True
        if expect_found is not None: ok &= bool(r and r.get('found')) == expect_found
        if expect_reason is not None: ok &= (r or {}).get('reason') == expect_reason
        if expect_text is not None: ok &= expect_text in norm((r or {}).get('text',''))
        tests.append({'name':name,'ok':bool(ok),'result':r})
    await one('distinct-sibling-context-second', '<body><article class="card"><h3>One</h3><p>alpha before target alpha after</p></article><article class="card"><h3>Two</h3><p>beta before target beta after</p></article></body>', 'target', 'beta before', 'beta after', True, 'resolved', 'beta')
    await one('distinct-sibling-context-first', '<body><article class="card"><h3>One</h3><p>alpha before target alpha after</p></article><article class="card"><h3>Two</h3><p>beta before target beta after</p></article></body>', 'target', 'alpha before', 'alpha after', True, 'resolved', 'alpha')
    await one('identical-sibling-ambiguous', '<body><article class="card"><p>same before target same after</p></article><article class="card"><p>same before target same after</p></article></body>', 'target', 'same before', 'same after', False, 'ambiguous-occurrence')
    await one('nested-inline', '<body><article class="card" id="n"><p>context acute <strong>pancreatitis</strong> diagnosis needs action</p></article></body>', 'acute pancreatitis diagnosis', 'context', 'needs action', True, 'resolved')
    await one('closed-details', '<body><details id="d"><summary>More</summary><p>before special target after</p></details></body>', 'special target', 'before', 'after', True, 'resolved')
    await one('script-generated', '<body><main id="m"></main><script>m.innerHTML=`<article class="card"><h3>Dynamic target</h3><p>generated after context</p></article>`;</script></body>', 'dynamic target', '', 'generated after context', True, 'resolved')
    await one('same-semantic-unit-repeat-first', '<body><article class="card" id="same"><p>first context target first tail</p><p>second context target second tail</p></article></body>', 'target', 'first context', 'first tail', True, 'resolved', 'first')
    await one('same-semantic-unit-repeat-second', '<body><article class="card" id="same"><p>first context target first tail</p><p>second context target second tail</p></article></body>', 'target', 'second context', 'second tail', True, 'resolved', 'second')
    await one('list-sibling-context', '<body><ul><li>alpha list target first</li><li>beta list target second</li></ul></body>', 'target', 'beta list', 'second', True, 'resolved', 'beta')
    await one('table-sibling-context', '<body><table><tr><td>alpha row target first</td></tr><tr><td>beta row target second</td></tr></table></body>', 'target', 'beta row', 'second', True, 'resolved', 'beta')
    return tests

async def main():
    template=resolver_template()
    seed=json.loads(gzip.decompress(base64.b64decode(SEED_GZIP_B64)).decode('utf-8'))
    registry=json.loads((SRC/'ShellData/resource-registry.json').read_text())['resources']
    by_id={r['resourceId']:r for r in registry if isinstance(r.get('number'),int)}
    records=[]; summaries=[]
    async with async_playwright() as p:
        browser=await p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
        page=await browser.new_page(viewport={'width':1440,'height':1000})
        grouped={}
        for rec in seed['records']: grouped.setdefault(rec['resourceId'], []).append(rec)
        for resource_id, rows in grouped.items():
            entry=by_id[resource_id]
            html=(SRC/'MedicalPayload/R2'/entry['canonicalPath']).read_text(errors='ignore')
            source=norm(extract_visible_text(html))
            await page.set_content(html, wait_until='load'); await page.wait_for_timeout(180)
            passed=0; failures=[]
            for seed_rec in rows:
                q=norm(seed_rec['query']); pos=occurrences(source,q); oi=seed_rec['occurrence']
                if oi >= len(pos):
                    failures.append({'query':q,'occurrence':oi,'reason':'source-occurrence-missing'}); continue
                idx=pos[oi]; before=source[max(0,idx-110):idx].strip(); after=source[idx+len(q):min(len(source),idx+len(q)+170)].strip(); hint=source[max(0,idx-110):min(len(source),idx+len(q)+170)].strip()
                result=await run_case(page,template,query=q,before=before,after=after,hint=hint,occurrence=oi,count=len(pos),resource_id=resource_id,source_version=entry.get('sourceSha256','0'*64),allow_search_assist=not (19 <= entry['number'] <= 22))
                ok=bool(result and result.get('found') is True and result.get('reason')=='resolved' and result.get('location'))
                if ok: passed+=1
                else: failures.append({'query':q,'occurrence':oi,'result':result})
                records.append({'resourceId':resource_id,'number':entry['number'],'query':q,'occurrence':oi,'count':len(pos),'ok':ok,'result':result})
            summaries.append({'resourceId':resource_id,'number':entry['number'],'tests':len(rows),'passed':passed,'failed':len(failures),'failures':failures[:8]})
            print(f"{entry['number']:02d} {resource_id}: {passed}/{len(rows)}")
        # Dedicated historical W2C exact fixture. Use a fresh page so hundreds of prior
        # dynamic cockpit executions cannot leak transient document/search state into this gate.
        await page.close()
        page=await browser.new_page(viewport={'width':1440,'height':1000})
        gi=by_id['gi-hepatobiliary']; html=(SRC/'MedicalPayload/R2'/gi['canonicalPath']).read_text(errors='ignore'); source=norm(extract_visible_text(html)); await page.set_content(html,wait_until='load'); await page.wait_for_timeout(100)
        q=norm('Acute pancreatitis diagnosis'); pos=occurrences(source,q); acute=[]
        for oi,idx in enumerate(pos):
            before=source[max(0,idx-110):idx].strip(); after=source[idx+len(q):min(len(source),idx+len(q)+170)].strip(); hint=source[max(0,idx-110):min(len(source),idx+len(q)+170)].strip()
            acute.append(await run_case(page,template,query=q,before=before,after=after,hint=hint,occurrence=oi,count=len(pos),resource_id='gi-hepatobiliary',source_version=gi.get('sourceSha256','0'*64),allow_search_assist=True))
        await page.close()
        page=await browser.new_page(viewport={'width':1440,'height':1000})
        synth=await synthetic_tests(page,template)
        await browser.close()
    acute_keys=[((r or {}).get('location',{}).get('anchor',''), (r or {}).get('location',{}).get('targetId',''), (r or {}).get('location',{}).get('targetPath','')) for r in acute]
    acute_ok=len(acute)>=2 and all((r or {}).get('found') for r in acute[:2]) and acute_keys[0] != acute_keys[1]
    total=sum(s['tests'] for s in summaries); passed=sum(s['passed'] for s in summaries)
    report={'total':total,'passed':passed,'failed':total-passed,'summaries':summaries,'records':records,'acutePancreatitis':{'count':len(pos),'ok':acute_ok,'results':acute},'synthetic':synth,'syntheticPassed':sum(t['ok'] for t in synth),'syntheticTotal':len(synth)}
    OUT.parent.mkdir(parents=True,exist_ok=True); OUT.write_text(json.dumps(report,indent=2))
    print('TOTAL',passed,'/',total)
    print('ACUTE',acute_ok,acute_keys[:4])
    print('SYNTH',report['syntheticPassed'],'/',report['syntheticTotal'])
    if passed != total or not acute_ok or report['syntheticPassed'] != report['syntheticTotal']:
        raise SystemExit(1)

if __name__=='__main__': asyncio.run(main())
