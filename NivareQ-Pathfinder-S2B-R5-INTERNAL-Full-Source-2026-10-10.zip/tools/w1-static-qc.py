from pathlib import Path
import hashlib, json, re, sys

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'src' / 'NivareQ.Step2Pathfinder'
MANIFEST = ROOT / 'Integrity' / 'MEDICAL_PAYLOAD_SHA256_MANIFEST.txt'
PAYLOAD = SRC / 'MedicalPayload'
errors=[]
checks=[]

def check(name, cond, detail=''):
    checks.append((name,bool(cond),detail))
    if not cond: errors.append(f'{name}: {detail}')

# 132/132 frozen payload preservation.
manifest=[]
for line in MANIFEST.read_text(encoding='utf-8').splitlines():
    if not line.strip(): continue
    h, rel=line.split('  ',1)
    manifest.append((h,rel))
for h,rel in manifest:
    p=PAYLOAD/rel
    actual=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else 'MISSING'
    check('medical:'+rel, actual==h, actual)
check('medical-count', len(manifest)==132, str(len(manifest)))

# New bounded persistence architecture markers.
files={p.name:p.read_text(encoding='utf-8') for p in [
    SRC/'Services'/'AtomicFileStore.cs',
    SRC/'Services'/'BackupContractService.cs',
    SRC/'Services'/'BackupExtensionStore.cs',
    SRC/'Services'/'RestoreTransactionService.cs',
    SRC/'Services'/'SettingsService.cs',
    SRC/'Services'/'PersonalStudyService.cs',
    SRC/'Models'/'BackupModels.cs',
    SRC/'MainWindow.PersonalStudy.cs',
    SRC/'MainWindow.xaml.cs',
    SRC/'MainWindow.Accessibility.cs',
]}
alltext='\n'.join(files.values())
for marker in [
    'BackupSchemaVersion { get; set; } = 2',
    'windows-canonical',
    'MaxBackupBytes = 100L * 1024L * 1024L',
    'File.Replace(tempPath, path, backupPath',
    'RestoreTransactionService.Commit',
    'EnsureInterruptedRestoreRecovered',
    'PreservedExtensions',
    'PwaState',
    'StrongFocusIndicators',
    'ReduceMotion',
    'ComfortableReadingSpacing',
    'ConfirmRestorePlanAsync', # explicit restore preview/confirmation path
    '_suspendCockpitPositionPersistenceUntilRestart',
    'journal.Committed = true',
    'TryValidateJournal',
    'ShouldPreservePwaSelectorOnly',
    'OpenTransactedWriteAsync',
    'EnsureOnlyProperties',
    'ValidateCanonicalCoverage',
    'QueuePersistenceFailureNotice',
    'ReadBoundedStoreText',
    'keepLastGood: false',
]:
    check('marker:'+marker, marker in alltext, 'missing source marker')

# Bounded source-change scope: protect unrelated accepted Windows code.
baseline_src = ROOT.parent / '02-WINDOWS-v1.2-WORKING-SNAPSHOT' / 'src' / 'NivareQ.Step2Pathfinder'
allowed_changed = {
    'MainWindow.PersonalStudy.cs',
    'MainWindow.xaml.cs',
    'MainWindow.Accessibility.cs',
    'Services/PathfinderPaths.cs',
    'Services/PersonalStudyService.cs',
    'Services/SettingsService.cs',
}
allowed_new = {
    'Models/BackupModels.cs',
    'Services/AtomicFileStore.cs',
    'Services/BackupContractService.cs',
    'Services/BackupExtensionStore.cs',
    'Services/PersistenceHealth.cs',
    'Services/RestoreTransactionService.cs',
}
source_scope_errors=[]
for bp in baseline_src.rglob('*'):
    if not bp.is_file(): continue
    rel=bp.relative_to(baseline_src).as_posix()
    cp=SRC/rel
    if rel.startswith('MedicalPayload/'):
        continue
    if not cp.exists(): source_scope_errors.append('deleted:'+rel); continue
    if bp.read_bytes()!=cp.read_bytes() and rel not in allowed_changed:
        source_scope_errors.append('unexpected-change:'+rel)
for cp in SRC.rglob('*'):
    if not cp.is_file(): continue
    rel=cp.relative_to(SRC).as_posix()
    if rel.startswith('MedicalPayload/'): continue
    bp=baseline_src/rel
    if not bp.exists() and rel not in allowed_new:
        source_scope_errors.append('unexpected-new:'+rel)
check('bounded-source-change-scope', not source_scope_errors, '; '.join(source_scope_errors))
check('no-uworld-source-alias', 'SlugAliases' not in files['BackupContractService.cs'], 'PWA native Selector must not alias to legacy Windows PDF')
check('restore-journal-definite-assignment',
      'if (journal is null)' in files['RestoreTransactionService.cs'] and
      'if (!TryValidateJournal(journal, out var journalError))' in files['RestoreTransactionService.cs'],
      'restore journal null/validation branches must be separate so journalError is definitely assigned')

# Prohibited architecture regression checks.
check('no-portable-data-root', 'AppRoot, "Data"' not in alltext and 'PortableData' not in alltext, 'portable-data path marker found')
app = (SRC/'App.xaml.cs').read_text(encoding='utf-8')
baseline_app = ROOT.parent / '02-WINDOWS-v1.2-WORKING-SNAPSHOT' / 'src' / 'NivareQ.Step2Pathfinder' / 'App.xaml.cs'
check('sta-startup-byte-identical', baseline_app.exists() and app == baseline_app.read_text(encoding='utf-8'), 'App.xaml.cs differs from accepted v1.2 startup')
check('no-custom-main', not re.search(r'\bstatic\s+(?:async\s+)?(?:void|int|Task(?:<int>)?)\s+Main\s*\(', app), 'custom Main entry point found')

# Build contract fixtures (schema semantics independent of UI/runtime).
fixture_dir=ROOT/'docs'/'W1-fixtures'
fixture_dir.mkdir(parents=True, exist_ok=True)
win_v1={
  'BackupSchemaVersion':1,
  'ExportedUtc':'2026-09-29T12:00:00Z',
  'ShellSettings':{
    'ThemeId':'ocean','RestoreLastSession':True,'StrongFocusIndicators':True,'ReduceMotion':False,'ComfortableReadingSpacing':True,
    'LastSessionTabs':[{'Kind':'shell','Id':'Search','IsPinned':False,'HasLocation':False,'Hash':'','ScrollX':0,'ScrollY':0},{'Kind':'study','Id':'cardiology','IsPinned':True,'HasLocation':True,'Hash':'#hf','ScrollX':0,'ScrollY':120}],
    'LastSelectedTabIndex':2
  },
  'PersonalStudy':{'SchemaVersion':1,'ShowProgress':True,'FavoriteSlugs':['cardiology'],'RecentSubjects':[{'Slug':'cardiology','LastOpenedUtc':'2026-09-29T12:00:00Z'}],'ProgressBySlug':{'cardiology':'Studying'},'PositionsBySlug':{'cardiology':{'Hash':'#hf','ScrollX':0,'ScrollY':120,'UpdatedUtc':'2026-09-29T12:00:00Z'}},'SubjectNotes':{'cardiology':'note'},'Bookmarks':[]}
}
pwa_v1={
  'BackupSchemaVersion':1,
  'ExportedUtc':'2026-09-29T12:00:00Z',
  'ShellSettings':{
    'ThemeId':'sage','RestoreLastSession':True,
    'LastSessionTabs':[{'Kind':'search','Id':'search','IsPinned':False,'HasLocation':False,'Hash':'','ScrollX':0,'ScrollY':0},{'Kind':'study','Id':'cardiology','IsPinned':False,'HasLocation':True,'Hash':'#af','ScrollX':0,'ScrollY':300},{'Kind':'study','Id':'extra-uworld-selector','IsPinned':False,'HasLocation':False,'Hash':'','ScrollX':0,'ScrollY':0}],
    'LastSelectedTabIndex':3
  },
  'PersonalStudy':{'SchemaVersion':1,'ShowProgress':False,'FavoriteSlugs':['cardiology','extra-uworld-selector'],'RecentSubjects':[],'ProgressBySlug':{},'PositionsBySlug':{},'SubjectNotes':{},'Bookmarks':[]},
  'PwaState':{'Tabs':[{'id':'t1','kind':'subject','slug':'cardiology'}],'CockpitStudyState':{'SchemaVersion':1,'Owners':{}},'Journal':{'SchemaVersion':1,'Replace':True,'StorageVersion':2,'Entries':[]}}
}
canonical_v2={
  'BackupSchemaVersion':2,'FormatId':'nivareq.step2pathfinder.backup','ContractAuthority':'windows-canonical','Producer':'NivareQ Step 2 Pathfinder Windows','ProducerBuild':'W1','ExportedUtc':'2026-09-29T12:00:00Z',
  'ShellSettings':win_v1['ShellSettings'],'PersonalStudy':win_v1['PersonalStudy'],
  'Coverage':{'Included':['Windows shell settings and accessibility preferences'],'Deferred':['live cockpit review/quiz/mode state owned by WebView2 content (scheduled W3)'],'PreservedOpaque':['PwaState']},
  'PreservedExtensions':{'PwaState':pwa_v1['PwaState']}
}
for name,obj in [('windows-v1.json',win_v1),('pwa-b4a-v1.json',pwa_v1),('canonical-w1-v2.json',canonical_v2)]:
    (fixture_dir/name).write_text(json.dumps(obj,indent=2),encoding='utf-8')
    loaded=json.loads((fixture_dir/name).read_text(encoding='utf-8'))
    check('fixture:'+name, loaded['BackupSchemaVersion'] in (1,2), 'schema')
check('fixture-pwa-opaque-state', 'PwaState' in pwa_v1, '')
check('fixture-v2-preserved-extension', 'PwaState' in canonical_v2['PreservedExtensions'], '')

passed=sum(1 for _,ok,_ in checks if ok)
print(json.dumps({'passed':passed,'failed':len(errors),'medical_files':len(manifest),'errors':errors},indent=2))
sys.exit(1 if errors else 0)
