$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$Src = Join-Path $Root 'src\NivareQ.Step2Pathfinder\MedicalPayload'
$Manifest = Join-Path $Root 'Integrity\MEDICAL_PAYLOAD_SHA256_MANIFEST.txt'
$fail = 0; $count = 0
Get-Content $Manifest | ForEach-Object {
  if (-not $_.Trim()) { return }
  $parts = $_ -split '  ',2
  $expected = $parts[0].Trim(); $rel = $parts[1].Trim().Replace('/', [IO.Path]::DirectorySeparatorChar)
  $path = Join-Path $Src $rel
  $count++
  if (-not (Test-Path -LiteralPath $path)) { Write-Host "MISSING $rel" -ForegroundColor Red; $fail++; return }
  $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $path).Hash.ToLowerInvariant()
  if ($actual -ne $expected) { Write-Host "MISMATCH $rel" -ForegroundColor Red; $fail++ }
}
if ($fail -gt 0) { throw "Medical payload integrity FAILED: $fail of $count files." }
Write-Host "Medical payload integrity PASS: $count/$count files byte-identical." -ForegroundColor Green
