from pathlib import Path
import hashlib, json, re, sys

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'src' / 'NivareQ.Step2Pathfinder'
PAYLOAD = SRC / 'MedicalPayload'
REGISTRY = SRC / 'ShellData' / 'resource-registry.json'
FROZEN_MAP = SRC / 'ShellData' / 'frozen-content-map.json'
INTEGRITY_MANIFEST = ROOT / 'Integrity' / 'MEDICAL_PAYLOAD_SHA256_MANIFEST.txt'
errors=[]; checks=[]

def check(name, cond, detail=''):
    checks.append((name,bool(cond),detail))
    if not cond: errors.append(f'{name}: {detail}')

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

# Frozen payload: 132 files, all preserved by bytes under canonical short paths.
fmap=json.loads(FROZEN_MAP.read_text(encoding='utf-8'))
check('frozen-map-count', fmap.get('fileCount')==132 and len(fmap.get('files',[]))==132, str(fmap.get('fileCount')))
legacy=set(); canonical=set()
for rec in fmap['files']:
    legacy_path=rec['legacyPath']; rel=rec['canonicalPath']; expected=rec['sha256']
    check('unique-legacy:'+legacy_path, legacy_path not in legacy, legacy_path); legacy.add(legacy_path)
    check('unique-canonical:'+rel, rel not in canonical, rel); canonical.add(rel)
    p=PAYLOAD/'R2'/rel
    check('medical:'+rel, p.exists() and sha(p)==expected, 'missing or hash mismatch')
check('canonical-file-count', len([p for p in (PAYLOAD/'R2').rglob('*') if p.is_file()])==132, 'must remain exactly 132 frozen files')
check('legacy-hub-absent', not (PAYLOAD/'Step2CK-2026-One-Launch-Study-Hub').exists(), 'legacy physical hub path still present')
maxrel=max((len(str(p.relative_to(PAYLOAD))) for p in PAYLOAD.rglob('*') if p.is_file()), default=0)
check('short-path-envelope', maxrel <= 80, f'max relative path={maxrel}')
check('no-long-package-wrapper-dir', not any('Fearless-Cockpit-R1-Package/' in x.replace('\\','/') for x in canonical), 'legacy long package wrapper remains')

# Build-time medical manifest must use verifier-compatible "hash  relative/path" format.
manifest_lines=[x for x in INTEGRITY_MANIFEST.read_text(encoding='utf-8').splitlines() if x.strip()]
parsed_manifest=[]
for i,line in enumerate(manifest_lines):
    parts=line.split('  ',1)
    ok=len(parts)==2 and re.fullmatch(r'[0-9a-f]{64}',parts[0]) is not None and parts[1].startswith('R2/')
    check(f'medical-manifest-format:{i:03d}',ok,line[:120])
    if ok: parsed_manifest.append((parts[0],parts[1]))
check('medical-manifest-count',len(parsed_manifest)==132,str(len(parsed_manifest)))

# Canonical resource registry.
registry=json.loads(REGISTRY.read_text(encoding='utf-8'))
resources=registry.get('resources',[])
check('registry-schema', registry.get('schemaVersion')==1, str(registry.get('schemaVersion')))
check('registry-resource-count', len(resources)==25, str(len(resources)))
ids=[r.get('resourceId','') for r in resources]
check('registry-ids-unique', len(ids)==len(set(x.lower() for x in ids)), str(ids))
check('registry-study-count', sum(1 for r in resources if r.get('role')=='study')==23, '')
check('registry-reference-count', sum(1 for r in resources if r.get('role')=='reference')==2, '')
check('legacy-extra-id-clinical-recall', 'extra-clinical-recall-library' in ids, '')
check('legacy-extra-id-uworld', 'extra-uworld-checkbox-selector' in ids, '')
for r in resources:
    p=PAYLOAD/'R2'/r['canonicalPath']
    check('resource:'+r['resourceId'], p.exists() and sha(p)==r['sourceSha256'], r['canonicalPath'])
    if r.get('role') == 'study':
        check('study-main-short:'+r['resourceId'], Path(r['canonicalPath']).name == 'main.html', r['canonicalPath'])
    check('legacy-provenance:'+r['resourceId'], bool(r.get('legacyMainPath')), 'legacyMainPath missing')

# The Resource Registry must preserve released NAVIGATION-MANIFEST semantics exactly.
legacy_manifest=json.loads((PAYLOAD/'R2'/'meta'/'NAVIGATION-MANIFEST.json').read_text(encoding='utf-8'))
study=[r for r in resources if r.get('role')=='study']
refs=[r for r in resources if r.get('role')!='study']
check('legacy-nav-study-count',len(legacy_manifest.get('items',[]))==len(study)==23,'')
for old,new in zip(legacy_manifest.get('items',[]),study):
    for old_key,new_key in [('n','number'),('slug','resourceId'),('title','title'),('subtitle','subtitle'),('kind','kind'),('phase','phase'),('main','legacyMainPath')]:
        check(f'legacy-nav:{new.get("resourceId")}:{old_key}',old.get(old_key)==new.get(new_key),f'{old.get(old_key)!r} != {new.get(new_key)!r}')
legacy_extras=legacy_manifest.get('extras',[])
check('legacy-nav-extra-count',len(legacy_extras)==len(refs)==2,'')
for old,new in zip(legacy_extras,refs):
    check('legacy-extra-title:'+new['resourceId'],old.get('title')==new.get('title'),'')
    check('legacy-extra-path:'+new['resourceId'],old.get('path')==new.get('legacyMainPath'),'')
    check('legacy-extra-type:'+new['resourceId'],old.get('type','html')==new.get('contentType','html'),'')

# W2A dependency audit: 25 runtime resources must be self-contained at file level.
# Frozen historical/meta documents can retain legacy links as provenance; they are not runtime resources.
attr_patterns=[
    re.compile(r'''(?:href|src)\s*=\s*["']([^"']+)["']''',re.I),
    re.compile(r'''url\(\s*["']?([^)'"\s]+)''',re.I),
    re.compile(r'''(?:fetch|open)\s*\(\s*["']([^"']+)["']''',re.I),
    re.compile(r'''(?:location(?:\.href)?|window\.location)\s*=\s*["']([^"']+)["']''',re.I),
]
relative_dependencies=[]
for r in resources:
    if str(r.get('contentType','html')).lower()!='html':
        continue
    p=PAYLOAD/'R2'/r['canonicalPath']
    text=p.read_text(encoding='utf-8',errors='ignore')
    for pat in attr_patterns:
        for raw in pat.findall(text):
            value=raw.strip()
            if not value or '${' in value or value.startswith(('#','data:','http:','https:','mailto:','javascript:','blob:')):
                continue
            base=value.split('#',1)[0].split('?',1)[0].strip()
            if base:
                relative_dependencies.append((r['resourceId'],value))
check('runtime-resource-relative-file-dependencies',not relative_dependencies,str(relative_dependencies[:20]))

# Alias contract is explicit and conflict-free in the registry.
alias_owner={}
for r in resources:
    aliases=[r['resourceId'],r.get('legacyMainPath',''),*r.get('legacyAliases',[])]
    for alias in aliases:
        if not alias: continue
        key=alias.casefold()
        prior=alias_owner.get(key)
        check('alias-unambiguous:'+alias,prior in (None,r['resourceId']),f'{prior} vs {r["resourceId"]}')
        alias_owner[key]=r['resourceId']
check('alias-count-positive',len(alias_owner)>=50,str(len(alias_owner)))

# W2A source contract and first-class registry markers.
paths=(SRC/'Services'/'PathfinderPaths.cs').read_text(encoding='utf-8')
catalog=(SRC/'Services'/'ContentCatalogService.cs').read_text(encoding='utf-8')
runtime=(SRC/'Services'/'RuntimeContentService.cs').read_text(encoding='utf-8')
subject=(SRC/'Models'/'SubjectEntry.cs').read_text(encoding='utf-8')
textsel=(SRC/'MainWindow.TextSelection.cs').read_text(encoding='utf-8')
main=(SRC/'MainWindow.xaml.cs').read_text(encoding='utf-8')
check('content-root-r2', 'MedicalPayload", "R2"' in paths, '')
check('registry-path', 'resource-registry.json' in paths, '')
check('catalog-uses-registry', 'PathfinderPaths.ResourceRegistry' in catalog and 'NavigationManifest' not in catalog, '')
check('catalog-alias-resolver', '_byAlias' in catalog and 'public SubjectEntry? Resolve' in catalog and 'RegisterAlias' in catalog, '')
check('session-uses-alias-resolver', '_catalog.Resolve(saved.Id)' in main and '_catalog.Resolve(slug)' in main, '')
check('resource-id-model', 'ResourceId' in subject and 'LegacyMainPath' in subject and 'ExpectedSha256' in subject, '')
check('runtime-hash-authority', 'subject.ExpectedSha256' in runtime and 'Frozen study content integrity check failed' in runtime, '')
check('runtime-keyed-by-resource', '_byResourceId' in runtime, '')

# Native selectable shell text regression closure.
check('shell-text-native-menu', 'MenuFlyout' in textsel and 'TextCommandBarFlyout' in textsel, '')
check('shell-text-copy', 'Clipboard.SetContent' in textsel and 'SelectedText' in textsel, '')
check('shell-text-select-all', 'text.SelectAll()' in textsel, '')
check('shell-text-touch-selection', 'SelectionFlyout = CreateShellTextMenu' in textsel, '')
check('shell-text-context', 'ContextFlyout = CreateShellTextMenu' in textsel, '')
check('shell-content-wrapped', 'PrepareShellContent(content)' in main and 'PrepareShellContent(CreateHomeView())' in main, '')
check('shell-text-no-pointer-disable', 'IsHitTestVisible = false' not in textsel and 'IsEnabled = false' not in textsel, '')

# Preserve W1 / startup / storage guardrails.
allcs='\n'.join(p.read_text(encoding='utf-8',errors='ignore') for p in SRC.rglob('*.cs'))
for marker in ['windows-canonical','RestoreTransactionService.Commit','PreservedExtensions','EnsureOnlyProperties','QueuePersistenceFailureNotice','keepLastGood: false']:
    check('w1-marker:'+marker, marker in allcs, '')
check('no-portable-data-root', 'AppRoot, "Data"' not in allcs and 'PortableData' not in allcs, '')
app=SRC/'App.xaml.cs'
check('sta-startup-hash', sha(app)=='11233f9b7f67b8fd0963fe6bdf71a36b292ef6de5ac0a58e85189809a4c3349e', sha(app))
check('no-custom-main', not re.search(r'\bstatic\s+(?:async\s+)?(?:void|int|Task(?:<int>)?)\s+Main\s*\(', app.read_text(encoding='utf-8')), '')

# Build/publish tooling must independently verify the new registry contract as well as 132 frozen bytes.
build=(ROOT/'tools'/'build-windows.ps1').read_text(encoding='utf-8')
verify_registry=(ROOT/'tools'/'verify-resource-registry.ps1').read_text(encoding='utf-8')
check('build-source-registry-gate', "verify-resource-registry.ps1')" in build, '')
check('build-published-registry-gate', "verify-resource-registry.ps1') -PublishDir" in build, '')
check('registry-verifier-count', 'expected 25 resources' in verify_registry and 'Get-FileHash' in verify_registry, '')

passed=sum(1 for _,ok,_ in checks if ok)
result={'passed':passed,'failed':len(errors),'medical_files':132,'resources':len(resources),'aliases':len(alias_owner),'max_payload_relative_path':maxrel,'runtime_relative_dependencies':relative_dependencies,'errors':errors}
print(json.dumps(result,indent=2))
sys.exit(1 if errors else 0)
