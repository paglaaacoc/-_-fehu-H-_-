#!/usr/bin/env python3
"""Portable S2-B SQL contract smoke; DOES NOT compile or execute C#."""
import pathlib, re, sqlite3, tempfile, json, hashlib, zipfile
root=pathlib.Path(__file__).resolve().parents[1]
src=(root/'src/NivareQ.Step2Pathfinder/Services/NotesStoreV1.cs').read_text()
match=re.search(r'using \(var cmd = Command\(db, transaction, """\n(.*?)\n\s*"""\)\) cmd.ExecuteNonQuery\(\);',src,re.S)
assert match, 'Could not locate S2-B DDL'
sql=match.group(1)
with tempfile.TemporaryDirectory() as tmp:
    path=pathlib.Path(tmp)/'test.sqlite'
    db=sqlite3.connect(path)
    db.execute('PRAGMA foreign_keys=ON')
    db.executescript(sql)
    tables={x[0] for x in db.execute("SELECT name FROM sqlite_master WHERE type IN ('table','view')")}
    for tbl in ['notebooks','notes','pages','cells','note_sources','attachments','image_objects','note_fts','meta']:
        assert tbl in tables,tbl
    assert db.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()==('1',)
    now='2026-10-09T21:00:00Z'
    db.execute("INSERT INTO notebooks VALUES (?,?,?,?,?)",('general','General',0,now,now))
    db.execute("INSERT INTO notes(id,notebook_id,title,active_page_id,created_utc,updated_utc) VALUES (?,?,?,?,?,?)",('n1','general','A note','p1',now,now))
    db.execute("INSERT INTO pages (id,note_id,ordinal,guide,spacing) VALUES ('p1','n1',0,'ruled',32)")
    db.execute("INSERT INTO cells VALUES ('p1',0,'text','[]')")
    db.execute("INSERT INTO note_fts(note_id,title,body) VALUES ('n1','A note','text')")
    assert db.execute("SELECT note_id FROM note_fts WHERE note_fts MATCH ?",('"text"',)).fetchone()==('n1',)
    assert db.execute("UPDATE pages SET revision=revision+1 WHERE id='p1' AND revision=0").rowcount==1
    assert db.execute("UPDATE pages SET revision=revision+1 WHERE id='p1' AND revision=0").rowcount==0
    try:
        db.execute("INSERT INTO image_objects VALUES ('i1','p1',0,'"+'0'*64+"',0,0,.5,.5,0)")
        raise AssertionError('FK was not enforced')
    except sqlite3.IntegrityError: pass
    try:
        db.execute("INSERT INTO note_sources VALUES ('src','n1','some-source','v1',NULL,1)")
        raise AssertionError('False verified reference was accepted')
    except sqlite3.IntegrityError: pass
    db.commit()
    assert db.execute('PRAGMA integrity_check').fetchone()==('ok',)
    assert db.execute('PRAGMA foreign_key_check').fetchall()==[]
manifest=sorted(str(p.relative_to(root)) for p in (root/'src/NivareQ.Step2Pathfinder/MedicalPayload').rglob('*') if p.is_file())
assert len(manifest)==132,len(manifest)
assert 'PackageReference Include="Microsoft.Data.Sqlite" Version="10.0.12"' in (root/'src/NivareQ.Step2Pathfinder/NivareQ.Step2Pathfinder.csproj').read_text()
print(json.dumps({'result':'PASS','kind':'Python SQLite DDL/static contract smoke (NOT .NET compile)',
 'medical_payload_files':len(manifest),'schema_tables':sorted(tables),'test_cases':8},indent=2))
