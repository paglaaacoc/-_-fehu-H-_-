from pathlib import Path
import json, subprocess, sys, xml.etree.ElementTree as ET, re
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'src'/'NivareQ.Step2Pathfinder'
FULL=ROOT.parents[0]
checks=[]; errors=[]
def check(n,c,d=''):
    checks.append((n,bool(c),d))
    if not c: errors.append(f'{n}: {d}')
def read(r): return (SRC/r).read_text(encoding='utf-8')
# Preserve the already-proven resource/payload foundation.
p=subprocess.run([sys.executable,str(ROOT/'tools'/'w2a-static-qc.py')],capture_output=True,text=True)
try: base=json.loads(p.stdout)
except Exception: base={'passed':0,'failed':1,'errors':[p.stdout[-500:]+p.stderr[-500:]]}
check('w2a-foundation',p.returncode==0 and base.get('failed')==0,str(base.get('errors',[]))[:1000])
main=read('MainWindow.xaml.cs'); xaml=read('MainWindow.xaml'); host=read('MainWindow.CockpitHost.cs'); loc=read('MainWindow.Location.cs')
pers=read('MainWindow.PersonalStudy.cs'); settings=read('MainWindow.Settings.cs')
backup=read('Services/BackupContractService.cs'); bm=read('Models/BackupModels.cs'); cs=read('Services/CockpitStateService.cs'); cr=read('Services/CockpitStateRegistry.cs')
build=(ROOT/'tools'/'build-windows.ps1').read_text(encoding='utf-8')
# Build identity/tooling.
check('build-id','W3 R1 CANDIDATE' in xaml and 'W3 R1 Candidate' in xaml,'')
check('short-stage','NQPF-W3-Build' in build,'')
check('backup-schema4','BackupSchemaVersion { get; set; } = 4' in bm and 'CanonicalSchemaVersion = 4' in backup,'')
check('backup-producer','W3-R1' in bm and 'W3-R1' in backup,'')
# W2D retained shell/settings/reset.
check('settings-surface',all(m in settings for m in ['General','Appearance','Accessibility & display','Data, backup & reset','Session & navigation','Workspace & Split View','About & integrity']),'')
check('time-topbar-still-gone','x:Name="TimeButton"' not in xaml and 'Study planning & time estimates' in pers,'')
check('reset-backup-mandatory','CreateCanonicalBackupFileAsync(' in settings and 'verifyAfterWrite: true' in settings and 'Backup verified · reset now?' in settings,'')
check('sidebar-preflight-focus-fix','AllowFocusOnInteraction = false' in main,'')
# State registry exact PWA parity.
reg=json.loads((SRC/'ShellData'/'cockpit-state-allowlist.json').read_text())
check('cockpit-registry-schema',reg.get('schemaVersion')==1,'')
check('cockpit-registry-24',len(reg.get('resources',{}))==24,str(len(reg.get('resources',{}))))
check('cockpit-registry-2607',sum(len(v) for v in reg.get('resources',{}).values())==2607,'')
app=(ROOT.parent/'03-PWA-B4A-WORKING-SNAPSHOT'/'deploy'/'app.js')
if app.exists():
    text=app.read_text(encoding='utf-8'); needle='const COCKPIT_ALLOWED_KEYS_BY_SLUG=new Map(Object.entries('
    try:
        i=text.index(needle)+len(needle); j=text.index(').map(([slug,keys])=>[slug,new Set(keys)]));',i); pwa=json.loads(text[i:j]); pwa.pop('extra-uworld-selector',None)
        check('registry-exact-pwa-source',pwa==reg['resources'],'')
    except Exception as e: check('registry-exact-pwa-source',False,str(e))
else: check('registry-exact-pwa-source',False,'PWA source missing')
# Canonical state provider / bounded persistence.
check('cockpit-state-path','CockpitStatePath' in read('Services/PathfinderPaths.cs'),'')
check('cockpit-state-bounds','MaxStoreBytes = 16L * 1024L * 1024L' in cs and 'MaxResourceStateCharacters = 2_000_000L' in cs,'')
check('cockpit-state-atomic','AtomicFileStore.WriteText(PathfinderPaths.CockpitStatePath' in cs,'')
check('cockpit-state-transactional-change','var nextValues = new Dictionary<string, string>(state.Values' in cs and 'state.Values = validated' in cs,'')
check('exact-allowlist-bridge','allowed=new Set(__ALLOWED_KEYS__)' in host and '_registry.IsAllowed(resourceId, key)' in cs,'')
check('legacy-profile-adoption','NeedsLegacyStateAdoption' in main and 'CaptureCockpitStateSnapshotAsync' in host and 'migratedFromProfile: true' in host,'')
check('backup-cockpit-state','CockpitState = validatedCockpitState' in backup and 'CockpitStatePath' in pers,'')
check('reset-cockpit-state','CockpitStatePath' in settings and 'nextCockpitState' in settings,'')
check('pwa-state-promotion','TryParsePwaCockpitState' in backup and 'Unsupported PWA-only state remains preserved opaquely' in backup,'')
# View roles / authority.
check('view-role-model','ReadOnlySecondary' in read('Models/CockpitHostModels.cs') and 'Primary' in read('Models/CockpitHostModels.cs'),'')
check('one-primary','FindPrimaryStudyContext' in main and 'viewRole == CockpitViewRole.Primary' in main,'')
check('explicit-secondary','explicitSecondary' in main and 'CockpitViewRole.ReadOnlySecondary' in main,'')
check('secondary-isolated-origin','context.ViewId.ToString("N")[..10]' in main and 'InternalHostSuffix' in main,'')
check('secondary-not-session','read-only secondary views are intentionally ephemeral until W4' in main,'')
check('secondary-no-location-write','context.ViewRole != CockpitViewRole.Primary' in loc and 'context.ViewRole == CockpitViewRole.Primary' in loc,'')
check('secondary-readonly-guard',"data-pathfinder-view-role','read-only-secondary" in host and "const mutating='button,input,textarea,select" in host,'')
check('secondary-banner','Read-only reference view' in main and 'does not own or write canonical study state' in main and 'Read-only reference view' in read('MainWindow.SourcePreview.cs'),'')
# Runtime repair evidence.
check('study-map-37',host.count('"Foundation"')>=1 and 'Rheumatology/MSK/Dermatology' not in host and 'focusSection(labels[i])' in host,'')
labels_total=22+7+8
check('study-map-count-37',labels_total==37,'')
check('supplemental-quiz-shim',all(x in host for x in ['ai-quiz-q','ento-quiz-q','poisonenv-quiz-q','generalmulti-quiz-q']),'')
quiz_counts=sum(1 for r,v in reg['resources'].items() for k in v if re.search(r'-quiz-q\d{3}$',k))
check('supplemental-quiz-count-166',quiz_counts==166,str(quiz_counts))
check('biostat-migration',all(x in host for x in ["bioQuizV2","bioQuiz","explicitReset","localStorage.removeItem('bioQuiz')"]),'')
check('19-22-theme-adapter',all(x in host for x in ['allergy-immunology','ent-ophthalmology','poisoning-environmental','general-principles-misc','nivareq-w3-compat-theme']),'')
# Lifecycle/recovery.
models=read('Models/CockpitHostModels.cs')
check('lifecycle-model',all(x in models for x in ['Initializing','Navigating','Ready','Recovering','Failed','Closed']),'')
check('runtime-recovery','Reload cockpit safely' in host and 'RecoveryAttempts >= 3' in host and 'RecoverCockpitHostAsync' in host,'')
# Future Journal source-action foundation only.
check('source-action-foundation','SourceActionDraft' in models and 'CaptureSourceActionDraftAsync' in host and 'SelectedText' in host,'')
check('journal-not-implemented', 'CreateJournal' not in host, '')
# Frozen payload / registry.
check('medical-132',base.get('medical_files')==132,str(base.get('medical_files')))
check('resources-25',base.get('resources')==25,str(base.get('resources')))
# XML parsing.
for rel in ['MainWindow.xaml','NivareQ.Step2Pathfinder.csproj','App.xaml']:
    try: ET.parse(SRC/rel); ok=True; detail=''
    except Exception as e: ok=False; detail=str(e)
    check('xml:'+rel,ok,detail)
# Lexical balance.
def strip_cs(s):
    out=[]; i=0; n=len(s); state='code'
    while i<n:
        if state=='code':
            if s.startswith('//',i): state='line'; out.extend('  '); i+=2; continue
            if s.startswith('/*',i): state='block'; out.extend('  '); i+=2; continue
            m=re.match(r'\$*"""',s[i:])
            if m: state='raw'; out.extend(' '*len(m.group(0))); i+=len(m.group(0)); continue
            if s.startswith('@"',i): state='verbatim'; out.extend('  '); i+=2; continue
            if s[i]=='"': state='string'; out.append(' '); i+=1; continue
            if s[i]=="'": state='char'; out.append(' '); i+=1; continue
            out.append(s[i]); i+=1
        elif state=='line':
            if s[i]=='\n': state='code'; out.append('\n')
            else: out.append(' ')
            i+=1
        elif state=='block':
            if s.startswith('*/',i): state='code'; out.extend('  '); i+=2
            else: out.append('\n' if s[i]=='\n' else ' '); i+=1
        elif state=='string':
            if s[i]=='\\' and i+1<n: out.extend('  '); i+=2
            elif s[i]=='"': state='code'; out.append(' '); i+=1
            else: out.append('\n' if s[i]=='\n' else ' '); i+=1
        elif state=='verbatim':
            if s.startswith('""',i): out.extend('  '); i+=2
            elif s[i]=='"': state='code'; out.append(' '); i+=1
            else: out.append('\n' if s[i]=='\n' else ' '); i+=1
        elif state=='raw':
            if s.startswith('"""',i): state='code'; out.extend('   '); i+=3
            else: out.append('\n' if s[i]=='\n' else ' '); i+=1
        elif state=='char':
            if s[i]=='\\' and i+1<n: out.extend('  '); i+=2
            elif s[i]=="'": state='code'; out.append(' '); i+=1
            else: out.append(' '); i+=1
    return ''.join(out),state
lex=[]
files=list(SRC.rglob('*.cs'))
for path in files:
    t,state=strip_cs(path.read_text(encoding='utf-8'))
    if state!='code': lex.append(f'{path.name}: ended {state}')
    for a,b in [('(',')'),('[',']'),('{','}')]:
        dep=0
        for ch in t:
            if ch==a: dep+=1
            elif ch==b:
                dep-=1
                if dep<0: break
        if dep!=0: lex.append(f'{path.name}: {a}{b}={dep}')
check('all-csharp-lexical-balance',not lex,'; '.join(lex[:20]))
passed=sum(1 for _,ok,_ in checks if ok)
result={'w2a_base_passed':base.get('passed',0),'w3_checks_passed':passed,'combined_passed':base.get('passed',0)+passed,'failed':len(errors),'medical_files':base.get('medical_files',132),'resources':base.get('resources',25),'cockpit_state_resources':len(reg.get('resources',{})),'cockpit_state_keys':sum(len(v) for v in reg.get('resources',{}).values()),'csharp_files':len(files),'errors':errors}
(ROOT/'docs'/'W3-R1-STATIC-QC-RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2)); sys.exit(1 if errors else 0)
