# ONE-TIME OWNER-DEVICE CI TRANSFER. Not executed in the ChatGPT environment.
# Requires authenticated git access to the pre-authorized temporary GitHub repo.
# Uploads app source, harness, CI workflow and source-identity guard; no release.
param([switch]$DryRun)
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$Repo = 'https://github.com/paglaaacoc/-_-fehu-H-_-.git'
$Branch = 'dev/pathfinder-scratchpad-s2-r1-20261009'
$LeaseSha = '6face5b0df1c4467f118a8e23395a382f7fb9df2'
$Manifest = Join-Path $Root 'INTEGRITY-S2B-R4-MANIFEST.json'
if (-not (Test-Path -LiteralPath $Manifest)) { throw 'R4 source integrity manifest is missing.' }
$state = Get-Content -LiteralPath $Manifest -Raw | ConvertFrom-Json
if ($state.checkpoint -ne 'S2-B R4 internal wire/recovery hardening') { throw 'Wrong source checkpoint.' }
foreach ($entry in $state.sha256_all_payload_files_excluding_this_manifest.PSObject.Properties) {
  $name = [string]$entry.Name
  if ($name.Contains('..') -or [IO.Path]::IsPathRooted($name)) { throw "Unsafe manifest path: $name" }
  $path = Join-Path $Root ($name -replace '/', [IO.Path]::DirectorySeparatorChar)
  if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "Missing checkpoint file: $name" }
  $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $path).Hash.ToLowerInvariant()
  if ($actual -ne [string]$entry.Value) { throw "Checkpoint changed: $name" }
}
Write-Host "R4 manifest verified: $($state.sha256_all_payload_files_excluding_this_manifest.Count) entries"
& (Join-Path $Root 'tools/verify-medical-payload.ps1')
if ($LASTEXITCODE -and $LASTEXITCODE -ne 0) { throw 'Medical hash verification failed.' }
$remoteHead = (& git ls-remote $Repo "refs/heads/$Branch" | Select-Object -First 1)
if ($LASTEXITCODE -ne 0 -or -not $remoteHead) { throw 'Cannot verify isolated dev branch; no changes made.' }
$remoteSha = ($remoteHead -split '\s+')[0]
if ($remoteSha -ne $LeaseSha) { throw "Branch moved ($remoteSha). Reconcile before any push; no changes made." }
if ($DryRun) { Write-Host "DRY RUN PASS. Branch $Branch is at $remoteSha. No clone, commit or push."; return }
$working = Join-Path ([IO.Path]::GetTempPath()) ('pathfinder-s2b-r4-' + [guid]::NewGuid().ToString('N'))
try {
  & git clone --single-branch --branch $Branch $Repo $working
  if ($LASTEXITCODE -ne 0) { throw 'Git clone failed.' }
  $head = (& git -C $working rev-parse HEAD).Trim()
  if ($head -ne $LeaseSha) { throw 'Local clone failed branch lease guard.' }
  foreach ($folder in @('src','tests','tools')) {
    $target = Join-Path $working $folder
    if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Recurse -Force }
    Copy-Item -LiteralPath (Join-Path $Root $folder) -Destination $target -Recurse -Force
  }
  $destIntegrity = Join-Path $working 'Integrity'
  New-Item -ItemType Directory -Path $destIntegrity -Force | Out-Null
  Copy-Item -LiteralPath (Join-Path $Root 'Integrity/MEDICAL_PAYLOAD_SHA256_MANIFEST.txt') -Destination $destIntegrity -Force
  $workflowDir = Join-Path $working '.github/workflows'
  New-Item -ItemType Directory -Path $workflowDir -Force | Out-Null
  Copy-Item -LiteralPath (Join-Path $Root '.github/workflows/pathfinder-s2b-native.yml') -Destination $workflowDir -Force
  Copy-Item -LiteralPath $Manifest -Destination $working -Force
  & git -C $working add -- src tests tools Integrity/MEDICAL_PAYLOAD_SHA256_MANIFEST.txt .github/workflows/pathfinder-s2b-native.yml INTEGRITY-S2B-R4-MANIFEST.json
  if ($LASTEXITCODE -ne 0) { throw 'Git stage failed.' }
  & git -C $working -c user.name='NivareQ S2B CI Bootstrap' -c user.email='noreply@nivareq.com' commit -m 'S2B R4 internal source: native harness, recovery wire and CI gates'
  if ($LASTEXITCODE -ne 0) { throw 'Git commit failed; no remote push.' }
  & git -C $working push origin "HEAD:refs/heads/$Branch"
  if ($LASTEXITCODE -ne 0) { throw 'Git push rejected; reconcile without forcing.' }
  Write-Host 'Isolated development branch source transfer complete. Review Actions (harness, x64, ARM64).'
} finally {
  if (Test-Path -LiteralPath $working) { Remove-Item -LiteralPath $working -Recurse -Force }
}
