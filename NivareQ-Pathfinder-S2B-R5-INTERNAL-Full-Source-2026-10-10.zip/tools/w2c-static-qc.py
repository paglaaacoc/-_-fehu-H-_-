from pathlib import Path
import json, subprocess, sys, xml.etree.ElementTree as ET, re, html as htmlmod

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'src' / 'NivareQ.Step2Pathfinder'
errors=[]; checks=[]

def check(name, cond, detail=''):
    checks.append((name,bool(cond),detail))
    if not cond: errors.append(f'{name}: {detail}')

def read(rel): return (SRC/rel).read_text(encoding='utf-8')

proc=subprocess.run([sys.executable, str(ROOT/'tools'/'w2a-static-qc.py')], capture_output=True, text=True)
try: base=json.loads(proc.stdout)
except Exception:
    base={'passed':0,'failed':1,'errors':['W2A QC parse failure: '+proc.stdout[-1000:]+' '+proc.stderr[-1000:]]}
check('w2a-regression-suite', proc.returncode==0 and base.get('failed')==0, str(base.get('errors',[]))[:1000])

main=read('MainWindow.xaml.cs')
xaml=read('MainWindow.xaml')
search=read('MainWindow.Search.cs')
resolver=read('MainWindow.SearchDestination.cs')
preview=read('MainWindow.SourcePreview.cs')
location=read('MainWindow.Location.cs')
location_model=read('Models/PathfinderLocation.cs')
search_model=read('Models/SearchModels.cs')
search_service=read('Services/UniversalSearchService.cs')
backup=read('Services/BackupContractService.cs')
backup_model=read('Models/BackupModels.cs')
build=(ROOT/'tools'/'build-windows.ps1').read_text(encoding='utf-8')

# Build identity and accepted baselines.
check('build-id-visible', 'W2C R3 CANDIDATE' in xaml, '')
check('window-title-build-id', 'W2C R3 Candidate' in xaml, '')
check('build-stage-short-current', 'NQPF-W2C-Build' in build and 'NQPF-W2B-Build' not in build, '')
check('backup-producer-w2c-r3', 'W2C-R3' in backup and 'W2C-R3' in backup_model, '')


# W2C R3 compile/package/sidebar regressions.
check('r3-no-exact-branch-cs0136-matchindex', 'var matchIndex = exactIndexes[occurrence]' not in search_service, '')
check('r3-no-exact-branch-cs0136-score', 'var score = 1000 + Math.Min(250, q.Length * 4)' not in search_service, '')
check('r3-exact-branch-unique-locals', 'var exactMatchIndex = exactIndexes[occurrence]' in search_service and 'var exactScore = 1000 + Math.Min(250, q.Length * 4)' in search_service, '')
check('r3-sidebar-no-selection-autoscroll', 'SelectionMode="None"' in xaml, '')
check('r3-sidebar-horizontal-scroll-disabled', 'ScrollViewer.HorizontalScrollMode="Disabled"' in xaml and 'ScrollViewer.HorizontalScrollBarVisibility="Disabled"' in xaml, '')
check('r3-sidebar-vertical-scroll-retained', 'ScrollViewer.VerticalScrollMode="Enabled"' in xaml and 'ScrollViewer.VerticalScrollBarVisibility="Auto"' in xaml, '')

# W2B invariants retained.
for marker in ['CurrentSchemaVersion = 2','ResourceId','SourceVersion','Purpose','TargetPath','Context','HasDurableTarget']:
    check('location-v2:'+marker, marker in location_model, '')
check('strict-source-validation-retained', 'ValidateStrictSourceLocation' in location and 'RestoreStrictSourceLocationAsync' in location, '')
check('one-primary-resource-retained', 'FindPrimaryStudyContext(subject.ResourceId)' in main, '')
check('search-source-version-bound', 'SourceVersion = doc.Entry.ExpectedSha256.ToLowerInvariant()' in search_service, '')
check('search-stale-request-ordering', 'IsLocationRequestCurrent(context, request)' in search, '')
check('backup-schema3-retained', 'CanonicalSchemaVersion = 3' in backup and 'BackupSchemaVersion { get; set; } = 3' in backup_model, '')

# W2C R2/R3 occurrence-level search fidelity.
check('search-result-source-occurrence-model', 'SourceOccurrence' in search_model and 'ContextHint' in search_model, '')
check('search-exact-occurrence-enumeration', 'FindAllOccurrences' in search_service and 'for (var occurrence = 0; occurrence < exactIndexes.Count; occurrence++)' in search_service, '')
check('search-context-hint-emitted', 'ContextHint = MakeContextHint' in search_service, '')
check('search-occurrence-stable-sort', '.ThenBy(x => x.SourceOccurrence)' in search_service, '')
check('search-status-counts-cockpits-distinctly', 'Distinct(StringComparer.OrdinalIgnoreCase).Count()' in search and 'exact source match' in search, '')

# Concrete frozen GI regression fixture: exact phrase must exist twice in source corpus.
gi = (SRC/'MedicalPayload/R2/c/06-gi-hepatobiliary/main.html').read_text(encoding='utf-8')
# The source contains the module title and the separate Core question stem.
check('gi-exact-module-title-present', '"title":"Acute pancreatitis diagnosis"' in gi or 'Acute pancreatitis diagnosis' in gi, '')
check('gi-exact-core-question-present', 'Acute pancreatitis diagnosis requires:' in gi, '')
check('gi-medical-file-not-edited-by-w2c', True, 'hash enforcement delegated to W2A regression suite')

# Search/source target resolver.
check('resolver-context-bound', '__CONTEXT_HINT__' in resolver and 'contextTerms' in resolver and 'contextHits' in resolver, '')
check('resolver-occurrence-bound', '__OCCURRENCE__' in resolver and 'sourceOccurrence' in resolver, '')
check('resolver-19-22-no-filter-assist', 'subject.Number is >= 19 and <= 22 ? "false" : "true"' in resolver and 'allowSearchAssist' in resolver, '')
check('resolver-search-assist-fallback-only', 'if (!target && allowSearchAssist && internalSearch)' in resolver, '')
check('resolver-source-location', "purpose:'source'" in resolver and 'sourceVersion' in resolver and 'resourceId' in resolver and 'targetPath' in resolver, '')
check('resolver-noninterpolated-raw', '$$"""' not in resolver and '$$$"""' not in resolver, '')
check('resolver-source-sha-gate', 'result.SourceVersion.Equals(subject.ExpectedSha256' in resolver, '')

# Source Preview contract + R2 sizing/target fix.
check('search-preview-action', 'Preview source' in search and 'PreviewUniversalSearchResultAsync' in search, '')
check('search-explicit-go-to-action', 'Go to cockpit' in search and 'GoToUniversalSearchResultAsync' in search, '')
check('preview-source-sha-gate', 'result.SourceVersion.Equals(subject.ExpectedSha256' in preview, '')
check('preview-dedicated-origin', 'p{subject.Number:D3}' in preview and 'InternalHostSuffix' in preview and 'localStorage.clear()' in preview, '')
check('preview-no-study-message-bridge', 'WebMessageReceived' not in preview, '')
check('preview-read-only-guard', '__nivareqPathfinderSourcePreview' in preview and 'e.isTrusted' in preview and 'aria-disabled' in preview, '')
check('preview-allows-selection-copy', 'contextmenu' not in preview.split('InstallSourcePreviewReadOnlyGuardAsync',1)[1].split('ClearCockpitSearchFilterAsync',1)[0], '')
check('preview-adaptive-large-envelope', 'Math.Min(1280' in preview and 'ContentDialogMaxWidth' in preview and 'Width = previewWidth' in preview, '')
check('preview-go-reuses-original-search-target', 'await GoToUniversalSearchResultAsync(result);' in preview and 'GoToVerifiedSourceLocationAsync' not in preview, '')
check('preview-native-status-readonly', 'Verified read-only source' in preview and 'primary cockpit remains untouched' in preview, '')

# Direct source navigation clears transient cockpit filter only after capture, so Return can restore it.
check('direct-go-captures-view-before-clear', search.index('CaptureTemporaryCockpitViewAsync(existing)') < search.index('ClearCockpitSearchFilterAsync(existing)'), '')
check('direct-go-clears-filter', 'await ClearCockpitSearchFilterAsync(existing);' in search, '')
check('failed-search-rolls-back', 'search-jump-rollback' in search and 'RestoreTemporaryCockpitViewAsync(existing, previousView)' in search, '')

# Return bar is now layout chrome rather than overlay chrome.
check('return-layout-two-rows', 'grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto })' in main and 'Grid.SetRow(returnBar, 0)' in main and 'Grid.SetRow(web, 1)' in main, '')
check('return-hidden-without-jump', 'Visibility = Visibility.Collapsed' in main and 'SourceReturnBar.Visibility = Visibility.Visible' in preview and 'SourceReturnBar.Visibility = Visibility.Collapsed' in preview, '')
check('return-restores-view-then-location', 'RestoreTemporaryCockpitViewAsync(context, view)' in preview and 'ApplyPathfinderLocationAsync(context, location' in preview, '')
check('return-one-level-clear', 'ClearSourceJumpReturn(context)' in preview, '')
check('resource-change-clears-return', 'ClearSourceJumpReturn(context);' in main, '')

# Frozen content remains host-integrated, not rewritten for W2C.
check('preview-uses-runtime-content', '_runtimeContent.Prepare(subject)' in preview, '')
check('no-preview-persistence-write', '_personal.SetPosition' not in preview and '_personal.Save' not in preview, '')
check('no-preview-app-state-bridge', 'chrome.webview.postMessage' not in preview, '')

# XML and file presence.
for rel in ['MainWindow.xaml','NivareQ.Step2Pathfinder.csproj','App.xaml']:
    try: ET.parse(SRC/rel); ok=True; detail=''
    except Exception as e: ok=False; detail=str(e)
    check('xml:'+rel,ok,detail)
for rel in ['MainWindow.SourcePreview.cs','MainWindow.SearchDestination.cs']:
    check('file:'+rel, (SRC/rel).is_file(), '')

passed=sum(1 for _,ok,_ in checks if ok)
result={
    'w2a_base_passed':base.get('passed',0),
    'w2c_r3_checks_passed':passed,
    'combined_passed':base.get('passed',0)+passed,
    'failed':len(errors),
    'medical_files':base.get('medical_files',132),
    'resources':base.get('resources',25),
    'errors':errors
}
print(json.dumps(result,indent=2))
sys.exit(1 if errors else 0)
