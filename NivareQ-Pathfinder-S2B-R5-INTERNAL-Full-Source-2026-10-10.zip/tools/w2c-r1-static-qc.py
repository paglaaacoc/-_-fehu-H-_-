from pathlib import Path
import json, subprocess, sys, xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'src' / 'NivareQ.Step2Pathfinder'
errors=[]; checks=[]

def check(name, cond, detail=''):
    checks.append((name,bool(cond),detail))
    if not cond: errors.append(f'{name}: {detail}')

def read(rel): return (SRC/rel).read_text(encoding='utf-8')

proc=subprocess.run([sys.executable, str(ROOT/'tools'/'w2a-static-qc.py')], capture_output=True, text=True)
try: base=json.loads(proc.stdout)
except Exception:
    base={'passed':0,'failed':1,'errors':['W2A QC parse failure: '+proc.stdout[-1000:]+' '+proc.stderr[-1000:]]}
check('w2a-regression-suite', proc.returncode==0 and base.get('failed')==0, str(base.get('errors',[]))[:1000])

main=read('MainWindow.xaml.cs')
xaml=read('MainWindow.xaml')
search=read('MainWindow.Search.cs')
resolver=read('MainWindow.SearchDestination.cs')
preview=read('MainWindow.SourcePreview.cs')
location=read('MainWindow.Location.cs')
location_model=read('Models/PathfinderLocation.cs')
search_model=read('Models/SearchModels.cs')
search_service=read('Services/UniversalSearchService.cs')
backup=read('Services/BackupContractService.cs')
backup_model=read('Models/BackupModels.cs')
build=(ROOT/'tools'/'build-windows.ps1').read_text(encoding='utf-8')

# Build identity and fast-test staging.
check('build-id-visible', 'W2C R1 CANDIDATE' in xaml, '')
check('window-title-build-id', 'W2C R1 Candidate' in xaml, '')
check('build-stage-short-current', 'NQPF-W2C-Build' in build and 'NQPF-W2B-Build' not in build, '')
check('backup-producer-w2c', 'W2C-R1' in backup and 'W2C-R1' in backup_model, '')

# W2B invariants retained.
for marker in ['CurrentSchemaVersion = 2','ResourceId','SourceVersion','Purpose','TargetPath','Context','HasDurableTarget']:
    check('location-v2:'+marker, marker in location_model, '')
check('strict-source-validation-retained', 'ValidateStrictSourceLocation' in location and 'RestoreStrictSourceLocationAsync' in location, '')
check('one-primary-resource-retained', 'FindPrimaryStudyContext(subject.ResourceId)' in main, '')
check('search-source-version-bound', 'SourceVersion = doc.Entry.ExpectedSha256.ToLowerInvariant()' in search_service, '')
check('search-stale-request-ordering', 'IsLocationRequestCurrent(context, request)' in search, '')
check('backup-schema3-retained', 'CanonicalSchemaVersion = 3' in backup and 'BackupSchemaVersion { get; set; } = 3' in backup_model, '')

# W2C search/source-preview contract.
check('search-preview-action', 'Preview source' in search and 'PreviewUniversalSearchResultAsync' in search, '')
check('search-explicit-go-to-action', 'Go to cockpit' in search and 'GoToUniversalSearchResultAsync' in search, '')
check('shared-search-resolver', 'ResolveSearchDestinationAsync' in resolver and 'ResolveSearchDestinationAsync' in search and 'ResolveSearchDestinationAsync' in preview, '')
check('resolver-source-location', "purpose:'source'" in resolver and 'sourceVersion' in resolver and 'resourceId' in resolver and 'targetPath' in resolver, '')
check('resolver-noninterpolated-raw', '$$"""' not in resolver and '$$$"""' not in resolver, '')
check('resolver-source-sha-gate', 'result.SourceVersion.Equals(subject.ExpectedSha256' in resolver, '')
check('preview-source-sha-gate', 'result.SourceVersion.Equals(subject.ExpectedSha256' in preview, '')
check('preview-dedicated-origin', 'p{subject.Number:D3}' in preview and 'InternalHostSuffix' in preview and 'localStorage.clear()' in preview, '')
check('preview-no-study-message-bridge', 'WebMessageReceived' not in preview, '')
check('preview-read-only-guard', '__nivareqPathfinderSourcePreview' in preview and "e.isTrusted" in preview and 'aria-disabled' in preview, '')
check('preview-allows-selection-copy', 'contextmenu' not in preview.split('InstallSourcePreviewReadOnlyGuardAsync',1)[1].split('GoToVerifiedSourceLocationAsync',1)[0], 'Do not suppress the native WebView2 context menu; selection/copy must remain available.')
check('preview-primary-untouched-by-default', 'GoToVerifiedSourceLocationAsync' in preview and 'ContentDialogResult.Primary' in preview, '')
check('preview-explicit-primary-button', 'PrimaryButtonText = "Go to cockpit"' in preview and 'CloseButtonText = "Close"' in preview, '')
check('preview-native-status-readonly', 'Verified read-only source' in preview and 'primary cockpit remains untouched' in preview, '')

# Go-to-cockpit and one-level return behavior.
check('direct-go-to-captures-return', 'CapturePositionAsync(existing)' in search and 'CaptureTemporaryCockpitViewAsync(existing)' in search and 'ArmSourceJumpReturn' in search, '')
check('verified-go-to-captures-return', 'CapturePositionAsync(existing)' in preview and 'CaptureTemporaryCockpitViewAsync(existing)' in preview and 'ArmSourceJumpReturn' in preview, '')
check('return-infobar-created', 'Return to previous position' in main and 'InfoBarSeverity.Informational' in main, '')
check('return-location-state', 'SourceJumpReturnLocation' in main and 'SourceJumpReturnView' in main, '')
check('return-restores-view-then-location', 'RestoreTemporaryCockpitViewAsync(context, view)' in preview and 'ApplyPathfinderLocationAsync(context, location' in preview, '')
check('return-one-level-clear', 'ClearSourceJumpReturn(context)' in preview, '')
check('resource-change-clears-return', 'ClearSourceJumpReturn(context);' in main, '')
check('failed-search-rolls-back', 'search-jump-rollback' in search and 'RestoreTemporaryCockpitViewAsync(existing, previousView)' in search, '')
check('failed-strict-jump-rolls-back', 'source-jump-rollback' in preview and 'Your previous study position was restored' in preview, '')
check('strict-preview-go-to', 'RestoreStrictSourceLocationAsync(existing, sourceLocation)' in preview, '')
check('new-cockpit-strict-location', 'CreateStudyTabAsync(subject, false, CloneLocationV2(sourceLocation))' in preview, '')

# Frozen content remains host-integrated, not edited for W2C.
check('preview-uses-runtime-content', '_runtimeContent.Prepare(subject)' in preview, '')
check('no-preview-persistence-write', '_personal.SetPosition' not in preview and '_personal.Save' not in preview, '')
check('no-preview-app-state-bridge', 'chrome.webview.postMessage' not in preview, '')

# XML and basic file presence.
for rel in ['MainWindow.xaml','NivareQ.Step2Pathfinder.csproj','App.xaml']:
    try: ET.parse(SRC/rel); ok=True; detail=''
    except Exception as e: ok=False; detail=str(e)
    check('xml:'+rel,ok,detail)
for rel in ['MainWindow.SourcePreview.cs','MainWindow.SearchDestination.cs']:
    check('file:'+rel, (SRC/rel).is_file(), '')

passed=sum(1 for _,ok,_ in checks if ok)
result={
    'w2a_base_passed':base.get('passed',0),
    'w2c_checks_passed':passed,
    'combined_passed':base.get('passed',0)+passed,
    'failed':len(errors),
    'medical_files':base.get('medical_files',132),
    'resources':base.get('resources',25),
    'errors':errors
}
print(json.dumps(result,indent=2))
sys.exit(1 if errors else 0)
