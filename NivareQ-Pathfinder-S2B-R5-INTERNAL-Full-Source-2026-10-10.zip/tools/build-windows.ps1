param([ValidateSet('All','x64','arm64')][string]$Arch='All')
$ErrorActionPreference='Stop'
$Root = Split-Path -Parent $PSScriptRoot
$ProjectSource = Join-Path $Root 'src\NivareQ.Step2Pathfinder'
$Logs = Join-Path $Root 'Build Logs'
New-Item -ItemType Directory -Force -Path $Logs | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$log = Join-Path $Logs ("build-$stamp.log")

# WinUI/XAML markup compilation still encounters classic path-length-sensitive internals.
# Always compile from a deliberately short temporary path so the FULL continuity ZIP can
# be extracted into a descriptive folder without producing >260-character generated paths.
$StageRoot = Join-Path ([IO.Path]::GetTempPath()) 'NQPF-W8-Closure-Build'
$StageProjectDir = Join-Path $StageRoot 'src\NivareQ.Step2Pathfinder'
$StageProject = Join-Path $StageProjectDir 'NivareQ.Step2Pathfinder.csproj'
$StageOutRoot = Join-Path $StageRoot 'out'
$BuildSucceeded = $false

Start-Transcript -Path $log -Force | Out-Null
try {
  & (Join-Path $PSScriptRoot 'verify-medical-payload.ps1')
  & (Join-Path $PSScriptRoot 'verify-resource-registry.ps1')
  if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw "The .NET 10 SDK is not installed. Install Microsoft.DotNet.SDK.10, reopen this window, then run BUILD-ON-WINDOWS.cmd again. No medical files need to be changed."
  }
  $sdkList = @(& dotnet --list-sdks 2>$null)
  if ($LASTEXITCODE -ne 0 -or -not ($sdkList | Where-Object { $_ -match '^10\.0\.' })) {
    throw "dotnet is present, but no .NET 10 SDK was found. Install Microsoft.DotNet.SDK.10, reopen this window, and rerun BUILD-ON-WINDOWS.cmd. A runtime alone is not enough to build Pathfinder."
  }
  Write-Host (".NET SDK gate PASS: " + (($sdkList | Where-Object { $_ -match '^10\.0\.' } | Select-Object -Last 1))) -ForegroundColor Green

  # Recreate a short-path staging workspace. The source-of-truth remains the candidate tree.
  if (Test-Path -LiteralPath $StageRoot) { Remove-Item -LiteralPath $StageRoot -Recurse -Force }
  New-Item -ItemType Directory -Force -Path $StageProjectDir | Out-Null
  New-Item -ItemType Directory -Force -Path $StageOutRoot | Out-Null

  Write-Host "Preparing short-path WinUI build staging workspace..." -ForegroundColor Cyan
  Write-Host "Stage: $StageRoot" -ForegroundColor DarkGray
  & robocopy $ProjectSource $StageProjectDir /E /XD bin obj /NFL /NDL /NJH /NJS /NP | Out-Null
  $copyExit = $LASTEXITCODE
  if ($copyExit -ge 8) { throw "Could not stage Pathfinder source for short-path compilation (robocopy exit $copyExit)." }
  if (-not (Test-Path -LiteralPath $StageProject)) { throw "Short-path staging failed: project file was not copied." }

  $Out = Join-Path $Root 'Built Apps'
  New-Item -ItemType Directory -Force -Path $Out | Out-Null
  $all = @(
    @{Name='x64'; Platform='x64'; Rid='win-x64'; Folder='NivareQ Step 2 Pathfinder - x64'},
    @{Name='arm64'; Platform='ARM64'; Rid='win-arm64'; Folder='NivareQ Step 2 Pathfinder - ARM64'}
  )
  $targets = if($Arch -eq 'All'){$all}else{$all | Where-Object {$_.Name -eq $Arch}}
  $results=@()

  foreach($a in $targets){
    $dest = Join-Path $Out $a.Folder
    $stageDest = Join-Path $StageOutRoot $a.Name
    if(Test-Path -LiteralPath $dest){Remove-Item -LiteralPath $dest -Recurse -Force}
    if(Test-Path -LiteralPath $stageDest){Remove-Item -LiteralPath $stageDest -Recurse -Force}

    Write-Host "Publishing $($a.Name) from short staging path..." -ForegroundColor Cyan
    & dotnet publish $StageProject -c Release -r $a.Rid --self-contained true `
      -p:Platform=$($a.Platform) `
      -p:WindowsAppSDKSelfContained=true `
      -p:PublishSingleFile=false `
      -p:PublishTrimmed=false `
      -p:PublishReadyToRun=false `
      -o $stageDest
    if($LASTEXITCODE -ne 0){throw "Publish failed for $($a.Name)."}

    # Keep the app folder user-facing: remove build/debug artifacts that are not needed to run.
    Get-ChildItem -LiteralPath $stageDest -Filter '*.pdb' -File -ErrorAction SilentlyContinue | Remove-Item -Force
    Get-ChildItem -LiteralPath $stageDest -Filter '*.xml' -File -ErrorAction SilentlyContinue | Where-Object {$_.Name -like 'NivareQ.Step2Pathfinder*'} | Remove-Item -Force

    & (Join-Path $PSScriptRoot 'verify-published-payload.ps1') -PublishDir $stageDest
    & (Join-Path $PSScriptRoot 'verify-resource-registry.ps1') -PublishDir $stageDest

    New-Item -ItemType Directory -Force -Path $dest | Out-Null
    & robocopy $stageDest $dest /E /NFL /NDL /NJH /NJS /NP | Out-Null
    $publishCopyExit = $LASTEXITCODE
    if ($publishCopyExit -ge 8) { throw "Build succeeded but copying the $($a.Name) app back to Built Apps failed (robocopy exit $publishCopyExit)." }

    & (Join-Path $PSScriptRoot 'verify-published-payload.ps1') -PublishDir $dest
    & (Join-Path $PSScriptRoot 'verify-resource-registry.ps1') -PublishDir $dest
    $results += $dest
  }

  $BuildSucceeded = $true
  Write-Host ''
  Write-Host 'Pathfinder build complete.' -ForegroundColor Green
  foreach($r in $results){
    Write-Host "App folder: $r"
    Write-Host "Launch:     $(Join-Path $r 'NivareQ.Step2Pathfinder.exe')"
  }
  Write-Host ''
  Write-Host "Build log: $log"
  Write-Host 'WinUI compilation used a short temporary staging path to avoid XAML compiler path-length failures.' -ForegroundColor DarkGray
  Write-Host 'No README/checksum/developer files are copied into the built app folders.' -ForegroundColor DarkGray
}
finally {
  if ($BuildSucceeded -and (Test-Path -LiteralPath $StageRoot)) {
    try { Remove-Item -LiteralPath $StageRoot -Recurse -Force } catch { }
  }
  try { Stop-Transcript | Out-Null } catch { }
}
