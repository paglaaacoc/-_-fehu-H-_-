#!/usr/bin/env python3
"""S2-B R5 *static only* cross-language release-fence checks; no Windows proof."""
from pathlib import Path
import re, json
root = Path(__file__).resolve().parents[1]
js = (root / 'src/NivareQ.Step2Pathfinder/NotesProtocol/notes-draft-coordinator.js').read_text()
test = (root / 'tests/NotesProtocolHarness/run.cjs').read_text()
ci = (root / '.github/workflows/pathfinder-s2b-native.yml').read_text()
assert 'this._navigationInProgress = true' in js
assert 'c.releasing = true;' in js
assert 'if (c.releasing) throw new Error' in js
assert 'await this.flush();' in js and 'await this._releaseCurrent(c);' in js
assert js.index('c.releasing = true;') < js.index('await this._releaseCurrent(c);')
assert 'this._current = isClose ? null : next;' in js
assert 'c.releasing = false;' in js
assert 'zIndex >= -10000 && im.zIndex <= 10000' in js
assert "im.id.length <= 100" in js
assert "a.id.localeCompare" not in js
assert 'release barrier rejected' in test
assert 'failed native release retains current page and draft' in test
assert 'python tools/s2b_r5_release_fence.py' in ci
helper = (root / 'tools/PUBLISH-S2B-R5-TO-CI.ps1').read_text()
assert "@('src','tests','tools','ci')" in helper
assert 'git -C $working add -- src tests tools ci Integrity/' in helper
assert 'Microsoft.Data.Sqlite' in (root / 'tests/NotesStoreHarness/NotesStoreHarness.csproj').read_text()
assert 'ReleaseStagingPage' in (root / 'src/NivareQ.Step2Pathfinder/Services/NotesStagingPageRouterV1.cs').read_text()
print(json.dumps({'result':'PASS','scope':'static release/navigation contract only; NOT native CI','checks':17}))
