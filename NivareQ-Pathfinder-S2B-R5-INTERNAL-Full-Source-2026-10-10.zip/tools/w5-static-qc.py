from pathlib import Path
import json, subprocess, sys, xml.etree.ElementTree as ET, re, hashlib, unicodedata

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'src'/'NivareQ.Step2Pathfinder'
FULL=ROOT.parent
BASE=FULL/'06-WINDOWS-W4-CANDIDATE'/'src'/'NivareQ.Step2Pathfinder'
checks=[]; errors=[]
def check(name, cond, detail=''):
    checks.append((name,bool(cond),detail))
    if not cond: errors.append(f'{name}: {detail}')
def read(rel): return (SRC/rel).read_text(encoding='utf-8')

# Proven frozen-content/resource foundation.
p=subprocess.run([sys.executable,str(ROOT/'tools'/'w2a-static-qc.py')],capture_output=True,text=True)
try: base=json.loads(p.stdout)
except Exception: base={'passed':0,'failed':1,'errors':[p.stdout[-700:]+p.stderr[-700:]]}
check('w2a-foundation',p.returncode==0 and base.get('failed')==0,str(base.get('errors',[]))[:1200])

main=read('MainWindow.xaml.cs'); xaml=read('MainWindow.xaml'); split=read('MainWindow.SplitWorkspace.cs')
journal=read('MainWindow.Journal.cs'); js=read('Services/JournalService.cs'); jm=read('Models/JournalModels.cs')
pers=read('MainWindow.PersonalStudy.cs'); pmodel=read('Models/PersonalStudyModels.cs'); psvc=read('Services/PersonalStudyService.cs')
searchn=read('Services/SearchNormalization.cs'); searchsvc=read('Services/UniversalSearchService.cs')
searchui=read('MainWindow.Search.cs'); dest=read('MainWindow.SearchDestination.cs')
backup=read('Services/BackupContractService.cs'); bm=read('Models/BackupModels.cs'); settings=read('MainWindow.Settings.cs')
paths=read('Services/PathfinderPaths.cs'); preview=read('MainWindow.SourcePreview.cs')
host=read('MainWindow.CockpitHost.cs')
build=(ROOT/'tools'/'build-windows.ps1').read_text(encoding='utf-8')

# Identity / package build gate.
check('build-id', 'W5 R4 CANDIDATE' in xaml and 'W5 R4 Candidate' in xaml and 'W5 R4 Candidate' in settings)
check('short-stage-w5', 'NQPF-W5-Build' in build)
check('backup-schema6', 'BackupSchemaVersion { get; set; } = 6' in bm and 'CanonicalSchemaVersion = 6' in backup)
check('backup-producer-w5', 'W5-R4' in bm and 'ProducerBuild = "W5-R4"' in backup)

# W5 R2 compile repair retained in R4: TextBox uses ScrollViewer's attached scrollbar API.
check('journal-editor-scrollbar-attached-api', 'ScrollViewer.SetVerticalScrollBarVisibility(note, ScrollBarVisibility.Auto);' in journal)

# Medical bytes unchanged from accepted W4 R3 source tree.
def tree_hashes(root):
    out={}
    for f in sorted(root.rglob('*')):
        if f.is_file(): out[f.relative_to(root).as_posix()]=hashlib.sha256(f.read_bytes()).hexdigest()
    return out
w5_med=tree_hashes(SRC/'MedicalPayload')
if (BASE/'MedicalPayload').exists():
    w4_med=tree_hashes(BASE/'MedicalPayload')
    medical_ok=w5_med==w4_med
    medical_detail=f'w4={len(w4_med)} w5={len(w5_med)}'
else:
    # Lightweight TEST packages intentionally omit the full W4 source tree. In that
    # layout, prove the same frozen bytes against the carried authoritative manifest.
    manifest={}
    for line in (ROOT/'Integrity'/'MEDICAL_PAYLOAD_SHA256_MANIFEST.txt').read_text(encoding='utf-8').splitlines():
        if not line.strip(): continue
        digest, rel=line.split('  ',1)
        manifest[rel]=digest
    current={k.removeprefix('R2/'):v for k,v in w5_med.items() if k.startswith('R2/')}
    expected={k.removeprefix('R2/'):v for k,v in manifest.items() if k.startswith('R2/')}
    medical_ok=current==expected and len(expected)==132
    medical_detail=f'accepted-manifest={len(expected)} w5-R4={len(current)}'
check('medical-tree-byte-identical-w4r3', medical_ok, medical_detail)

# Search boundary correctness.
check('search-whole-term-api', all(x in searchn for x in ['IsWholeTermMatch','IndexOfWholeTerm','ContainsWholeTerm']))
check('search-exact-occurrences-whole', 'SearchNormalization.IndexOfWholeTerm(haystack, needle, at)' in searchsvc)
check('search-token-whole', 'SearchNormalization.IndexOfWholeTerm(doc.Normalized.Value, t)' in searchsvc)
check('search-title-whole', 'SearchNormalization.ContainsWholeTerm(title, t)' in searchsvc)
check('search-alias-whole', 'SearchNormalization.IndexOfWholeTerm(doc.Normalized.Value, alias.Normalized)' in searchsvc)
check('search-partial-fallback-lower', 'partialTokenMatch' in searchsvc and 'score = 220 +' in searchsvc)
check('search-exact-highlight-boundary', 'ApplyTextHighlights(title, result.HighlightTerms, result.IsExactPhrase)' in searchui and 'FindDisplayRanges(block.Text, terms, wholeTermsOnly)' in searchui)
check('search-destination-whole', 'const hasWhole' in dest and 'exactRequested' in dest and 'hasMatch(text, query, exactRequested)' in dest)

# Behavioral reference for normalized boundary semantics used by the C# implementation.
def norm(s):
    d=unicodedata.normalize('NFD',s or '')
    out=[]; pending=False
    for c in d:
        if unicodedata.category(c)=='Mn': continue
        if c.isalnum():
            if pending and out and out[-1]!=' ': out.append(' ')
            out.append(c.lower()); pending=False
        else: pending=True
    return ''.join(out).strip()
def whole(h,n):
    h=norm(h); n=norm(n)
    at=h.find(n)
    while at>=0:
        left=at==0 or h[at-1].isspace(); r=at+len(n); right=r>=len(h) or h[r].isspace()
        if left and right:return True
        at=h.find(n,at+1)
    return False
check('regression-ards-standalone', whole('ARDS acute respiratory distress syndrome','ARDS'))
check('regression-ards-not-standards', not whole('standards stewardship DMARDs','ARDS'))
check('regression-multiword-exact', whole('acute respiratory distress syndrome (ARDS)','respiratory distress'))
check('regression-hyphen-normalized-boundary', whole('non-ARDS / ARDS-like discussion','ARDS'))

# Split View: optional empty, hidden parked tab, deliberate ownership changes only.
check('split-empty-slot', 'Second pane is empty' in split and 'Split View may be intentionally empty' in split)
check('split-no-auto-secondary', 'Opening Split by itself' in split and 'requestedSecondary is not null' in split)
check('split-park-hidden', 'tab.Content = null;' in split and 'tab.Visibility = Visibility.Collapsed;' in split)
check('split-return-same-tab', 'tab.Content = content;' in split and 'tab.Visibility = Visibility.Visible;' in split and 'ReturnSecondaryWorkspaceTabAsync' in split)
check('split-return-ui', 'ReturnSecondaryWorkspaceButton' in xaml and 'Return to tabs' in xaml)
check('split-no-placeholder-model', '_splitSecondaryPlaceholderContent' not in split and 'currently shown in the other Split View pane' not in split)
check('split-no-auto-click-swap', 'QueueDeferredSecondarySwap' not in split and 'deferredSecondary' not in split)
check('split-selected-secondary-stays-parked', 'PulseSecondaryWorkspaceAlreadyOpen' in split and 'Tabs.SelectedItem = _splitPrimaryTab' in split)
check('split-library-parked-handling', 'TryHandleAlreadyParkedBeside(alreadyOpen.Tab)' in main)
check('split-tool-parked-handling', main.count('TryHandleAlreadyParkedBeside(existing)') >= 2)
check('split-deliberate-swap', 'SwapSplitPanesAsync' in split and 'Swap panes' in split)
check('split-repeated-swap-button-reenable', 'if (_splitWorkspaceActive) UpdateSecondaryWorkspaceChrome();' in split and '_splitSwapInProgress = false;' in split)
check('split-safe-return-detach', 'Beside view is still settling' in split and 'if (content is not null && !await WaitForSplitElementDetachAsync(content))' in split)
check('split-safe-swap-failsafe', 'oldPrimary.Content is null && await WaitForSplitElementDetachAsync(primaryContent)' in split and 'avoided an unsafe reparent' in split)
check('split-invariant-hidden-owner', 'secondary tab must be hidden from the main tab strip' in split and 'SecondaryWorkspaceContent.Content' in split)
check('split-empty-session-restorable', 'LastWorkspaceSplitEnabled = _splitWorkspaceActive' in split and 'string.IsNullOrWhiteSpace(_settings.LastWorkspaceSecondaryId)' in split)
check('split-readonly-restore-no-guess', 'restore its secondary slot empty' in split and 'ReadOnlySecondary' in split)
check('search-preview-show-beside', 'selectedBefore' in preview and 'ShowTabBesideAsync(sourceTab)' in preview)

# Native Journal provider and UX.
check('journal-files', (SRC/'MainWindow.Journal.cs').exists() and (SRC/'Services/JournalService.cs').exists() and (SRC/'Models/JournalModels.cs').exists())
check('journal-paths', all(x in paths for x in ['JournalRoot','JournalSnapshotPath','JournalLogPath']))
check('journal-append-only', 'FileMode.Append' in js and 'FileOptions.WriteThrough' in js and 'Flush(flushToDisk: true)' in js)
check('journal-bounds', all(x in js for x in ['MaxEntries = 20_000','MaxTitleLength = 500','MaxBodyLength = 500_000','48L * 1024L * 1024L']))
check('journal-compaction', 'CompactOperationCount = 100' in js and 'CompactLogBytes = 2L * 1024L * 1024L' in js and 'AtomicFileStore.WriteText(PathfinderPaths.JournalSnapshotPath' in js)
check('journal-partial-tail-recovery', 'incomplete final Journal write was ignored' in js)
check('journal-100-render', '_journalResultLimit = 100' in journal and '_journalResultLimit += 100' in journal)
check('journal-search-full-body-owner', 'Search Journal title, full note text, or cockpit' in journal and 'normalized.Title + " " + normalized.Body' in js and 'ownerMatches' in js)
check('journal-filter-all-general-cockpit', all(x in journal for x in ['All notes','General (','RepresentedSlugs']))
check('journal-general-and-from-study', 'New general note' in journal and 'From current Study' in journal)
check('journal-selected-text', 'draft?.SelectedText' in journal and 'Selected cockpit text was copied into the note body' in journal)
check('journal-source-capture', 'CaptureSourceActionDraftAsync(context, selectedTextOverride)' in journal and 'will not invent a source link' in journal)
check('journal-dirty-draft', 'Discard unsaved Journal changes?' in journal and 'Keep editing' in journal and 'Save note' in journal)
check('journal-delete-confirm', 'Delete Journal note?' in journal)
check('journal-source-hash-guard', 'Source version changed' in journal and 'ExpectedSha256' in journal)
check('journal-readonly-source-open', 'CreateReadOnlySourceTabForLocationAsync' in journal and 'CloneLocation(entry.SourceLocation)' in journal and 'CockpitViewRole.ReadOnlySecondary' in split)
check('journal-my-study-recent', '_journal.Recent(3)' in pers and 'Open Journal' in pers)
check('journal-study-context-action', 'Add note to Journal' in pers)
check('journal-shell-tab', 'shell:Journal' in journal and 'saved.Id.Equals("Journal"' in main)
check('journal-split-participation', 'Search, Glossary and Journal can participate' in main)
check('journal-live-inplace-refresh', 'JournalRootBelongsTo' in journal and '_journalRenderResults?.Invoke();' in journal and '_journalRefreshFilters?.Invoke();' in journal)
check('journal-inline-editor-visible', 'IsJournalWorkspaceVisible()' in journal and 'RenderJournalInlineEditor' in journal and 'New Journal note' in journal)
check('journal-inline-save-refresh', 'SaveJournalInlineEditorAsync' in journal and '_journalEditorSession = null;' in journal and '_journalRenderResults?.Invoke();' in journal)
check('journal-popup-when-not-visible', 'await EditJournalEntryPopupAsync(existing, draft, sourceSubject);' in journal and 'New Journal note' in journal and 'ContentDialog' in journal)
check('journal-inline-dirty-close', 'ConfirmDiscardJournalDraftAsync' in journal and 'Equals(tab.Tag, "shell:Journal")' in pers and 'if (!await ConfirmDiscardJournalDraftAsync()) return;' in pers)
check('journal-study-memory-selection', '_journalLastStudyTab = ctx.Tab;' in main and 'ResolveJournalStudyContext' in journal)
check('journal-study-context-beside', '_splitSecondaryTab is not null && _studyTabs.TryGetValue(_splitSecondaryTab, out var beside)' in journal)
check('journal-webview-context-menu-hook', 'AddJournalContextMenu(context, e);' in main and 'AddGlossaryContextMenu(context, e);' in main)
check('journal-webview-context-selection', 'Add selection to Journal…' in journal and 'Add current place to Journal…' in journal and 'args.ContextMenuTarget.SelectionText' in journal)
sel_guard=journal.find('if (args.ContextMenuTarget.HasSelection)')
sel_read=journal.find('args.ContextMenuTarget.SelectionText')
check('journal-webview-context-hasselection-guard', sel_guard >= 0 and sel_read > sel_guard and 'var selected = "";' in journal)
check('journal-selected-text-override', 'string? selectedTextOverride = null' in host and 'selectedTextOverride ?? ""' in host)
check('journal-shell-context-show-beside', 'ConfigureShellTabWorkspaceFeatures(tab);' in main and 'Show beside in Split View' in split)
check('journal-open-source-main-pairs-beside', 'await ShowTabBesideAsync(sourceTab);' in journal and 'Tabs.SelectedItem = journalTab;' in journal)
check('journal-open-source-journal-beside-stays', 'journalIsBeside' in journal and 'The Journal already occupies the static secondary slot' in journal)
check('journal-source-location-strict-helper', 'CreateReadOnlySourceTabForLocationAsync' in split and 'location.IsStrictSource' in split and 'location.SourceVersion.Equals(subject.ExpectedSha256' in split)

# Legacy Personal -> Journal migration is idempotent and rollback-safe.
check('legacy-payload-retained', 'SubjectNotes' in pmodel and 'State.SubjectNotes.Remove' in psvc and 'SubjectNotes.Clear' not in journal)
check('legacy-marker-in-journal-not-personal', 'LegacyPersonalMigrationSlugs' in jm and 'LegacySubjectNoteMigrationSlugs' not in pmodel and 'LegacySubjectNoteMigrationSlugs' not in psvc)
check('legacy-atomic-migration-op', 'legacy-personal-migrate' in js and 'Entry + migration marker are one append-only operation' in js)
check('legacy-deterministic-id', 'legacy-personal-' in journal and 'LegacyPersonalJournalId' in journal)
check('legacy-idempotence', 'IsLegacyPersonalMigrated(marker)' in journal and 'MigrateLegacyPersonal(entry, marker)' in journal)
check('legacy-readback', 'verified.LegacyPersonalMigrationSlugs' in journal and 'verifiedIds' in journal)
check('legacy-return-tab-uniform', 'ReturnSecondaryWorkspaceTabAsync' in split and 'ReadOnlySecondary' not in split[split.find('private async Task ReturnSecondaryWorkspaceTabAsync'):split.find('private async void ReturnSecondaryWorkspaceButton_Click')])

# Canonical backup/restore coverage and compatibility.
check('backup-journal-first-class', 'public JournalState Journal' in bm and '"Journal"' in backup and 'native Journal General notes' in backup)
check('backup-journal-strict-schema', 'ParseCanonicalJournal' in backup and 'LegacyPersonalMigrationSlugs' in backup)
check('backup-old-preserves-journal', 'older Windows canonical backup predates the native Journal provider' in backup and 'Current Journal entries will be preserved' in backup)
check('backup-pwa-journal-promotion', 'TryParsePwaJournal' in backup and 'promotedJournalProvider' in backup and 'node.Remove("Journal")' in backup)
check('backup-journal-source-validation', 'SourceLocation source identity does not match' in backup and 'SourceVersion does not match the installed frozen resource' in backup)
check('backup-personal-shape-compatible', 'LegacySubjectNoteMigrationSlugs' not in backup and '"SubjectNotes", "Bookmarks"' in backup)
check('backup-journal-markers-canonicalized', 'Journal legacy Personal migration marker' in backup)
check('backup-create-compacts-journal', '_journal.Compact()' in pers and '_journal.ExportState()' in pers)
check('restore-transaction-journal', 'JournalSnapshotPath' in pers and 'JournalLogPath' in pers and '_journal.ReplaceInMemory(journalTarget)' in pers)
check('reset-journal', 'JournalSnapshotPath' in settings and 'JournalLogPath' in settings and '_journal.ReplaceInMemory(nextJournal)' in settings)

# Existing W3/W4 foundations retained.
host=read('MainWindow.CockpitHost.cs'); models=read('Models/CockpitHostModels.cs'); loc=read('MainWindow.Location.cs')
check('view-role-model', 'ReadOnlySecondary' in models and 'Primary' in models)
check('secondary-state-readonly', "data-pathfinder-view-role','read-only-secondary" in host and 'context.ViewRole != CockpitViewRole.Primary' in loc)
check('processfailed-recovery', 'Reload cockpit safely' in main and 'ProcessFailed' in main)
check('source-action-foundation', 'SourceActionDraft' in models and 'CaptureSourceActionDraftAsync' in host)

# Registry parity retained.
reg=json.loads((SRC/'ShellData'/'cockpit-state-allowlist.json').read_text())
check('cockpit-registry-24', len(reg.get('resources',{}))==24, str(len(reg.get('resources',{}))))
check('cockpit-registry-2607', sum(len(v) for v in reg.get('resources',{}).values())==2607, str(sum(len(v) for v in reg.get('resources',{}).values())))

# XML parse.
for rel in ['MainWindow.xaml','App.xaml','NivareQ.Step2Pathfinder.csproj']:
    try: ET.parse(SRC/rel); ok=True; detail=''
    except Exception as e: ok=False; detail=str(e)
    check('xml:'+rel,ok,detail)

# C# lexical balance (comments/strings stripped; not a substitute for Windows compile).
def strip_cs(s):
    out=[]; i=0; n=len(s); state='code'; raw_quotes=0
    while i<n:
        if state=='code':
            if s.startswith('//',i): state='line'; out.extend('  '); i+=2; continue
            if s.startswith('/*',i): state='block'; out.extend('  '); i+=2; continue
            m=re.match(r'\$*"""',s[i:])
            if m: state='raw'; raw_quotes=3; out.extend(' '*len(m.group(0))); i+=len(m.group(0)); continue
            if s.startswith('@"',i): state='verbatim'; out.extend('  '); i+=2; continue
            if s[i]=='"': state='string'; out.append(' '); i+=1; continue
            if s[i]=="'": state='char'; out.append(' '); i+=1; continue
            out.append(s[i]); i+=1
        elif state=='line':
            if s[i]=='\n': state='code'; out.append('\n')
            else: out.append(' ')
            i+=1
        elif state=='block':
            if s.startswith('*/',i): state='code'; out.extend('  '); i+=2
            else: out.append('\n' if s[i]=='\n' else ' '); i+=1
        elif state=='string':
            if s[i]=='\\' and i+1<n: out.extend('  '); i+=2
            elif s[i]=='"': state='code'; out.append(' '); i+=1
            else: out.append('\n' if s[i]=='\n' else ' '); i+=1
        elif state=='verbatim':
            if s.startswith('""',i): out.extend('  '); i+=2
            elif s[i]=='"': state='code'; out.append(' '); i+=1
            else: out.append('\n' if s[i]=='\n' else ' '); i+=1
        elif state=='raw':
            if s.startswith('"""',i): state='code'; out.extend('   '); i+=3
            else: out.append('\n' if s[i]=='\n' else ' '); i+=1
        elif state=='char':
            if s[i]=='\\' and i+1<n: out.extend('  '); i+=2
            elif s[i]=="'": state='code'; out.append(' '); i+=1
            else: out.append(' '); i+=1
    return ''.join(out),state
lex=[]; files=list(SRC.rglob('*.cs'))
for path in files:
    t,state=strip_cs(path.read_text(encoding='utf-8'))
    if state!='code': lex.append(f'{path.name}: ended {state}')
    for a,b in [('(',')'),('[',']'),('{','}')]:
        dep=0
        for ch in t:
            if ch==a: dep+=1
            elif ch==b:
                dep-=1
                if dep<0: break
        if dep!=0: lex.append(f'{path.name}: {a}{b}={dep}')
check('all-csharp-lexical-balance',not lex,'; '.join(lex[:30]))

passed=sum(1 for _,ok,_ in checks if ok)
result={
    'w2a_base_passed':base.get('passed',0),
    'w5_checks_passed':passed,
    'combined_passed':base.get('passed',0)+passed,
    'failed':len(errors),
    'medical_files':base.get('medical_files',132),
    'resources':base.get('resources',25),
    'cockpit_state_resources':len(reg.get('resources',{})),
    'cockpit_state_keys':sum(len(v) for v in reg.get('resources',{}).values()),
    'csharp_files':len(files),
    'errors':errors
}
(ROOT/'docs'/'W5-R4-STATIC-QC-RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
sys.exit(1 if errors else 0)
