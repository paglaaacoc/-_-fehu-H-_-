param([Parameter(Mandatory=$true)][string]$PublishDir)
$ErrorActionPreference='Stop'
$Root = Split-Path -Parent $PSScriptRoot
$Manifest = Join-Path $Root 'Integrity\MEDICAL_PAYLOAD_SHA256_MANIFEST.txt'
$Payload = Join-Path $PublishDir 'MedicalPayload'
$fail=0;$count=0
Get-Content $Manifest | ForEach-Object {
  if (-not $_.Trim()) { return }
  $parts=$_ -split '  ',2; $expected=$parts[0].Trim(); $rel=$parts[1].Trim().Replace('/',[IO.Path]::DirectorySeparatorChar)
  $path=Join-Path $Payload $rel; $count++
  if(-not(Test-Path -LiteralPath $path)){Write-Host "MISSING $rel" -ForegroundColor Red;$fail++;return}
  $actual=(Get-FileHash -Algorithm SHA256 -LiteralPath $path).Hash.ToLowerInvariant()
  if($actual -ne $expected){Write-Host "MISMATCH $rel" -ForegroundColor Red;$fail++}
}
if($fail){throw "Published medical payload FAILED integrity: $fail/$count"}
Write-Host "Published medical payload PASS: $count/$count." -ForegroundColor Green
