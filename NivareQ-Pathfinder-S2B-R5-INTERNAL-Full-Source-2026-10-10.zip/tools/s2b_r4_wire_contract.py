#!/usr/bin/env python3
"""R4 source/wire guard only; C# compilation remains a separate CI gate."""
from pathlib import Path
import json
r=Path(__file__).resolve().parents[1]
js=(r/'src/NivareQ.Step2Pathfinder/NotesProtocol/notes-draft-coordinator.js').read_text()
cs=(r/'src/NivareQ.Step2Pathfinder/Services/NotesStagingPageRouterV1.cs').read_text()
harness=(r/'tests/NotesStoreHarness/Program.cs').read_text()
s1=(r/'src/NivareQ.Step2Pathfinder/MainWindow.Scratchpad.cs').read_text()
for marker in ['strokesJson','_reconcile(c)','Native Notes session-release','needsReconciliation','lastAcknowledgedRevision']:
    assert marker in js, marker
for marker in ['record NotesPageProbe','public NotesPageProbe Probe(', 'ReadPage(request.NoteId, request.PageId)', 'ReleaseStagingPage']:
    assert marker in cs, marker
assert 'jsDto.Page.Cells[0].StrokesJson' in harness
assert 'notes-draft-coordinator.js' not in s1 and 'NotesStagingPageRouterV1' not in s1
assert len([p for p in (r/'src/NivareQ.Step2Pathfinder/MedicalPayload').rglob('*') if p.is_file()])==132
print(json.dumps({'result':'PASS','scope':'R4 source/DTO/static guards only; .NET, WebView2 and Windows compilation NOT executed'}))
