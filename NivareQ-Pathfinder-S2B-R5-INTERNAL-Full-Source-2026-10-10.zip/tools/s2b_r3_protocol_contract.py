#!/usr/bin/env python3
"""S2-B R3 packaging/protocol static guard; this is NOT C# compilation.
Guard absence of live wiring and validate that the future JS/native envelope has
matching typed members. Run the real JS behavior suite separately in Node.
"""
import json
from pathlib import Path
root = Path(__file__).resolve().parents[1]
js = (root/'src/NivareQ.Step2Pathfinder/NotesProtocol/notes-draft-coordinator.js').read_text()
cs = (root/'src/NivareQ.Step2Pathfinder/Services/NotesStagingPageRouterV1.cs').read_text()
csproj = (root/'tests/NotesStoreHarness/NotesStoreHarness.csproj').read_text()
harness = (root/'tests/NotesStoreHarness/Program.cs').read_text()
s1 = (root/'src/NivareQ.Step2Pathfinder/MainWindow.Scratchpad.cs').read_text()
work = (root/'ci/S2B-R2-WINDOWS-CI-TEMPLATE.yml').read_text()
assert 'nivareq.notes.page-save.v1' in js and 'nivareq.notes.page-save.v1' in cs
assert 'SavePage(packet.NoteId, packet.PageId' in cs
assert 'session.LastRequestHash == payloadHash' in cs
assert 'packet.ExpectedRevision != session.Revision' in cs
assert 'session.LastSequence != lastAcknowledgedSequence' in cs
assert 's.NoteId == noteId && s.PageId == pageId' in cs
for name in ['SessionId','Sequence','NoteId','PageId','ExpectedRevision','Page','PersistedRevision']:
    assert name in cs, name
for name in ['sessionId','sequence','noteId','pageId','expectedRevision','page','persistedRevision']:
    assert name in js, name
assert 'NotesStagingPageRouterV1.cs' in csproj
assert 'pageRouter.Write(packet)' in harness and 'JsonSerializer.Deserialize<NotesPageWritePacket>' in harness
assert 'notes-draft-coordinator.js' not in s1 and 'NotesStagingPageRouterV1' not in s1
assert '.github/workflows' not in str(root/'ci/S2B-R2-WINDOWS-CI-TEMPLATE.yml')
assert 'node tests/NotesProtocolHarness/run.cjs' in work
assert (root/'src/NivareQ.Step2Pathfinder/MedicalPayload').is_dir()
assert len([p for p in (root/'src/NivareQ.Step2Pathfinder/MedicalPayload').rglob('*') if p.is_file()]) == 132
print(json.dumps({'result':'PASS','scope':'static cross-language protocol and isolation checks; NOT compiled .NET',
    'protocol':'nivareq.notes.page-save.v1','medical_files':132,'live_S1_bridge_modified':False}, indent=2))
