#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, re, sys
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT/'src'/'NivareQ.Step2Pathfinder'
errors=[]; passed=0

def ok(cond,msg):
    global passed
    if cond: passed += 1
    else: errors.append(msg)

loc=(SRC/'Models'/'PathfinderLocation.cs').read_text(encoding='utf-8')
bak=(SRC/'Services'/'BackupContractService.cs').read_text(encoding='utf-8')
# Core repair contract
ok('using System.Text.Json.Serialization;' in loc, 'Json serialization namespace missing')
ok(bool(re.search(r'\[JsonIgnore\]\s*public bool IsStrictSource\s*=>',loc)), 'IsStrictSource is not JsonIgnore')
ok(bool(re.search(r'\[JsonIgnore\]\s*public bool HasDurableTarget\s*=>',loc)), 'HasDurableTarget is not JsonIgnore')
ok(loc.count('[JsonIgnore]')==2, 'Unexpected JsonIgnore count in PathfinderLocation.cs')
ok('Purpose.Equals("source", StringComparison.OrdinalIgnoreCase)' in loc, 'IsStrictSource runtime semantics changed')
ok('!string.IsNullOrWhiteSpace(TargetId) || !string.IsNullOrWhiteSpace(TargetPath) || !string.IsNullOrWhiteSpace(Context)' in loc, 'HasDurableTarget runtime semantics changed')
# Strict importer should remain strict; helpers must not be added to canonical contract.
rich='EnsureOnlyProperties(element, label, "SchemaVersion", "ResourceId", "SourceVersion", "Purpose", "Anchor", "TargetId", "TargetPath", "Context", "OffsetY", "TargetOffsetY", "Hash", "ScrollX", "ScrollY", "OpenDetails", "UpdatedUtc")'
ok(rich in bak, 'Location v2 strict canonical allowlist changed unexpectedly')
ok('"IsStrictSource"' not in bak, 'Strict importer was weakened to accept IsStrictSource')
ok('"HasDurableTarget"' not in bak, 'Strict importer was weakened to accept HasDurableTarget')
# R1 medical correction must remain byte-identical.
manifest=ROOT/'Integrity'/'W8-MEDICAL-CORRECTION-R1-SOURCE-SHA256.txt'
expected={}
for line in manifest.read_text(encoding='utf-8').splitlines():
    if not line.strip(): continue
    h,rel=line.split('  ',1); expected[rel]=h
med=[(rel,h) for rel,h in expected.items() if rel.startswith('MedicalPayload/R2/')]
ok(len(med)==132, f'Expected 132 R1 medical files in baseline manifest, got {len(med)}')
for rel,h in med:
    p=SRC/rel
    ok(p.exists(), f'Missing medical payload file: {rel}')
    if p.exists(): ok(hashlib.sha256(p.read_bytes()).hexdigest()==h, f'Medical payload changed from R1: {rel}')
# Non-medical source: exactly PathfinderLocation.cs may differ from R1 baseline.
changed=[]; missing=[]
for rel,h in expected.items():
    if rel.startswith('MedicalPayload/R2/'): continue
    p=SRC/rel
    if not p.exists(): missing.append(rel); continue
    if hashlib.sha256(p.read_bytes()).hexdigest()!=h: changed.append(rel)
ok(not missing, f'Non-medical source missing vs R1: {missing}')
ok(changed==['Models/PathfinderLocation.cs'], f'Unexpected R2 runtime source delta: {changed}')
ok(hashlib.sha256((SRC/'Models'/'PathfinderLocation.cs').read_bytes()).hexdigest()=='b8d8fcb1c47f3e801610a584def0a2f1e772776864771dfa523f1dae1049885d','PathfinderLocation exact R2 hash mismatch')
result={'passed':passed,'failed':len(errors),'medical_files_verified_against_r1':len(med),'runtime_changed_files':changed,'errors':errors}
print(json.dumps(result,indent=2))
sys.exit(1 if errors else 0)
