from pathlib import Path
import hashlib,json,re,zipfile,sys
ROOT=Path(__file__).resolve().parents[1]
PAY=ROOT/'src/NivareQ.Step2Pathfinder/MedicalPayload/R2'
ERR=[]; PASS=0
def check(name,cond,detail=''):
    global PASS
    if cond: PASS+=1
    else: ERR.append(f'{name}: {detail}')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
# 132-file full manifest
entries=[]
for line in (ROOT/'Integrity/MEDICAL_PAYLOAD_SHA256_MANIFEST.txt').read_text().splitlines():
    if not line.strip(): continue
    h,r=line.split('  ',1); entries.append((h,r))
check('manifest-count',len(entries)==132,len(entries))
for h,r in entries:
    p=ROOT/'src/NivareQ.Step2Pathfinder/MedicalPayload'/r
    check('payload:'+r,p.exists() and sha(p)==h, r)
# Frozen map
fm=json.loads((ROOT/'src/NivareQ.Step2Pathfinder/ShellData/frozen-content-map.json').read_text())
check('map-revision',fm.get('contentRevision')=='W8-MEDICAL-CORRECTION-R1',str(fm.get('contentRevision')))
check('map-count',len(fm.get('files',[]))==132,str(len(fm.get('files',[]))))
for f in fm.get('files',[]):
    p=PAY/f['canonicalPath']; check('map:'+f['canonicalPath'],p.exists() and sha(p)==f['sha256'] and p.stat().st_size==f['bytes'])
# Resource registry
reg=json.loads((ROOT/'src/NivareQ.Step2Pathfinder/ShellData/resource-registry.json').read_text())
check('registry-revision',reg.get('contentRevision')=='W8-MEDICAL-CORRECTION-R1')
check('registry-count',len(reg.get('resources',[]))==25,str(len(reg.get('resources',[]))))
for r in reg['resources']:
    p=PAY/r['canonicalPath']; check('resource:'+r['resourceId'],p.exists() and sha(p)==r['sourceSha256'])
# Historical pkg/o hashes
expected={}
for line in (ROOT/'Integrity/W8-MEDICAL-CORRECTION-R1-PKG-O-BASELINE-SHA256.txt').read_text().splitlines():
    h,n=line.split('  ',1);expected[n]=h
current=list((PAY/'pkg/o').glob('*.zip'))
check('pkg-o-count',len(current)==19,str(len(current)))
for p in current: check('pkg-o:'+p.name,expected.get(p.name)==sha(p))
# No new pkg/p slots
pz=sorted(p.name for p in (PAY/'pkg/p').glob('*.zip'))
check('pkg-p-shape',pz==['03-pulmonary.zip','05-endocrine.zip','07-hematology-oncology.zip','08-infectious-disease.zip','11-psychiatry-substance-use.zip','12-obstetrics.zip','14-pediatrics.zip','17-ethics-qi-systems.zip'],str(pz))
# Refreshed pkg/p live HTML exactness
for zn,sub in [('05-endocrine.zip','05-endocrine'),('07-hematology-oncology.zip','07-hematology-oncology'),('08-infectious-disease.zip','08-infectious-disease'),('12-obstetrics.zip','12-obstetrics'),('14-pediatrics.zip','14-pediatrics')]:
    z=zipfile.ZipFile(PAY/'pkg/p'/zn); hs=[n for n in z.namelist() if n.lower().endswith('.html') and 'audit' not in n.lower()]
    check('pkg-p-live:'+zn,len(hs)==1 and z.read(hs[0])==(PAY/'c'/sub/'main.html').read_bytes(),str(hs))
# Key audit corrections / stale phrase removals
texts={rel:(PAY/rel).read_text(errors='replace') for rel in [
'c/02-cardiology/main.html','c/05-endocrine/main.html','c/06-gi-hepatobiliary/main.html','c/07-hematology-oncology/main.html','c/08-infectious-disease/main.html','c/09-rheumatology-msk-dermatology/main.html','c/10-neurology/main.html','c/12-obstetrics/main.html','c/13-repro-gyn-breast/main.html','c/14-pediatrics/main.html','c/15-surgery-trauma-em/main.html','c/21-poisoning-environmental/main.html','x/clinical-recall.html']}
need={
'MED-001':('c/06-gi-hepatobiliary/main.html','Suspected hemorrhage requires urgent vascular imaging'),
'MED-002':('c/06-gi-hepatobiliary/main.html','begins dysplasia surveillance around 8 years'),
'MED-003':('c/06-gi-hepatobiliary/main.html','Selected chronic-HBV patients need surveillance even without cirrhosis'),
'MED-004-GI':('c/06-gi-hepatobiliary/main.html','decompensated cirrhosis needs antiviral treatment regardless of HBV DNA or ALT'),
'MED-004-ID':('c/08-infectious-disease/main.html','decompensated cirrhosis'),
'MED-005':('c/02-cardiology/main.html','at least 4 weeks afterward'),
'MED-006':('c/02-cardiology/main.html','>120 min'),
'MED-007':('c/08-infectious-disease/main.html','Bladder-confined urinary symptoms'),
'MED-008':('c/12-obstetrics/main.html','universally again in the third trimester, and at birth'),
'MED-009':('c/14-pediatrics/main.html',r'8\u201321 days'),
'MED-010':('c/15-surgery-trauma-em/main.html','Sustained polymorphic VT'),
'MED-011':('c/07-hematology-oncology/main.html','does not reliably distinguish liver disease from DIC'),
'MED-012':('c/10-neurology/main.html','<185/110'),
'MED-013':('c/05-endocrine/main.html','After 16 weeks'),
'MED-014':('c/05-endocrine/main.html',r'BMI \u226530'),
'MED-016':('c/13-repro-gyn-breast/main.html','at least 25 years'),
'MED-017':('c/13-repro-gyn-breast/main.html','FSH >25 IU/L'),
'MED-018':('c/21-poisoning-environmental/main.html','does not recommend beta-adrenergic antagonists'),
'MED-020-GI':('c/06-gi-hepatobiliary/main.html','over <24 hours'),
'MED-020-TOX':('c/21-poisoning-environmental/main.html','>24 hours'),
'MED-020-RECALL':('x/clinical-recall.html','spanning <24 h'),
'MED-021':('x/clinical-recall.html',r'\u226515 min'),
}
for k,(rel,s) in need.items(): check(k,s in texts[rel],s)
check('MED-015-removed','Avacopan can reduce glucocorticoid exposure' not in texts['c/09-rheumatology-msk-dermatology/main.html'])
check('MED-019-old-ams-removed','nausea, dizziness, fatigue, or sleep disturbance' not in texts['c/21-poisoning-environmental/main.html'])
# GI deeper count and MAX amendment.
t=texts['c/06-gi-hepatobiliary/main.html']
m=re.search(r'const\s+TOPICS\s*=\s*',t); i=m.end();
while t[i].isspace(): i+=1
st=i;d=0;ins=False;esc=False;end=None
for j in range(i,len(t)):
    c=t[j]
    if ins:
        if esc:esc=False
        elif c=='\\':esc=True
        elif c=='"':ins=False
    else:
        if c=='"':ins=True
        elif c=='[':d+=1
        elif c==']':
            d-=1
            if d==0:end=j+1;break
topics=json.loads(t[st:end]); by={x['id']:x for x in topics}
check('GI-topic-count',len(topics)==86,str(len(topics)))
check('GI-deeper-populated',sum(bool(x.get('deeper')) for x in topics)==23,str(sum(bool(x.get('deeper')) for x in topics)))
check('GI-deeper-empty',sum(not bool(x.get('deeper')) for x in topics)==63)
check('GI-MAX-omit-acute-pancreatitis-dx',by['acute-pancreatitis-dx'].get('deeper')==[],str(by['acute-pancreatitis-dx'].get('deeper')))
optional=['eoe','hpylori','diverticulitis','uc','asuc','choledocholithiasis','acute-pancreatitis-mgmt','gallstone-pancreatitis','necrotizing-pancreatitis','ascites','sbp','hrs','variceal-bleed','hav-hev']
check('GI-14-optional',all(by[x].get('deeper') for x in optional))
# Selector exact corrected PDF hash fixed for this frozen candidate.
selector=PAY/'x/uworld-selector.pdf'
check('MED-022-selector-hash',sha(selector)=='fff605e66f2391ea04ea6df7d0b29fa25392a5b355ec027d74127094fbd8145a',sha(selector))
result={'passed':PASS,'failed':len(ERR),'medical_files':len([p for p in PAY.rglob('*') if p.is_file()]),'resources':len(reg['resources']),'gi_deeper_populated':23,'gi_deeper_empty':63,'errors':ERR}
print(json.dumps(result,indent=2))
if ERR: sys.exit(1)
