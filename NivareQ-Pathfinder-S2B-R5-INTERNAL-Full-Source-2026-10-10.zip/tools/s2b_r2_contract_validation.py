#!/usr/bin/env python3
"""S2-B R2 portable safety CONTRACT tests; exercises SQLite SQL but NOT the C# service.
No writes to real Pathfinder user data. Fails closed if contract implementations disappear.
"""
from pathlib import Path
import json, re, sqlite3, tempfile
root = Path(__file__).resolve().parents[1]
service = (root/'src/NivareQ.Step2Pathfinder/Services/NotesStoreV1.cs').read_text()
collections = (root/'src/NivareQ.Step2Pathfinder/Services/NotesStoreV1.Collections.cs').read_text()
harness = (root/'tests/NotesStoreHarness/Program.cs').read_text()
assert 'sealed partial class NotesStoreV1' in service
assert 'partial class NotesStoreV1' in collections
assert 's1_import_state' in service and "'in_progress'" in service and "'complete'" in service
assert 'Reducing writing spaces would discard saved text or ink' in service
assert 'Reducing writing spaces would discard an image' in service
assert 'deleted_utc IS NULL' in service and 'deleted_utc IS NOT NULL' in collections
assert 'RequireWritableStaging();' in collections
assert 'verifyExactSource' in service
assert 'ReadNoteSources' in collections
assert 'lock (_writeGate)' in service
assert 'S1 source' in harness
assert 'sealed' in harness
assert 'Metadata' in collections
assert 'SavePage' in harness
assert 'NotesStoreV1.Collections.cs' in (root/'tests/NotesStoreHarness/NotesStoreHarness.csproj').read_text()
match=re.search(r'using \(var cmd = Command\(db, transaction, """\n(.*?)\n\s*"""\)\) cmd.ExecuteNonQuery\(\);',service,re.S)
assert match
sql=match.group(1)
checks=0
def check(test, msg):
    global checks
    assert test, msg
    checks+=1
with tempfile.TemporaryDirectory() as td:
    db = sqlite3.connect(str(Path(td)/'notes.sqlite'))
    db.execute('PRAGMA foreign_keys=ON')
    db.executescript(sql)
    now='2026-10-09T21:00:00Z'
    db.execute('INSERT INTO notebooks VALUES (?,?,?,?,?)', ('a','General',0,now,now))
    db.execute('INSERT INTO notebooks VALUES (?,?,?,?,?)', ('b','Cardiology',1,now,now))
    db.execute('INSERT INTO notes(id,notebook_id,title,active_page_id,created_utc,updated_utc) VALUES (?,?,?,?,?,?)',('n','a','Anatomy','p',now,now))
    db.execute('INSERT INTO pages (id,note_id,ordinal,guide,spacing) VALUES (?,?,?,?,?)',('p','n',0,'ruled',32))
    db.execute('INSERT INTO cells VALUES (?,?,?,?)',('p',0,'prior text','[]'))
    db.execute('INSERT INTO note_fts(note_id,title,body) VALUES (?,?,?)',('n','Anatomy','prior text'))
    db.commit()
    check(db.execute('PRAGMA foreign_key_check').fetchall()==[], 'initial FK')
    check(db.execute('SELECT id FROM notes WHERE deleted_utc IS NULL').fetchone()==('n',),'active note visible')
    # Real SQL from the C# metadata operation (not a rewrite).
    m=re.search(r'public long UpdateNoteMetadata\(.*?UPDATE notes SET (.*?)\n\s*""",',collections,re.S)
    check(m is not None,'metadata SQL found')
    update='UPDATE notes SET '+m.group(1)
    params={'b':'b','t':'Arrhythmias','s':'cardiology','p':1,'now':now,'id':'n','rev':0}
    check(db.execute(update, params).rowcount==1,'metadata CAS succeeds')
    check(db.execute(update, params).rowcount==0,'metadata CAS rejects stale')
    check(db.execute('SELECT notebook_id,pinned,revision,title FROM notes WHERE id="n"').fetchone()==('b',1,1,'Arrhythmias'),'metadata persisted')
    # The original page stays intact through a note move and pin.
    check(db.execute('SELECT text FROM cells WHERE page_id="p"').fetchone()==('prior text',),'page text preserved')
    # The actual page CAS UPDATE expression in the C# service.
    m=re.search(r'UPDATE pages SET guide=@g, spacing=@s, revision=revision\+1\n(.*?)\n\s*""",',service,re.S)
    check(m is not None,'page CAS SQL found')
    save='UPDATE pages SET guide=@g, spacing=@s, revision=revision+1\n'+m.group(1)
    check(db.execute(save, {'g':'ruled','s':44,'p':'p','n':'n','rev':0}).rowcount==1,'page CAS succeeds')
    check(db.execute(save, {'g':'ruled','s':24,'p':'p','n':'n','rev':0}).rowcount==0,'page CAS blocks stale')
    check(db.execute('SELECT spacing,revision FROM pages WHERE id="p"').fetchone()==(44,1),'page CAS did not regress')
    # The read query must exclude Trash and keep note docs in place.
    m=re.search(r'public long SetTrashed\(.*?UPDATE notes SET (.*?)\n\s*""",',collections,re.S)
    check(m is not None,'Trash SQL found')
    trash='UPDATE notes SET '+m.group(1)
    check(db.execute(trash,{'deleted':now,'now':now,'id':'n','rev':1,'trash':1}).rowcount==1,'Trash CAS')
    check(db.execute(save,{'g':'ruled','s':32,'p':'p','n':'n','rev':1}).rowcount==0,'Trash blocks page save')
    check(db.execute('SELECT text FROM cells WHERE page_id="p"').fetchone()==('prior text',),'Trash does not cascade')
    check(db.execute(trash,{'deleted':None,'now':now,'id':'n','rev':2,'trash':0}).rowcount==1,'restore CAS')
    check(db.execute('SELECT deleted_utc,revision FROM notes WHERE id="n"').fetchone()==(None,3),'restored note visible')
    # Exact-source schema cannot accept verified sources without location.
    try:
        db.execute('INSERT INTO note_sources VALUES (?,?,?,?,?,?)',('s','n','resource','v1',None,1))
        check(False,'false verified source accepted')
    except sqlite3.IntegrityError:
        check(True,'verified source location required')
    db.execute('INSERT INTO note_sources VALUES (?,?,?,?,?,?)',('s','n','resource','v1',None,0))
    check(db.execute('SELECT verified FROM note_sources').fetchone()==(0,), 'unverified link retained')
    # Creating/rejecting migration stage statuses is crash durable at SQLite level.
    db.execute('INSERT INTO meta VALUES (?,?)',('s1_import_state','in_progress'))
    db.commit(); db.close()
    reopened=sqlite3.connect(str(Path(td)/'notes.sqlite'))
    check(reopened.execute("SELECT value FROM meta WHERE key='s1_import_state'").fetchone()==('in_progress',), 'crash leaves quarantine marker')
    check(reopened.execute('PRAGMA integrity_check').fetchone()==('ok',),'integrity after reopen')
    reopened.close()
medical = list((root/'src/NivareQ.Step2Pathfinder/MedicalPayload').rglob('*'))
check(len([p for p in medical if p.is_file()]) == 132,'132 original medical files')
print(json.dumps({'result':'PASS','scope':'portable SQLite SQL + static C# contracts; NOT native .NET compilation','checks':checks,'medical_files':132},indent=2))
