from pathlib import Path
import json, re, subprocess, sys, xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'src' / 'NivareQ.Step2Pathfinder'
errors=[]; checks=[]

def check(name, cond, detail=''):
    checks.append((name,bool(cond),detail))
    if not cond: errors.append(f'{name}: {detail}')

def read(rel): return (SRC/rel).read_text(encoding='utf-8')

# W2A remains the accepted foundation and must continue to pass intact.
proc=subprocess.run([sys.executable, str(ROOT/'tools'/'w2a-static-qc.py')], capture_output=True, text=True)
try: base=json.loads(proc.stdout)
except Exception:
    base={'passed':0,'failed':1,'errors':['W2A QC could not be parsed: '+proc.stdout[-1000:]+' '+proc.stderr[-1000:]]}
check('w2a-regression-suite', proc.returncode==0 and base.get('failed')==0, str(base.get('errors',[]))[:1000])

location_model=read('Models/PathfinderLocation.cs')
location=read('MainWindow.Location.cs')
main=read('MainWindow.xaml.cs')
xaml=read('MainWindow.xaml')
search=read('MainWindow.Search.cs')
search_model=read('Models/SearchModels.cs')
search_service=read('Services/UniversalSearchService.cs')
backup=read('Services/BackupContractService.cs')
backup_model=read('Models/BackupModels.cs')
personal_model=read('Models/PersonalStudyModels.cs')
personal_service=read('Services/PersonalStudyService.cs')
build=(ROOT/'tools'/'build-windows.ps1').read_text(encoding='utf-8')

# Explicit running-build identity.
check('build-id-visible', 'W2B R2 CANDIDATE' in xaml, '')
check('window-title-build-id', 'W2B R2 Candidate' in xaml, '')
check('build-stage-short-current', 'NQPF-W2B-Build' in build and 'NQPF-W2A-Build' not in build, '')

# Unified Location v2 model and source identity.
for marker in [
    'CurrentSchemaVersion = 2', 'ResourceId', 'SourceVersion', 'Purpose', 'Anchor',
    'TargetId', 'TargetPath', 'Context', 'TargetOffsetY', 'OpenDetails', 'HasDurableTarget'
]: check('location-model:'+marker, marker in location_model, '')
check('study-location-inherits-unified-model', 'StudyLocationState : PathfinderLocation' in personal_model, '')
check('strict-validates-resource-owner', 'location.ResourceId.Equals(context.Subject.ResourceId' in location, '')
check('strict-validates-source-sha', 'location.SourceVersion.Equals(context.Subject.ExpectedSha256' in location, '')
check('strict-requires-durable-target', '!location.HasDurableTarget' in location, '')
check('strict-no-pixel-fallback', "if(strict)return JSON.stringify({ok:false,reason:'target-missing'})" in location and "reason:'pixel-fallback'" in location, '')
check('resume-source-version-fallback', 'saved semantic identity belongs to older cockpit bytes' in location and 'effective.TargetPath = ""' in location, '')
check('semantic-target-capture', 'meaningful=(el)=>' in location and 'pathFor=(a,t)=>' in location, '')
check('details-state-capture', "openDetails:details.slice(0,30)" in location, '')
check('location-request-ordering', 'LocationRequestVersion' in main and 'BeginLocationRequest' in location and 'IsLocationRequestCurrent' in location, '')
check('web-message-generation-ordering', 'message.Generation != context.ContentGeneration' in location, '')
check('web-message-source-binding', 'message.SourceVersion.Equals(context.Subject.ExpectedSha256' in location, '')
check('capture-authority-gate', 'CaptureAuthorityReady' in main and 'CaptureAuthorityReady' in location, '')
check('strict-restore-foundation', 'RestoreStrictSourceLocationAsync' in location and 'ValidateStrictSourceLocation' in location, '')
check('temporary-view-snapshot-foundation', 'CaptureTemporaryCockpitViewAsync' in location and 'RestoreTemporaryCockpitViewAsync' in location, '')
check('location-js-no-interpolated-raw-literals', '$$\"\"\"' not in location and '$$$\"\"\"' not in location, 'Use non-interpolated JS templates so JavaScript braces cannot collide with C# raw interpolation delimiters.')
check('location-js-template-injection', '__GENERATION__' in location and '__LOCATION_JSON__' in location and '__SNAPSHOT_JSON__' in location, '')

# One authoritative primary interactive view per resource.
check('primary-reuse-open', 'FindPrimaryStudyContext(subject.ResourceId)' in main and 'Tabs.SelectedItem = alreadyOpen.Tab' in main, '')
check('primary-reuse-create', 'FindPrimaryStudyContext(subject.ResourceId) is { } existingPrimary' in main, '')
check('internal-new-window-routes-through-primary', 'await OpenSubjectAsync(subject, true);' in main, '')
check('guide-documents-primary-rule', 'one authoritative primary tab' in main, '')

# Search is source-version-bound and stale async landing cannot win.
check('search-result-source-version-model', 'SourceVersion' in search_model, '')
check('search-index-binds-source-sha', 'SourceVersion = doc.Entry.ExpectedSha256.ToLowerInvariant()' in search_service, '')
check('search-rejects-stale-source', 'result.SourceVersion' in search and 'context.Subject.ExpectedSha256' in search, '')
check('search-request-ordering', 'IsLocationRequestCurrent(context, request)' in search and 'BeginLocationRequest(existing, "search")' in search, '')
check('search-suppresses-capture-while-jumping', 'context.CaptureAuthorityReady = false' in search and 'context.CaptureAuthorityReady = true' in search, '')

# Backup contract advances canonically so richer Location v2 is not lost.
check('backup-schema3', 'CanonicalSchemaVersion = 3' in backup and 'BackupSchemaVersion { get; set; } = 3' in backup_model, '')
check('backup-producer-w2b', 'W2B-R2' in backup and 'W2B-R2' in backup_model, '')
check('backup-imports-schema2', 'schema != 1 && schema != 2 && schema != CanonicalSchemaVersion' in backup, '')
check('backup-location-rich-fields', '"SchemaVersion", "ResourceId", "SourceVersion", "Purpose", "Anchor", "TargetId", "TargetPath", "Context"' in backup, '')
check('backup-location-resource-validation', 'ResourceId does not match its owning Pathfinder resource' in backup, '')
check('backup-location-sha-validation', 'is not a SHA-256 source identity' in backup, '')
check('backup-canonicalizes-current-source', '_sourceVersionByResource' in backup and 'CanonicalizePersonalLocations' in backup, '')
check('backup-w1-stale-wording-removed', 'Windows W1' not in backup and 'W1 coverage' not in read('MainWindow.PersonalStudy.cs'), '')

# Persistence clone retains the Location v2 fields.
for marker in ['SchemaVersion = source.SchemaVersion', 'ResourceId = source.ResourceId', 'SourceVersion = source.SourceVersion', 'TargetPath = source.TargetPath', 'OpenDetails =']:
    check('personal-clone:'+marker, marker in personal_service, '')

# Structural XML parse gate.
for rel in ['MainWindow.xaml','NivareQ.Step2Pathfinder.csproj','App.xaml']:
    try:
        ET.parse(SRC/rel); ok=True; detail=''
    except Exception as e: ok=False; detail=str(e)
    check('xml:'+rel,ok,detail)

# Do not smuggle W2C Source Preview UI into this bounded gate.
check('no-w2c-source-preview-ui', 'SourcePreviewHost' not in main and 'Preview source' not in main, '')

passed=sum(1 for _,ok,_ in checks if ok)
result={
    'w2a_base_passed':base.get('passed',0), 'w2b_checks_passed':passed,
    'combined_passed':base.get('passed',0)+passed,
    'failed':len(errors), 'medical_files':base.get('medical_files',132),
    'resources':base.get('resources',25), 'errors':errors
}
print(json.dumps(result,indent=2))
sys.exit(1 if errors else 0)
