param([string]$PublishDir='')
$ErrorActionPreference='Stop'
$Root = Split-Path -Parent $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($PublishDir)) {
  $App = Join-Path $Root 'src\NivareQ.Step2Pathfinder'
  $Label = 'Source'
} else {
  $App = $PublishDir
  $Label = 'Published'
}
$RegistryPath = Join-Path $App 'ShellData\resource-registry.json'
$PayloadRoot = Join-Path $App 'MedicalPayload\R2'
if (-not (Test-Path -LiteralPath $RegistryPath)) { throw "$Label resource registry missing: $RegistryPath" }
if (-not (Test-Path -LiteralPath $PayloadRoot)) { throw "$Label canonical R2 payload root missing: $PayloadRoot" }
$registry = Get-Content -LiteralPath $RegistryPath -Raw | ConvertFrom-Json
if ($registry.schemaVersion -ne 1) { throw "$Label resource registry schema must be 1." }
$resources = @($registry.resources)
if ($resources.Count -ne 25) { throw "$Label resource registry expected 25 resources, found $($resources.Count)." }
$ids = @{}
$aliases = @{}
$count = 0
foreach ($r in $resources) {
  $id = [string]$r.resourceId
  if ([string]::IsNullOrWhiteSpace($id)) { throw "$Label resource registry contains a blank resourceId." }
  $key = $id.ToLowerInvariant()
  if ($ids.ContainsKey($key)) { throw "$Label duplicate resourceId: $id" }
  $ids[$key] = $true
  $rel = ([string]$r.canonicalPath).Replace('/', [IO.Path]::DirectorySeparatorChar)
  $path = Join-Path $PayloadRoot $rel
  if (-not (Test-Path -LiteralPath $path)) { throw "$Label resource missing: $id -> $rel" }
  $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $path).Hash.ToLowerInvariant()
  $expected = ([string]$r.sourceSha256).ToLowerInvariant()
  if ($actual -ne $expected) { throw "$Label resource hash mismatch: $id" }
  $allAliases = @($id)
  $allAliases += [string]$r.legacyMainPath
  $allAliases += @($r.legacyAliases)
  foreach ($aliasRaw in $allAliases) {
    $alias = ([string]$aliasRaw).Trim()
    if ([string]::IsNullOrWhiteSpace($alias)) { continue }
    $ak = $alias.ToLowerInvariant()
    if ($aliases.ContainsKey($ak) -and $aliases[$ak] -ne $id) { throw "$Label ambiguous resource alias '$alias' for $id and $($aliases[$ak])." }
    $aliases[$ak] = $id
  }
  $count++
}
Write-Host "$Label resource registry PASS: $count resources, $($aliases.Count) canonical/legacy aliases, hashes exact." -ForegroundColor Green
