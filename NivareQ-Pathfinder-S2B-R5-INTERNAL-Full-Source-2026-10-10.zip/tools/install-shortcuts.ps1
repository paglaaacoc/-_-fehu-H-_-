param([ValidateSet('x64','arm64')][string]$Arch='x64',[switch]$Desktop)
$ErrorActionPreference='Stop'
$Root=Split-Path -Parent $PSScriptRoot
$Folder = if($Arch -eq 'arm64'){'NivareQ Step 2 Pathfinder - ARM64'}else{'NivareQ Step 2 Pathfinder - x64'}
$Exe=Join-Path $Root ("Built Apps\$Folder\NivareQ.Step2Pathfinder.exe")
if(-not(Test-Path $Exe)){throw "Build $Arch first with BUILD-ON-WINDOWS.cmd. The app will be under the Built Apps folder."}
$Programs=Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\NivareQ'
New-Item -ItemType Directory -Force -Path $Programs|Out-Null
$Wsh=New-Object -ComObject WScript.Shell
function New-Link($Path){$s=$Wsh.CreateShortcut($Path);$s.TargetPath=$Exe;$s.WorkingDirectory=Split-Path $Exe;$s.IconLocation="$Exe,0";$s.Description='NivareQ Step 2 Pathfinder';$s.Save()}
New-Link (Join-Path $Programs 'NivareQ Step 2 Pathfinder.lnk')
if($Desktop){New-Link (Join-Path ([Environment]::GetFolderPath('Desktop')) 'NivareQ Step 2 Pathfinder.lnk')}
Write-Host 'Start-menu shortcut installed.' -ForegroundColor Green
