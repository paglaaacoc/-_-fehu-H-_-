from pathlib import Path
import json, subprocess, sys, xml.etree.ElementTree as ET, re, hashlib

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'src' / 'NivareQ.Step2Pathfinder'
errors=[]; checks=[]

def check(name, cond, detail=''):
    checks.append((name,bool(cond),detail))
    if not cond: errors.append(f'{name}: {detail}')

def read(rel): return (SRC/rel).read_text(encoding='utf-8')

proc=subprocess.run([sys.executable, str(ROOT/'tools'/'w2a-static-qc.py')], capture_output=True, text=True)
try: base=json.loads(proc.stdout)
except Exception:
    base={'passed':0,'failed':1,'errors':['W2A QC parse failure: '+proc.stdout[-1000:]+' '+proc.stderr[-1000:]]}
check('w2a-regression-suite', proc.returncode==0 and base.get('failed')==0, str(base.get('errors',[]))[:1000])

xaml=read('MainWindow.xaml')
main=read('MainWindow.xaml.cs')
settings=read('MainWindow.Settings.cs')
personal=read('MainWindow.PersonalStudy.cs')
access=read('MainWindow.Accessibility.cs')
search=read('MainWindow.Search.cs')
resolver=read('MainWindow.SearchDestination.cs')
preview=read('MainWindow.SourcePreview.cs')
location=read('MainWindow.Location.cs')
search_service=read('Services/UniversalSearchService.cs')
backup=read('Services/BackupContractService.cs')
backup_model=read('Models/BackupModels.cs')
build=(ROOT/'tools'/'build-windows.ps1').read_text(encoding='utf-8')

# Build identity / short-path build tooling.
check('build-id-visible', 'W2D R2 CANDIDATE' in xaml, '')
check('window-title-build-id', 'W2D R2 Candidate' in xaml, '')
check('build-stage-short-current', 'NQPF-W2D-Build' in build and 'NQPF-W2C-Build' not in build, '')
check('backup-producer-w2d-r2', 'W2D-R2' in backup and 'W2D-R2' in backup_model, '')

# W2C accepted core stays intact.
for marker in ['Preview source','Go to cockpit','PreviewUniversalSearchResultAsync','GoToUniversalSearchResultAsync']:
    check('w2c-search-preview:'+marker, marker in search, '')
check('w2c-exact-occurrence-search', 'FindAllOccurrences' in search_service and 'exactIndexes.Count' in search_service, '')
check('w2c-return-position', 'Return to previous position' in main and 'SourceJumpReturnLocation' in main and 'SourceJumpReturnLocation' in preview, '')
check('w2c-source-sha-gate', 'ExpectedSha256' in resolver and 'SourceVersion' in resolver, '')
check('w2c-19-22-no-filter-assist', 'subject.Number is >= 19 and <= 22 ? "false" : "true"' in resolver, '')
check('w2c-return-layout-row', 'Grid.SetRow(returnBar, 0)' in main and 'Grid.SetRow(web, 1)' in main, '')
check('location-v2-retained', 'ValidateStrictSourceLocation' in location and 'RestoreStrictSourceLocationAsync' in location, '')

# Mandatory W2D shell blocker: no virtualized grouped ListView remains.
check('sidebar-no-listview', '<ListView x:Name="SubjectsList"' not in xaml and 'SubjectsList_' not in main, '')
check('sidebar-bounded-scroll-stack', 'SubjectsScrollViewer' in xaml and 'SubjectsPanel' in xaml and 'CreateSubjectLibraryButton' in main, '')
check('sidebar-horizontal-scroll-disabled', 'SubjectsScrollViewer' in xaml and 'HorizontalScrollMode="Disabled"' in xaml and 'HorizontalScrollBarVisibility="Disabled"' in xaml, '')
check('sidebar-group-boundary-rendering', 'CreateSubjectGroupHeader' in main and 'SUPPLEMENTAL COVERAGE' in main and 'EXTRAS & REFERENCE' in main, '')
check('sidebar-25-resource-nonvirtualized-rationale', '25-resource' in main and 'late-library' in main, '')
check('sidebar-pointer-offset-preserved', '_pendingLibraryPointerVerticalOffset' in main and 'RestoreSubjectLibraryOffset' in main and 'SubjectsScrollViewer.ChangeView' in main, '')
check('first-open-search-return-anchor', 'savedResume = CloneLocation(_personal.PositionFor(subject.ResourceId))' in search and 'PendingSearchReturnLocation' in main and 'ArmSourceJumpReturn(context, returnLocation, null)' in main, '')

# Taxonomy: study tabs/tools vs app surfaces/flyouts.
check('app-surface-host-xaml', 'AppSurfaceHost' in xaml and 'AppSurfaceContent' in xaml and 'Return to study' in xaml, '')
check('app-surface-open-close', 'OpenAppSurfaceSafe' in settings and 'CloseAppSurface' in settings, '')
check('my-study-app-surface', 'OpenAppSurfaceSafe("my-study", "My Study"' in personal, '')
check('guide-app-surface', 'OpenAppSurfaceSafe("guide", "Guide"' in main, '')
check('accessibility-routes-settings', 'OpenSettings("accessibility")' in main and 'AccessibilityButton_Click' in main, '')
check('settings-top-command', 'x:Name="SettingsButton"' in xaml and 'SettingsButton_Click' in settings, '')
check('study-time-removed-topbar', 'x:Name="TimeButton"' not in xaml and 'TimeButton_Click' not in main, '')
check('study-time-moved-my-study', 'Study planning & time estimates' in personal and 'View all subject estimates' in personal, '')
check('search-remains-tool-tab', 'OpenSpecialTabSafe("Search", CreateUniversalSearchView)' in main or 'OpenSpecialTabSafe("Search", CreateUniversalSearchView)' in read('MainWindow.Search.cs'), '')
check('glossary-remains-tool-tab', 'OpenSpecialTab("Glossary", CreateGlossaryView(query))' in read('MainWindow.Glossary.cs'), '')
check('legacy-app-tabs-not-restored', 'Legacy Guide/My Study/Accessibility/Study-time tab records are intentionally' in main, '')

# Settings foundation sections.
for marker in ['General','Appearance','Accessibility & display','Data, backup & reset','Session & navigation','Workspace & Split View','About & integrity']:
    check('settings-section:'+marker, marker in settings, '')
check('settings-theme-shared', 'ThemeCombo.SelectedItem = choice' in settings, '')
check('settings-session-card', 'MakeSessionRestoreCard()' in settings, '')
check('settings-split-view-committed', 'Split View is a committed W4 feature' in settings, '')

# Backup-mandatory destructive reset.
check('reset-ui-present', 'Reset Pathfinder data…' in settings and 'Choose reset scope' in settings, '')
check('reset-four-scopes', all(x in settings for x in ['Session/view state only','Study/progress state','Personal My Study data','Full canonical Pathfinder user data']), '')
check('reset-backup-first', settings.index('CreateCanonicalBackupFileAsync(') < settings.index('ApplyDestructiveResetAsync(scope)'), '')
check('reset-backup-verified', 'verifyAfterWrite: true' in settings and 'Backup verified · reset now?' in settings, '')
check('reset-cancel-without-backup', 'No verified backup was created' in settings and 'reset to continue' in settings, '')
check('reset-transactional-commit', 'RestoreTransactionService.Commit' in settings and 'Reset failed safely' in settings, '')
check('backup-helper-strict-readback', 'ParseImport(readBack' in personal and 'just-written file did not verify' in personal, '')
check('reset-full-includes-opaque-extension-state', 'nextExtensions = new PreservedBackupExtensionState()' in settings, '')
check('reset-does-not-delete-medical-or-webview', 'Installed app/medical content and the WebView2 runtime/cache are not deleted.' in settings, '')

# No frozen medical source changes delegated to W2A hash suite.
check('medical-payload-hash-enforced', base.get('medical_files') == 132, str(base.get('medical_files')))
check('resource-registry-enforced', base.get('resources') == 25, str(base.get('resources')))

# XML parse.
for rel in ['MainWindow.xaml','NivareQ.Step2Pathfinder.csproj','App.xaml']:
    try: ET.parse(SRC/rel); ok=True; detail=''
    except Exception as e: ok=False; detail=str(e)
    check('xml:'+rel,ok,detail)

# Crude C# lexical balance for every source file: comments/strings stripped before braces.
def strip_cs(s):
    out=[]; i=0; n=len(s); state='code'
    while i<n:
        if state=='code':
            if s.startswith('//',i): state='line'; out.extend('  '); i+=2; continue
            if s.startswith('/*',i): state='block'; out.extend('  '); i+=2; continue
            # interpolated raw strings use one or more $ before triple quote
            m=re.match(r'\$*"""', s[i:])
            if m: state='raw'; out.extend(' '*len(m.group(0))); i+=len(m.group(0)); continue
            if s.startswith('@"',i): state='verbatim'; out.extend('  '); i+=2; continue
            if s[i]=='"': state='string'; out.append(' '); i+=1; continue
            if s[i]=="'": state='char'; out.append(' '); i+=1; continue
            out.append(s[i]); i+=1
        elif state=='line':
            if s[i]=='\n': state='code'; out.append('\n')
            else: out.append(' ')
            i+=1
        elif state=='block':
            if s.startswith('*/',i): state='code'; out.extend('  '); i+=2
            else: out.append('\n' if s[i]=='\n' else ' '); i+=1
        elif state=='string':
            if s[i]=='\\' and i+1<n: out.extend('  '); i+=2
            elif s[i]=='"': state='code'; out.append(' '); i+=1
            else: out.append('\n' if s[i]=='\n' else ' '); i+=1
        elif state=='verbatim':
            if s.startswith('""',i): out.extend('  '); i+=2
            elif s[i]=='"': state='code'; out.append(' '); i+=1
            else: out.append('\n' if s[i]=='\n' else ' '); i+=1
        elif state=='raw':
            if s.startswith('"""',i): state='code'; out.extend('   '); i+=3
            else: out.append('\n' if s[i]=='\n' else ' '); i+=1
        elif state=='char':
            if s[i]=='\\' and i+1<n: out.extend('  '); i+=2
            elif s[i]=="'": state='code'; out.append(' '); i+=1
            else: out.append(' '); i+=1
    return ''.join(out),state

lex_fail=[]
for path in sorted(SRC.rglob('*.cs')):
    text,state=strip_cs(path.read_text(encoding='utf-8'))
    if state!='code': lex_fail.append(f'{path.name}: ended in {state}')
    for opening,closing in [('(',')'),('[',']'),('{','}')]:
        depth=0
        for ch in text:
            if ch==opening: depth+=1
            elif ch==closing:
                depth-=1
                if depth<0: break
        if depth!=0: lex_fail.append(f'{path.name}: {opening}{closing} balance={depth}')
check('all-csharp-lexical-balance', not lex_fail, '; '.join(lex_fail[:20]))

passed=sum(1 for _,ok,_ in checks if ok)
result={
    'w2a_base_passed':base.get('passed',0),
    'w2d_checks_passed':passed,
    'combined_passed':base.get('passed',0)+passed,
    'failed':len(errors),
    'medical_files':base.get('medical_files',132),
    'resources':base.get('resources',25),
    'errors':errors
}
print(json.dumps(result,indent=2))
sys.exit(1 if errors else 0)
