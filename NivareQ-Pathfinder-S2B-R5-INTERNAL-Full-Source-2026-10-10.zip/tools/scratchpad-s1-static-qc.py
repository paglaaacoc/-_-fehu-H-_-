#!/usr/bin/env python3
"""Read-only S1 source/payload boundary QC. Requires Python 3; no Git or network."""
from pathlib import Path
from collections import Counter
import hashlib, zipfile, json, subprocess, xml.etree.ElementTree as ET, sys
root=Path(__file__).resolve().parents[1]
baseline=root/'AUTHORITY/ACCEPTED-v1.2.1-STABLE-SOURCE-READ-ONLY.zip'
allowed={
 'installer/Pathfinder-ARM64.iss',
 'installer/Pathfinder-Installer-Common.iss',
 'installer/Pathfinder-x64.iss',
 'src/NivareQ.Step2Pathfinder/MainWindow.PersonalStudy.cs',
 'src/NivareQ.Step2Pathfinder/MainWindow.Settings.cs',
 'src/NivareQ.Step2Pathfinder/Models/BackupModels.cs',
 'src/NivareQ.Step2Pathfinder/MainWindow.xaml',
 'src/NivareQ.Step2Pathfinder/MainWindow.xaml.cs',
 'src/NivareQ.Step2Pathfinder/NivareQ.Step2Pathfinder.csproj',
 'src/NivareQ.Step2Pathfinder/Services/BackupContractService.cs'
}
reports=[]
def gate(name,ok,notes=''):
 reports.append({'gate':name,'pass':bool(ok),'detail':notes})
 print(('PASS' if ok else 'FAIL'),name,notes)
with zipfile.ZipFile(baseline) as z:
 source=[i.filename for i in z.infolist() if not i.is_dir()]
 missing=[];modified=[];preserved=0;medical=0
 for name in source:
  target=root/name
  if not target.is_file():missing.append(name);continue
  old=hashlib.sha256(z.read(name)).digest();new=hashlib.sha256(target.read_bytes()).digest()
  if old!=new:modified.append(name)
  else:preserved+=1
  if 'MedicalPayload/' in name and old==new:medical+=1
 gate('baseline-present',len(source)==504 and not missing,f'504 source files, {len(missing)} missing')
 gate('only-ten-existing-files-modified',set(modified)==allowed,'; '.join(sorted(modified)))
 gate('all-other-source-byte-identical',preserved==len(source)-len(allowed),f'{preserved}/{len(source)} files byte-identical; {medical} MedicalPayload files')
 gate('medical-payload-unchanged',all('MedicalPayload/' not in n for n in modified),f'{medical} payload files matched')
 xaml=root/'src/NivareQ.Step2Pathfinder/MainWindow.xaml'
 ET.parse(xaml)
 xml=xaml.read_text()
 gate('bottom-corner-only-guide-replacement',xml.count('Click="ScratchpadButton_Click"')==1 and xml.count('Click="GuideButton_Click"')==1,'One Scratchpad launch; one top-bar Guide preserved')
 app=(root/'src/NivareQ.Step2Pathfinder/MainWindow.xaml.cs').read_text()
 bkup=(root/'src/NivareQ.Step2Pathfinder/Services/BackupContractService.cs').read_text()
 gate('scratchpad-restarts-with-session','CreateScratchpadView()' in app and 'saved.Id.Equals("Scratchpad"' in app,'Native shell tool session restoration registered')
 gate('scratchpad-canonical-backup-allowlist','"Scratchpad"' in bkup and '"scratchpad"' in bkup,'Canonical utility IDs include scratchpad')
 bridge=(root/'src/NivareQ.Step2Pathfinder/MainWindow.Scratchpad.cs').read_text()
 gate('native-bridge-origin-bound', 'args.Source.Equals(ScratchpadPageUrl' in bridge and 'DenyCors' in bridge,'Dedicated virtual host, bridge-origin verification, DenyCors')
 gate('save-uses-atomic-existing-extension-store', '_backupExtensions.Save()' in bridge and 'ScratchpadExtensionKey' in bridge,'Native atomic store; canonical backup extensions')
 gate('backup-and-tabclose-flush', 'FlushScratchpadBeforeLeavingAsync()' in (root/'src/NivareQ.Step2Pathfinder/MainWindow.PersonalStudy.cs').read_text(),'Renderer snapshot before backup or close')
 gate('no-added-GitHub-workflows', not any(p.is_file() for p in (root/'.github/workflows').rglob('*.yml')) if (root/'.github/workflows').exists() else True,'No GitHub Actions created')
 gate('scratchpad-script-syntax',subprocess.run(['node','--check',str(root/'src/NivareQ.Step2Pathfinder/ScratchpadAssets/scratchpad.js')],capture_output=True).returncode==0,'Node JavaScript parse')
 gate('candidate-version-labelled', '1.2.2 S1 TEST' in xml and '1.2.2-Scratchpad-S1-TEST' in (root/'installer/Pathfinder-x64.iss').read_text(),'Unaccepted test identity visible')
 gate('one-click-local-build-tool', (root/'BUILD-SCRATCHPAD-S1-LOCALLY.cmd').exists() and (root/'tools/build-scratchpad-s1-locally.ps1').exists(),'Offline-local build with x64/ARM64 installer paths')
report={'candidate':'SCRATCHPAD-S1-TEST','authority':'v1.2.1 OWNER-ACCEPTED','source_zip_sha256':hashlib.sha256(baseline.read_bytes()).hexdigest(),'changed_existing':sorted(modified),'preserved_count':preserved,'medical_payload_identical_count':medical,'gates':reports,'all_static_pass':all(x['pass'] for x in reports),'windows_compile':'NOT RUN - Linux environment','Windows owner acceptance':'PENDING'}
(root/'SCRATCHPAD-S1-QC-RESULTS.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print('SUMMARY:',sum(x['pass'] for x in reports),'/',len(reports),'static gates passed')
sys.exit(0 if report['all_static_pass'] else 2)
