from pathlib import Path
import json, subprocess, sys, xml.etree.ElementTree as ET, re, hashlib, unicodedata

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'src'/'NivareQ.Step2Pathfinder'
FULL=ROOT.parent
BASE=FULL/'06-WINDOWS-W4-CANDIDATE'/'src'/'NivareQ.Step2Pathfinder'
checks=[]; errors=[]
def check(name, cond, detail=''):
    checks.append((name,bool(cond),detail))
    if not cond: errors.append(f'{name}: {detail}')
def read(rel): return (SRC/rel).read_text(encoding='utf-8')

# Proven frozen-content/resource foundation.
p=subprocess.run([sys.executable,str(ROOT/'tools'/'w2a-static-qc.py')],capture_output=True,text=True)
try: base=json.loads(p.stdout)
except Exception: base={'passed':0,'failed':1,'errors':[p.stdout[-700:]+p.stderr[-700:]]}
check('w2a-foundation',p.returncode==0 and base.get('failed')==0,str(base.get('errors',[]))[:1200])

main=read('MainWindow.xaml.cs'); xaml=read('MainWindow.xaml'); split=read('MainWindow.SplitWorkspace.cs')
journal=read('MainWindow.Journal.cs'); js=read('Services/JournalService.cs'); jm=read('Models/JournalModels.cs')
pers=read('MainWindow.PersonalStudy.cs'); pmodel=read('Models/PersonalStudyModels.cs'); psvc=read('Services/PersonalStudyService.cs')
searchn=read('Services/SearchNormalization.cs'); searchsvc=read('Services/UniversalSearchService.cs')
searchui=read('MainWindow.Search.cs'); dest=read('MainWindow.SearchDestination.cs')
backup=read('Services/BackupContractService.cs'); bm=read('Models/BackupModels.cs'); settings=read('MainWindow.Settings.cs')
paths=read('Services/PathfinderPaths.cs'); preview=read('MainWindow.SourcePreview.cs')
host=read('MainWindow.CockpitHost.cs')
build=(ROOT/'tools'/'build-windows.ps1').read_text(encoding='utf-8')
selector_ui=read('MainWindow.UWorldSelector.cs'); selector_svc=read('Services/UWorldSelectorService.cs'); selector_model=read('Models/UWorldSelectorModels.cs')
selector_catalog=json.loads((SRC/'ShellData'/'uworld-selector-recipes.json').read_text(encoding='utf-8'))
selector_ref=json.loads((ROOT/'Integrity'/'PWA-B4A-UWORLD-SELECTOR-REFERENCE.json').read_text(encoding='utf-8'))
theme_registry=json.loads((SRC/'Brand'/'Themes'/'registry.json').read_text(encoding='utf-8'))

# Identity / package build gate.
check('build-id', 'W8 CLOSURE R1 CANDIDATE' in xaml and 'W8 Closure R1 Candidate' in xaml and 'W8 Closure R1 Candidate' in settings)
check('short-stage-w8', 'NQPF-W8-Closure-Build' in build)
check('backup-schema7', 'BackupSchemaVersion { get; set; } = 7' in bm and 'CanonicalSchemaVersion = 7' in backup)
check('backup-producer-w8', 'W8-CLOSURE-R1' in bm and 'ProducerBuild = "W8-CLOSURE-R1"' in backup)


# W8 integrated stabilization / release-readiness packaging gates.
csproj=read('NivareQ.Step2Pathfinder.csproj')
root_builder=(ROOT/'BUILD-ON-WINDOWS.cmd').read_text(encoding='utf-8')
test_launcher=(ROOT/'TEST-W8-x64.cmd').read_text(encoding='utf-8')
w8_impl=(ROOT/'docs'/'W8-R1-INTEGRATED-STABILIZATION.md').read_text(encoding='utf-8')
w8_test=(ROOT/'docs'/'W8-R1-EXTREMELY-EASY-WINDOWS-TEST.md').read_text(encoding='utf-8')
w8_astra=(ROOT/'docs'/'W8-R1-ASTRA-CLOSURE-AUDIT-PROMPT.txt').read_text(encoding='utf-8')
check('w8-project-platforms-x64-arm64', '<Platforms>x64;ARM64</Platforms>' in csproj and '<RuntimeIdentifiers>win-x64;win-arm64</RuntimeIdentifiers>' in csproj)
check('w8-builder-default-all-architectures', "[string]$Arch='All'" in build and "if($Arch -eq 'All')" in build and "Name='x64'" in build and "Name='arm64'" in build)
check('w8-root-builder-does-not-force-one-arch', 'build-windows.ps1' in root_builder and '-Arch' not in root_builder)
check('w8-fast-test-is-x64-bounded', '-Arch x64' in test_launcher and 'W8 Closure R1' in test_launcher)
check('w8-self-contained-windows-appsdk', '<WindowsAppSDKSelfContained>true</WindowsAppSDKSelfContained>' in csproj and '<SelfContained>true</SelfContained>' in csproj)
check('w8-known-journal-issue-explicit', 'multi-block' in w8_impl and 'did not solve it' in w8_impl and 'does not add another speculative runtime patch' in w8_impl)
check('w8-astra-closure-targets-journal', 'ASTRA-W8-JOURNAL-SELECTION-ROOT-CAUSE' in w8_astra and 'Known unresolved Journal defect' in w8_astra)
check('w8-medical-gate-preserved', 'Medical Content Audit / Re-review' in w8_impl and 'Medical Content Audit/Re-review' in w8_test)
check('w8-stable-release-both-architectures', 'x64 + ARM64' in w8_impl and 'x64 + ARM64' in w8_test)

# Inherited accepted W7 shell/themes/workspace/polish gate.
theme_ids={x.get('id') for x in theme_registry.get('themes',[]) if x.get('enabled')}
check('w7-theme-count-13', len(theme_ids)==13, str(len(theme_ids)))
check('w7-theme-new-day', {'sage-day','sunlit-apricot'}.issubset(theme_ids))
check('w7-theme-new-evening', {'ember-glow','twilight-bloom'}.issubset(theme_ids))
check('w7-theme-existing-preserved', {'light','dark','oled-black','ocean','forest','amber','aurora','parchment','glacier'}.issubset(theme_ids))
check('w7-home-continue-snapshot', 'MakeHomeStudySnapshotCard' in main and 'Continue & study snapshot' in pers and 'Open My Study' in pers)
check('w7-split-shortcut', 'Key="S" Modifiers="Control,Menu" Invoked="SplitWorkspaceAccelerator_Invoked"' in xaml and 'SplitWorkspaceAccelerator_Invoked' in split)
check('w7-split-50-50-reset', 'DoubleTapped="WorkspaceDivider_DoubleTapped"' in xaml and '_splitRatio = 0.50;' in split)
check('w7-selection-cache-runtime', 'RuntimeSelectionSnapshotTemplate' in host and '__nivareqSelectionSnapshot' in host and "document.addEventListener('contextmenu',capture,true)" in host)
check('w7-selection-cache-consumed', '__nivareqSelectionSnapshot' in host and 'cached.length>current.length?cached:current' in host)
check('w7-supplemental-drill-feedback', '.opt.correct::after' in host and '✓ Correct' in host and '.opt.wrong::after' in host and '✕ Your choice' in host)
check('w7-guide-theme-docs', 'Sage Day' in main and 'Sunlit Apricot' in main and 'Ember Glow' in main and 'Twilight Bloom' in main)
check('w7-guide-split-docs', 'Ctrl+Alt+S' in main and 'double-click/tap' in main)

# W5 R2 compile repair retained in R4: TextBox uses ScrollViewer's attached scrollbar API.
check('journal-editor-scrollbar-attached-api', 'ScrollViewer.SetVerticalScrollBarVisibility(note, ScrollBarVisibility.Auto);' in journal)

# Medical bytes unchanged from accepted W4 R3 source tree.
def tree_hashes(root):
    out={}
    for f in sorted(root.rglob('*')):
        if f.is_file(): out[f.relative_to(root).as_posix()]=hashlib.sha256(f.read_bytes()).hexdigest()
    return out
w5_med=tree_hashes(SRC/'MedicalPayload')
if (BASE/'MedicalPayload').exists():
    w4_med=tree_hashes(BASE/'MedicalPayload')
    medical_ok=w5_med==w4_med
    medical_detail=f'w4={len(w4_med)} w5={len(w5_med)}'
else:
    # Lightweight TEST packages intentionally omit the full W4 source tree. In that
    # layout, prove the same frozen bytes against the carried authoritative manifest.
    manifest={}
    for line in (ROOT/'Integrity'/'MEDICAL_PAYLOAD_SHA256_MANIFEST.txt').read_text(encoding='utf-8').splitlines():
        if not line.strip(): continue
        digest, rel=line.split('  ',1)
        manifest[rel]=digest
    current={k.removeprefix('R2/'):v for k,v in w5_med.items() if k.startswith('R2/')}
    expected={k.removeprefix('R2/'):v for k,v in manifest.items() if k.startswith('R2/')}
    medical_ok=current==expected and len(expected)==132
    medical_detail=f'accepted-manifest={len(expected)} w5-R4={len(current)}'
check('medical-tree-byte-identical-w4r3', medical_ok, medical_detail)

# Search boundary correctness.
check('search-whole-term-api', all(x in searchn for x in ['IsWholeTermMatch','IndexOfWholeTerm','ContainsWholeTerm']))
check('search-exact-occurrences-whole', 'SearchNormalization.IndexOfWholeTerm(haystack, needle, at)' in searchsvc)
check('search-token-whole', 'SearchNormalization.IndexOfWholeTerm(doc.Normalized.Value, t)' in searchsvc)
check('search-title-whole', 'SearchNormalization.ContainsWholeTerm(title, t)' in searchsvc)
check('search-alias-whole', 'SearchNormalization.IndexOfWholeTerm(doc.Normalized.Value, alias.Normalized)' in searchsvc)
check('search-partial-fallback-lower', 'partialTokenMatch' in searchsvc and 'score = 220 +' in searchsvc)
check('search-exact-highlight-boundary', 'ApplyTextHighlights(title, result.HighlightTerms, result.IsExactPhrase)' in searchui and 'FindDisplayRanges(block.Text, terms, wholeTermsOnly)' in searchui)
check('search-destination-whole', 'const hasWhole' in dest and 'exactRequested' in dest and 'hasMatch(text, query, exactRequested)' in dest)

# Behavioral reference for normalized boundary semantics used by the C# implementation.
def norm(s):
    d=unicodedata.normalize('NFD',s or '')
    out=[]; pending=False
    for c in d:
        if unicodedata.category(c)=='Mn': continue
        if c.isalnum():
            if pending and out and out[-1]!=' ': out.append(' ')
            out.append(c.lower()); pending=False
        else: pending=True
    return ''.join(out).strip()
def whole(h,n):
    h=norm(h); n=norm(n)
    at=h.find(n)
    while at>=0:
        left=at==0 or h[at-1].isspace(); r=at+len(n); right=r>=len(h) or h[r].isspace()
        if left and right:return True
        at=h.find(n,at+1)
    return False
check('regression-ards-standalone', whole('ARDS acute respiratory distress syndrome','ARDS'))
check('regression-ards-not-standards', not whole('standards stewardship DMARDs','ARDS'))
check('regression-multiword-exact', whole('acute respiratory distress syndrome (ARDS)','respiratory distress'))
check('regression-hyphen-normalized-boundary', whole('non-ARDS / ARDS-like discussion','ARDS'))

# Split View: optional empty, hidden parked tab, deliberate ownership changes only.
check('split-empty-slot', 'Second pane is empty' in split and 'Split View may be intentionally empty' in split)
check('split-no-auto-secondary', 'Opening Split by itself' in split and 'requestedSecondary is not null' in split)
check('split-park-hidden', 'tab.Content = null;' in split and 'tab.Visibility = Visibility.Collapsed;' in split)
check('split-return-same-tab', 'tab.Content = content;' in split and 'tab.Visibility = Visibility.Visible;' in split and 'ReturnSecondaryWorkspaceTabAsync' in split)
check('split-return-ui', 'ReturnSecondaryWorkspaceButton' in xaml and 'Return to tabs' in xaml)
check('split-no-placeholder-model', '_splitSecondaryPlaceholderContent' not in split and 'currently shown in the other Split View pane' not in split)
check('split-no-auto-click-swap', 'QueueDeferredSecondarySwap' not in split and 'deferredSecondary' not in split)
check('split-selected-secondary-stays-parked', 'PulseSecondaryWorkspaceAlreadyOpen' in split and 'Tabs.SelectedItem = _splitPrimaryTab' in split)
check('split-library-parked-handling', 'TryHandleAlreadyParkedBeside(alreadyOpen.Tab)' in main)
check('split-tool-parked-handling', main.count('TryHandleAlreadyParkedBeside(existing)') >= 2)
check('split-deliberate-swap', 'SwapSplitPanesAsync' in split and 'Swap panes' in split)
check('split-repeated-swap-button-reenable', 'if (_splitWorkspaceActive) UpdateSecondaryWorkspaceChrome();' in split and '_splitSwapInProgress = false;' in split)
check('split-safe-return-detach', 'Beside view is still settling' in split and 'if (content is not null && !await WaitForSplitElementDetachAsync(content))' in split)
check('split-safe-swap-failsafe', 'oldPrimary.Content is null && await WaitForSplitElementDetachAsync(primaryContent)' in split and 'avoided an unsafe reparent' in split)
check('split-invariant-hidden-owner', 'secondary tab must be hidden from the main tab strip' in split and 'SecondaryWorkspaceContent.Content' in split)
check('split-empty-session-restorable', 'LastWorkspaceSplitEnabled = _splitWorkspaceActive' in split and 'string.IsNullOrWhiteSpace(_settings.LastWorkspaceSecondaryId)' in split)
check('split-readonly-restore-no-guess', 'restore its secondary slot empty' in split and 'ReadOnlySecondary' in split)
check('search-preview-show-beside', 'selectedBefore' in preview and 'ShowTabBesideAsync(sourceTab)' in preview)

# Native Journal provider and UX.
check('journal-files', (SRC/'MainWindow.Journal.cs').exists() and (SRC/'Services/JournalService.cs').exists() and (SRC/'Models/JournalModels.cs').exists())
check('journal-paths', all(x in paths for x in ['JournalRoot','JournalSnapshotPath','JournalLogPath']))
check('journal-append-durable-boundary', 'FileMode.OpenOrCreate' in js and 'FileAccess.ReadWrite' in js and 'lastByte != (byte)' in js and 'FileOptions.WriteThrough' in js and 'Flush(flushToDisk: true)' in js)
check('journal-bounds', all(x in js for x in ['MaxEntries = 20_000','MaxTitleLength = 500','MaxBodyLength = 500_000','48L * 1024L * 1024L']))
check('journal-compaction', 'CompactOperationCount = 100' in js and 'CompactLogBytes = 2L * 1024L * 1024L' in js and 'AtomicFileStore.WriteText(PathfinderPaths.JournalSnapshotPath' in js)
check('journal-partial-tail-recovery', 'incomplete final Journal write was ignored' in js)
check('journal-100-render', '_journalResultLimit = 100' in journal and '_journalResultLimit += 100' in journal)
check('journal-search-full-body-owner', 'Search Journal title, full note text, or cockpit' in journal and 'normalized.Title + " " + normalized.Body' in js and 'ownerMatches' in js)
check('journal-filter-all-general-cockpit', all(x in journal for x in ['All notes','General (','RepresentedSlugs']))
check('journal-general-and-from-study', 'New general note' in journal and 'From current Study' in journal)
check('journal-selected-text', 'draft?.SelectedText' in journal and 'Selected cockpit text was copied into the note body' in journal)
check('journal-source-capture', 'CaptureSourceActionDraftAsync(context, selectedTextOverride, preferLiveSelection)' in journal and 'will not invent a source link' in journal)
check('journal-dirty-draft', 'Discard unsaved Journal changes?' in journal and 'Keep editing' in journal and 'Save note' in journal)
check('journal-delete-confirm', 'Delete Journal note?' in journal)
check('journal-source-hash-guard', 'Source version changed' in journal and 'ExpectedSha256' in journal)
check('journal-readonly-source-open', 'CreateReadOnlySourceTabForLocationAsync' in journal and 'CloneLocation(entry.SourceLocation)' in journal and 'CockpitViewRole.ReadOnlySecondary' in split)
check('journal-my-study-recent', '_journal.Recent(3)' in pers and 'Open Journal' in pers)
check('journal-study-context-action', 'Add note to Journal' in pers)
check('journal-shell-tab', 'shell:Journal' in journal and 'saved.Id.Equals("Journal"' in main)
check('journal-split-participation', 'Search, Glossary and Journal can participate' in main)
check('journal-live-inplace-refresh', 'JournalRootBelongsTo' in journal and '_journalRenderResults?.Invoke();' in journal and '_journalRefreshFilters?.Invoke();' in journal)
check('journal-inline-editor-visible', 'IsJournalWorkspaceVisible()' in journal and 'RenderJournalInlineEditor' in journal and 'New Journal note' in journal)
check('journal-inline-save-refresh', 'SaveJournalInlineEditorAsync' in journal and '_journalEditorSession = null;' in journal and '_journalRenderResults?.Invoke();' in journal)
check('journal-popup-when-not-visible', 'await EditJournalEntryPopupAsync(existing, draft, sourceSubject);' in journal and 'New Journal note' in journal and 'ContentDialog' in journal)
check('journal-inline-dirty-close', 'ConfirmDiscardJournalDraftAsync' in journal and 'Equals(tab.Tag, "shell:Journal")' in pers and 'if (!await ConfirmDiscardJournalDraftAsync()) return;' in pers)
check('journal-study-memory-selection', '_journalLastStudyTab = ctx.Tab;' in main and 'ResolveJournalStudyContext' in journal)
check('journal-study-context-beside', '_splitSecondaryTab is not null && _studyTabs.TryGetValue(_splitSecondaryTab, out var beside)' in journal)
check('journal-webview-context-menu-hook', 'AddJournalContextMenu(context, e, contextSelectionSnapshot);' in main and 'AddGlossaryContextMenu(context, e);' in main)
check('journal-webview-context-selection', 'Add selection to Journal…' in journal and 'Add current place to Journal…' in journal and 'args.ContextMenuTarget.SelectionText' in journal)
sel_guard=journal.find('var hasSelection = args.ContextMenuTarget.HasSelection;')
sel_read=journal.find('args.ContextMenuTarget.SelectionText')
check('journal-webview-context-hasselection-guard', sel_guard >= 0 and sel_read > sel_guard and 'var hasSelection = args.ContextMenuTarget.HasSelection;' in journal)
check('journal-selected-text-override', 'string? selectedTextOverride = null, bool preferLiveSelection = false' in host and 'CaptureLiveSelectionTextAsync(context, selectedTextOverride)' in host)
check('journal-shell-context-show-beside', 'ConfigureShellTabWorkspaceFeatures(tab);' in main and 'Show beside in Split View' in split)
check('journal-open-source-main-pairs-beside', 'await ShowTabBesideAsync(sourceTab);' in journal and 'Tabs.SelectedItem = journalTab;' in journal)
check('journal-open-source-journal-beside-stays', 'journalIsBeside' in journal and 'The Journal already occupies the static secondary slot' in journal)
check('journal-source-location-strict-helper', 'CreateReadOnlySourceTabForLocationAsync' in split and 'location.IsStrictSource' in split and 'location.SourceVersion.Equals(subject.ExpectedSha256' in split)

# Legacy Personal -> Journal migration is idempotent and rollback-safe.
check('legacy-payload-retained', 'SubjectNotes' in pmodel and 'State.SubjectNotes.Remove' in psvc and 'SubjectNotes.Clear' not in journal)
check('legacy-marker-in-journal-not-personal', 'LegacyPersonalMigrationSlugs' in jm and 'LegacySubjectNoteMigrationSlugs' not in pmodel and 'LegacySubjectNoteMigrationSlugs' not in psvc)
check('legacy-atomic-migration-op', 'legacy-personal-migrate' in js and 'Entry + migration marker are one append-only operation' in js)
check('legacy-deterministic-id', 'legacy-personal-' in journal and 'LegacyPersonalJournalId' in journal)
check('legacy-idempotence', 'IsLegacyPersonalMigrated(marker)' in journal and 'MigrateLegacyPersonal(entry, marker)' in journal)
check('legacy-readback', 'verified.LegacyPersonalMigrationSlugs' in journal and 'verifiedIds' in journal)
check('legacy-return-tab-uniform', 'ReturnSecondaryWorkspaceTabAsync' in split and 'ReadOnlySecondary' not in split[split.find('private async Task ReturnSecondaryWorkspaceTabAsync'):split.find('private async void ReturnSecondaryWorkspaceButton_Click')])

# Canonical backup/restore coverage and compatibility.
check('backup-journal-first-class', 'public JournalState Journal' in bm and '"Journal"' in backup and 'native Journal General notes' in backup)
check('backup-journal-strict-schema', 'ParseCanonicalJournal' in backup and 'LegacyPersonalMigrationSlugs' in backup)
check('backup-old-preserves-journal', 'older Windows canonical backup predates the native Journal provider' in backup and 'Current Journal entries will be preserved' in backup)
check('backup-pwa-journal-promotion', 'TryParsePwaJournal' in backup and 'promotedJournalProvider' in backup and 'node.Remove("Journal")' in backup)
check('backup-journal-source-validation', 'SourceLocation source identity does not match' in backup and 'SourceVersion does not match the installed frozen resource' in backup)
check('backup-personal-shape-compatible', 'LegacySubjectNoteMigrationSlugs' not in backup and '"SubjectNotes", "Bookmarks"' in backup)
check('backup-journal-markers-canonicalized', 'Journal legacy Personal migration marker' in backup)
check('backup-create-compacts-journal', '_journal.Compact()' in pers and '_journal.ExportState()' in pers)
check('restore-transaction-journal', 'JournalSnapshotPath' in pers and 'JournalLogPath' in pers and '_journal.ReplaceInMemory(journalTarget)' in pers)
check('reset-journal', 'JournalSnapshotPath' in settings and 'JournalLogPath' in settings and '_journal.ReplaceInMemory(nextJournal)' in settings)

# W6 Native Interactive UWorld Selector.
stable_ids=['r01','r02','r03','r04','r05','r06','r07','r08','r09','r10a','r10b','r11a','r11b','r12a','r12b','r13','r14','r15','r16','r17','r18','r19','r20','r21','residual-six','final-audit']
check('selector-catalog-schema', selector_catalog.get('schemaVersion')==1 and selector_catalog.get('recipeVersion')==1 and selector_catalog.get('resourceId')=='extra-uworld-selector')
check('selector-catalog-exact-pwa-b4a-reference', selector_catalog.get('recipes')==selector_ref.get('recipes') and selector_catalog.get('allSystems')==selector_ref.get('allSystems'))
check('selector-pwa-source-hash-reference', selector_ref.get('pwaSourceSha256')=='8fd96cd34df70ef079f2a12244acfaca28036dfdc052934c4a3b784460af0f5a' and 'AcceptedPwaSelectorSourceVersion = "8fd96cd34df70ef079f2a12244acfaca28036dfdc052934c4a3b784460af0f5a"' in backup)
check('selector-26-stable-ids', [x.get('id') for x in selector_catalog.get('recipes',[])]==stable_ids, str([x.get('id') for x in selector_catalog.get('recipes',[])]))
check('selector-22-systems', len(selector_catalog.get('allSystems',[]))==22 and len(set(selector_catalog.get('allSystems',[])))==22)
check('selector-residual-six', selector_catalog['recipes'][-2]['id']=='residual-six' and len(selector_catalog['recipes'][-2]['systems'])==6 and 'six-system' in selector_catalog['recipes'][-2]['how'])
check('selector-final-audit', selector_catalog['recipes'][-1]['id']=='final-audit' and len(selector_catalog['recipes'][-1]['subjects'])==5 and selector_catalog['recipes'][-1]['systems']==['ALL systems'] and 'Unused = 0' in selector_catalog['recipes'][-1]['how'])
check('selector-first-pass-unused-only', 'Status: Unused ONLY' in ''.join(x.get('how','') for x in selector_catalog['recipes']) and 'Question mode: Standard' in ''.join(x.get('how','') for x in selector_catalog['recipes']))
check('selector-state-unknown-distinct-zero', 'Report(string id)' in selector_svc and 'report is null ? "unknown" : report.Unused == 0 ? "zero" : "remaining"' in selector_svc)
check('selector-count-bounds', 'MaxUnusedCount = 100000' in selector_svc and 'unused < 0 || unused > MaxUnusedCount' in selector_svc)
check('selector-timestamp', 'ReportedUtc = DateTimeOffset.UtcNow' in selector_svc and 'reported' in selector_ui.lower())
check('selector-atomic-state', 'AtomicFileStore.WriteText(PathfinderPaths.UWorldSelectorStatePath' in selector_svc and 'last-good' in selector_svc.lower())
check('selector-library-placement', 'extra-clinical-recall-library' in main and 'CreateUWorldSelectorLibraryButton()' in main and 'Native manual Unused-only recipe tracker' in selector_ui)
check('selector-tool-tab', 'shell:UWorld Selector' in selector_ui and 'OpenSpecialTab("UWorld Selector"' in selector_ui and 'ConfigureShellTabWorkspaceFeatures(tab)' in main)
check('selector-session-restore', 'saved.Id.Equals("UWorld Selector"' in main and '"UWorld Selector"' in backup and 'WindowsUtilityIds' in backup)
check('selector-split-static-compatible', 'TryHandleAlreadyParkedBeside(existing)' in selector_ui and 'Show beside in Split View' in split)
check('selector-search-filter', '_uworldSelector.Search(query, UWorldSelectorStatusKey())' in selector_ui and 'All reported states' in selector_ui and 'Unused remaining' in selector_ui)
check('selector-targeted-open-clears-local-filters', '_uworldSelectorSearchBox.Text = "";' in selector_ui and '_uworldSelectorStatusFilter.SelectedIndex = 0;' in selector_ui and 'source/search destination must reveal its recipe' in selector_ui)
check('selector-final-audit-search-alias', '"final-audit" => "All Subjects All Systems final audit"' in selector_svc and '"residual-six" => "Residual six system sweep verification"' in selector_svc)
check('selector-global-search', 'selectorMatches = _uworldSelector.Search(trimmed, "")' in searchui and 'MakeUWorldSelectorSearchCard' in searchui+selector_ui)
check('selector-open-cockpit', 'Open cockpit' in selector_ui and 'OpenBySlugAsync(recipe.Slug, true)' in selector_ui)
check('selector-printable-pdf-retained', 'extra-uworld-checkbox-selector' in selector_ui and 'Open printable selector PDF' in selector_ui)
check('selector-no-account-automation', 'does not connect to, read, scrape, or verify a UWorld account' in selector_ui and not re.search(r'uworld\.com|api\.uworld', selector_ui, re.I))
check('selector-journal-source', 'Add note to Journal…' in selector_ui and 'UWorldSelectorRecipeLocation' in selector_ui and 'SourceActionDraft' in selector_ui)
check('selector-journal-filter-owner', 'ResolveJournalSubject' in journal and 'UWorldSelectorService.ResourceId' in journal)
check('selector-journal-open-source', 'NormalizeUWorldRecipeTarget' in journal+selector_ui and 'journalBesideSelector' in journal and 'ShowTabBesideAsync(selectorTab)' in journal)
check('selector-backup-first-class', 'public UWorldSelectorState UWorldSelector' in bm and 'native UWorld Selector 26-recipe' in backup and 'ParseCanonicalUWorldSelector' in backup)
check('selector-backup-schema7-required', '"UWorldSelector", "Coverage"' in backup and 'schema >= 7' in backup)
check('selector-old-backup-preserves', 'older Windows canonical backup predates the native UWorld Selector provider' in backup and 'Current Selector reports will be preserved' in backup)
check('selector-pwa-promotion', 'TryParsePwaUWorldSelector' in backup and 'promotedSelectorProvider' in backup and 'selectorCockpits.Remove(UWorldSelectorService.ResourceId)' in backup)
check('selector-pwa-journal-source-translation', 'AcceptedPwaSelectorSourceVersion' in backup and 'selectorTranslation' in backup)
check('selector-restore-transaction', 'UWorldSelectorStatePath' in pers and '_uworldSelector.ReplaceInMemory(selectorTarget)' in pers)
check('selector-reset-study-progress', 'nextSelector = UWorldSelectorService.NewState();' in settings and 'UWorldSelectorStatePath' in settings)
check('selector-source-hash', len(re.search(r'SourceVersion.*SHA256', selector_svc, re.S).group(0))>0 if re.search(r'SourceVersion.*SHA256', selector_svc, re.S) else False)
check('selector-scratchpad-gate-not-opened', 'InkCanvas' not in selector_ui and 'InkPresenter' not in selector_ui)

# W6 R2/R3 bounded context-menu / selection-capture/navigation repair.
check('r2-live-selection-authoritative', 'CaptureLiveSelectionTextAsync' in host and 'window.getSelection' in host and 'replace(/\\r\\n?/g' in host)
check('r3-context-selection-snapshot-early', 'Task<string>? contextSelectionSnapshot = null;' in main and 'contextSelectionSnapshot = CaptureLiveSelectionTextAsync(context, fallbackSelection);' in main)
check('r3-journal-uses-context-snapshot', 'CreateJournalNoteFromContextMenuAsync' in journal and 'await contextSelectionSnapshot' in journal and 'preferLiveSelection: false' in journal)
check('r2-journal-hasselection-label', 'var hasSelection = args.ContextMenuTarget.HasSelection;' in journal and 'var label = hasSelection ? "Add selection to Journal…" : "Add current place to Journal…";' in journal)
check('r3-search-selection-snapshot', 'SearchCockpitSelectionSnapshotAsync' in searchui and 'await contextSelectionSnapshot' in searchui)
check('r3-search-prefill-explicit-refresh', 'RefreshUniversalSearchResults(value, _universalSearchResults, _universalSearchStatus);' in searchui and 'Programmatic prefill' in searchui)
check('r2-context-tools-hook', 'AddPathfinderToolsContextMenu(context, e, contextSelectionSnapshot);' in main)
check('r2-native-more-tools-preferred', 'FindNativeMoreToolsSubmenu' in selector_ui and 'moreTools' in selector_ui and 'Pathfinder tools' in selector_ui)
check('r2-search-selection-menu', 'Search selection in Pathfinder…' in selector_ui and 'SearchCockpitSelectionSnapshotAsync(context, capturedFallback, contextSelectionSnapshot)' in selector_ui)
check('r2-selector-cockpit-menu', 'Open UWorld Selector for this cockpit' in selector_ui and 'OpenUWorldSelectorForCockpit' in selector_ui)
check('r2-selector-exact-slug-mapping', 'x.Slug.Equals(context.Subject.ResourceId' in selector_ui and 'recipe.Slug' in selector_svc)
check('r3-selector-consistent-visible-filter', 'Use one visible navigation rule for every cockpit' in selector_ui and '_uworldSelectorSearchBox.Text = context.Subject.ResourceId;' in selector_ui and 'mapped.Count == 1 ? mapped[0].Id : null' in selector_ui)
check('r2-root-journal-glossary-preserved', 'AddJournalContextMenu(context, e, contextSelectionSnapshot);' in main and 'AddGlossaryContextMenu(context, e);' in main)
check('r2-rich-text-still-deferred', 'RichEditBox' not in journal and 'InkCanvas' not in journal)

# Existing W3/W4 foundations retained.
host=read('MainWindow.CockpitHost.cs'); models=read('Models/CockpitHostModels.cs'); loc=read('MainWindow.Location.cs')
check('view-role-model', 'ReadOnlySecondary' in models and 'Primary' in models)
check('secondary-state-readonly', "data-pathfinder-view-role','read-only-secondary" in host and 'context.ViewRole != CockpitViewRole.Primary' in loc)
check('processfailed-recovery', 'Reload cockpit safely' in main and 'ProcessFailed' in main)
check('source-action-foundation', 'SourceActionDraft' in models and 'CaptureSourceActionDraftAsync' in host)

# Registry parity retained.
reg=json.loads((SRC/'ShellData'/'cockpit-state-allowlist.json').read_text())
check('cockpit-registry-24', len(reg.get('resources',{}))==24, str(len(reg.get('resources',{}))))
check('cockpit-registry-2607', sum(len(v) for v in reg.get('resources',{}).values())==2607, str(sum(len(v) for v in reg.get('resources',{}).values())))

# XML parse.
for rel in ['MainWindow.xaml','App.xaml','NivareQ.Step2Pathfinder.csproj']:
    try: ET.parse(SRC/rel); ok=True; detail=''
    except Exception as e: ok=False; detail=str(e)
    check('xml:'+rel,ok,detail)

# C# lexical balance (comments/strings stripped; not a substitute for Windows compile).
def strip_cs(s):
    out=[]; i=0; n=len(s); state='code'; raw_quotes=0
    while i<n:
        if state=='code':
            if s.startswith('//',i): state='line'; out.extend('  '); i+=2; continue
            if s.startswith('/*',i): state='block'; out.extend('  '); i+=2; continue
            m=re.match(r'\$*"""',s[i:])
            if m: state='raw'; raw_quotes=3; out.extend(' '*len(m.group(0))); i+=len(m.group(0)); continue
            if s.startswith('@"',i): state='verbatim'; out.extend('  '); i+=2; continue
            if s[i]=='"': state='string'; out.append(' '); i+=1; continue
            if s[i]=="'": state='char'; out.append(' '); i+=1; continue
            out.append(s[i]); i+=1
        elif state=='line':
            if s[i]=='\n': state='code'; out.append('\n')
            else: out.append(' ')
            i+=1
        elif state=='block':
            if s.startswith('*/',i): state='code'; out.extend('  '); i+=2
            else: out.append('\n' if s[i]=='\n' else ' '); i+=1
        elif state=='string':
            if s[i]=='\\' and i+1<n: out.extend('  '); i+=2
            elif s[i]=='"': state='code'; out.append(' '); i+=1
            else: out.append('\n' if s[i]=='\n' else ' '); i+=1
        elif state=='verbatim':
            if s.startswith('""',i): out.extend('  '); i+=2
            elif s[i]=='"': state='code'; out.append(' '); i+=1
            else: out.append('\n' if s[i]=='\n' else ' '); i+=1
        elif state=='raw':
            if s.startswith('"""',i): state='code'; out.extend('   '); i+=3
            else: out.append('\n' if s[i]=='\n' else ' '); i+=1
        elif state=='char':
            if s[i]=='\\' and i+1<n: out.extend('  '); i+=2
            elif s[i]=="'": state='code'; out.append(' '); i+=1
            else: out.append(' '); i+=1
    return ''.join(out),state
lex=[]; files=list(SRC.rglob('*.cs'))
for path in files:
    t,state=strip_cs(path.read_text(encoding='utf-8'))
    if state!='code': lex.append(f'{path.name}: ended {state}')
    for a,b in [('(',')'),('[',']'),('{','}')]:
        dep=0
        for ch in t:
            if ch==a: dep+=1
            elif ch==b:
                dep-=1
                if dep<0: break
        if dep!=0: lex.append(f'{path.name}: {a}{b}={dep}')
check('all-csharp-lexical-balance',not lex,'; '.join(lex[:30]))

passed=sum(1 for _,ok,_ in checks if ok)
# Post-Astra closure blockers and bounded repairs.
restore=(SRC/'Services/RestoreTransactionService.cs').read_text(encoding='utf-8')
check('closure-json-casing', 'JsonSerializer.Deserialize<CockpitStateMessage>(text, LocationJsonOptions)' in host)
check('closure-live-selection-valid-literal', 'const string script = @"(()=>{const clean=' in host and "replace(/\\r\\n?/g,'\\n')" in host)
check('closure-journal-tail-boundary', 'FileMode.OpenOrCreate' in js and 'stream.Seek(-1, SeekOrigin.End)' in js and "lastByte != (byte)'\\n'" in js)
check('closure-mutation-block', 'MutationsBlocked' in restore and 'RequireMutationAllowed' in restore and 'SetMutationBlock' in restore)
check('closure-commit-blocked-recovery', 'Cannot start a new restore/reset transaction while interrupted recovery is unresolved' in restore)
check('closure-service-write-fences', all('RequireMutationAllowed' in (SRC/x).read_text(encoding='utf-8') for x in ['Services/SettingsService.cs','Services/PersonalStudyService.cs','Services/BackupExtensionStore.cs','Services/CockpitStateService.cs','Services/UWorldSelectorService.cs','Services/JournalService.cs']))
check('closure-current-primary-writer', 'IsCurrentPrimaryCockpitWriter' in host and 'ReferenceEquals(registered, context)' in host)
check('closure-snapshot-postawait-recheck', 'context.ContentGeneration != generation' in host and '!ReferenceEquals(webView, context.WebView)' in host)
location=(SRC/'MainWindow.Location.cs').read_text(encoding='utf-8')
check('closure-location-fence', 'RestoreTransactionService.MutationsBlocked' in location and 'ReferenceEquals(registered, context)' in location and 'IsLocationRequestCurrent(context, request)' in location)
check('closure-split-selector-whitelist', 'LastWorkspaceSecondaryId.Equals("UWorld Selector"' in backup)
check('closure-pwa-nested-strict', 'EnsureOnlyProperties(extension, "PwaState.CockpitStudyState"' in backup and 'EnsureOnlyProperties(extension, "PwaState.Journal"' in backup and 'EnsureOnlyProperties(item, label' in backup)
selector_ui=(SRC/'MainWindow.UWorldSelector.cs').read_text(encoding='utf-8')
check('closure-selector-reset-routes-data-settings', 'private Task ResetUWorldSelectorReportsAsync()' in selector_ui and 'OpenSettings("data")' in selector_ui)
check('closure-restore-precommit-suspend', '_suspendCockpitPositionPersistenceUntilRestart = true;' in pers and '_suspendCockpitStatePersistenceUntilRestart = true;' in pers and 'RestoreTransactionService.Commit' in pers)
check('closure-reset-precommit-suspend', '_suspendCockpitPositionPersistenceUntilRestart = true;' in settings and '_suspendCockpitStatePersistenceUntilRestart = true;' in settings and 'RestoreTransactionService.Commit' in settings)
check('closure-restored-tab-index', 'var restoredTabs = new List<TabViewItem>();' in main and 'var safeIndex = Math.Clamp(selectedIndex' in main and 'Tabs.SelectedItem = restoredTabs[safeIndex];' in main)
check('closure-journal-editor-reconcile', '_journalEditorSession = null;' in pers and 'RefreshJournalWorkspace();' in pers and '_journalEditorSession = null;' in settings and 'RefreshJournalWorkspace();' in settings)

result={
    'w2a_base_passed':base.get('passed',0),
    'w8_checks_passed':passed,
    'combined_passed':base.get('passed',0)+passed,
    'failed':len(errors),
    'medical_files':base.get('medical_files',132),
    'resources':base.get('resources',25),
    'cockpit_state_resources':len(reg.get('resources',{})),
    'cockpit_state_keys':sum(len(v) for v in reg.get('resources',{}).values()),
    'csharp_files':len(files),
    'errors':errors
}
(ROOT/'docs'/'W8-CLOSURE-R1-STATIC-QC-RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
sys.exit(1 if errors else 0)
