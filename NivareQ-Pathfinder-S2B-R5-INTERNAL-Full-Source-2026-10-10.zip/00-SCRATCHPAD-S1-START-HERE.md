# NivareQ Step 2 Pathfinder — Scratchpad S1 TEST, CI-Corrected Source R2
Date: 2026-10-09

**Status: UNACCEPTED Windows TEST candidate**, version 1.2.2. Owner-accepted v1.2.1 Stable is unchanged and authoritative. Public-Impact G0 remains paused.

This self-contained full source package carries the accepted v1.2.1 source read-only, the S1 Scratchpad candidate, and the three bounded CI-proven corrections described in `SCRATCHPAD-S1-DOCS/CI-BUILD-CORRECTIONS-R2.md`. It supersedes the *source packaging only* of the uncompiled S1 initial candidate; it is not owner acceptance.

Scratchpad S1: lower-left Scratchpad button replaces Guide (top-bar Guide remains), tool tab with Split View, separate text/drawing modes with selection and copy/paste plus pointer pen/eraser, named pads with pages, writing lines, adjustable guide spacing, one/two/four writing spaces, autosave and canonical backup integration. No cockpit or medical edits.

Windows local builder: double-click `BUILD-SCRATCHPAD-S1-LOCALLY.cmd` with .NET 10 SDK and Inno Setup 6.7+ or 7 installed. GitHub is not needed locally. Never test install over accepted Stable without exporting and verifying a canonical backup first; strongly prefer a VM or separate Windows user.

The authoritative v1.2.1 source is included byte-for-byte at `AUTHORITY/ACCEPTED-v1.2.1-STABLE-SOURCE-READ-ONLY.zip`. All file hashes are listed in `INTEGRITY-S1-MANIFEST.json`. No acceptance or deployment is implied by successful compilation.
