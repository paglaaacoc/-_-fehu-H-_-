@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "PROJECT=%CD%\src\NivareQ.Step2Pathfinder\NivareQ.Step2Pathfinder.csproj"
set "ART=%CD%\artifacts"
set "ISCC="

if exist "%ProgramFiles%\Inno Setup 7\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 7\ISCC.exe"
if not defined ISCC if exist "%ProgramFiles(x86)%\Inno Setup 7\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 7\ISCC.exe"

if not defined ISCC (
  echo Inno Setup 7 was not found. Attempting a quiet install using winget...
  where winget >nul 2>nul
  if errorlevel 1 goto :NOINNO
  winget install --id JRSoftware.InnoSetup.7 -e --silent --accept-package-agreements --accept-source-agreements
  if errorlevel 1 goto :NOINNO
  if exist "%ProgramFiles%\Inno Setup 7\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 7\ISCC.exe"
  if not defined ISCC if exist "%ProgramFiles(x86)%\Inno Setup 7\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 7\ISCC.exe"
)
if not defined ISCC goto :NOINNO

if exist "%ART%\publish-x64" rmdir /s /q "%ART%\publish-x64"
if not exist "%ART%\installers" mkdir "%ART%\installers"
mkdir "%ART%\publish-x64" || exit /b 1

echo.
echo [1/2] Publishing the accepted R2 application for x64...
dotnet publish "%PROJECT%" -c Release -r win-x64 --self-contained true -o "%ART%\publish-x64"
if errorlevel 1 exit /b 1

echo.
echo [2/2] Compiling Installer I1 x64...
"%ISCC%" "%CD%\installer\Pathfinder-x64.iss"
if errorlevel 1 exit /b 1

set "SETUP=%ART%\installers\NivareQ-Step2-Pathfinder-I1-Setup-x64.exe"
if not exist "%SETUP%" (
  echo ERROR: Expected installer was not created.
  exit /b 1
)

echo.
echo === INSTALLER I1 x64 READY ===
certutil -hashfile "%SETUP%" SHA256

echo.
echo Launching the x64 installer now...
start "" "%SETUP%"
exit /b 0

:NOINNO
echo.
echo ERROR: Inno Setup 7 could not be found or installed automatically.
echo Install Inno Setup 7, then run this file again.
exit /b 1
