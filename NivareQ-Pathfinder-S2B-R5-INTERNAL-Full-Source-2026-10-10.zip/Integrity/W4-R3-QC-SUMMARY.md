# W4 R3 static/source QC summary

- W4 inherited + R3-specific static gate: **977 PASS / 0 FAIL**.
- Frozen medical payload: **132 / 132 exact**.
- Resource registry: **25 resources**.
- Canonical cockpit-state registry: **24 resources / 2607 exact allowed keys**.
- C# lexical-balance gate: pass across **39 C# files**.
- XML parse gate: MainWindow.xaml, project file and App.xaml pass.
- Source differential from W4 R2: **5 files**, consisting of one Split View implementation file plus four candidate/backup-producer identity files.
- Frozen MedicalPayload source differential: **0 files**.
- This environment does **not** provide the Windows/.NET WinUI compile path; no real Windows compile or runtime claim is made.
- Owner real-Windows test is mandatory, especially the R2 stale-placeholder reproduction sequence.
