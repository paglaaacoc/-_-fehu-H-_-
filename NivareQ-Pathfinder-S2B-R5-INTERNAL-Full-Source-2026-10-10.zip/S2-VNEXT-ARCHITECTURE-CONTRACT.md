# Scratchpad S2 — implementation design for scalable storage and complete archives

**Design status:** Proposed implementation contract accepted in principle; requires Windows CI and fault-injection confirmation before any owner-test release. The initial S2-A patch is NOT a release candidate.

## Data ownership and transaction model

Use a native `ScratchpadStoreV2` service with SQLite metadata plus content-addressed binary image files. SQLite transactions preserve pads, pages, cells, ink and image-object metadata; actual image bytes are stored separately, never included in the browser's routine autosave JSON. A browser insertion first writes/verifies an image blob, then acknowledges its SHA-256 reference to the renderer, which can persist the new object. If a blob is written but no note ever references it, it may be garbage collected only during a verified maintenance pass. No error should mark an unsaved image as saved.

### Proposed logical schema

- `meta(key, value)` — schema version and active-pad identifier
- `pads(id, title, active_page_id, ordinal, updated_utc)`
- `pages(id, pad_id, guide, spacing, ordinal)`
- `cells(page_id, ordinal, text, strokes_json, image_objects_json)`
- image objects include `{id, blobSha256, mime, x, y, width, height, zIndex}` with bounded finite normalized coordinates; no executable HTML
- attachments are immutable content-addressed blobs in `Scratchpad/generations/<generation-id>/attachments/`, SHA-256 on bytes, allowlisted image formats, dimension/pixel safeguards and deduplication

The browser editor may post JSON for the current page and collection metadata, but native persistence must use targeted SQLite operations, not rewrite a monolithic user-data JSON file on every debounce. Design for thousands of pads/pages/images; retain practical sanity caps for malformed inputs rather than arbitrary whole-library 1GB/5GB ceilings.

## Atomicity across global Pathfinder data and Scratchpad binary data

**Prefer generational Scratchpad storage with a single atomic pointer in an existing provider** over modifying the trusted `RestoreTransactionService.Commit()` mechanism to swap thousands of files individually.

- Store the active generation identifier under a validated new preserved-extension key (e.g. `nivareq.scratchpad.activeGeneration.v2`). It is a small ASCII UUID-like token, not an arbitrary filesystem path.
- Normal saves write only within the active SQLite/attachment generation.
- Before restore, completely extract and validate a *new* generation under a temporary, non-active directory; verify its SQLite database and every referenced SHA-256 attachment, then finalize that generation read-only until activation.
- `RestoreTransactionService.Commit()` already atomically updates all Pathfinder's bounded *text* providers with restart-time rollback journal recovery. Include the new generation pointer within its preserved-extension target along with settings, My Study, Journal, UWorld and cockpit state. The transaction changes a small pointer only, never multi-GB data.
- A crash before pointer commit leaves an orphan staged generation; old notes remain active. A crash during the text-provider commit is rolled back by the existing journal. A commit success activates only an already-verified generation. Old generation files are preserved for rollback and can be collected later through an explicit audited cleanup procedure, never on the first restore.
- Any manual deletion/partial disk failure involving an active generation must disable saving or restore and report a health fault; never invent an empty library or overwrite preserved live data.

**Important remaining proof obligation:** a normal writer must not continue mutating a generation after the restore pointer changes. Block mutations until clean restart as the existing global restore already does, and keep an application-level writer gate. Require concurrent-save/restore fault tests.

## Backup VNext format

A versioned `.nqpfbackup` ZIP64 archive with `manifest.json`, `pathfinder-state.json` (strict canonical Windows provider contract), `scratchpad.sqlite` (SQLite consistent backup snapshot), and `attachments/<sha256>.<allowlisted extension>`. UTF-8 entry names, stable paths, deterministic manifests, independent checksums and sizes of every entry. Never load images or the full ZIP into RAM. Use buffered streams with checkpoints and progress indicators.

Backup creation: flush latest scratch edits and normal providers -> generate a consistent SQLite snapshot -> enumerate immutable referenced attachments -> precheck files/free space -> write temp ZIP to the user-selected destination -> reopen/re-stream verify every entry -> publish with an atomic replace/rename only after verified. During long backup, block or snapshot concurrent mutations so provider/text and Scratchpad states represent a coherent point in time; reject and retry if epoch changes. Do not blindly trust a previously completed save status in the WebView.

Restore: treat archive as untrusted. Reject duplicate/case-colliding entry names, traversal/absolute paths, symlinks, unsupported compression, oversized manifests, suspicious expansion ratios or decompression counts; enforce a maximum entries policy and per-asset dimension/size checks rather than a total ~100MB cap. Stream verify all hashes, and first parse the canonical Windows study provider plan using existing strict validators. Then create a staged SQLite+blobs generation and verify relational/image integrity. Confirm user consent, acquire a global mutation gate, stage all standard text files using the existing transaction, and commit the new Scratchpad generation pointer in the same journal-protected transaction. Block old views from writing after restore and require restart. Error/cancellation before commit must leave old active generation and providers intact.

## Upgrade and reset

- S1 live Scratchpad legacy extension data must migrate into a new generation after a verified recovery snapshot. Never auto-delete the old extension key in the same operation unless a durable rollback copy remains. Migration must be idempotent after crash/restart; verify counts, text, ink, pad IDs and page IDs.
- Older `.json` import is *not required* by owner, but the existing live v1.2.1 study providers remain supported. Clearly label any discontinued import behavior in the UI; keep S1 data migration separate from old-file import.
- Protected reset requires an independently verified *complete* `.nqpfbackup` (study data + images) before deletion. If reset removes any generations or binary data, it requires the same recovery discipline as restore; the old 100 MB JSON confirmation must not be treated as sufficient.
- Windows remains master truth; PWA untouched.

## Theme, text and image UX (owner scope)

- Palette only around the writing page, not the paper; preserve white/off-white and dark ink. No cockpit CSS injection.
- Synchronize CSS ruled guide background with textarea scrollTop; baseline offset must be calibrated at 24/32/44/60 px spacing, repeated in one/two/four spaces and Split View. Handwriting is spatial ink, not a paragraph-anchored Word feature.
- `Type / Paste` retains plain-text semantics and clipboard shortcuts; image-containing Ctrl+V inserts an object only when image present; normal text clipboard must remain unchanged.
- `Draw / Pen` keeps full pointer behavior, supports drawing over displayed images.
- `Arrange` enables pointer/touch selection/moving/resizing, large handles and a small context/action menu. No implicit image loss on reducing writing spaces.
- Dedicated `Paste Image` control for touch, with a native clipboard fallback if browser clipboard permissions fail and an optional file-picker fallback. Clipboard never automatically uploads anywhere; no cloud.
- **Rich HTML paste is deferred** because untrusted HTML/rich editor history creates a much larger editor and security surface. No Word-style inline image wrapping in S2.

## Acceptance matrix, before S2 R1 candidate

1. Source diff proves 132/132 medical files and their hashes unchanged and identifies every altered shell/provider file.
2. Complete S1->S2 migration for multi-pad, mixed text/ink, non-default guides, plus interrupted migration recovery.
3. Typing/selection/copy-paste, mixed image/text, persistent resize and position, touch long-press, stylus and pen at 125% scaling and Split View.
4. Theme cycling through all enabled themes with fixed legible paper and high-contrast behavior; cold restart preserves theme and data.
5. Backups at 1GB, 5GB and >4GB sparse/synthetic test inputs, plus corrupted manifest/image, zip bomb, out-of-space, mid-stream cancellation and forced crash during restore.
6. Invalid image must be rejected without erasing previous note, saved-status lying, malformed WebView2 messages or orphan file abuse.
7. Real Windows x64 and ARM64 CI, and user-device exploratory tests. No stable release without owner acceptance.
