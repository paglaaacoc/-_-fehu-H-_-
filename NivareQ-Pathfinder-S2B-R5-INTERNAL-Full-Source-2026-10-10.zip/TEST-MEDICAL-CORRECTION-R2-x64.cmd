@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\build-windows.ps1" -Arch x64
if errorlevel 1 (
  echo.
  echo W8 MEDICAL CORRECTION R2 BUILD FAILED. Read the message above or newest Build Logs file.
  pause
  exit /b 1
)
set "APP=%~dp0Built Apps\NivareQ Step 2 Pathfinder - x64\NivareQ.Step2Pathfinder.exe"
if not exist "%APP%" (
  echo Built app was not found at:
  echo %APP%
  pause
  exit /b 1
)
echo.
echo Launching Pathfinder W8 Medical Correction R2...
start "" "%APP%"
exit /b 0
