@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\build-windows.ps1"
pause
