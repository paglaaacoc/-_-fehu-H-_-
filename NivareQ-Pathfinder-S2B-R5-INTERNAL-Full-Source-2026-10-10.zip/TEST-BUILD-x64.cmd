@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\build-windows.ps1" -Arch x64
if errorlevel 1 (
  echo.
  echo W8 CLOSURE R1 BUILD FAILED. Read the message above or the newest file in Build Logs.
  pause
  exit /b 1
)
set "APP=%~dp0Built Apps\NivareQ Step 2 Pathfinder - x64\NivareQ.Step2Pathfinder.exe"
if not exist "%APP%" (
  echo Built app was not found at:
  echo %APP%
  pause
  exit /b 1
)
echo.
echo Launching Pathfinder W8 Closure R1 - Astra Closure Candidate...
start "" "%APP%"
exit /b 0
