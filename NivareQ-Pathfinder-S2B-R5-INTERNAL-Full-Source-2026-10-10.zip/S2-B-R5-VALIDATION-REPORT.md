# S2-B R5 — Native Release Boundary / Data-Loss Regression Report

## Finding

In R4, `switchTo()` and `close()` performed `await flush(); await releaseNative(); then change current page`. User edits occurring after `flush()` completed but while native `release` remained unresolved were accepted and incremented a local dirty counter. On a successful release ACK, the current page was replaced without persisting those later edits. This is a potential silent local draft loss on rapid editing/navigation.

## Correction

- `NotesDraftCoordinator._transition()` serializes navigation and close. It retains all edits throughout the initial save; if a late edit arrives before release, it re-flushes.
- A synchronous `c.releasing = true` fence is installed before awaiting native release, and `edit()` and `flush()` reject while the fence is active. `status.transitioning` exposes this state so a future WebView2 UI can disable typing/navigation.
- Native release failure never moves to the target page and retains the entire current draft/error. An explicit retry is necessary. Concurrent switches are rejected.
- Image IDs and z-index checked against native bounds, and stable binary ordering replaces locale-dependent tie sort.

## Proof collected (not a native build)

- 52 Node protocol assertions: PASS. They include deferred-release edit rejection, concurrent close rejection, failed-release retained draft and explicit retry, and consistent image bounds/order.
- New regression assertion fails against R4 coordinator (before fix) at the `transitioning` gate.
- 8 Python SQLite smoke assertions: PASS.
- 22 SQL/static assertions: PASS.
- R3, R4 and R5 cross-language static guards: PASS.
- CI transfer preflight: the R5 helper includes `ci/`, which an R3 static check references. Omitting it would cause an avoidable CI failure.
- Native .NET compilation/run: NOT EXECUTED (SDK unavailable); WinUI x64 and ARM64: NOT EXECUTED.
- Existing S1 persistent bridge: UNCHANGED. Medical payload: 132/132 unchanged.

## Critical integration requirement

The application must freeze actual editor inputs **before and throughout** native release, and cannot silently ignore edit exceptions. The coordinator is not wired to the live WebView2 editor. This checkpoint is an internal safety slice, not a shippable feature or evidence that native/backup activation is safe.
