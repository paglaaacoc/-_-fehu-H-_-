# W2D R2 — Extremely Easy Windows Test

Use the lightweight TEST ZIP.

## 1. Build + launch
Double-click:

`TEST-W2D-x64.cmd`

Expected before publish:
- medical payload integrity PASS: 132/132;
- source resource registry PASS: 25 resources / canonical+legacy aliases;
- W2D static QC PASS;
- .NET 10 SDK gate PASS;
- short-path staging under `%TEMP%\NQPF-W2D-Build`.

Confirm the running app says:

**W2D R2 CANDIDATE**

## 2. Sidebar closure
Scroll low in the Study library and click/tap 17–22, Clinical Recall and UWorld in mixed order.

**Required:** the sidebar must remain full-width and must not reproduce the old horizontal shrink/collapse rendering defect.

R2 also tries to preserve the exact vertical scroll position on pointer/touch activation. Report whether the late-list position jump is gone. If a small self-correcting vertical jump remains but the rendering/shrink defect stays fixed, report it; the owner has allowed that cosmetic residue to be deferred rather than consume repeated builds.

## 3. First-open Search → Go → Return
Choose a cockpit with a known saved resume position, close its tab, then:
1. Search for a different source inside that cockpit.
2. Click **Go to cockpit** directly from Search.
3. Verify the cockpit opens at the source.
4. Verify **Return to previous position** appears on this first open.
5. Click Return and confirm the saved study position comes back.

Then repeat while the cockpit is already open. Both paths should behave coherently.

If a cockpit has genuinely never had a saved position, no Return bar is expected on its first source open.

## 4. Study Time cleanup
Confirm there is **no permanent Time button in the top bar**.

Open **My Study** and find **Study planning & time estimates**.
- whole-suite totals should wrap cleanly;
- expand **View all subject estimates**;
- no horizontal flyout scrollbar should be required.

## 5. W2D shell/settings regression
Quickly confirm:
- My Study / Settings / Guide remain app surfaces;
- Search remains a tool tab;
- Aa routes to Settings → Accessibility & display;
- Settings → Data, backup & reset still opens;
- one canonical backup can still be created.

## 6. W2C regression
One quick Search → Preview source → Go to cockpit → Return check.

## Report
A compact report is enough:
- Build/launch: PASS/FAIL
- Sidebar no shrink/collapse: PASS/FAIL
- Sidebar vertical offset: PASS/FAIL/still minor
- First-open Search Go/Return: PASS/FAIL
- Time removed + My Study planning: PASS/FAIL
- Settings/backup: PASS/FAIL
- W2C Preview/Go/Return: PASS/FAIL
- Any screenshot/odd behavior
