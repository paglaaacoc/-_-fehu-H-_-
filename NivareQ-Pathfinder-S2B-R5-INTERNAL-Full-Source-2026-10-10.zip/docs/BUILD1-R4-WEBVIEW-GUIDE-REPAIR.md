# NivareQ Step 2 Pathfinder — Build 1 R4
## Cockpit Loading + Study Manual Repair

Date: 2026-09-25

This is a bounded Build 1 repair. It does not change audited medical content.

## Real-Windows finding that triggered R4
Build 1 R3 launched successfully on x64. The native shell, nine themes, Focus behavior, and Time panel were operational, but study tabs were blank: tabs were created while the actual frozen cockpit pages did not render.

The user also correctly identified that the Guide was too shallow. It explained app navigation but did not adequately teach a new user how to use the actual cockpit controls or how to turn the material into a learning workflow.

## R4 cockpit-loading repair
R4 replaces the fragile deep-path/.local content route with an on-demand byte-exact runtime content cache:

- Bundled authoritative `MedicalPayload` stays untouched.
- When a subject is opened, Pathfinder copies only that subject's main HTML/PDF byte-for-byte into a short LocalAppData runtime folder.
- The copied file is SHA-256 compared to the bundled source before navigation continues.
- Each subject gets its own reserved `.pathfinder.invalid` virtual origin.
- WebView2 navigates with `CoreWebView2.Navigate(...)`, following Microsoft's virtual-host mapping pattern.
- Per-subject origins isolate WebView2 storage between cockpits.
- Native Edge/WebView2 pinch zoom and pan remain untouched.
- Navigation failures now show the actual WebView2 error status instead of silently producing a blank study area.
- WebView2 process failure now produces a visible shell error message rather than an unexplained empty tab.
- The app manifest opts into long-path awareness for source-copy robustness.

No cockpit HTML is rewritten, injected into, normalized, renamed in the authoritative payload, or regenerated.

## Guide / Study Manual repair
The native Guide has been expanded into a real Study Manual. It now explains:

- how to approach a new/weak subject;
- how to approach a familiar subject;
- active-recall behavior inside a cockpit;
- Start;
- Decoder / Question moves;
- Study map;
- Topics;
- Patterns;
- specialized recognition areas such as ECG, Murmurs, Localize, Signs, Formula lab, Screening, Bias, Abstracts, and Calculators;
- One-step deeper;
- Drills / Practice;
- Rapid review / Cram;
- Sources;
- Full Study / Full / Full Repair;
- 60-second Recall / Recall only;
- Focused / Focused A-priority;
- the difference between Pathfinder Focus and a cockpit Focused mode;
- Print where present;
- an actionable Pathfinder + UWorld/AMBOSS learning loop;
- how to review incorrect, guessed, and slow questions;
- how to diagnose knowledge vs discrimination vs process errors;
- how to transition from targeted to mixed blocks;
- same-day, 1–3 day, and later review behavior;
- how to use Time estimates without turning them into deadlines;
- app tabs, touch, themes, progress, and navigation;
- common unhelpful study patterns to avoid.

This manual is shell documentation only and does not edit audited teaching content.

## Build-script QoL
The Windows build script now checks for an actual .NET 10 SDK, not merely the presence of a `dotnet` executable. A machine with only a runtime gets a clean actionable message before publish begins.

## Required Windows retest
1. Build x64 + ARM64.
2. Launch x64.
3. Open Cardiology: actual cockpit text/UI must render.
4. Open Pulmonary and Renal in separate tabs.
5. Back/Forward across subjects.
6. Change several themes while a cockpit is open.
7. Test Focus while a cockpit is visible.
8. Open Time.
9. Open Guide and verify the expanded Study Manual.
10. On a touch device, verify native pinch zoom + pan remains unchanged.
11. If an ARM64 machine is available, launch the ARM64 build natively.
