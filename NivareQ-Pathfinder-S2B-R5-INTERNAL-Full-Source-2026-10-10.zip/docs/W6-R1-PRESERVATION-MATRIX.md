# W6 R1 Preservation Matrix

- Base: **W5 R4 owner-accepted**.
- Runtime/source differential: **13 files**.
- MedicalPayload differential: **0 files**; all 132 frozen files remain exact.
- Canonical backup advances from schema 6 to **schema 7** solely to add first-class Native UWorld Selector state.
- W5 Search boundary behavior, optional/static Split View and Journal workflows are carry-forward requirements.
- Existing printable UWorld selector PDF remains a separate resource.
- Native Selector catalog is statically checked for exact 26-recipe + 22-system parity with the accepted PWA B4A Selector reference.
- No UWorld account/API/scraping automation is introduced.
- Journal Pen Scratchpad Gate stays **CLOSED / DEFERRED / owner decision required**.
