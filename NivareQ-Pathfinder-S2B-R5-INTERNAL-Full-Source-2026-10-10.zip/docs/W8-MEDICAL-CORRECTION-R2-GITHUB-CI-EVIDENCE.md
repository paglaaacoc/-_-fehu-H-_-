# W8 Medical Correction R2 — GitHub CI evidence

Repository: `tanzim137/RAM-TEST` (private)  
Branch: `pathfinder-w8-medical-correction-r2`  
Final CI commit: `bb420689da49fc8634fd17efcfa0c77f7c0a4b14`  
GitHub Actions run: **17** / run ID `37321988835`  
Conclusion: **SUCCESS**

## Exact-source gate
- R2 compile-source manifest: **49/49 source/project files exact**.
- The compact closure transport is reconstructed, then the exact R2 `PathfinderLocation.cs` bytes are installed and verified against the R2 manifest before compilation.

## Compilation
- win-x64 self-contained publish: **PASS**
- win-arm64 self-contained publish: **PASS**

## Recorded hashes
- x64 EXE: `59715d7e58dd00641bd37db3035201401e76dcbf06b36bdbe39420eba3974c79`
- x64 application DLL: `ec10e6ed4df59ff89cc69087e8d2cd1bf1e67550a71fa26ccbf6e1ece584796b`
- ARM64 EXE: `0556e0bed83dfa59ca3657f0daa2bd20af47c6e843d5430d954187f2e1454adb`
- ARM64 application DLL: `5a82feff8a25259e242148932928900569fbd2aecd29dd354fb41b30d665dc07`

The EXE hashes are unchanged apphost stubs; the application DLL hashes record the compiled R2 application code.

## Artifact note
Run 16 also passed exact-source verification and both publishes but was marked failed only when `actions/upload-artifact` hit the repository artifact-storage quota. Run 17 intentionally removed artifact upload and preserved compile evidence in the Actions log, producing a fully green CI result without changing R2 application source.
