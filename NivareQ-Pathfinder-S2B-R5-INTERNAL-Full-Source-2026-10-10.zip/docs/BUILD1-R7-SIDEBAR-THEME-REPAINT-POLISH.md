# Build 1 R7 — Sidebar Theme Repaint + Accelerator Hint Polish

## Scope

R7 is a **shell-only cosmetic/interaction repair** on top of the real-Windows-working R6 build.

The user reported that R6 now loads and keeps the cockpit HTML visible correctly and that runtime cockpit theming works. The remaining issue is confined to the Pathfinder sidebar and a Windows keyboard-accelerator affordance.

## Real-Windows observations carried into R7

1. Cockpit visibility/layout: **PASS** in R6.
2. Runtime Pathfinder-to-cockpit theme bridge: **PASS** in R6.
3. Subject cards: individual card/tile structure is desired and retained.
4. Subject-card visual defect: after switching a custom theme, the already-realized card fill can keep the prior theme color. A cold start paints the correct theme.
5. Hover feedback: R6's opaque subject-card fill visually hides the nicer native ListViewItem hover/selection treatment.
6. Accelerator affordance: a floating `Alt + Left` hint is unwanted.

## R7 repair

### Subject cards

- Keep every subject as a separate bordered card/tile inside its group.
- Change the card's main fill to **Transparent**.
- Keep the themed outline, accent stripe, title/subtitle, and study-time badge.
- Because the card no longer places an opaque panel over the ListViewItem, native hover/selection feedback can remain visible.

### Immediate theme repaint

R6 replaced entries in `RootGrid.Resources` with a new `SolidColorBrush` on every theme switch. Existing realized controls can retain a reference to the old brush object, especially when switching between two custom themes with the same WinUI light/dark `RequestedTheme`.

R7 keeps a stable local `SolidColorBrush` object for each overridden shell resource and changes that brush's `Color` in place. Any existing control that already holds the resource brush therefore receives the new color immediately without requiring a restart or template re-creation.

### Remove the floating accelerator hint, keep the shortcut

`RootGrid.KeyboardAcceleratorPlacementMode="Hidden"` suppresses WinUI's automatic on-screen keyboard-accelerator presentation. The registered accelerators themselves are unchanged:

- `Alt+Left` = Back
- `Alt+Right` = Forward
- `Ctrl+W` = close tab
- `Ctrl+T` = new/home tab
- `F11` = fullscreen
- `Esc` = exit fullscreen when applicable

Back/Forward button tooltips are simplified to `Back` and `Forward`.

## Explicit non-changes

- No medical HTML/JSON/PDF/content file changed.
- R6 TabView/WebView layout repair is preserved.
- R4/R6 runtime-only cockpit theme bridge is preserved.
- No custom zoom/pan behavior added.
- No changes to Focus, Time, Guide, fullscreen, or native tabs.
