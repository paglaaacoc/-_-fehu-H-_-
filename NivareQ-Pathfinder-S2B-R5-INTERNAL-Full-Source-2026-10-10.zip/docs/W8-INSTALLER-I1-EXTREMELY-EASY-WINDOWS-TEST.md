# W8 Installer I1 — extremely easy Windows test

I1 is installer/uninstaller work only. Do not repeat the medical audit or old W8 runtime adversarial suite.

## A. Start clean
For the cleanest installer-era test, close Pathfinder and manually purge old beta data only if you intend to start fresh:
`%LOCALAPPDATA%\NivareQ\Step2Pathfinder`
Also remove old extracted beta copies/shortcuts so you do not launch the wrong EXE.

## B. Build the installers
Double-click `BUILD-INSTALLER-I1.cmd`.
PASS if both installer EXEs appear in `artifacts\installers`.

## C. Fresh x64 install
Run `NivareQ-Step2-Pathfinder-I1-Setup-x64.exe`.
PASS if:
- setup identifies Pathfinder correctly;
- it installs without requiring admin rights;
- Pathfinder appears in Windows Settings > Apps > Installed apps;
- Start Menu entry exists;
- Pathfinder launches normally from the installed shortcut.

Create a tiny amount of disposable study data: change one study state and add one short Journal entry.

## D. Upgrade-in-place
Run the same x64 installer again.
PASS if it behaves as an update/reinstall to the same application rather than creating a second Pathfinder installation, and your disposable study data remains present afterward.

## E. Normal uninstall — KEEP DATA
Uninstall Pathfinder from Windows Settings > Apps > Installed apps.
Choose **Keep my Pathfinder study data (recommended)**.
PASS if the app is removed but this folder still exists:
`%LOCALAPPDATA%\NivareQ\Step2Pathfinder`

Reinstall with the x64 installer.
PASS if the preserved disposable study data returns.

## F. Destructive uninstall — REMOVE DATA
Uninstall again.
Choose the permanent-remove option.
PASS if a second large warning appears and removal is blocked until you type exactly:
`REMOVE MY PATHFINDER DATA`

First intentionally type something wrong.
PASS if deletion is refused.
Then enter the exact phrase and continue.
PASS if uninstall completes and this folder is gone:
`%LOCALAPPDATA%\NivareQ\Step2Pathfinder`

## G. Clean reinstall after destructive uninstall
Install x64 once more.
PASS if Pathfinder behaves as a genuinely fresh first run with none of the disposable data restored.

That is enough for I1 on the x64 owner-test PC. ARM64 compilation is CI-gated separately; real ARM64 lifecycle testing can remain for Installer I2/final closure unless you have an ARM64 Windows device immediately available.
