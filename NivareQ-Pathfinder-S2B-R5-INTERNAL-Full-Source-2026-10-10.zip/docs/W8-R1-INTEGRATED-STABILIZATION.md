# W8 R1 — Integrated Windows Stabilization / Personal-Friend Release Gate

## Purpose
W8 R1 is the final planned Windows integration gate before closure audit and stable-release cutting. It intentionally adds no new product feature surface.

## Runtime delta from accepted W7 R1
The intended runtime/source differential is release-candidate identity only:
- window/build identifier → W8 R1 Candidate;
- About/Settings build identifier → W8 R1 Candidate;
- canonical backup `ProducerBuild` → `W8-R1`;
- backup schema remains 7.

No medical file changes are authorized. No accepted Search/Journal/Split/UWorld/theme/accessibility behavior is intentionally redesigned.

## Stabilization targets
W8 owner testing should exercise the combined product rather than isolated new features:
- launch/single instance/offline cockpit loading;
- Search exact/partial behavior and source preview;
- Journal create/edit/search/source links/context-menu capture;
- static/optional Split View, deliberate Show beside/Swap/Return to tabs;
- UWorld Selector recipes/filter/navigation/manual counts;
- all 13 themes and accessibility/display options;
- session restore and workspace restoration;
- schema-7 canonical backup/restore and reset safety;
- supplemental cockpits 19–22 drill feedback;
- native touch/pinch/zoom/pan and keyboard accelerators;
- x64 publish/runtime and ARM64 publish path.

## Known accepted-deferred issue
Large/multi-block cockpit selection can still reach Journal only partially. The W7 runtime selection-cache attempt did not solve it. W8 R1 deliberately does not add another speculative runtime patch. The defect is a mandatory targeted item in the post-W8 Astra closure audit.

Short/ordinary selection capture must still work. Any regression beyond the already-known bounded defect fails W8.

## Remaining closure gates after W8 acceptance
1. App-wide Astra closure/release-readiness audit using `W8-R1-ASTRA-CLOSURE-AUDIT-PROMPT.txt`.
2. Mandatory Medical Content Audit / Re-review gate from the FULL continuity root.
3. Only bounded fixes/revisions justified by those audits.
4. Stable personal/friend release cut with complete source/continuity and easy x64 + ARM64 builders.

## Explicitly still deferred
- Journal Pen Scratchpad Gate — CLOSED / owner decision required.
- Journal rich-text storage — DEFERRED.
