# W7 R1 — Extremely Easy Real-Windows Test

## 1. Build
1. Extract the TEST ZIP to a normal local Windows folder.
2. Double-click **TEST-W7-x64.cmd**.
3. Build must succeed and the app must visibly say **W7 R1 CANDIDATE**.

Stop and report the first build/runtime error.

## 2. New themes
Open the top theme selector and confirm all old themes still exist plus:
- Sage Day
- Sunlit Apricot
- Ember Glow
- Twilight Bloom

Open a normal cockpit and switch through all four. Confirm shell + cockpit change together. Pay special attention to:
- Sage Day / Sunlit Apricot: comfortable daytime reading, not harsh white.
- Ember Glow: clearly brighter/warmer than Amber without neon glare.
- Twilight Bloom: low-light but colorful/cheerful rather than gloomy.

## 3. Home convenience
Open Home. Confirm **Continue & study snapshot** appears. After opening any cockpit, return Home and confirm it offers that recent cockpit plus My Study.

## 4. Split View polish
- Press **Ctrl+Alt+S**: Split View should open. Press again: it should close safely.
- Open Split again, put a view beside, drag the divider, then double-click or double-tap the divider. It should return to roughly **50/50** without changing which views are in the panes.
- Quick regression: Return to tabs and Swap panes still work.

## 5. Cockpits 19–22 drill feedback
Open any of Allergy + Immunology / ENT + Ophthalmology / Poisoning + Environmental / General Principles + Misc. Find a drill/quiz question and answer it. Confirm you can visibly tell:
- the correct option (**✓ Correct**), and
- if you chose incorrectly, your selected wrong option (**✕ Your choice**).
Explanation/reveal and saved answer behavior must still work. Try one light and one dark theme.

## 6. Deferred Journal selection repair attempt
In a normal Primary cockpit, select a visibly large passage spanning multiple bullets/paragraphs. Right-click → **Add selection to Journal…**. Confirm the note body captures the complete selected text as plain text (line breaks are fine).

If this is still partial, report it; W7 must not fake success. Rich-text formatting is intentionally not part of this build.

## 7. Quick W6/W5 regression
- More tools still contains Search selection in Pathfinder and Open UWorld Selector when mapped.
- Search selection shows results immediately.
- UWorld Selector still has 26 recipes/manual counts.
- Journal, Search, Split View and session restore open normally.
- Optional: create a schema-7 canonical backup and verify Restore can parse it.

## 8. Known watch item
If the late-library sidebar jumps vertically when opening resources near 19–22/Extras, report it. W7 R1 carries this as a low-severity watch and does not claim it fixed.

W7 R1 remains unaccepted until explicit owner acceptance after real-Windows testing. W6 R3 remains the accepted fallback.
