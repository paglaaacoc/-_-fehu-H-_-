# W8 Medical Correction R2 — minimal Windows acceptance test

This is a **narrow backup/reset regression test**. Do not repeat the full Closure R1 suite or the medical audit.

## Optional clean-beta start
If you want this machine clean before the installer era, first close Pathfinder and manually delete `%LOCALAPPDATA%\NivareQ\Step2Pathfinder` as previously discussed. This is optional for the R2 bug test; old beta compatibility is not a product requirement.

## Test
1. Extract the TEST ZIP to a normal short folder.
2. Double-click **`TEST-MEDICAL-CORRECTION-R2-x64.cmd`**.
3. Confirm the pre-build gates report **Medical payload integrity PASS: 132/132** and **Source resource registry PASS: 25 resources**.
4. Let Pathfinder launch. Open **Strategy** (or another cockpit), move/scroll enough that Pathfinder has a saved study position. Optionally create a bookmark as well. This intentionally exercises a `PathfinderLocation` inside canonical backup data.
5. Go to **Settings → Data, backup & reset → Create canonical backup**. Save a **fresh R2 backup**. Do not reuse the R1 backup that exposed the bug; R2 deliberately keeps the strict importer strict, so an old malformed beta backup may still be refused.
   - **PASS:** the backup saves/verifies normally.
   - **FAIL:** any complaint about `IsStrictSource`, `HasDurableTarget`, or another unsupported field.
6. Now choose **Reset Pathfinder data…** and select the same full/canonical reset scope you were testing in R1. Save the **required fresh pre-reset backup** when prompted.
   - **PASS:** Pathfinder verifies its just-created backup and advances to the **second explicit destructive confirmation**.
   - You may CANCEL at that second confirmation if you do not actually want to erase the data. Reaching that confirmation proves the R1 self-rejection defect is fixed.
7. Optional stronger check: complete the reset, restart when instructed, then restore the fresh backup. PASS if restore parses/applies normally.
8. Brief smoke: open one medical cockpit, Search, and Journal. No behavior change is expected outside the backup serialization fix.

If steps 5–6 pass, report **W8 Medical Correction R2 ACCEPTED** (or send the first error/screenshot if anything fails).
