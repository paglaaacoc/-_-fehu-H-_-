# W8 R1 — Extremely Easy Windows Test

This is an **integrated stabilization test**, not a new-feature hunt. If a serious new regression appears, stop and report it.

## 1. Build and launch
1. Extract the TEST ZIP to a normal local folder.
2. Double-click `TEST-W8-x64.cmd`.
3. Confirm the build succeeds and Pathfinder opens.
4. Confirm the header/About says **W8 R1 CANDIDATE**.

PASS: launches normally and medical/resource integrity gates pass before publish.

## 2. Basic cockpit / offline smoke
1. Open Cardiology, Pulmonary, Renal and one supplemental cockpit.
2. Navigate, scroll, select/copy text, pinch/zoom or Ctrl +/-.
3. If convenient, disconnect network briefly and reopen a cockpit.

PASS: local study content remains usable; no network dependency is introduced.

## 3. Search + verified source
1. Search `ARDS`; standalone ARDS exact hits should rank above unrelated partial fragments.
2. Select a short phrase in a Primary cockpit → More tools → Search selection in Pathfinder…
3. Results should appear immediately.
4. Preview/open a verified source beside Search.

PASS: Search/result/source routing is coherent.

## 4. Journal
1. Add a General note; save and confirm it appears immediately.
2. Select a normal short passage in a cockpit → Add selection to Journal…
3. With no selection → Add current place to Journal…
4. Open Journal beside a cockpit; edit/save inline.
5. Open a note's source and confirm Journal/source can remain side-by-side.

KNOWN DEFERRED: a **large/multi-block selection may still capture partially**. If it reproduces exactly as before, record it but do not fail W8 solely for that known issue. If short selections now fail, source links break, notes disappear, or the problem is materially worse, FAIL.

## 5. Split View
1. Open Split with Ctrl+Alt+S; allow an empty second pane.
2. Show a cockpit or Journal beside.
3. Main-tab/library navigation must not replace the parked beside view.
4. Swap panes deliberately.
5. Return to tabs; verify the exact parked tab returns.
6. Double-click/tap divider; verify 50/50 reset.

PASS: no stale placeholder, crash, unintended auto-swap or lost tab.

## 6. UWorld Selector
1. Open Native UWorld Selector.
2. From Cardiology More tools → Open UWorld Selector for this cockpit.
3. Repeat from Psychiatry or Obstetrics.
4. Enter/clear a manual Unused count and verify Unknown remains distinct from zero.

PASS: filter/routing and manual state behave as accepted; Pathfinder does not claim to read UWorld.

## 7. Themes + 19–22 drill feedback
1. Try Day plus Sage Day/Sunlit Apricot.
2. Try Ember Glow/Twilight Bloom and one older night theme.
3. In cockpits 19–22 answer a drill.

PASS: readable shell/cockpit theming and visible Correct / Your choice feedback.

## 8. Session / accessibility / workspace
1. Leave several tabs open, optionally Split View active; close/reopen Pathfinder.
2. Check last-session behavior according to your setting.
3. Open Aa / Ctrl+Shift+A; toggle one optional aid and restore it.
4. Check High Contrast/scaling if readily available.

PASS: state/session/accessibility foundations remain intact.

## 9. Backup / restore smoke
1. Create a canonical backup.
2. Make one harmless visible state change (for example favorite/progress/Selector count or a disposable Journal note).
3. Restore the backup.
4. Confirm restored state and no silent loss warning.

PASS: schema-7 backup/restore remains functional.

## 10. Watch items
- If the late-library sidebar vertical-position jump appears, note whether it is unchanged or worse.
- If `BrowserProcessExited` appears, report the exact action sequence. The recovery UI should still offer Reload cockpit safely.

## 11. Optional architecture publish check
After the x64 runtime test passes, double-click `BUILD-ON-WINDOWS.cmd`.

That builder publishes **both x64 and ARM64**. On an x64 PC you only need to confirm both output folders are produced successfully; do not try to launch the ARM64 executable unless you have ARM64 Windows hardware.

## Acceptance
If the integrated gates pass and there is no serious new regression, explicitly accept **W8 R1**. After acceptance, Pathfinder still goes through the prepared Astra closure audit and mandatory Medical Content Audit/Re-review before the final stable x64 + ARM64 release cut.
