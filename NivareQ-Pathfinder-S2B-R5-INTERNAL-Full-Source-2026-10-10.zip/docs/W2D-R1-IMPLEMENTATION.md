# W2D R1 — Native Shell Taxonomy + Settings Foundation

## Base
Owner-accepted **W2C R3**.

## Scope implemented

### 1. Mandatory late-library sidebar blocker
W2C testing showed transient sidebar collapse/jump/shrink on resources 19–22, Clinical Recall and UWorld Selector. W2D removes the old grouped/selectable/virtualized `ListView` from the study library entirely.

The bounded 25-resource catalog now renders as deterministic native group headers + resource buttons inside one vertical `ScrollViewer`/`StackPanel`. Horizontal scrolling is disabled. There is no selection-owned bring-into-view behavior.

This is intentionally a shell fix; frozen medical HTML is not changed.

### 2. Native shell taxonomy
- **Study resources:** actual Pathfinder study-resource tabs.
- **Tool/workspaces:** Search and Glossary remain tabs for now and are suitable for future Split View.
- **App surfaces:** My Study, Settings and Guide render in a native app-surface host instead of consuming ordinary closable tabs.
- **Study Time:** toolbar flyout/panel rather than a tab.
- **Home:** remains special/non-closable.

Legacy session records that referred to Guide/My Study/Accessibility/Study Time tabs are not recreated as pseudo-tabs.

### 3. Proper Settings foundation
Native Settings sections:
- General
- Appearance
- Accessibility & display
- Data, backup & reset
- Session & navigation
- Workspace & Split View
- About & integrity

The existing top theme selector and Aa remain quick controls over the same canonical settings. Aa/Ctrl+Shift+A route directly to Accessibility & display.

### 4. Backup-mandatory destructive reset
Reset scopes:
1. Session/view state only
2. Study/progress state
3. Personal My Study data
4. Full canonical Pathfinder user data

The reset flow cannot pass the backup gate unless a new canonical Windows backup is saved and read back through the strict canonical importer. Only after successful verification does Pathfinder present the destructive confirmation.

The reset itself uses `RestoreTransactionService.Commit` across canonical settings, My Study and preserved-extension files. If transactional commit fails, the operation reports safe failure/rollback. Live cockpit/session position writers are suspended after a successful reset until restart so pre-reset WebViews cannot repopulate erased state.

Installed app files, frozen medical content and WebView2 runtime/cache are not deleted.

### 5. Preserved foundations
- W1 Windows canonical/master backup authority
- W2A resource registry/short paths
- W2B Location v2/strict source fidelity/one-primary-cockpit rule
- W2C occurrence-level Search, read-only Source Preview, immutable Preview→Go target and one-level Return
- generated WinUI STA + accepted single-instance model
- accessibility/High Contrast/DPI/native WebView2 touch/zoom foundations
- 132/132 frozen medical/teaching payload bytes

## Not in W2D
- no CockpitHost/state-provider migration (W3)
- no Split View implementation (required W4)
- no Journal/UWorld native workspace implementation
- no medical-content enrichment/correction
- no portable-data architecture

## Build/test truth
This package has static/source/integrity verification only. It is **not** claimed compiled/launched on Windows until the owner runs `TEST-W2D-x64.cmd`.
