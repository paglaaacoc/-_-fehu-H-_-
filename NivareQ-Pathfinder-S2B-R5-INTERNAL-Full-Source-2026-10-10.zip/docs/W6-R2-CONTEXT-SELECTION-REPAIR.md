# W6 R2 — Context Menu + Full Selection Capture Repair

W6 R2 is a bounded revision of the unaccepted W6 R1 Selector candidate. The 26-recipe Selector model, backup schema 7 and frozen medical payload remain unchanged.

## Full Journal selection capture
W6 R1 used WebView2 `ContextMenuTarget.SelectionText` as the final note payload. Real-Windows testing showed that this string can represent only part of a visibly larger multi-block DOM selection.

R2 keeps the context-menu string only as a fallback. When the user actually invokes **Add selection to Journal…**, Pathfinder executes an in-page `window.getSelection().toString()` capture against the originating Primary cockpit. This is the authoritative payload. It remains plain text, preserves meaningful block line breaks, normalizes CRLF and non-breaking spaces, and retains the established 12,000-character safety cap.

Rich-text/HTML Journal storage is intentionally not introduced. Search, backup, export/migration and source identity therefore remain simple and stable.

## More tools reconciliation
Pathfinder keeps the root context-menu commands already accepted:
- Add selection to Journal… / Add current place to Journal…
- Pathfinder Glossary

For the two new convenience actions Pathfinder first locates the native WebView2 **More tools** submenu by its stable unlocalized name (`moreTools`), with the visible label only as a defensive fallback. When present, Pathfinder adds:
- **Search selection in Pathfinder…** — resolves the actual current DOM selection and opens Universal Search prefilled with it.
- **Open UWorld Selector for this cockpit** — available only for Primary cockpits with exact stable recipe mappings.

If the runtime does not expose More tools as a modifiable submenu, Pathfinder creates one **Pathfinder tools** submenu at root. The native WebView2 menu is never replaced wholesale.

## Selector mapping
Cockpit-to-Selector routing uses the stable recipe `slug` field. Single-mapped cockpits jump directly to their recipe. Cockpits intentionally mapped to multiple recipes (for example core + crossover recipes) open the Selector filtered by the exact stable cockpit slug so all and only those mapped recipes remain visible.

## Frozen content
No MedicalPayload file changes in W6 R2.
