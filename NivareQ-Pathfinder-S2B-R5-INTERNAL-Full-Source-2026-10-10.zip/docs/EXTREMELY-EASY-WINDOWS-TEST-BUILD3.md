# Build 3 — Extremely Easy Windows Test

You do not need to inspect source code.

## 1. Build
1. Extract the ZIP to a normal folder.
2. Double-click `BUILD-ON-WINDOWS.cmd`.
3. Confirm the medical check says **132/132 PASS**.
4. Launch the x64 app from `Built Apps`.

If the app does not compile or launch, stop and send the exact build/runtime error.

## 2. Basic regression check
Open Strategy, Cardiology, Pulmonary, and Renal.
Confirm:
- cockpit stays visible;
- themes still work;
- tabs still work;
- sidebar cards still look correct;
- full screen still works.

## 3. Exact resume-position test
1. Open Pulmonary.
2. Scroll to a very obvious place well down the page.
3. Wait about 1 second.
4. Close the Pulmonary tab.
5. Reopen Pulmonary.

PASS = it returns very close to the same place.

Then:
1. Leave Pulmonary scrolled down.
2. Quit Pathfinder normally.
3. Reopen Pathfinder.

PASS = the Pulmonary tab/session returns and the cockpit resumes near the saved position.

## 4. Favorites
1. Right-click Cardiology in the library.
2. Choose **Add to favorites**.

PASS = Cardiology gets a star, sorts to the top of its existing group, and appears in **My Study**.

Remove it again once to confirm the reverse path.

## 5. Bookmark
1. Open any study cockpit and scroll somewhere recognizable.
2. Click **My Study**.
3. Click **Bookmark current place**.
4. Give it a name and save it.
5. Move somewhere else in the cockpit.
6. Return to My Study and click **Go to bookmark**.

PASS = Pathfinder opens/selects the right subject and returns near the bookmarked place.

## 6. Personal note
1. Right-click a subject in the library.
2. Choose **Personal note…**.
3. Save a short note.
4. Open **My Study**.

PASS = the note appears and can be edited or cleared.

## 7. Optional progress
Progress must be OFF by default on a fresh Build 3 state.

1. Open My Study.
2. Enable **Show study progress in the subject library**.
3. Right-click a subject and set it to **Studying**.

PASS = the state appears with that subject.

Then disable progress.
PASS = the progress text disappears but the subject remains otherwise unchanged.

Enable it again.
PASS = **Studying** returns; the state was hidden, not deleted.

## 8. Tab QoL
Open at least four study tabs.

Right-click one tab and test:
- Pin tab
- Close tabs to the right
- Close other tabs

PASS = pinned tabs are protected and remain open.

Close an unpinned study tab, then press **Ctrl+Shift+T**.
PASS = it reopens.

Open My Study.
PASS = recently closed tabs are visible there during the current session.

## 9. Backup / restore
1. Create one favorite, one bookmark, and one note.
2. Click **Back up my data** and save the JSON somewhere obvious.
3. Change or delete those test items.
4. Click **Restore backup** and choose the saved JSON.
5. Restart Pathfinder once.

PASS = the backed-up personal state and saved tab session return.

## Acceptance rule
If all sections above pass and the original v1.0 behavior remains intact, Build 3 can be accepted and Build 4 can proceed to Universal Search + v1.1 refinement.
