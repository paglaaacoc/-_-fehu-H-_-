# W2C R1 — Extremely Easy Windows Test

1. Double-click **TEST-W2C-x64.cmd**.
2. Confirm the app says **W2C R1 CANDIDATE**.
3. Open **Cardiology** and scroll to a recognizable study position.
4. Open **Search**, search for a Cardiology concept that is somewhere else in the cockpit.
5. Click **Preview source**.
   - A large **Read-only source preview · Cardiology** dialog should open.
   - It should land on/highlight the relevant source.
   - You should be able to scroll, pinch/zoom, select and copy text.
   - Study-changing buttons/inputs/links in the preview should not act as an authoritative cockpit.
6. Close the preview. Switch back to Cardiology. **Your original Cardiology position must still be there.**
7. Preview the result again and click **Go to cockpit**.
   - Pathfinder should activate the single primary Cardiology cockpit and move it to that source.
   - You should see an InfoBar with **Return to previous position**.
8. Click **Return to previous position**. Your earlier Cardiology study position should come back.
9. Back in Search, try the result's direct **Go to cockpit** button and then Return again.
10. Confirm reopening Cardiology still does **not** create Cardiology #2.
11. Quick regression: cockpit right-click text menu works; tab context menu works; shell selectable text menu is readable.
12. Optional: create a backup and confirm it is still schema 3 / producer `W2C-R1`.

If compilation fails, send the complete console output. If runtime behavior differs, screenshot the exact state and tell me which numbered step failed.
