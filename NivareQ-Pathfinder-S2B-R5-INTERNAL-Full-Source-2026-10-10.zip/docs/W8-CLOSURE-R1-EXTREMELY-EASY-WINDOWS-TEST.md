# W8 Closure R1 — extremely easy Windows test

W8 R1 is still your accepted fallback. This closure candidate already passed x64 + ARM64 Windows compilation in GitHub Actions. You only need to validate runtime behavior on your real x64 Windows machine.

## 1. Build and launch
Double-click **TEST-CLOSURE-x64.cmd**.

PASS if Pathfinder launches and the shell says **W8 CLOSURE R1 CANDIDATE**.

## 2. The old Journal multi-block problem — highest priority
1. Open an ordinary Primary cockpit such as Cardiology.
2. Select a visibly large passage spanning multiple paragraphs/bullets (the kind that failed before).
3. Right-click -> **Add selection to Journal…**.
4. Inspect the prefilled note body before saving.

PASS if the whole visible selection arrives as plain text with sensible line breaks. A 12,000-character safety cap still intentionally exists.

Also quickly verify a short one-sentence selection still works.

## 3. Cockpit state persistence
In a normal Primary cockpit, change a meaningful supported state (for example a drill/quiz answer, mastery/check state, or other persisted cockpit control). Close/reopen the cockpit and then restart Pathfinder once.

PASS if the state is retained as before. Read-only source previews must still not become state writers.

## 4. UWorld Selector + Split backup/restore
1. Open UWorld Selector and place it **beside** another normal view.
2. Put a harmless manual count in one recipe if desired.
3. Create a canonical backup from Data management.
4. Restore that backup.
5. Restart Pathfinder when instructed.

PASS if restore succeeds without the old unsupported-tool whitelist error and the supported workspace/Selector state returns normally.

## 5. UWorld Selector reset safety
Open UWorld Selector and click **Reset reported counts…**.

PASS if Pathfinder takes you to **Settings / Data management** instead of immediately clearing all 26 reports. The bulk reset must use the existing protected reset workflow/fresh verified backup policy.

## 6. Journal/source regression
- Create/edit/delete a normal Journal note.
- Open a source-linked note's exact source.
- If Journal is beside, confirm exact source still pairs with it correctly.

PASS if the accepted W5–W8 Journal/Split behavior remains intact.

## 7. Quick regression smoke
- Search `ARDS`: standalone ARDS remains the exact/top behavior; substrings such as `standards` are not exact ARDS.
- Select text -> More tools -> Search selection in Pathfinder: results appear immediately.
- Split View swap / Return to tabs / empty secondary still behave as accepted.
- Switch through one light and one evening W7 theme (for example Sage Day and Ember Glow).
- Open a 19–22 drill and confirm Correct / Your choice feedback is still visible.

## What you do NOT need to force-test
The damaged Journal-tail recovery, deliberately broken rollback journal, and unknown nested PWA-field rejection are destructive/adversarial paths. They were addressed by source-level closure checks and the Astra finding-specific repair. Do not corrupt your real AppData just to test them.

## Acceptance
If these checks pass, tell the development chat **W8 Closure R1 is accepted** and mention any residual issue you observed. Do not call the product final Stable yet; the separate Medical Content Audit/Re-review gate still follows.
