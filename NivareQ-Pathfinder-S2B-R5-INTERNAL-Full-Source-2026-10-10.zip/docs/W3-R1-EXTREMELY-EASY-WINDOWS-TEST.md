# W3 R1 — Extremely Easy Windows Test

## Start
1. Extract the TEST ZIP.
2. Double-click **TEST-W3-x64.cmd**.
3. The console must pass medical payload **132/132** and resource registry checks, compile, then launch Pathfinder.
4. Confirm the title/header says **W3 R1 CANDIDATE**.

## Five important checks
### 1 — Primary + read-only secondary
- Open **Cardiology** normally.
- Right-click Cardiology in the Study library and choose **Open in new tab** (or Ctrl/middle-click it).
- You should now have the normal Cardiology primary plus **Cardiology · Read-only**.
- Read-only should scroll/zoom/select/copy, but study-changing controls should not work.
- Close it. Primary Cardiology must remain intact.

### 2 — Canonical cockpit-state persistence
- In a normal primary cockpit, make one harmless study-state change (for example a reviewed checkbox or quiz answer).
- Close/reopen that cockpit; optionally restart Pathfinder.
- The state should remain.
- A read-only secondary must not be able to change that canonical state.

### 3 — Runtime compatibility spot check
- Open one of 19–22 and change Light/Dark/Amber: the cockpit should follow Pathfinder more coherently than before.
- In 19–22, answer one quiz item, close/reopen the cockpit and confirm it persists.
- Optional: in Rheumatology/MSK/Dermatology, Obstetrics or Repro/Gyn/Breast, click a Study Map jump that previously had a malformed frozen onclick; it should navigate rather than fail.

### 4 — Backup
Create a new canonical backup. If you inspect the JSON, it should say:
- `"BackupSchemaVersion": 4`
- `"ProducerBuild": "W3-R1"`
- contain a `"CockpitState"` object.

### 5 — Quick regressions
- Search → Preview source → Go to cockpit → Return still works.
- Settings/My Study/Guide still behave as W2D app surfaces.
- Try late-library clicks around 17–22/Clinical Recall. The old shrink/collapse must remain gone; ideally the residual fixed-position vertical jump is gone too.

## If anything fails
Send the exact console error or a screenshot and describe which step failed. W3 R1 is not accepted until real-Windows testing passes.
