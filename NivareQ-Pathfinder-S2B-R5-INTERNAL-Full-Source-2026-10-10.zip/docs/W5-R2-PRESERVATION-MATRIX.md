# W5 R2 Preservation Matrix

| Area | W5 R2 requirement/status |
|---|---|
| Accepted base | Built from owner-accepted W4 R3 |
| Frozen medical/teaching payload | 132/132 byte-identical; no content revision |
| Windows data root | Remains `%LOCALAPPDATA%\NivareQ\Step2Pathfinder` |
| Startup/single instance | Preserve accepted WinUI STA + named mutex/activation model |
| Native WebView2 touch/zoom | Preserve |
| Accessibility / High Contrast / DPI | Preserve |
| Resource registry | 25 resources preserved |
| Location/source identity | Location v2 and strict frozen-source identity preserved |
| Search Preview/Go/Return | Preserved; exact boundaries corrected |
| Cockpit state authority | 24 providers / 2607 allowed keys preserved |
| Same-resource write authority | One interactive Primary; read-only secondary remains non-writer |
| Split View | Simplified UI ownership only; deliberate safe reparent rules retained |
| Legacy Personal notes | Migrated to Journal but retained as inactive rollback compatibility shadow |
| Bookmark notes | Remain bookmark notes; not conflated with Journal |
| Journal | New native provider under existing AppData root |
| Canonical backup | Advances to schema 6; Journal first-class |
| Older canonical backup import | Supported; older backup does not silently wipe current Journal |
| W4 rollback | W4 R3 remains accepted fallback during W5 candidate test |
| Search/Glossary app-surface redesign | Not performed; remain current tab architecture |
| Portable/removable data migration | Not performed |
| Known sidebar jump | Carried forward as low-severity watch/polish item |
| 19–22 drill answer feedback | Carried forward for later compatibility/polish |
