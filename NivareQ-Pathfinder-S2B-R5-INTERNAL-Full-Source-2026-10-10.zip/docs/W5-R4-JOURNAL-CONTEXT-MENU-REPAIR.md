# W5 R4 — Journal No-Selection Context-Menu Repair

## Status
**UNACCEPTED CANDIDATE.** W4 R3 remains the owner-accepted Windows development baseline until this exact R4 candidate passes real-Windows testing and is explicitly accepted.

## Why R4 exists
Owner testing of W5 R3 confirmed that selecting cockpit text and right-clicking correctly exposed `Add selection to Journal…`. The same ordinary Primary cockpit, when right-clicked/long-touched with no selection, showed only the native WebView2 menu and omitted the intended `Add current place to Journal…` action.

The R3 Journal context hook queried `ContextMenuTarget.SelectionText` before explicitly checking whether WebView2 reported a selection. WebView2 defines `SelectionText` for the selection path and exposes `HasSelection` as the authoritative discriminator. R4 makes that contract explicit and keeps the no-selection path independent of selection-text retrieval.

## Repair
For canonical interactive Primary cockpit WebViews:
1. Initialize captured selection to empty.
2. Check `args.ContextMenuTarget.HasSelection`.
3. Only when true, read/trim/cap `SelectionText`.
4. If captured selection is non-empty, insert `Add selection to Journal…`.
5. Otherwise insert `Add current place to Journal…`.
6. Bind the command to the exact originating `StudyTabContext` and reuse the existing strict source/location Journal capture pipeline.

Read-only source/reference views remain intentionally excluded by the existing `CockpitViewRole.Primary` guard; they do not claim fresh Journal source identity.

## Preservation
- W5 R3 selected-text capture behavior preserved.
- W5 R3 Journal inline/popup editor behavior preserved.
- W5 R3 Split-aware Journal Open source preserved.
- W5 Search Boundary Correctness preserved.
- W5 static/empty Split View model preserved unchanged.
- Backup schema remains **6**; ProducerBuild advances only to `W5-R4`.
- Journal provider schema remains **1**.
- Frozen medical/teaching payload changes: **0**.
- Journal Pen Scratchpad Gate remains **CLOSED / OWNER DECISION REQUIRED**.
