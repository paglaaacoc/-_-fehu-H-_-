# W5 R1 — Native Journal + Search/Split Preflight

## Status
**CANDIDATE / NOT OWNER-ACCEPTED.** W5 R1 is source/static verified in the Linux build workspace, but this environment has no .NET/WinUI build chain and cannot compile or run the native Windows app. W4 R3 remains the current owner-accepted Windows development baseline until W5 R1 passes real-Windows testing and is explicitly accepted.

## Base and scope
W5 R1 is built directly from owner-accepted W4 R3. It implements the already-approved W5 Native Journal milestone and folds in two owner-approved bounded preflight repairs discovered after W4 acceptance:

1. **Search Boundary Correctness** — fix short-term/acronym exact-match classification such as `ARDS` matching inside `standards`, `stewardship`, or `DMARDs`.
2. **Split View Secondary-Tab Isolation** — simplify the W4 placeholder/auto-swap model into an optional, static, deliberate secondary slot.
3. **Native Journal** — scalable General and cockpit/source-linked notes under Windows canonical persistence/backup authority.

No frozen medical/teaching HTML is revised.

## Search Boundary Correctness
The accepted W4 search implementation used normalized substring matching in several places. That allowed an acronym such as `ARDS` to be labelled/highlighted as exact when the character sequence only occurred inside a larger word.

W5 R1 introduces normalized whole-term/phrase boundary matching for exact classification. Exact phrase detection, direct token/title/alias matching, exact highlighting and source-destination matching now use compatible boundary semantics. Useful substring matching is retained as a lower-ranked non-exact fallback instead of being incorrectly promoted to Exact match.

Static regressions include:
- standalone `ARDS` is a whole-term exact match;
- `standards stewardship DMARDs` is not an exact ARDS match;
- normalized multiword exact phrases still work;
- punctuation/hyphen normalization does not break legitimate phrase boundaries.

## Split View Secondary-Tab Isolation
W4 R3 is accepted and its ownership repair remains the foundation, but the owner approved a simpler W5 interaction model to remove the need for an interactable secondary placeholder tab.

### W5 R1 model
- Split View may be **open with an empty second pane**.
- A view enters the second pane only through a deliberate **Show beside** action.
- While parked beside, that exact tab/view remains logically alive but its main TabView header is **hidden/collapsed**.
- Ordinary main-tab or Study Library navigation does **not** replace or implicitly swap the parked view.
- If the user tries to open a cockpit that is already parked beside, Pathfinder leaves it beside and indicates **Already open beside · use Swap panes to move it to main** rather than duplicating it.
- **Swap panes** is deliberate. It promotes the parked view to main and parks the former main view beside.
- **Return to tabs** restores the exact parked tab to the main tab strip and leaves Split View open but empty.
- The return rule is uniform: normal cockpit tabs and state-read-only Source Preview tabs are restored rather than silently discarded.
- **Close Split View** first safely returns any parked tab, then closes the secondary workspace.
- **Show beside** while a view is already parked returns the old secondary tab before parking the newly requested one.
- Search and Glossary remain tabs in W5; converting them to permanent app surfaces is explicitly out of scope.

### Reparent safety retained
The simplification does not remove WinUI visual-parent constraints. W5 R1 retains explicit detach/attach verification around deliberate moves and strengthens settle retries. If a UIElement has not actually detached, Pathfinder aborts rather than assigning it to a second visual parent. Swap fail-safe recovery likewise avoids blind reparent attempts.

## Native Journal
W5 R1 retires the legacy subject-level Personal-note UI as the active note surface and introduces one native Journal workspace.

### Note model
- **General notes** with no cockpit owner.
- **Cockpit-linked notes** associated with a canonical resource ID.
- **Exact source/location-linked notes** carrying frozen source version plus Windows Location v2 state.
- Selected text captured from a ready cockpit may prefill a source-linked note.
- Pathfinder refuses to invent an exact source link if verified capture is unavailable; the user can retry or create a General note instead.

### Journal workspace
- New General note.
- From current Study.
- Search title/full note text/cockpit owner.
- Filter All / General / represented cockpit.
- Result cards with edit/delete and Open cockpit or Open source.
- Bounded rendering with Load more.
- Dirty-draft protection: Cancel on a changed draft requires Discard or Keep editing.
- Title is required.
- Exact-source open validates source identity/version and does not silently redirect a source link to changed content.

### Native persistence
Journal uses a Windows-native provider under the existing `%LOCALAPPDATA%\NivareQ\Step2Pathfinder` root:
- compact JSON snapshot;
- append-only NDJSON operation log;
- atomic snapshot writes through existing persistence infrastructure;
- idempotent replay and tolerance for an incomplete final log line;
- periodic compaction;
- last-good snapshot recovery/quarantine path.

Safety bounds are intentionally generous but finite: 20,000 entries, 500-character titles, 500,000-character bodies, and a 48 MB logical title/body text budget.

## Legacy Personal-note migration and rollback safety
Existing W4 subject notes are migrated into Journal once. The migration is deliberately rollback-safe:

- the old `PersonalStudy.SubjectNotes` payload remains as an **inactive compatibility shadow** rather than being erased by a W5 test build;
- Journal is the only active note UI/model in W5;
- durable per-resource migration markers live in the Journal provider, not PersonalStudy;
- the migrated note and its marker are written as one append-only Journal operation;
- if a migrated Journal note is later intentionally deleted, the Journal marker prevents W5 from resurrecting it from the retained shadow;
- because W4 does not know or rewrite Journal files, temporarily rolling back to W4 does not erase those W5 migration markers.

This design prioritizes recoverability while the W5 candidate is being tested.

## Canonical backup
Windows canonical backup advances from schema 5 to **schema 6**. W5 schema 6 adds first-class Journal state and migration markers while preserving existing Windows cockpit/location/workspace authority.

- ProducerBuild: `W5-R1`.
- Native Journal is included in canonical backup/restore/reset transactions.
- Older Windows canonical backups that predate Journal do not silently clear the current Journal; W5 preserves current Journal and warns.
- Supported PWA Journal data may be promoted into native Journal where the existing import contract can identify it; unsupported extension data remains preserved opaquely.
- Backup maximum remains bounded (100 MB).

## Integrity and static QC
Current W5 R1 static/source gate:
- W2A inherited foundation checks: **912 PASS**
- W5-specific checks: **83 PASS**
- Combined: **995 PASS / 0 FAIL**
- Frozen medical payload: **132 files, byte-identical to accepted W4 R3**
- Resource registry: **25**
- Canonical cockpit-state providers: **24**
- Canonical cockpit-state keys: **2607**

These are source/static claims only. Real-Windows compile/runtime/device testing remains mandatory.
