# W6 R2 — Extremely Easy Real-Windows Test

## 1. Build / identity
1. Extract the entire TEST ZIP to a normal local Windows folder.
2. Double-click **TEST-W6-x64.cmd**.
3. Build must succeed and Pathfinder must visibly say **W6 R2 CANDIDATE**.
4. If compilation fails, stop and send the complete error.

## 2. Full multi-block Journal selection — R1 blocker
1. Open an ordinary Primary cockpit such as Cardiology.
2. Drag-select several lines/bullets so the highlight clearly spans multiple blocks.
3. Right-click the highlighted selection → **Add selection to Journal…**.
4. Confirm the note body contains the entire visible selection, not only the first/last fragment.
5. Sensible plain-text line breaks are expected; bold/list HTML formatting is intentionally not stored.

## 3. Native More tools
1. Select a short phrase in Cardiology and right-click.
2. Root **Add selection to Journal…** and **Pathfinder Glossary** should still be present exactly as before.
3. Open **More tools**. It should no longer be an empty/useless flyout when WebView2 exposes it: look for **Search selection in Pathfinder…** and **Open UWorld Selector for this cockpit**.
4. If your WebView2 runtime does not expose a modifiable native More tools submenu, one root **Pathfinder tools** submenu is acceptable instead. Report which layout you see.

## 4. Search selection
1. Select a distinctive phrase such as `RV infarction` or another phrase known to exist.
2. More tools → **Search selection in Pathfinder…**.
3. Search should open and the search box should already contain the selected text.
4. Results should refresh normally using the accepted W5 Search boundary semantics.

## 5. Open UWorld Selector for this cockpit
1. In Cardiology, More tools → **Open UWorld Selector for this cockpit**.
2. Selector should open at/for Cardiology without changing any reported count.
3. Try Psychiatry or Obstetrics if convenient: multiple mapped recipes should remain visible together rather than silently choosing one crossover recipe.
4. Opening Selector must never imply UWorld completion.

## 6. No-selection regression
1. Right-click ordinary Primary cockpit text with nothing selected.
2. **Add current place to Journal…** must still appear and work.

## 7. Quick W6/W5 smoke
- Record a Selector count, clear it back to Unknown, restart and confirm persistence.
- Split View still behaves as accepted in W5.
- Journal inline/popup workflows still behave normally.
- Search `ARDS`: unrelated `standards`, `stewardship`, `DMARDs` must not be exact ARDS matches.

## Acceptance
W6 R2 remains unaccepted until the owner explicitly accepts it after real-Windows testing. W5 R4 remains the accepted fallback.
