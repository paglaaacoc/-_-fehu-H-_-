# Build 4 — Medical Abbreviation Glossary / Index Audit

## Scope

A comprehensive abbreviation/short-term candidate audit was run across the **23 numbered runtime study cockpits**. The purpose is quick lookup for medical students without modifying the frozen medical payload or asking Pathfinder to infer meaning from surrounding prose.

## Result

- Runtime cockpits audited: **23**
- Curated glossary/index entries in this candidate: **1000**
- Entries with empty abbreviation/term: **0**
- Entries with empty expansion: **0**
- Duplicate exact term + expansion pairs: **0**
- Curated entries with zero verified occurrences in the audited runtime corpus: **0**

The raw candidate extractor intentionally over-collects strings so likely abbreviations are not silently missed. UI labels, question IDs, code identifiers, version tags, HTML/JS tokens, Roman-numeral noise, and similar non-medical candidates are excluded from the curated glossary rather than being presented as medical abbreviations.

This report therefore describes a **comprehensive candidate audit with a curated medical glossary**, not a claim that every uppercase sequence in the source is a medical abbreviation.

## Ambiguity rule

Pathfinder does not infer which expansion is intended from sentence context. When the same short form has more than one curated meaning, all relevant meanings remain available.

Examples include:
- `GBS` — group B Streptococcus / Guillain–Barré syndrome;
- `PE` — pulmonary embolism / physical examination;
- `AED` — automated external defibrillator / antiepileptic drug;
- `AMS` — altered mental status / acute mountain sickness.

This is deliberate. The student interprets the surrounding medical context.

## Alias rule

Aliases are explicit and deterministic. They are used for names that are genuinely equivalent to a literal source term, such as:
- `Helicobacter pylori` ↔ `H. pylori`;
- `Stevens-Johnson syndrome` ↔ `SJS`;
- punctuation/diacritic-normalized forms such as `Guillain-Barre` / `Guillain–Barré`.

Expansion text is **not automatically converted into a cockpit search alias**. Only explicitly curated aliases can bridge to a different literal source term. Ambiguous source abbreviations are excluded from automatic alias bridging.

## Fuzzy search rule

**No Pathfinder fuzzy search is implemented.** Search and glossary text boxes explicitly preserve native Windows spell-check/proofing so Windows can surface spelling suggestions. This keeps typo assistance visible to the user without allowing Pathfinder to silently substitute one medical term for another.

## Medical-payload boundary

The glossary is stored in Pathfinder shell data:

`src/NivareQ.Step2Pathfinder/ShellData/medical-glossary.json`

It is not inserted into or written back to the audited cockpit HTML/JS payload. The medical-payload SHA-256 manifest remains the authority for the frozen 132 files.

## Bounded post-user-test coverage polish

After real-Windows glossary use exposed a missing `BiPAP` entry, one **bounded missing-abbreviation coverage sweep** was run without reopening the medical-content audit. Only high-confidence abbreviations that actually occur in the frozen runtime corpus and have clear meanings in this library were added.

Added coverage: `BiPAP` (with `BPAP` alias), `IgA`, `IgE`, `IgG`, `IgM`, `IgAN`, `EoE`, `FeUrea`, `TdT`, `CrAg`, `SPEP`, `MEN2A`, `PND`, `LAMA`, `ACA`, and `AMI`.

This sweep deliberately stopped after these concrete omissions; it did not attempt to turn every uppercase/UI/source token into a glossary item.
