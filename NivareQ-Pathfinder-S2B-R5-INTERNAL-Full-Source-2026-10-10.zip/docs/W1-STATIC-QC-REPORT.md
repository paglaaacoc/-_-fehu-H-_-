# W1 Static / Source QC Report

**Environment limitation:** no .NET SDK / MSBuild / C# compiler is available in this execution environment, so this report does **not** claim Windows compilation or runtime/device testing.

## Completed here
- W1 source isolated in `06-WINDOWS-W1-CANDIDATE`; accepted `02-WINDOWS-v1.2-WORKING-SNAPSHOT` was not edited.
- Static W1 QC script: **166 passed / 0 failed**.
- Frozen medical payload verification: **132 / 132 exact SHA-256 matches** against accepted manifest.
- Candidate `App.xaml.cs` is byte-identical to accepted v1.2 `App.xaml.cs`; normal generated STA + mutex/activation design is untouched.
- No custom `static Main` detected.
- No portable app-local Data-root marker detected.
- New/modified C# files passed lexical brace/string/comment balance checks.
- Real released catalog comparison confirms PWA B4A and Windows v1.2 differ in resource slug identity only for the UWorld Selector pair (`extra-uworld-selector` vs `extra-uworld-checkbox-selector`); W1 deliberately does not treat them as source-equivalent.
- Three JSON contract fixtures generated and JSON-parsed successfully: Windows v1, PWA B4A-shaped v1, W1 canonical v2.
- Static markers verify transactional backup export, canonical fail-closed field validation, coverage/extension consistency validation, runtime save-failure surfacing, bounded extension-store reads, and rollback `.lastgood` protection.

## Requires real Windows
- .NET 10 / WinUI compile and publish.
- launch/WebView2 smoke test.
- file-picker backup/export and restore UI.
- real filesystem replacement semantics under NTFS.
- recovery behavior under actual denied/locked/full-disk conditions if later failure injection is desired.
- real-device preservation of accessibility/touch/zoom behavior.

See `W1-EXTREMELY-EASY-WINDOWS-TEST.md`.

- R3 adds `restore-journal-definite-assignment` to prevent recurrence of the R2 CS0165 null/validation short-circuit defect.
