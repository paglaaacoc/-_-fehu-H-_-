# Build 1 R3 — Runtime + UI Repair

## Why R3 exists
R2 proved that Pathfinder compiles for both x64 and ARM64 and that the x64 binary launches. Real Windows testing then revealed shell-only runtime defects. R3 is a bounded repair; it is **not Build 2** and does not reopen medical content.

## Repairs
- Home no longer depends on an `ms-appx:///Brand/...` URI in the unpackaged/self-contained build.
- Home, Guide, and Time now preserve a single WinUI visual tree. Controls are no longer removed from one `StackPanel` and inserted into another.
- Time and Guide use guarded panel creation; shell exceptions become visible error tabs rather than process crashes.
- Study-time totals use safe dictionary lookup.
- Theme application now paints the SplitView content background explicitly in addition to the root and tab surface.
- Theme family is: Light, Dark, OLED Black, Ocean, Forest, Amber, Aurora, Parchment, Glacier.
- `MedicalPayload` is published as plain copied runtime files (`None` with copy metadata), not WinUI resource-indexed `Content`. This is intended to remove the 23 prior PRI249 qualifier warnings while preserving exact filenames and bytes.

## Immutable-content result
- authoritative R2 ZIP SHA-256: `8fcde78900b3ecc5bb1616dff7ea3c8b05743c110bff149c12bc12c387734139`
- frozen payload files: **132**
- mismatched: **0**
- missing: **0**
- extra inside frozen payload copy: **0**

## Still gated
R3 must be compiled and run on Windows. This Linux build environment cannot honestly claim a native WinUI runtime pass.
