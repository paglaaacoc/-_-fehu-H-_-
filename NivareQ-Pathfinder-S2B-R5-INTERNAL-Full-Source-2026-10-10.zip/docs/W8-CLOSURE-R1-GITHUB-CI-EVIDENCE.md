# GitHub Actions Windows CI evidence — W8 Closure R1

Repository: `tanzim137/RAM-TEST` (private)
Branch: `pathfinder-w8-closure-r1`
Workflow: `Pathfinder W8 Closure CI`
Final fidelity commit: `da94750a62bcfec216940c7098015511f58c90b3`
Run: 15 / Actions run ID `36820329796`
Result: **SUCCESS**

Windows runner evidence:
- .NET SDK 10.0.401 / MSBuild 18.9.11.
- Exact compile-source manifest PASS: 49 C#/XAML/project/manifest files.
- The exact real project definition includes `<ApplicationIcon>Assets\\Pathfinder.ico</ApplicationIcon>`; CI supplied a tiny valid stand-in icon only because the compact compile transport intentionally excludes binary assets. The delivered TEST/FULL package retains Pathfinder's authoritative icon bytes.
- `dotnet publish ... -r win-x64 --self-contained true`: PASS.
- `dotnet publish ... -r win-arm64 --self-contained true`: PASS.

CI executable hashes:
- x64: `59715d7e58dd00641bd37db3035201401e76dcbf06b36bdbe39420eba3974c79`
- ARM64: `0556e0bed83dfa59ca3657f0daa2bd20af47c6e843d5430d954187f2e1454adb`

Compiler warning:
- CS8604 at `MainWindow.Journal.cs` exact-source opening: nullable analysis cannot infer that `CloneLocation(entry.SourceLocation)` is non-null after the explicit `entry.SourceLocation is null` guard. No compile error; both architecture publishes completed. This candidate does not spend a closure revision solely to silence a flow-analysis warning.
