# W8 R1 Preservation Matrix

| Area | W8 rule |
|---|---|
| Frozen medical payload | 132/132 byte-identical; no content revision |
| Search | Preserve W5 boundary correctness + W6 selected-text Search behavior |
| Journal | Preserve W5/W6 workflows; known large multi-block truncation remains explicit/deferred |
| Split View | Preserve accepted optional/static parked-secondary model |
| UWorld Selector | Preserve exact 26 recipes, 22-system audit, Unknown ≠ 0 manual workflow |
| Themes | Preserve all 13 W7 themes |
| Accessibility | Preserve Build 5 foundations/options and native WebView2 touch/zoom |
| Session/workspace | Preserve W7 session + Split workspace restoration semantics |
| Backup | Schema 7; only ProducerBuild advances to W8-R1 |
| x64/ARM64 | Preserve both project/platform publish paths; x64 is fast owner test, both architectures in stable release package |
| Pen Scratchpad | CLOSED owner-decision gate |
| Rich-text Journal | DEFERRED |
