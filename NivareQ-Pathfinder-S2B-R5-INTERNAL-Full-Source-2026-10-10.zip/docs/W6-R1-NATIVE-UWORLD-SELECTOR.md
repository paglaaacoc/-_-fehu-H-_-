# W6 R1 — Native Interactive UWorld Selector

W6 adapts the accepted PWA B4A UWorld Selector workflow into a native Windows Tool/Workspace without treating UWorld as an integrated account service.

## Contract
- 26 stable recipe IDs: r01–r09, r10a/r10b, r11a/r11b, r12a/r12b, r13–r21, residual-six and final-audit.
- Exactly 22 systems are preserved for the final audit.
- First-pass rule: **Question mode Standard + Status Unused ONLY**. Tutor/Timed and block size remain the learner's choice.
- **Unknown is not zero.** A recipe is Unknown until the user explicitly records a current Unused count. Reported zero means only that the user reported 0 at the recorded timestamp.
- Opening a recipe or cockpit never marks anything complete.
- Pathfinder performs no UWorld login, API access, scraping, browser automation or count verification.

## Authoritative PWA parity
The native catalog is checked directly against the accepted PWA B4A Selector reference: all 26 recipe definitions and the 22-system final-audit list must remain exact. The accepted PWA source identity is also retained as an import/source-translation reference.

Targeted navigation is deterministic: when Global Search or a Journal source link opens a specific Selector recipe, Pathfinder clears any local Selector search/status filter that would otherwise hide that destination. Familiar searches such as **All Subjects All Systems** and **residual six** resolve to the final-audit and residual-six recipes without changing the canonical recipe definitions.

## Native workspace
The Selector appears directly below Clinical Recall in the Study Library and opens as a normal Tool/Workspace tab. It can participate in the accepted W5 Split View model. The workspace provides a KPI summary, search/status filters, recipe cards, report/clear actions, cockpit links where a canonical cockpit exists, Journal capture and the exact 22-system final-audit list.

## Residual/final safety sweep
`residual-six` retains the six-system verification sweep. `final-audit` explicitly uses all five UWorld subjects and all 22 systems. Pathfinder displays the user-reported count and timestamp; it does not infer UWorld completion from overlapping recipe counts.

## Existing PDF retained
The frozen `extra-uworld-checkbox-selector` PDF remains available through **Open printable selector PDF**. Its identity is not conflated with the native Selector recipe catalog/source identity.

## Persistence and backup
Native reports live under the existing Pathfinder AppData root in a first-class atomic/last-good-backed provider. Canonical Windows backup advances to schema 7 and includes UWorldSelector explicitly. Older schema-6 Windows backups preserve current Selector state rather than silently clearing it. PWA `uwsel_state_v1` state can promote into the native provider on import.

## Source/Journal integration
Each recipe has a stable native recipe source target and source-version hash. Journal notes can point back to that exact recipe. Journal Open source verifies the Selector source version and opens the exact recipe, using the accepted Split View topology when Journal is visible.

## Frozen content
No MedicalPayload file changes in W6 R1.
