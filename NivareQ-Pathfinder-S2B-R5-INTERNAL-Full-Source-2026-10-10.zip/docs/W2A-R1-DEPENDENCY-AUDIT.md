# W2A R1 — Frozen Resource Dependency / Reference Audit

## Why this audit exists
W2A changes physical paths while preserving all frozen payload bytes. A byte-preserved HTML file can still break if it depends on sibling files by relative path, so physical relocation was not allowed until runtime resources were inspected.

## Findings
- The released frozen payload contains 132 files total.
- The runtime catalog contains 25 resources: 23 study HTML resources, Clinical Recall HTML, and the legacy UWorld Selector PDF.
- Static inspection of all 24 runtime HTML resources found **no concrete external relative file dependencies** in `href`, `src`, CSS `url(...)`, literal `fetch/open(...)`, or literal location assignments after excluding anchors, data URLs, network URLs and JavaScript template expressions.
- Therefore the runtime resources are file-level self-contained for W2A relocation.
- The historical `START-HERE.html` / historical navigation and preservation documents contain legacy links. They are retained byte-exact as provenance artifacts under `meta/`; they are not runtime resource identity and are not used by the Windows shell to launch study resources.
- The new Resource Registry reproduces the released 23-item navigation metadata and 2 extras exactly for number/slug/title/subtitle/kind/phase/legacy main path/content type, while assigning short canonical physical paths.
- Canonical IDs and legacy path aliases are conflict-free.

## Byte-preservation verification
A direct old-path → new-path comparison was performed for all 132 map entries. Every old and new file SHA-256 matched the frozen-content map: **132/132 exact, 0 mismatches**.

## Runtime defense
W2A does not rely only on packaging QC. Before a resource is hosted, `RuntimeContentService` hashes the bundled canonical file and compares it with the registry's expected source SHA-256. A mismatch fails closed rather than silently hosting altered medical content.
