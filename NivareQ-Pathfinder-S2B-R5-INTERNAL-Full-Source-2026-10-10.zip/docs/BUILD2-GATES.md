# Build 2 gates — current RC1 status

Build 2 has now been assembled as RC1.

Static gates passed in this package:
- frozen medical payload unchanged: 132/132 exact hashes
- authoritative source ZIP hash preserved
- x64 + ARM64 targets preserved
- working R6 study-surface layout repair preserved
- R7 outline-first sidebar / repaint / hidden accelerator-hint behavior preserved in source
- friend-facing Home / Guide / Time copy cleaned
- last-session/tab restore implemented (default ON)
- Ctrl+Shift+T reopen-closed-study-tab implemented
- Pathfinder cockpit theme authority expanded to all known neutral surface aliases; cockpit theme toggle hidden while hosted

Still requires real Windows validation:
1. native compile/publish
2. cockpit visual theme authority across repeated switches
3. session restore ON/OFF behavior
4. Ctrl+Shift+T behavior
5. no regression to R6 cockpit visibility

If those pass, cut the friend release directly from this Build 2 RC1 source without another feature build.

Post-friend-release only:
- personal bookmarks / annotations or other optional expansion
