# Build 1 R5 — Cockpit Visibility Isolation + UI Polish Repair

R5 is a bounded shell-only repair after real Windows testing showed each frozen cockpit briefly paint and then become effectively invisible.

## Root-cause investigation
R4 contained a shell-to-cockpit runtime theme bridge. After every successful WebView2 navigation, Pathfinder injected theme CSS into the frozen cockpit DOM. Theme changes injected another runtime layer into every open cockpit.

The bridge used a generic shell variable set (`--text`, `--bg`, `--panel`, `--p2`, `--line`, `--accent`, etc.). A manifest-wide inspection found that 21 of the 23 numbered cockpit files use `--ink` rather than `--text` as their primary explicit text variable. R4 therefore changed many cockpit backgrounds/panels to dark Pathfinder theme colors while leaving explicit `--ink` text rules at their original light-theme dark color.

A standalone Chromium reproduction with the frozen Cardiology cockpit and the R4 Amber injection confirmed this mismatch: the page remained structurally loaded, but non-primary navigation buttons and several interactive elements became dark text on dark backgrounds. This explains the real-Windows symptom of cockpit chrome flashing correctly before R4's post-navigation injection made much of the interface appear blank/invisible.

Because the Chromium reproduction did not literally collapse the document, R5 does not assume theme injection was the only possible factor. It also adds read-only WebView/XAML lifecycle diagnostics so a remaining WinUI/WebView2 composition issue can be distinguished from content rendering.

## R5 repairs
- Removed all Pathfinder shell-theme CSS/script injection into WebView2.
- Cleared `contentCss` values in the shell theme registry as defense in depth.
- Pathfinder themes now affect native shell chrome only; each frozen cockpit keeps complete control of its own HTML/CSS/theme state.
- Added diagnostics at `%LOCALAPPDATA%\NivareQ\Step2Pathfinder\study-view-events.log` covering XAML load/unload/zero-size transitions, navigation start/content/DOM/source/completion, tab selection, and WebView process failures.
- Added visually separated sidebar groups: Start Here, Core Subject Sequence, Cross-Cutting Exam Domains, Supplemental Coverage, and Extras & Reference.
- Sidebar cards now show each resource's useful subtitle instead of repeating its phase label.
- Added theme-aware native Windows title-bar colors where Windows supports title-bar customization.
- Added true Windows full-screen mode using the AppWindow FullScreen presenter.
- Full-screen controls: toolbar `⛶`, `F11`, `Esc`, and a persistent 44×44 touch-friendly icon-only `⤡` exit control in the top-right corner.
- Fullscreen and Focus remain independent and can be combined.

## Medical-content invariant
No medical HTML, JS, CSS, question, answer, wording, source, or package member is edited by R5. The medical payload remains byte-identical to the accepted R2 correctness-patched baseline.

## Deliberately still gated
Cockpit theme synchronization remains disabled until all cockpit rendering and interaction is stable on real Windows. If it is revisited later, it must be implemented per-cockpit or through a proven compatibility layer rather than a single generic CSS variable override.
