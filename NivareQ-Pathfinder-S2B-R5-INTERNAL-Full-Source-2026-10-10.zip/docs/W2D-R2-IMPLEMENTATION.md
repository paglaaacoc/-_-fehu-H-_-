# W2D R2 — Shell Navigation Closure + Study Planning Cleanup

## Base
Real-Windows-tested **W2D R1 candidate**, itself based on owner-accepted **W2C R3**.

W2D R1 proved the major shell rewrite: the late-library **horizontal shrink/collapse defect is gone**. Real-device testing still found a smaller residual vertical-position jump for late resources, and Search → Go to cockpit could omit the one-level Return bar on the first open of a cockpit that already had a saved resume position.

## R2 bounded fixes

### 1. First-open Search → Go return anchor
When Search opens a cockpit that is not currently live, Pathfinder now checks for a canonical saved resume position before launching the strict source jump.

- the search destination remains the strict immutable SourceTarget;
- the saved resume location is carried separately as a pending one-level return anchor;
- only after the strict source jump succeeds does Pathfinder expose **Return to previous position**;
- if the source jump fails, Pathfinder attempts to restore the saved resume point instead of leaving the new cockpit stranded at an arbitrary start state;
- truly never-opened/no-saved-position cockpits legitimately have no Return bar.

This makes first-open and already-open Search → Go behavior coherent without inventing a return point that does not exist.

### 2. Late-library vertical offset preservation
W2D R1's deterministic non-virtualized library remains intact. R2 adds a narrow pointer/touch mitigation for the remaining position jump:

- capture the sidebar's exact vertical offset before pointer/touch activation;
- perform the normal cockpit/tab switch;
- restore the same vertical offset immediately and once more at low dispatcher priority after layout settles;
- keyboard navigation keeps normal focus/bring-into-view behavior for accessibility.

The already-fixed horizontal shrink/collapse behavior must not regress. If this bounded mitigation does not fully eliminate a harmless self-correcting vertical jump, the user has explicitly allowed that polish item to be deferred rather than consume repeated builds.

### 3. Study Time removed from permanent top-bar chrome
The top **Time** button is removed. Study-time estimates are low-frequency planning information and no longer consume persistent command-bar space.

**My Study** now owns a **Study planning & time estimates** card with:
- whole-suite rough totals;
- disclaimer/planning guidance;
- an expandable all-subject estimate list;
- wrapped text rather than a horizontally scrolling flyout.

Guide language now points users to `My Study → Study planning & time estimates`.

### 4. Personal notes future disposition recorded
The current lightweight subject-level Personal note feature is preserved through W2D because Journal does not exist yet. At W5, native Journal becomes the single notes model:
- PWA-style General notes;
- source/location-linked notes;
- migration of existing Personal notes into Journal;
- retirement of the old parallel Personal note UI after migration/acceptance.

## Preserved W2D R1 architecture
- deterministic non-virtualized 25-resource sidebar;
- Study Resource / Tool Workspace / App Surface taxonomy;
- My Study, Settings and Guide as app surfaces;
- proper seven-section native Settings foundation;
- backup-mandatory deliberate destructive reset;
- W1 canonical Windows backup authority;
- W2A canonical Resource Registry / short paths;
- W2B Location v2 / strict source identity;
- W2C occurrence-level Search / Source Preview / Go / Return;
- 132/132 frozen medical/teaching payload bytes.

## Not in W2D R2
- no outside-click/light-dismiss custom WebView preview plumbing;
- no CockpitHost migration (W3);
- no read-only secondary cockpit tabs yet (W3);
- no Split View implementation (required W4);
- no Journal implementation or Personal-note removal yet (W5);
- no medical-content revision.

## Build/test truth
Static/source/integrity checks only in this environment. Real Windows compilation/runtime acceptance remains the owner's test.
