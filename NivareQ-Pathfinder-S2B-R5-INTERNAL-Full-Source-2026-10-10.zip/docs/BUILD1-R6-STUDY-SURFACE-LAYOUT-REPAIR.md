# Build 1 R6 — Study Surface Layout + Subject Cards Repair

Date: 2026-09-25

## Why R6 exists

R5 real-Windows diagnostics resolved the ambiguity left by R4/R5. The frozen cockpit pages are not failing to load. Across Strategy, Core Acute Care, Cardiology, Pulmonary, Renal, Endocrine, GI and other tested entries, WebView2 reports navigation start, source change, content loading, DOMContentLoaded and successful NavigationCompleted.

Immediately after successful navigation, however, the WebView's XAML size repeatedly changes from approximately `1130x36` to `1130x0`.

The `36` pixel pre-collapse height matches the explicit 36×36 Pathfinder loading ProgressRing in each study tab. The study content root itself has no intrinsic desired height because the WebView is a stretch surface. When navigation completes R5 collapses that loading ring. The selected TabView content then loses its only measured intrinsic height and the WebView is arranged at zero height.

This is a native WinUI host-layout failure, not a medical HTML navigation failure.

## R6 root-cause repair

R6 keeps WinUI TabView, but fixes the actual content presenter that hosts each selected tab:

- Pathfinder now explicitly locates WinUI TabView's internal `TabContentPresenter` after the template is loaded.
- `HorizontalContentAlignment` is forced to `Stretch`.
- `VerticalContentAlignment` is forced to `Stretch`.
- The guard is reapplied on tab selection and checked again after navigation completes.
- The study root Grid and WebView remain explicitly Stretch/Stretch.
- The diagnostic log gains a `layout-guard` event showing whether the presenter was found plus current WebView/TabView dimensions.

This targets the measured 36→0 collapse directly. It does not alter any cockpit file.

## Theme bridge

The user requested the R4 Pathfinder cockpit theme behavior be retained now that the actual host-layout failure has been identified.

R6 therefore restores the R4 runtime-only theme bridge:

- the theme CSS is injected only into the live WebView DOM;
- no frozen medical file is written or changed;
- theme changes update already-open cockpit tabs;
- all nine Pathfinder themes remain available.

The bridge is compatibility-hardened rather than blindly restoring the old mismatch: the cockpit suite commonly uses `--ink` for primary text while the old R4 bridge set `--text`. R6 sets both aliases, and also maps common card/soft surface variables. This preserves the R4 theme concept while avoiding the known dark-text-on-dark-background failure mode.

## Subject library correction

Grouped headings remain, but subjects are no longer presented as plain text rows. Every subject now appears as its own bordered card/tile inside its group with:

- a visible card boundary;
- accent stripe;
- subject title and subtitle;
- study-time badge;
- full-width click/tap target;
- normal ListView selection/hover behavior;
- the same click, right-click/touch-hold, middle-click and Ctrl+click behavior as before.

## Preserved R5/R4 shell features

R6 preserves:

- grouped library sections;
- theme-aware Windows title bar where supported;
- true AppWindow fullscreen with F11/Esc and touch exit control;
- Focus mode;
- Time panel;
- expanded Guide/Study Manual;
- native WebView2/Edge pinch zoom and pan;
- x64 + native ARM64 targets;
- .NET 10 SDK preflight;
- LocalAppData diagnostics.

## Medical integrity

Authoritative R2 ZIP SHA-256:

`8fcde78900b3ecc5bb1616dff7ea3c8b05743c110bff149c12bc12c387734139`

R6 verification:

- 132/132 medical manifest files match.
- R5 → R6 medical tree: 132/132 byte-identical.
- 0 medical files changed.
- Embedded authoritative ZIP hash remains exact.

## Remaining gate

This environment cannot compile or run WinUI 3, so R6 is a source candidate pending real-Windows validation.

The first test is intentionally narrow: Cardiology, Pulmonary and Renal must remain visible after the spinner disappears and must occupy the study viewport instead of collapsing to zero height.

If a failure remains, close Pathfinder and send:

`%LOCALAPPDATA%\NivareQ\Step2Pathfinder\study-view-events.log`

R6's new `layout-guard` entries should make the next diagnosis much more specific.
