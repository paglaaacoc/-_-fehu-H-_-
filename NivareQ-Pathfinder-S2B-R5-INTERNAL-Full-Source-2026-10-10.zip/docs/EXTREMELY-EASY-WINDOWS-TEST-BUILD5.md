# Pathfinder Build 5 — very short real-device acceptance test

## 1. Build + open
Double-click **TEST-BUILD-x64.cmd**.

**PASS:** it builds, Pathfinder opens normally, and a second launch brings you back to the existing window instead of breaking WebView2.

## 2. Accessibility switches
Click **Aa** (or press **Ctrl+Shift+A**). Open one normal study cockpit.

Turn each optional switch ON, then OFF:
- Stronger keyboard focus
- Reduce motion
- More spacious study text

**PASS:** each change is visible/usable where applicable, and turning it OFF returns to normal. Restart Pathfinder once; your chosen switch states should persist.

## 3. Keyboard + Narrator quick check
Without the mouse, press **Tab / Shift+Tab**, then **Ctrl+K**, then **Ctrl+Shift+A**. If convenient, toggle Windows Narrator with **Win+Ctrl+Enter** and Tab across the top bar.

**PASS:** keyboard focus is usable; Search and Accessibility open; Narrator announces sensible names such as Subjects, Back, Home, NivareQ theme, Accessibility and display, Search, My Study, Full screen, Time to study, and App and study guide.

## 4. High Contrast + scaling
Turn on a Windows **Contrast theme**, then return to Pathfinder. Turn it back off. Also try Windows display scaling at **200%** (or your highest convenient setting) and resize Pathfinder fairly narrow.

**PASS:** text/controls remain readable, the cockpit does not become blank, the selected Pathfinder theme returns after Contrast theme is off, and narrow windows do not create a broken/cut-off study surface. Time/Guide/theme may intentionally disappear from the top bar at narrow widths; they remain reachable from Home/Aa.

## 5. Touch regression — only if this PC has touch
Open a cockpit and pinch-zoom, pan while zoomed, and tap controls.

**PASS:** native touch remains normal. If this PC has no touchscreen, skip this item.

## ACCEPT
If all applicable checks PASS, tell the development chat: **“Build 5 accepted.”**
Then the next action is a release cut only; development closes again after that.
