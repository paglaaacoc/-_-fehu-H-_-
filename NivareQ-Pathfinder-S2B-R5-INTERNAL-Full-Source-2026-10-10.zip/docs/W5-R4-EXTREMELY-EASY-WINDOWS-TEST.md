# W5 R4 — Extremely Easy Real-Windows Test

W5 R4 is **not accepted yet**. W4 R3 remains the accepted fallback until you explicitly accept this exact candidate.

## 1 — Build and identify
1. Extract the TEST ZIP to a normal local Windows folder.
2. Double-click **`TEST-W5-x64.cmd`**.
3. Confirm the app visibly says **W5 R4 CANDIDATE**.
4. If compilation fails, stop and send the first useful compiler error.

## 2 — FIRST / blocker retest: Primary cockpit with NO selected text
1. Open an ordinary interactive Primary cockpit such as Cardiology.
2. Make sure **no text is selected**.
3. Right-click or long-touch a normal text/page area.
4. Expected: the native menu contains **Add current place to Journal…**.
5. Choose it.
6. If Journal is visible, expected: its inline editor receives the cockpit/source context.
7. If Journal is not visible, expected: the compact Journal composer opens without forcing Journal to open.

This is the exact R3 failure and is the main R4 acceptance blocker.

## 3 — Selected-text regression
1. Select a short cockpit phrase.
2. Right-click the selection.
3. Expected: **Add selection to Journal…** is present.
4. Choose it and confirm the selected text is copied into the Journal body as before.

## 4 — Read-only source/reference guard
1. Open a verified read-only source preview.
2. Right-click there.
3. Expected: Pathfinder does **not** offer fresh `Add current place/selection to Journal…` capture from that read-only source view. Copy/selection behavior remains available.

## 5 — Quick Journal smoke
1. Open Journal and save/edit one note.
2. Confirm the visible list refreshes immediately.
3. Right-click the Journal tab and use **Show beside in Split View** once.
4. Confirm Journal parks/returns cleanly.
5. From an exact-source Journal note, use **Open source** and confirm Journal/source are arranged side-by-side as in R3.

## 6 — Quick Search / Split regression
- Search `ARDS`: embedded `standards`, `stewardship`, `DMARDs` must not be exact ARDS.
- Open Split empty, park a cockpit beside, change main tabs, Swap twice, Return to tabs. The parked view remains static and no stale placeholder/crash appears.

## 7 — Restart / backup smoke
1. Save a Journal note; restart Pathfinder and confirm it persists.
2. Create/restore one canonical backup if convenient.
3. Backup metadata should identify schema **6 / W5-R4**.

## Acceptance checkpoint
Please report either **Accepted** or the exact first/most serious failure plus the shortest reproduction sequence.
