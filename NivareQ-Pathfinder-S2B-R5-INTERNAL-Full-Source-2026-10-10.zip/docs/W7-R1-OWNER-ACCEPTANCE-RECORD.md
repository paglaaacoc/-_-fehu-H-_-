# W7 R1 Owner Acceptance Record

**Product:** NivareQ Step 2 Pathfinder — Windows  
**Gate:** W7 — Shell / Settings / Workspace Completion + Themes + Guide + Compatibility/Polish  
**Accepted revision:** W7 R1  
**Owner acceptance date:** 2026-09-30

W7 R1 is accepted after real-Windows testing and supersedes W6 R3 as the active accepted Windows development baseline. W6 R3 remains historical rollback.

## Real-Windows acceptance evidence
- The W7 build compiled and ran successfully.
- Four additive reading themes and W7 shell/workspace polish passed the owner test.
- Supplemental cockpits 19–22 drill feedback repair passed.
- W6 Search, Journal, Split View and UWorld Selector foundations remained working.

## Accepted known deferred issue
The W7 runtime selection-cache attempt did **not** solve the already-known large/multi-block Journal selected-text truncation defect. The owner explicitly chose not to spend another W7 revision on it. Carry it to the final app-wide closure/release-readiness audit; do not represent it as fixed.

Journal remains plain text. Rich-text Journal storage remains deferred. Journal Pen Scratchpad Gate remains CLOSED / explicit owner decision required.

## Integrity
- Frozen medical payload remains 132/132 byte-identical.
- Canonical backup schema remains 7.
- W7 source/static QC was 1072 PASS / 0 FAIL before owner real-Windows acceptance.
