# W6 R3 — Extremely Easy Real-Windows Test

## 1. Build / identity
1. Extract the entire TEST ZIP to a normal local Windows folder.
2. Double-click **TEST-W6-x64.cmd**.
3. Build must succeed and Pathfinder must visibly say **W6 R3 CANDIDATE**.
4. If compilation fails, stop and send the complete error.

## 2. Multi-block Journal selection — highest priority
1. Open ordinary Primary Cardiology.
2. Drag-select several bullets/paragraphs so the highlight clearly spans multiple blocks.
3. Right-click → **Add selection to Journal…**.
4. The note body must contain the entire visible selected passage, not just the first bullet/fragment.
5. Plain-text line breaks are expected; rich text is intentionally deferred.

## 3. Search selection — immediate results
1. Select a distinctive single word/phrase such as `severe` or `RV infarction`.
2. More tools → **Search selection in Pathfinder…**.
3. Search must open prefilled AND results must already be visible immediately.
4. You should not need to delete/retype a character to trigger results.

## 4. Selector cockpit routing consistency
1. From Cardiology → More tools → **Open UWorld Selector for this cockpit**.
2. The Selector filter/search field should visibly contain `cardiology`, and the Cardiology recipe should be revealed/positioned.
3. Repeat from Psychiatry or Obstetrics. Their stable cockpit slug should also populate the filter, with both crossover recipes visible where applicable.
4. Opening Selector never changes or implies any UWorld completion/count.

## 5. Context-menu regression
- Native **More tools** should still contain both Pathfinder commands.
- Root **Add selection/current place to Journal…** and **Pathfinder Glossary** must remain unchanged.
- No selection → **Add current place to Journal…** still works.

## 6. Quick W6/W5 smoke
- Selector count record/clear/restart persistence.
- Split View remains as accepted in W5.
- Journal inline/popup workflows remain normal.
- Search `ARDS`: embedded `standards`/`stewardship`/`DMARDs` are not exact ARDS matches.

## Acceptance
W6 R3 remains unaccepted until the owner explicitly accepts it after real-Windows testing. W5 R4 remains the accepted fallback.
