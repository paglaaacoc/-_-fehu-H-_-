# W1 — Canonical Persistence & Backup Safety Foundation

**Candidate:** W1 R3 source candidate  
**Date:** 2026-09-29  
**Accepted baseline:** Windows v1.2 remains untouched/authoritative rollback until owner acceptance.

## Purpose
W1 makes Windows Pathfinder the canonical/master persistence and whole-app backup authority before W2–W7 add larger state surfaces. It deliberately does not move normal user data out of `%LOCALAPPDATA%\NivareQ\Step2Pathfinder`.

## Implemented

### Durable local writes
- `settings.json`, `personal-study.json`, and the new bounded `backup-extensions.json` use temporary-file + flush-to-disk + replace/move semantics.
- Successful replacement retains a `.lastgood` predecessor for settings/personal/extension recovery.
- Save APIs now return explicit success/failure instead of swallowing every exception.
- Persistence failures are recorded for truthful backup/recovery reporting.
- Ordinary runtime save failures also queue a one-per-session user-visible warning when the UI can safely show one; Pathfinder does not silently present an in-memory change as durably saved.

### Corrupt-startup recovery
- Unreadable current settings/personal/extension files are moved into `Recovery\Corrupt` rather than silently overwritten.
- Pathfinder attempts the corresponding `.lastgood` copy.
- If no valid last-known-good copy exists, a safe in-memory fallback is used while the corrupt original remains preserved.
- Recovery notices are surfaced after startup.

### Canonical Windows backup contract
- New canonical schema: `BackupSchemaVersion = 2`.
- `FormatId = nivareq.step2pathfinder.backup`.
- `ContractAuthority = windows-canonical`.
- Explicit producer/build/export metadata.
- Typed Windows `ShellSettings` + `PersonalStudy`.
- Explicit `Coverage` declaration.
- Schema-v2 is fail-closed for unknown or missing core fields. Future richer canonical state must use a newer schema or `PreservedExtensions`; W1 will not silently deserialize-and-drop it.
- Bounded `PreservedExtensions` dictionary for richer cross-platform/future state that W1 cannot yet natively own.

### Import compatibility
W1 can import:
1. released Windows schema-v1 backups;
2. accepted PWA B4A schema-v1 backups;
3. W1 canonical schema-v2 backups.

Compatibility behavior is semantic, not name-only:
- PWA utility tabs are translated to Windows shell-tab IDs.
- Missing Windows-only accessibility fields in a legacy/PWA backup preserve the current Windows values.
- PWA `PwaState` is preserved opaquely instead of being discarded.
- Unknown legacy top-level fields are carried as bounded opaque extensions.
- PWA Sage/Lavender/Dawn theme IDs may remain stored even before Windows gains those visual themes; current Windows visually falls back safely without rewriting the retained preference, and the restore preview explicitly warns that the current registry cannot render that retained ID yet.
- The PWA-native UWorld Selector is **not** treated as the same source as Windows v1.2's legacy checkbox-selector PDF. Its live tab/source locations/My Study associations are not redirected to the PDF. The richer PWA state remains preserved for W6.
- If a skipped legacy/PWA tab was before or was the selected tab, W1 adjusts the restored selected index deterministically rather than landing on the wrong neighboring tab.

### Strict restore gate
Before any AppData mutation W1 validates:
- JSON/envelope/schema/format authority;
- required canonical metadata;
- settings booleans/tab kinds/resource IDs;
- bounded tab/item/map/string counts;
- finite bounded coordinates;
- known progress values;
- duplicate bookmark/resource mappings;
- known Windows resource ownership for state that W1 actually applies;
- bounded preserved-extension keys/aggregate size;
- schema-v2 core-field allowlists/required fields and self-consistent `Coverage.PreservedOpaque` ↔ `PreservedExtensions` keys.

A restore preview shows source type and counts plus compatibility warnings before commit.

### Transactional multi-file restore
Restore writes are staged under the existing AppData root. Before mutation W1 records snapshots and a `restore-transaction.json` recovery journal. Recovery paths are validated to remain inside Pathfinder AppData before they may mutate anything. If a write fails, all already-targeted stores are rolled back. Rollback writes intentionally do not rotate the failed restore candidate into `.lastgood`; the pre-restore predecessor remains the recovery truth. After every target is written, W1 records an explicit committed marker before cleanup; therefore an undeleted cleanup journal cannot later roll back an already-committed restore. If the process is interrupted before that marker, startup checks the journal before normal state load and attempts rollback. Recovery material is retained if rollback is incomplete.

### Stale-writer protection after restore
Windows v1.2 cannot rebuild all live WebViews in-place safely yet. After a successful restore, W1 therefore:
- applies supported in-memory settings/My Study immediately;
- defers session persistence until restart;
- blocks pre-restore cockpit WebViews from overwriting restored reading positions;
- asks for one restart to reopen the restored tab/session state.

### Fresh backup snapshot
Before export W1 attempts to capture current positions from every live study WebView, flushes shell/My Study/extension stores, and reports any capture/local-flush failures. The exported backup itself is created from current in-memory canonical state, so a local AppData flush failure does not silently turn into a falsely successful durability claim. The selected backup file is written with Windows transacted-storage semantics before Pathfinder reports `Backup saved`, so an interrupted file-picker export is not intentionally treated as a completed canonical backup.

## Truthful W1 coverage boundary
W1 does **not** claim that Windows v1.2 can yet extract every meaningful cockpit-local WebView state. Therefore the canonical backup declares as deferred:
- live cockpit review/check/mastery/quiz/mode state — W3;
- native Journal provider — W5;
- native UWorld Selector provider — W6.

Accepted PWA versions of those features are retained opaquely when imported, so W1 does not destroy them while later Windows providers are still pending.

## Safety limits
- Import file cap: 100 MiB in W1.
- Preserved opaque extension aggregate cap: 90 MiB.
- Additional per-field/count bounds are enforced by the parser.
These are W1 safety limits, not a promise that future Windows-native Journal/Selector storage must remain browser-sized. Revisit deliberately when W5/W6 providers exist.

## R2 build-tooling repair
The first owner-side R1 compile attempt passed the medical and .NET SDK gates but failed inside WinUI XAML markup generation because the descriptive extracted package path produced a 265-character generated `MainWindow\.g.cs` path. R2 leaves all runtime/product source unchanged and compiles from a short temporary staging path, then verifies/copies the finished app back. This is build tooling only and does not alter Pathfinder data architecture.

## Explicitly unchanged
- no portable app-local `Data\` migration;
- `%LOCALAPPDATA%\NivareQ\Step2Pathfinder` remains normal Windows storage root;
- WinUI-generated STA + mutex/activation startup unchanged;
- 132/132 medical payload files unchanged;
- no Journal implementation;
- no Split View implementation;
- no W2 Search/Location/Source Preview implementation.
