# W2D R2 → W3 R1 File Diff

Generated from SHA-256 comparison against the accepted W2D R2 FULL ZIP.

- Added: 13
- Changed: 14
- Removed/renamed: 2

## Added
- `TEST-W3-x64.cmd`
- `W3-CANDIDATE-START-HERE.txt`
- `continuity/W3_STATE.json`
- `docs/W3-R1-EXTREMELY-EASY-WINDOWS-TEST.md`
- `docs/W3-R1-IMPLEMENTATION.md`
- `docs/W3-R1-JAVASCRIPT-SYNTAX-CHECK.json`
- `docs/W3-R1-STATIC-QC-RESULT.json`
- `src/NivareQ.Step2Pathfinder/MainWindow.CockpitHost.cs`
- `src/NivareQ.Step2Pathfinder/Models/CockpitHostModels.cs`
- `src/NivareQ.Step2Pathfinder/Services/CockpitStateRegistry.cs`
- `src/NivareQ.Step2Pathfinder/Services/CockpitStateService.cs`
- `src/NivareQ.Step2Pathfinder/ShellData/cockpit-state-allowlist.json`
- `tools/w3-static-qc.py`

## Changed
- `BUILD-ON-WINDOWS.cmd`
- `CONTINUITY-STATUS.txt`
- `TEST-BUILD-x64.cmd`
- `VERIFY-ONLY.cmd`
- `src/NivareQ.Step2Pathfinder/MainWindow.Location.cs`
- `src/NivareQ.Step2Pathfinder/MainWindow.PersonalStudy.cs`
- `src/NivareQ.Step2Pathfinder/MainWindow.Settings.cs`
- `src/NivareQ.Step2Pathfinder/MainWindow.SourcePreview.cs`
- `src/NivareQ.Step2Pathfinder/MainWindow.xaml`
- `src/NivareQ.Step2Pathfinder/MainWindow.xaml.cs`
- `src/NivareQ.Step2Pathfinder/Models/BackupModels.cs`
- `src/NivareQ.Step2Pathfinder/Services/BackupContractService.cs`
- `src/NivareQ.Step2Pathfinder/Services/PathfinderPaths.cs`
- `tools/build-windows.ps1`

## Removed/renamed
- `TEST-W2D-x64.cmd`
- `W2D-CANDIDATE-START-HERE.txt`
