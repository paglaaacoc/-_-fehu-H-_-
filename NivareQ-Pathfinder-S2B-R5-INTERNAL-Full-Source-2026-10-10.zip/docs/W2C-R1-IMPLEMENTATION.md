# W2C R1 — Search + Read-only Source Preview + Return Position

## Base
W2B R2, owner-accepted on real Windows.

## Implemented
- Search result cards now separate **Preview source** from **Go to cockpit**.
- Preview source loads the verified frozen cockpit bytes through a unique `.pathfinder.invalid` origin in an isolated WebView2.
- Preview source uses the same semantic Search destination resolver as the primary cockpit path and emits a strict Location-v2 source identity.
- Preview has no `WebMessageReceived` study bridge and no Windows persistence writes. User state-changing controls/links are blocked for trusted user input while scroll, touch/pinch zoom, selection/copy and native context menu remain available.
- Go to cockpit deliberately moves/reuses the single primary cockpit.
- Before moving an existing primary cockpit, Pathfinder captures its Location-v2 resume point plus temporary cockpit search/reveal state.
- A native InfoBar exposes **Return to previous position**. Return restores the prior transient search/reveal state first, then the semantic Location-v2 position.
- Failed Search/strict-source jumps restore the prior cockpit view and location.
- New primary cockpit opened from a verified preview receives the strict source location as its startup target.

## Not in W2C
- Journal source links (Journal itself is W5).
- detachable preview windows (architecture allows them; not required for this gate).
- Split View (required W4).
- shell taxonomy / proper Settings migration (W2D).
- CockpitHost v1/state adapters (W3).

## Integrity
No frozen medical/teaching source file was edited. W2A medical/resource QC remains mandatory.
