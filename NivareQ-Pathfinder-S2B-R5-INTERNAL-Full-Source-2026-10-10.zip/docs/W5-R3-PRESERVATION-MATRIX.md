# W5 R3 Preservation Matrix

- **Accepted fallback:** W4 R3.
- **Candidate:** W5 R3, unaccepted until real-Windows owner acceptance.
- **Medical payload:** 132/132 frozen files unchanged; 0 medical source changes.
- **Backup:** schema 6 retained; ProducerBuild advances to `W5-R3` only.
- **Search:** W5 boundary-correct exact matching retained.
- **Split View:** W5 R2 empty/static/hidden-secondary behavior retained; owner reported it perfect on real Windows.
- **Journal persistence:** native snapshot + append-only log retained; rollback-safe legacy Personal migration retained.
- **Journal R3 changes:** shell-tab Show beside; inline visible editor; immediate in-place refresh; cockpit WebView capture; stronger current-study resolution; Split-aware exact-source open.
- **Search/Glossary:** remain tabs; no app-surface redesign.
- **Journal Pen Scratchpad:** CLOSED future gate; explicit owner decision required to open.
