# W8 Installer I1 — GitHub CI evidence

- Repository: `tanzim137/RAM-TEST`
- Branch: `pathfinder-w8-installer-i1`
- Commit: `3403c70efd87c6c607c79f3c41db81536ee2fbe2`
- Workflow: `Pathfinder W8 Installer I1 CI`
- Run number: **1**
- Run ID: `37330421196`
- Conclusion: **SUCCESS**
- Compiler: verified Inno Setup **7.1.0 x64** installer, source release hash checked before installation.

Compile-only packaging gate:
- x64 installer definition: PASS
- ARM64 installer definition: PASS
- uninstall Pascal code: PASS
- typed destructive-removal flow: compiler-valid

Compile-only setup hashes from CI dummy payloads (syntax/package evidence only; these are not distributable Pathfinder installers):
- x64: `1e1ba27c7c545e76b1dc2f868d1c2de078615da8f8ce11f14a198ef38cbbc8ee`
- ARM64: `42aea84519190a5f5541e875a4771e4bc604e2a3c6e2e9a70ea4dc7dec01a02f`

The CI gate intentionally validates the installer definitions and uninstall code without shipping a dummy artifact. The owner TEST package builds the real installer from the byte-identical accepted R2 source on Windows.
