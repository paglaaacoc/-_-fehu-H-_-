# Build 1 R2 Compile Repair

This is a compile-only repair of Build 1. It does not advance the product roadmap and does not modify audited medical content.

## Windows compile errors addressed

1. `Windows.UI.Text.FontWeights` -> `Microsoft.UI.Text.FontWeights` for WinUI 3.
2. WebView2 environment construction now uses WinUI/WinRT `CoreWebView2Environment.CreateWithOptionsAsync(...)` with the same LocalAppData user-data folder.
3. `Windows.UI.ColorHelper` -> `Microsoft.UI.ColorHelper` for Windows App SDK / WinUI 3.
4. The XAML compiler internal error seen after those C# errors is treated as downstream until a clean Windows compile proves otherwise.

## Runtime-output cleanliness

The publish script still places user-facing builds only under `Built Apps/` and keeps build logs under `Build Logs/`. README, QC, continuity, integrity, and source files are not copied beside the built app executable.

## Medical immutability

No file under `src/NivareQ.Step2Pathfinder/MedicalPayload/` was edited. The authoritative R2 medical ZIP and the frozen per-file SHA-256 manifest remain the gate before and after publishing.
