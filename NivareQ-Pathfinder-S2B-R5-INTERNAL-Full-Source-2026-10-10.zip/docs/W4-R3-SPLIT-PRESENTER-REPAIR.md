# W4 R3 — Split View selected-presenter / stale-placeholder repair

## Why R3 exists
W4 R2 passed the two W4 R1 crash-blocker retests on real Windows:
- repeated **Swap panes** no longer crashed Pathfinder;
- right-clicking the current main tab and choosing **Show beside in Split View** no longer crashed.

R2 was nevertheless rejected because clicking the tab currently hosted in the secondary pane could leave the main TabView visually stuck on the message:

> This view is currently shown in the other Split View pane.

The logical primary/secondary assignment could continue swapping underneath that stale presenter. With Pulmonary main and Cardiology beside, repeated Cardiology/Pulmonary tab clicks could swap which live cockpit was actually beside while the main pane remained on the stale placeholder. Selecting an unrelated third tab could temporarily make normal content visible again.

One stress-test session also produced a single non-reproducible WebView2 `BrowserProcessExited` recovery message. The existing **Reload cockpit safely** recovery UI appeared. This remains a retest watch item, not a separately proven root cause.

## R2 root cause left behind
R2 correctly deferred pane mutation until after `SelectionChanged` and correctly avoided the old two-parent XAML crash. However, when the user clicked the secondary tab, that placeholder tab was already selected before `SwapSplitPanesAsync` restored its live content.

Changing `TabViewItem.Content` from placeholder -> live cockpit while that item was already selected could leave WinUI's selected `ContentPresenter` presenting the old placeholder even after the logical ownership variables had swapped.

## R3 bounded repair
R3 changes only the Split View pane-transfer/presenter transaction plus candidate identity/docs.

The transaction now:
1. captures old Primary, old Secondary, live secondary content and the exact placeholder instance;
2. if the secondary placeholder tab is currently selected, reselects the old Primary first;
3. yields to WinUI and verifies the old secondary placeholder is detached from the TabView visual tree;
4. detaches the live secondary content from `SecondaryWorkspaceContent` and verifies that detach;
5. restores the live secondary content to its tab **while that tab is unselected**;
6. selects that now-live tab and verifies its content root attaches as the new Primary presenter;
7. verifies the old Primary live root has detached from TabView;
8. creates one new placeholder for the old Primary and moves the old Primary live root into the secondary host;
9. verifies post-transaction ownership invariants before saving workspace state.

## New R3 safeguards
- Placeholder instances are explicitly marked and tracked.
- A successful active split must have **exactly one** placeholder-owning tab.
- The selected tab must equal the recorded Primary tab.
- The recorded Secondary tab must own the tracked placeholder.
- `SecondaryWorkspaceContent` must own the recorded live secondary content.
- Deferred secondary-tab swaps carry a selection-generation token; a newer tab selection invalidates an older deferred request.
- Transfer failure remains fail-safe: Pathfinder restores both live views as ordinary tabs, closes Split View, and reports the failure instead of terminating.

## Preserved scope
- No frozen medical/teaching HTML changed.
- No cockpit-state allowlist or medical teaching content changed.
- Backup schema remains 5; candidate producer identity advances from `W4-R2` to `W4-R3` only.
- W3 R1 remains the accepted development baseline until owner acceptance of R3.
- Existing low-severity sidebar vertical-position jump and 19–22 drill-answer visual feedback residuals are unchanged.
