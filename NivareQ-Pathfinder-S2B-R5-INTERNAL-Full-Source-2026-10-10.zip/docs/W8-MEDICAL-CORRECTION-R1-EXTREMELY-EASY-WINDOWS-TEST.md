# W8 Medical Correction R1 — extremely easy Windows test

This is a **content-only regression test**, not another feature hunt. W8 Closure R1 remains accepted until you explicitly accept this candidate.

1. Extract the TEST ZIP to a normal short folder.
2. Double-click **`TEST-MEDICAL-CORRECTION-x64.cmd`**.
3. Before compilation, confirm you see **Medical payload integrity PASS: 132/132** and **Source resource registry PASS: 25 resources**.
4. Let Pathfinder launch. Open a few ordinary cockpits (Cardiology, GI, Pediatrics, Surgery/Trauma/EM) and confirm normal rendering/navigation/search.
5. In **GI**, open several **One step deeper** items (for example EoE, IBD cancer surveillance, acute pancreatitis management, SBP/HRS, variceal bleeding, HCC). PASS if the new lines render normally without layout/interaction regressions.
6. Open the **UWorld Selector**. PASS if it now treats Allergy/Immunology, ENT/Ophthalmology, Poisoning/Environmental and General Principles/Miscellaneous as supplemental cockpit coverage rather than claiming they have no cockpit, while retaining the residual sweep/final zero-unused audit.
7. Brief smoke only: open Journal, Search and Split View once. They should behave exactly like accepted Closure R1; this build intentionally changes none of them.

You do **not** need to retest the old closure-adversarial paths or deliberately damage AppData.

If all passes, report **W8 Medical Correction R1 ACCEPTED**. If something fails, send the first clear screenshot/error and the cockpit/topic you were viewing.
