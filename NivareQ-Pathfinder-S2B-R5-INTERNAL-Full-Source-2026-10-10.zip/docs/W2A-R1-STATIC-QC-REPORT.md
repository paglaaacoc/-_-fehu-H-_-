# W2A R1 Static / Source QC Report

**Result: PASS**

- W2A contract checks: **912 passed / 0 failed**.
- Frozen payload: **132/132** files present and matching authoritative SHA-256 after old→new path migration.
- Runtime resources: **25** total — 23 study resources + 2 reference resources.
- Registry aliases: **50** canonical/legacy aliases, no conflicts.
- Runtime HTML dependency audit: **0 concrete relative file dependencies** across the runtime resource set.
- Longest canonical path inside `MedicalPayload/R2`: **49 characters**; **52** counted from `MedicalPayload` including `R2/`.
- C# lexical balance checks: **8/8 pass** for W2A-changed C# files.
- XAML/project XML well-formed checks: **3/3 pass**.
- `App.xaml.cs` remains exact to the protected v1.2 startup hash; no custom `Main` reintroduced.
- W1 canonical persistence/backup markers remain present.
- Portable app-local Data architecture remains absent.
- Build tooling now gates both the 132-file medical manifest and the 25-resource registry in source and published output.

## Important limitation
This environment cannot truthfully perform the Windows WinUI compile/device run. W2A R1 remains **pending real-Windows compile + device testing** using `TEST-W2A-x64.cmd`.
