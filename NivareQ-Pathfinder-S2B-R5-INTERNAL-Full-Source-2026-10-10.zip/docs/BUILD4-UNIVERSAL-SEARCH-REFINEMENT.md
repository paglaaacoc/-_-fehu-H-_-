# NivareQ Step 2 Pathfinder — Build 4
## Universal Search + Medical Glossary + v1.1 Refinement Candidate

Build 4 starts from the **user-accepted Build 3 — Personal Study Layer** baseline.

The 132-file medical payload remains immutable. Build 4 adds shell-owned search, glossary/index, native context-menu integration, Guide documentation, and closed-tab recovery refinement only.

## 1. Universal Search — accepted behavior preserved, results made explainable

Use the top-bar **⌕ Search all cockpits** command or `Ctrl+K`.

Build 4 searches all 23 numbered study cockpits locally/offline. It indexes visible HTML plus frozen JavaScript teaching strings used by the cockpit renderers. It does not rewrite or annotate the medical source files.

Search result behavior:
- the existing all-token cockpit matching behavior is preserved;
- a full normalized phrase match is ranked first under **Exact match**;
- exact phrases are highlighted inside the result snippet;
- non-exact results remain available under **Other matches/Cockpit matches**;
- the actual matching query terms are highlighted inside those snippets so the reason for the match is visible;
- snippets are centered around real matched material, and can include compact additional fragments when query terms are separated in the source;
- clicking **Open result** opens/selects the matching cockpit and uses the existing runtime-only jump/outline behavior;
- the Search tab remains session-restorable.

## 2. Safe normalization — no fuzzy guessing

Search comparison is normalized for lookup only:
- capitalization is ignored;
- accents/diacritics are normalized (`Barré` and `barre` compare equivalently);
- common hyphens/dashes, slash, vertical bar and punctuation act as separators;
- repeated whitespace is collapsed.

The original cockpit text is always displayed unchanged.

**There is no Pathfinder fuzzy-search/typo engine in Build 4.** Native Windows proofing remains explicitly enabled in the Universal Search and Medical Glossary text boxes. Windows can offer spelling suggestions without Pathfinder silently guessing a medical term.

## 3. Deterministic aliases only

A small curated alias bridge handles genuinely equivalent names/abbreviations when the cockpit uses a different literal form. Examples include:
- `Helicobacter pylori` → literal cockpit term `H. pylori`;
- `Stevens-Johnson syndrome` → literal cockpit term `SJS`.

Alias matching is deterministic and lower-priority than literal/normalized matching. It does not perform semantic inference. Ambiguous abbreviations are not silently used as alias bridges.

## 4. Medical Abbreviation Glossary / Index

Build 4 includes a **Pathfinder-owned medical abbreviation glossary/index** generated from a comprehensive candidate audit across all 23 numbered runtime cockpits and then curated to remove obvious UI/code/question-ID noise.

Current glossary candidate contains **1000 curated entries**. Entries can include:
- abbreviation or canonical short term;
- expansion;
- accepted aliases;
- subject locations;
- a brief ambiguity note when necessary.

Ambiguous abbreviations deliberately retain multiple curated meanings rather than pretending Pathfinder knows which meaning the surrounding sentence intends. Example: `PE` can list pulmonary embolism and physical examination. The student uses context.

The glossary is shell-owned (`ShellData/medical-glossary.json`) and does not change any medical-payload byte.

Access paths:
- Home → **Medical glossary**;
- Universal Search → **Open medical glossary**;
- Universal Search also shows matching glossary entries;
- select text inside a cockpit → right-click → **Pathfinder Glossary** submenu.

## 5. Native WebView2 context menu remains intact

Build 4 appends a **Pathfinder Glossary** submenu to the existing Edge/WebView2 context menu when text is selected.

For an exact glossary selection such as `GCS`, the submenu can show:
- `GCS — Glasgow Coma Scale`
- `Open glossary for “GCS”…`

For an ambiguous selection such as `GBS` or `PE`, all curated exact meanings are shown. Pathfinder does **not** choose a meaning from context.

The normal WebView2 menu is preserved: the handler deliberately does not mark the context-menu request as handled. Copy, Copy link to highlight, Print, Inspect and other native commands remain available.

## 6. Recently-closed tab refinement

Build 4 preserves the accepted Build 3 personal-study system and strengthens accidental-close recovery:
- each closed study tab keeps its own last reading-position snapshot;
- up to 10 closed snapshots are retained for the current session;
- repeat `Ctrl+Shift+T` to walk backward through the closed-tab stack;
- right-click a study tab → **Reopen closed tab**;
- My Study → Recently closed tabs → reopen a specific snapshot.

Duplicate tabs of the same subject remain independently recoverable.

## 7. ? Guide updated

The in-app **? Guide** now documents:
- Universal Search exact/other result behavior;
- result highlighting and normalization;
- deterministic alias behavior;
- Medical Glossary / Index;
- select-text/right-click glossary lookup;
- native Windows spelling/proofing and the explicit absence of fuzzy search;
- consolidated keyboard shortcuts;
- mouse and touch gestures.

## 8. Accepted Build 3 behavior preserved

Build 4 does not redesign accepted Build 3 features. It preserves:
- exact cockpit/session resume;
- bookmarks and personal notes;
- favorites and recently studied;
- optional manual progress states (OFF by default; hide-not-delete);
- pinned tabs and tab management;
- personal-data backup/restore;
- R6 full-height WebView/TabView repair;
- Pathfinder theme authority;
- fullscreen/top-aligned tabs;
- native WebView2 touch/pinch/pan.

## Explicit future gates — NOT Build 4

The following remain deferred:
- fuzzy/typo search or medical spelling inference;
- context-aware abbreviation disambiguation;
- deep persistent highlighting inside cockpit medical text;
- semantic/AI search inference;
- Build 5 accessibility/compatibility gate: keyboard-only audit, screen-reader review, high contrast, 125–200% DPI/scaling matrix, narrow-window behavior, reduced motion, and dedicated touch regression testing.

## Status

Static/source QC has passed. Final package checksum/ZIP verification is performed at delivery. Native Windows x64 compilation/runtime validation remains required before Build 4 can be accepted and v1.1 can be cut.
