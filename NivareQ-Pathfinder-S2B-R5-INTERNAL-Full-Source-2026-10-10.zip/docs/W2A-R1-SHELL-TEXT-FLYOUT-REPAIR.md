# W2A R1 — Native Selectable Shell Text Flyout Repair

## Observed regression/defect
On real Windows under Parchment, selectable text on native shell pages (for example My Study/Search explanatory text) could display the default WinUI TextBlock selection command flyout with an unreadable light/white command treatment.

The owner explicitly verified:
- cockpit/WebView2 text context menu: healthy;
- native TabView right-click menu: healthy.

The defect was therefore isolated to native selectable `TextBlock` command flyouts.

## Repair
`MainWindow.TextSelection.cs` applies a native `MenuFlyout` to selectable shell `TextBlock`s when a shell view is loaded.

Commands:
- Copy — enabled only when selection is non-empty;
- Select all.

The repair does not disable hit testing, text selection, touch selection, scrolling, cockpit/WebView2 menus or TabView menus. Clipboard failure is treated as a non-fatal convenience failure.

## Device verification required
Verify at minimum:
- Parchment: Search or My Study selected text → readable Copy/Select all;
- a dark theme: same;
- cockpit selected text menu remains unchanged/healthy;
- tab right-click menu remains unchanged/healthy.
