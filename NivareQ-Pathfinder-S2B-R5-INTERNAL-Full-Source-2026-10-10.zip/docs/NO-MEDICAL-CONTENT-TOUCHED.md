# Medical immutability gate — Build 4

**PASS at source packaging stage.**

Authoritative R2 patched hub ZIP SHA-256:
`8fcde78900b3ecc5bb1616dff7ea3c8b05743c110bff149c12bc12c387734139`

The complete study hub remains byte-identical inside:
`src/NivareQ.Step2Pathfinder/MedicalPayload/Step2CK-2026-One-Launch-Study-Hub/`

`Integrity/MEDICAL_PAYLOAD_SHA256_MANIFEST.txt` records all 132 source-file hashes.

Build 4 verification:
- 132/132 manifest entries PASS;
- changed vs user-accepted Build 3: 0;
- added medical files: 0;
- removed medical files: 0.

Universal Search is read-only. It reads the frozen files and builds an in-memory search corpus. Result jumping is performed only through runtime WebView2 scripting against the displayed page. No bundled medical file is rewritten.
