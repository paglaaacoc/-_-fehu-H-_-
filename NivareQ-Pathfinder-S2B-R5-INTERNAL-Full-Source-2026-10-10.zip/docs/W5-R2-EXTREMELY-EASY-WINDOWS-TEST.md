# W5 R2 — Extremely Easy Real-Windows Test

W5 R2 is **not accepted yet**. W5 R1 failed the Windows compile gate before runtime testing; R2 is its narrow compile-repair successor. Use this test on the extracted TEST package. W4 R3 remains the accepted fallback until you explicitly accept W5 R2.

## 1 — Build and identify
1. Double-click **`TEST-W5-x64.cmd`**.
2. Let it build and launch.
3. Confirm the title/about UI says **W5 R2 CANDIDATE**.
4. If it does not compile or launch, stop and report the first useful error. Do not continue testing a partial build.

## 2 — ARDS search boundary check
1. Open Search.
2. Search **`ARDS`**.
3. Genuine standalone/term ARDS occurrences should be treated as the exact matches and rank accordingly.
4. `standards`, `stewardship`, `DMARDs`, or other larger words containing the letters `ards` must **not** be labelled/highlighted as exact ARDS occurrences.
5. It is okay if useful partial matches still appear lower as non-exact results.
6. Open at least one genuine exact ARDS result and confirm the destination/highlight is the actual ARDS occurrence.

**Fail W5 if unrelated embedded substrings still appear as Exact match or exact-source navigation lands on the wrong substring.**

## 3 — Empty/static Split View
Use Pulmonary/Cardiology because that sequence exposed the older W4 problems.

1. Open Pulmonary normally.
2. Press Split View **without** choosing Show beside.
   - Expected: Split View stays open with an intentionally **empty second pane**.
3. Deliberately choose Cardiology → **Show beside**.
   - Expected: Cardiology appears beside.
   - Cardiology's tab should disappear from the main tab strip while parked.
4. Click other main tabs and several Study Library items.
   - Expected: only the main pane changes; Cardiology remains static beside.
5. Click Cardiology in the Study Library while Cardiology is already beside.
   - Expected: no duplicate and no implicit swap. Cardiology stays beside; Pathfinder may briefly indicate that it is already open beside.
6. Use **Swap panes**.
   - Expected: Cardiology becomes main and the former main view becomes the hidden/static beside view.
7. Repeat Swap panes several times.
   - Expected: no crash, stale placeholder, disabled Swap button, duplicate cockpit, or visual-parent error.
8. Use **Return to tabs**.
   - Expected: the exact parked view's tab returns to the main tab strip and Split View remains open with an empty second pane.
9. Put another view beside and use **Close Split View**.
   - Expected: the parked tab is safely returned before Split closes.

## 4 — Search Source Preview + beside
1. From Search, Preview a verified source result.
2. Choose **Show beside** for that read-only source view.
3. Expected: Search can remain main; the read-only source appears beside; its corresponding preview tab is hidden from the main tab strip while parked.
4. Use **Return to tabs**.
5. Expected: that same read-only tab returns. It must **not** be silently discarded simply because it is read-only.

## 5 — Journal basic test
1. Open **Journal** from the sidebar.
2. Create a **New general note** with a title and body. Save it.
3. Search for a distinctive word from that note. Confirm it appears.
4. Edit the note, make a change, then Cancel.
   - Expected: Pathfinder asks whether to discard unsaved changes or keep editing.
5. Choose Keep editing, then save.
6. Create another note and delete it; confirm deletion is deliberate.

## 6 — Journal from Study / source link
1. Open a normal study cockpit.
2. Select a small piece of cockpit text if convenient.
3. Use the note-to-Journal action / **From current Study**.
4. Expected: the Journal editor identifies the cockpit and, when capture succeeds, carries a verified source/location link; selected text may be prefilled.
5. Save it.
6. From Journal, use **Open source**.
7. Expected: Pathfinder opens the exact verified source/location as a state-read-only source view rather than silently redirecting to a different source.

## 7 — Legacy Personal-note migration, if your existing profile has one
If your W4 profile already contains a Personal subject note:
1. Launch W5 once.
2. Open Journal.
3. The old subject note should appear **once** in Journal.
4. The old active Personal-note editor should no longer be the notes UI.
5. Restart W5 and confirm the note is not duplicated.

If you had no old Personal note, simply skip this section.

## 8 — Restart / persistence
1. Leave at least one Journal note saved.
2. Optionally leave Split View open (empty or with a secondary view).
3. Close Pathfinder normally and reopen.
4. Confirm Journal content persists and normal accepted study state still persists.
5. Confirm restored Split state does not create a duplicate/stale secondary view.

## 9 — Backup/restore smoke test
1. Create a fresh Pathfinder backup from Settings.
2. Add a distinctive temporary Journal note after the backup.
3. Restore the fresh backup.
4. Confirm the Journal matches the restored backup state and Pathfinder reports no data-integrity failure.
5. Confirm existing cockpit state/settings remain consistent with the backup.

W5 canonical backup should identify **schema 6 / W5-R2**.

## 10 — Watch item
During W4 R2 stress testing, one non-reproducible WebView2 `BrowserProcessExited` recovery message appeared. If **any** such message appears during W5 testing, report exactly what you were doing when it appeared. Do not assume it is related unless reproducible.

## Acceptance checkpoint
Please report either:
- **Accepted**, if all important flows above pass; or
- the exact first/most serious failure plus the shortest reproduction sequence.

Do not treat W5 R2 as the accepted baseline until the owner explicitly says it is accepted.
