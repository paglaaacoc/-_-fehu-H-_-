# Build 2 RC1 — Session Restore + Theme Authority + Friend-Facing Polish

## Scope
Build 2 RC1 is a bounded shell-only successor to Build 1 R7. No audited medical source file was edited.

## 1. Last-session restore
`settings.json` now stores:
- whether session restore is enabled (default ON)
- the ordered list of open study / shell tabs
- the selected tab index

The snapshot is updated whenever tabs are opened, navigated, selected or closed. This makes recovery useful even after an accidental app close; it does not depend on a clean shutdown callback.

The Guide exposes a normal user-facing checkbox: **Reopen my last tabs when Pathfinder starts**.

## 2. Reopen closed study tab
Ctrl+Shift+T reopens the most recently closed study tab during the current running session. This is intentionally in-memory only.

## 3. Single cockpit theme authority
The R4/R6 runtime presentation adapter remains runtime-only, but now covers the known neutral aliases used across the cockpit suite:
- `--bg`
- `--panel`
- `--card`
- `--p2`
- `--panel2`
- `--p3`
- `--soft`
- `--text`
- `--ink`
- `--muted`
- `--line`
- `--accent`
- status colors and shadow
- `--active` / `--activeText`

`--panel2` was the important missed Strategy alias visible in the real-Windows screenshots. The cockpit-local theme button is hidden while hosted so Pathfinder's fixed theme selector is the only visual theme control. The source HTML remains unchanged on disk.

## 4. Friend-facing copy cleanup
Home, Guide and Time remove internal explanations about byte preservation, runtime injection, development gates and similar implementation detail. User-relevant behavior, workflow help, study guidance and independence / non-endorsement language are retained.

## 5. Preserved behavior
- R6 TabContentPresenter Stretch repair
- grouped library + individual subject cards
- R7 outline-first cards and same-session theme repaint
- Alt+Left/Alt+Right shortcuts without accelerator hint overlay
- native WebView2 pinch zoom / pan
- Focus, full screen, Time, Guide
- x64 + ARM64 targets
