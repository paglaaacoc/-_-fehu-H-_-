# W5 R3 — Extremely Easy Real-Windows Test

W5 R3 is **not accepted yet**. W4 R3 remains the accepted fallback until you explicitly accept this exact candidate.

## 1 — Build and identify
1. Extract the TEST ZIP to a normal local Windows folder.
2. Double-click **`TEST-W5-x64.cmd`**.
3. Confirm the app visibly says **W5 R3 CANDIDATE**.
4. If compilation fails, stop and send the first useful compiler error. Do not continue with a partial build.

## 2 — Quick preserved Search check
1. Open Search and search **`ARDS`**.
2. Genuine standalone ARDS should be exact/high-ranked.
3. `standards`, `stewardship`, and `DMARDs` must not be labelled/highlighted as exact ARDS matches.

## 3 — Quick preserved Split View check
The owner reported W5 R2 Split View perfect, so this is a regression smoke test rather than a redesign test.
1. Open Pulmonary.
2. Open Split with the second pane empty.
3. Put Cardiology beside; its main-strip tab should hide while parked.
4. Change several main tabs/library subjects; Cardiology should stay static beside.
5. Swap panes twice, then Return to tabs.
6. Expect no crash, stale placeholder, duplicate, disabled Swap button, or visual-parent error.

## 4 — Journal tab can deliberately go beside
1. Open a cockpit and Journal.
2. Right-click the **Journal tab header**.
3. Choose **Show beside in Split View**.
4. Expected: Journal parks beside and its tab hides from the main strip exactly like other parked views.
5. Use Return to tabs once and confirm the same Journal tab returns.

## 5 — Inline General note + immediate refresh
1. Open Journal as main.
2. Press **New general note**.
3. Expected: title/body editor appears **inside Journal**, not as a popup.
4. Enter a distinctive title/body and press **Save note**.
5. Expected: editor closes and the new note card appears **immediately**. Do not close/reopen Journal.
6. Edit that note. Expected: inline editor again.
7. Save an edit; the card should update immediately.
8. Start another edit, change text, press Cancel. Expected: dirty-draft confirmation.

## 6 — Selected cockpit text → Journal while Journal is beside
1. Put Journal beside a normal interactive cockpit such as Cardiology.
2. Select a short piece of text inside the cockpit.
3. Right-click the selected text.
4. Expected: native menu contains **Add selection to Journal…** in addition to the existing browser/Pathfinder Glossary items.
5. Choose it.
6. Expected: Journal stays beside and its **inline editor** appears, with the selected text copied into the body and a source/context label.
7. Save. Expected: note appears immediately in Journal.

Also right-click cockpit text with no selection and confirm **Add current place to Journal…** is available.

## 7 — Quick capture when Journal is not visible
1. Return Journal to tabs, then close Journal (or otherwise ensure Journal is not visible).
2. In a normal cockpit, select text → right-click → **Add selection to Journal…**.
3. Expected: a compact note popup appears prefilled with captured text/context.
4. Saving should **not force Journal to open**.
5. Open Journal afterward and confirm the saved note exists.

## 8 — From current Study context
1. Open Cardiology, then open/select Journal as main.
2. Press **From current Study**.
3. Expected: no false “Open a study cockpit first.” Cardiology should be used as the remembered study context.
4. Next put a study cockpit beside Journal and repeat. Expected: the beside study cockpit can be resolved as current context.

## 9 — Journal Open source becomes robust side-by-side
Use a Journal note that has an **exact source link**.

### Journal is main
1. Click **Open source**.
2. Expected: Journal remains main and the verified state-read-only source opens **beside** it.
3. The read-only source tab is hidden from the main strip while parked, following normal W5 Split rules.

### Journal is already beside
1. Arrange Journal beside another main view.
2. From Journal click **Open source** on an exact-source note.
3. Expected: exact state-read-only source becomes the **main** view and Journal remains parked beside.

In both cases the source must respect stored resource/version/location identity. Pathfinder must not silently redirect an old exact link to different frozen content.

## 10 — Existing tab-header capture regression
1. Select cockpit text.
2. Right-click the **study tab header** → **Add note to Journal…**.
3. Confirm selected text is still copied into the new note body as before.

## 11 — Restart / persistence
1. Save at least two Journal notes.
2. Close Pathfinder normally and reopen.
3. Confirm notes persist and normal study state still persists.

## 12 — Backup/restore smoke test
1. Create a fresh Pathfinder backup.
2. Add a distinctive temporary Journal note.
3. Restore the fresh backup.
4. Confirm Journal and existing study/settings state match the restored backup.

Canonical backup should identify **schema 6 / W5-R3**.

## 13 — Watch item
If a `BrowserProcessExited` recovery message appears even once, report exactly what you were doing when it appeared.

## Acceptance checkpoint
Please report either:
- **Accepted**, if the important flows pass; or
- the exact first/most serious failure plus the shortest reproduction sequence.

Do not treat W5 R3 as accepted until the owner explicitly accepts it.
