# W8 Medical Correction R2 — implementation record

**Base:** W8 Medical Correction R1 medical candidate, itself derived from owner-accepted W8 Closure R1.  
**Status:** unaccepted candidate pending owner Windows test.  
**Scope:** one-file canonical-backup serialization repair.

## Root cause
`StudyLocationState` inherits `PathfinderLocation`. `System.Text.Json` serializes public getter properties by default, so the computed runtime helpers `IsStrictSource` and `HasDurableTarget` leaked into schema-7 canonical backups. The strict canonical importer intentionally accepts only persisted Location-v2 fields, so Pathfinder could reject its own newly-created backup during pre-reset verification.

## Fix
`Models/PathfinderLocation.cs` now imports `System.Text.Json.Serialization` and marks exactly these computed helpers `[JsonIgnore]`:
- `IsStrictSource`
- `HasDurableTarget`

The importer was **not** relaxed. Runtime semantics of both helpers are unchanged. No backup schema bump is required because the fields were accidental serializer leakage, not part of the canonical contract.

## Preservation
- R1 medical payload: 132/132 byte-identical.
- Runtime source delta vs R1: exactly one file, `Models/PathfinderLocation.cs`.
- No C#/XAML area other than that model file changed.
- No Journal, Search, Split View, study-state key, medical content, UI, or QOL change.

## Required closure evidence
- existing R1 medical QC remains 350/350;
- inherited Closure R1 static QC remains 1081/1081;
- R2 targeted static QC must pass;
- exact R2 runtime source must compile/publish on GitHub Actions for win-x64 and win-arm64;
- owner must prove create canonical backup → required pre-reset backup verification reaches second destructive confirmation.
