# W3 R1 — First-Class Cockpit Host v1 + Canonical State Ownership

## Basis
W3 R1 is built from owner-accepted W2D R2. Windows v1.2 remains historical release rollback/reference. W3 has source/static verification only until the owner compiles/runs it on Windows.

## What W3 adds
- First-class `CockpitHost` roles: one authoritative `Primary` interactive view per resource plus explicit `ReadOnlySecondary` reference views.
- Explicit **Open in new tab** on an already-open HTML cockpit creates a read-only secondary view. It may scroll, native zoom/pan, select and copy, but cannot own resume/location or write canonical cockpit study state.
- Read-only secondaries use an isolated per-view `.invalid` virtual origin and are intentionally ephemeral until W4 workspace persistence.
- Canonical cockpit-state provider under `%LOCALAPPDATA%\NivareQ\Step2Pathfinder\cockpit-state.json`, with atomic writes, last-good recovery, source-SHA binding and exact key allowlisting.
- Allowlist is source-derived from accepted PWA B4A: 24 resource providers / 2607 exact keys. PWA native UWorld selector is deliberately not aliased to the Windows legacy PDF selector.
- Existing WebView2-profile state is adopted once when no canonical provider exists; thereafter Windows canonical state is injected before page scripts and becomes authoritative.
- Canonical Windows backup advances to schema 4 and includes cockpit state. PWA cockpit-study-state can be promoted into the Windows provider while unsupported PWA-only state stays opaque.
- Runtime-only compatibility repairs without editing frozen medical bytes:
  - 37 malformed frozen Study Map onclick handlers across Rheumatology/MSK/Dermatology, Obstetrics and Repro/Gyn/Breast;
  - 166 supplemental quiz-answer providers across resources 19–22;
  - Biostatistics legacy quiz migration and explicit-reset sentinel behavior;
  - host-side theme compatibility adapter for 19–22.
- Cockpit lifecycle states and bounded safe reload UI for WebView2 navigation/process failures.
- Source-action capture foundation (`SourceActionDraft`) for W5 Journal: resource/source identity, Location v2 and selected text. Journal UI is not implemented in W3.
- W3 preflight also tries a clean residual-sidebar-jump fix: pointer/touch clicks no longer focus late-library buttons (`AllowFocusOnInteraction=false`); keyboard tab focus remains available.

## Preservation
- Frozen R2 medical/teaching payload remains 132/132 byte-identical.
- W1 canonical Windows backup authority, W2A short paths, W2B Location v2, W2C Search/Preview/Go/Return, and W2D Settings/shell/reset remain in force.
- No portable-data migration.
- No medical-content enrichment/correction; that remains deferred to the mandatory release-readiness Medical Content Audit/Re-review Gate.

## Deliberately not in W3
- Split View layout itself (W4, required).
- Journal UI/storage workspace (W5).
- Native interactive UWorld Selector (W6).
- Multiple simultaneous interactive views of one resource.
