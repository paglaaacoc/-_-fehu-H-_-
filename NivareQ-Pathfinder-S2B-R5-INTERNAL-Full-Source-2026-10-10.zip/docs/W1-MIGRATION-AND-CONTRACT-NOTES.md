# W1 Migration and Contract Notes

## Authority direction
The Windows schema is canonical. Compatibility does not require every peer to edit every field. A future PWA/mobile peer may expose only supported sections while preserving/protecting richer Windows-owned state.

## Schema 1 → canonical schema 2
Schema-v1 remains importable. W1 never rewrites an old backup file in place; it translates into validated in-memory canonical state and writes Windows AppData only after confirmation/transaction staging. Any later export is schema-v2.

## Missing versus explicit state
- Legacy/schema-v1 lacks a versioned `PreservedExtensions` contract. W1 merges/preserves already-retained opaque extension state rather than treating absence as deletion.
- Canonical/schema-v2 includes `PreservedExtensions` explicitly and treats it as the canonical replacement set for that backup.
- Provider-specific empty-vs-missing semantics for cockpit state/Journal/Selector will be finalized when those native providers arrive (W3/W5/W6).

## PWA B4A
`PwaState` is inert preserved JSON in W1. It is not executed and does not gain write authority over Windows state. This includes B4A cockpit state, Location v2/J-1 source data, Journal and native UWorld Selector data.

## UWorld identity rule
`extra-uworld-selector` (PWA native planning tool) and `extra-uworld-checkbox-selector` (released Windows legacy PDF resource) are not source-equivalent. W1 does not fabricate source/location continuity between them.

## Windows-only accessibility settings
When a schema-v1/PWA backup lacks `StrongFocusIndicators`, `ReduceMotion`, or `ComfortableReadingSpacing`, W1 retains the current Windows values. Canonical schema-v2 requires all three fields.

## Unknown themes
W1 retains a syntactically valid theme ID even when current Windows has no corresponding registry entry. Runtime presentation safely falls back to the Windows default; the retained ID can become active when the corresponding Windows theme arrives in W7.


## Canonical schema-2 fail-closed rule
Schema-v2 is the Windows master contract, not a best-effort import format. W1 rejects unknown or missing canonical core fields instead of silently discarding them. Richer future state must either live under bounded `PreservedExtensions` or increment the canonical schema with an explicit migration. Legacy schema-v1 stays intentionally more tolerant and preserves unfamiliar top-level state opaquely.

## Backup-file commit semantics
The user-selected canonical backup file is written through the Windows transacted-storage API and committed before success is reported. This is separate from AppData atomic writes and the multi-file restore transaction.

## Runtime save-failure truthfulness
Settings/My Study/session write APIs return failure, record a persistence-health notice, and user-triggered/runtime save paths queue a one-per-session warning when possible. A changed control can still exist in memory for the current session, but Pathfinder no longer treats that as proof it reached durable storage.
