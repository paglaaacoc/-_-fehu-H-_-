NivareQ Step 2 Pathfinder v1.2 — START HERE

Status: Stable Accessibility / Compatibility Release
Accepted gate: Build 5 Accessibility / Compatibility RC1
Development status: CLOSED

Easiest build:
  Double-click BUILD-ON-WINDOWS.cmd on Windows.

What is new:
  Aa / Ctrl+Shift+A opens Accessibility & display.
  Optional focus, reduced-motion, and reading-spacing aids are independently switchable and default OFF.
  Core keyboard, screen-reader, Windows contrast/scaling, narrow-window, and native touch compatibility remain built in.

The in-app ? Guide is already updated for these controls.

Medical content remains frozen: 132/132 files exact.
Authoritative medical R2 SHA-256:
8fcde78900b3ecc5bb1616dff7ea3c8b05743c110bff149c12bc12c387734139

This continuity package preserves prior build/release history and the exact accepted v1.2 Friend Release under AcceptedRelease/.
