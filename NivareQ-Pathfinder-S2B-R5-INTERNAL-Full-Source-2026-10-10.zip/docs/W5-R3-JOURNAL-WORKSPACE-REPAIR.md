# W5 R3 — Native Journal Workspace Repair

## Status
**UNACCEPTED CANDIDATE.** W4 R3 remains the owner-accepted Windows development baseline until this exact R3 candidate passes real-Windows testing and is explicitly accepted.

## Why R3 exists
W5 R2 successfully repaired the R1 compile failure, and its redesigned Split View was reported **perfect** in owner real-Windows testing. Journal testing then exposed bounded integration/UX defects rather than a persistence architecture failure:

1. A newly saved General note persisted, but the already-presented Journal visual tree did not refresh until Journal was closed/reopened.
2. `From current Study` could report “Open a study cockpit first” while a cockpit existed because Journal itself was selected and the last-study fallback was stale.
3. The natural cockpit WebView right-click path had no Journal action; selected-text Journal capture existed only through the study-tab header action.
4. Journal remained technically splittable but its own tab header did not expose `Show beside in Split View`.
5. Journal `Open source` created a strict read-only source tab but did not deliberately arrange Journal + source side-by-side like Search source preview.

R3 repairs only these Journal integration issues plus candidate identity/continuity. It deliberately preserves the successful W5 R2 Search and Split View architecture.

## Journal remains a tab
Journal remains a normal closable Tool/Workspace tab because a core use case is **study cockpit in one pane + Journal in the other pane for live reference/note-taking**. It is not converted to an app surface.

Tool/shell tabs now receive a small tab-header workspace context menu with:
- `Show beside in Split View`
- `Close tab`

This uses the existing Split View transaction machinery rather than adding a second split system.

## Inline editor when Journal is visible
When Journal is visible either as the main tab or parked beside, New/Edit now renders an editor inside the Journal workspace itself:
- title;
- multiline body;
- source/context label;
- Save;
- Cancel;
- dirty-draft protection.

Saving updates the native Journal provider first. On success, the current filter counts and visible note list are refreshed **in place**, avoiding the R2 presentation defect where the persisted save appeared only after closing/reopening Journal.

If Journal is **not visible**, contextual capture retains a compact `ContentDialog` note composer. This lets a student quickly capture a note without forcing Journal to open or disrupting the current study layout.

## Cockpit context-menu capture
Primary interactive cockpit WebViews now add one Pathfinder command to the native WebView2 context menu:
- selection present: `Add selection to Journal…`
- no selection: `Add current place to Journal…`

The action is bound to the exact originating `StudyTabContext`. The WebView2 context-menu selection text is passed into the existing source-action draft pipeline instead of being re-guessed later. Source/location identity still uses the existing strict Location v2 capture; if Pathfinder cannot produce a verified source-linked draft, it does not invent one and offers General-note fallback.

The existing study-tab-header `Add note to Journal…` action remains supported.

## Current-study resolution
Journal now resolves a study context in this order:
1. currently selected primary study tab;
2. a study cockpit parked in the beside pane;
3. the last valid primary study tab remembered when tab selection changed.

This fixes the R2 case where Journal itself was selected and `From current Study` incorrectly concluded that no study cockpit was open.

## Journal Open source + Split View
Exact Journal source links retain strict resource/source-version checks.

- **Journal main:** create the exact state-read-only source tab, reselect Journal, then deliberately show the source beside it.
- **Journal already beside:** create/select the exact state-read-only source as the main view and leave Journal parked beside.
- If Show beside displaces an existing secondary view, the accepted W5 Split transaction returns that old view safely to tabs rather than destroying it.
- Journal entries without an exact `SourceLocation` keep the ordinary Open cockpit behavior.

This reuses the accepted read-only source role and safe Split View reparenting rules.

## Deferred gate — Journal Pen Scratchpad
**CLOSED / OWNER DECISION REQUIRED.** A persistent stylus/ink scratchpad remains a future Journal enhancement gate. It is recorded in continuity but is not scheduled automatically and is not implemented by W5 R3. Opening it later requires an explicit owner decision.

Potential future scope may include saved pen strokes and Journal/source association, but the gate must not force an unstable/experimental platform migration without a separate decision.

## Preservation
- W5 R2 Search Boundary Correctness preserved.
- W5 R2 optional/static Split View model preserved.
- Canonical backup schema remains **6**.
- Journal provider schema remains **1**.
- Frozen medical/teaching payload changes: **0**.
- 132/132 medical files remain byte-identical by source/static verification.
