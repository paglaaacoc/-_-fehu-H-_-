# W8 Closure R1 — Post-Astra targeted closure

## Authority
W8 R1 remains owner-accepted fallback. This is an unaccepted engineering closure candidate produced only because the independent GPT-6 Astra closure audit found bounded Stable blockers. It is not a feature expansion.

## Repairs
1. **Journal multi-block selection:** the live-selection JavaScript is now a C# verbatim string so JavaScript `\\r`/`\\n` escapes reach WebView2 intact instead of being converted into literal line breaks by C#. The existing page-selection snapshot/fallback logic and 12,000-character plain-text safety cap remain.
2. **Cockpit-state message casing:** cockpit live-state messages are deserialized with the existing case-insensitive/location-compatible JSON options, matching the camelCase browser contract.
3. **Write fencing / stale views:** direct cockpit snapshots, WebView messages, location captures and delayed saves require a current registered Primary writer and are blocked during restore/reset/recovery suspension. Snapshot authority is rechecked after `ExecuteScriptAsync` before mutation.
4. **Unresolved recovery:** RestoreTransactionService now exposes a mutation block when an interrupted restore journal is invalid or rollback/recovery is incomplete. Persistent services consult that gate; a new restore/reset transaction cannot begin while unresolved evidence remains.
5. **Journal log tail durability:** appends use read/write OpenOrCreate and first add an NDJSON newline separator when the existing file does not end in newline, preventing a later valid operation from being concatenated onto an interrupted final JSON record.
6. **Selector split backup:** canonical workspace validation recognizes UWorld Selector as a supported shell secondary.
7. **PWA promotion preservation:** PWA cockpit-state and Journal promotion paths reject unknown nested properties before promotion, rather than silently dropping unknown data.
8. **Selector reset safety:** `Reset reported counts…` routes to Settings > Data management so the established fresh verified-backup reset workflow applies to the bulk reset.
9. **Closure consistency:** restore/reset clears stale Journal editor sessions and refreshes the visible Journal; session restore indexes the set of tabs actually restored instead of indexing the full shell tab strip.

## Preserved
- Canonical backup schema 7.
- All W4–W8 accepted Search, Journal, Split View, UWorld Selector, source preview, themes, accessibility, session/workspace behavior unless directly involved in a closure repair above.
- 13 themes.
- 26-recipe UWorld Selector / 22-system final audit contract.
- Plain-text Journal; rich text remains deferred.
- Journal Pen Scratchpad gate remains closed.
- Frozen medical payload: 132/132 files byte-identical.

## Windows compile evidence
GitHub Actions run 15 on `windows-latest` / .NET SDK 10.0.401:
- 49/49 exact C#/XAML/project/manifest files verified against the closure manifest before restore/build.
- x64 self-contained publish PASS.
- ARM64 self-contained publish PASS.
- x64 EXE SHA-256 `59715d7e58dd00641bd37db3035201401e76dcbf06b36bdbe39420eba3974c79`.
- ARM64 EXE SHA-256 `0556e0bed83dfa59ca3657f0daa2bd20af47c6e843d5430d954187f2e1454adb`.

The CI artifact is compile evidence only. Owner runtime testing uses the normal TEST package so the authoritative icon, full frozen medical payload, ShellData and resource verification are present.
