# W2A R1 — Extremely Easy Windows Test

## 1. Build + launch
From the extracted FULL package, open `06-WINDOWS-W2A-CANDIDATE` and double-click:

`TEST-W2A-x64.cmd`

Expected build gates include:
- `Medical payload integrity PASS: 132/132 files byte-identical.`
- `Source resource registry PASS: 25 resources...`
- .NET 10 SDK PASS;
- short-path staging under `%TEMP%\NQPF-W2A-Build`;
- publish succeeds;
- `Published medical payload PASS: 132/132.`
- `Published resource registry PASS: 25 resources...`
- Pathfinder launches.

If compilation fails, stop and send the full console output or newest Build Logs file. Do not rename medical files manually.

## 2. Open representative resources
Open these from the Study library:
- Cardiology;
- Geriatrics + Prevention + Ambulatory;
- Surgery + Trauma + Emergency Medicine;
- one other cockpit you use often.

Each should load normally. Geriatrics and Surgery are especially important because their legacy paths were among the longest.

## 3. Extras/reference sanity
Open Clinical Recall Library. If you use the legacy UWorld PDF selector, open it as well. They should still resolve through the new registry.

## 4. Existing state continuity
Check that your existing Favorites/progress/notes/recent/session behavior still recognizes the same subjects. W2A keeps the released persisted slug IDs stable.

## 5. Search regression sanity
Use the current released Search for a known term and open a result. This is not the W2C Search upgrade yet; the goal is only to confirm the short-path migration did not break the existing index/open flow.

## 6. Native selectable-shell-text menu — regression closure
In **Parchment**:
1. open Search or My Study;
2. select some normal explanatory text;
3. invoke the selection/context menu.

Expected: Copy and Select all are readable and usable.

Repeat quickly in one dark theme.

Then confirm:
- select text inside a cockpit → its WebView2 context menu still works;
- right-click a tab → the existing native tab menu still works.

## 7. W1 backup sanity (quick carry-forward check)
Create one canonical backup from My Study and confirm the normal success message. You do not need to repeat destructive/failure-injection tests for W2A unless something looks wrong.

## 8. What to report
A short result is enough:

`Compile/launch PASS`  
`Cardiology/Geriatrics/Surgery PASS`  
`Clinical Recall/PDF PASS or not used`  
`Existing state PASS`  
`Search sanity PASS`  
`Shell text menu PASS in light + dark`  
`Cockpit menu PASS`  
`Tab menu PASS`  
`Backup sanity PASS`

If all pass, W2A can be accepted and development moves immediately to W2B — Unified Location v2 + Strict Source Identity.
