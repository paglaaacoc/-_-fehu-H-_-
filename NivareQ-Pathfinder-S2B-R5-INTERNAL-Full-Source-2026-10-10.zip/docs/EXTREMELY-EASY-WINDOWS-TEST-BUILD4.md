# Build 4 — Extremely Easy Windows Test

Build 3 is already accepted. Build 4 is intended to be the final development build before the Pathfinder v1.1 release cut if this test passes.

## 1. Build
1. Extract this ZIP to a normal folder.
2. Double-click `BUILD-ON-WINDOWS.cmd`.
3. Confirm **Medical payload integrity PASS: 132/132**.
4. Launch the x64 app from `Built Apps`.

If compilation or launch fails, stop and send the exact error.

## 2. Fast Build 3 regression check
Open Cardiology, Pulmonary, and Renal.

Confirm:
- cockpits remain visible/full-height;
- themes still apply immediately;
- tabs/sidebar/fullscreen still behave normally;
- My Study still opens;
- bookmarks, notes, favorites, optional progress and pinning still behave normally;
- quit/reopen still restores the last session and reading positions.

PASS = nothing accepted in Build 3 appears broken.

## 3. Universal Search — existing behavior + explainable results
Open **⌕ Search all cockpits** or press `Ctrl+K`.

Search a normal multi-token term such as:
`coronary artery disease`

Confirm:
- relevant cockpit matches remain available;
- if the full normalized phrase exists, an **Exact match** section appears first;
- exact phrase text is visibly highlighted in its snippet;
- non-exact matches remain below;
- the actual matching words in non-exact snippets are highlighted, so you can see why the cockpit matched;
- snippets show matched material rather than an apparently unrelated chunk.

Click **Open result** on a relevant result.

PASS = the correct cockpit opens/selects and the existing runtime jump/brief outline behavior still works.

## 4. Normalization — NO fuzzy search
Try these searches:
- `Guillain-Barré`
- `Guillain–Barré`
- `guillain barre`

PASS = punctuation/diacritic variants find the same relevant material and display the original medically formatted cockpit text.

Now type an intentional misspelling such as:
`gullain`

Right-click the misspelled word.

PASS = native Windows **Proofing** suggestions remain available. Pathfinder does not silently fuzzy-match/replace the medical term.

## 5. Deterministic aliases
Search:
`Helicobacter pylori`

PASS = the Medical glossary identifies **H. pylori — Helicobacter pylori**, and GI material can be found through the curated alias even though the frozen cockpit commonly uses `H. pylori`.

Search:
`Stevens Johnson syndrome`

PASS = the glossary identifies **SJS — Stevens–Johnson syndrome**, and relevant cockpit material can be reached through that explicit alias.

## 6. Medical Glossary / Index
Open **Medical glossary** from Home or Universal Search.

Search several examples:
- `GCS`
- `ARDS`
- `DKA`
- `GBS`
- `PE`
- `H. pylori`
- `BiPAP`

PASS = direct expansions appear. `BiPAP` resolves to bilevel positive airway pressure. Ambiguous terms such as `GBS`/`PE` can show more than one curated meaning instead of Pathfinder choosing one.

Then type a single letter such as `C`.

PASS = the glossary becomes an alphabetical C-index and shows only entries whose abbreviation/term begins with C. Change it to `Cp`.

PASS = the normal broad 2+ character search returns, including matches where `cp` occurs later in the abbreviation (for example ASCCP/ERCP/ICP/MCP when applicable).

Try selecting/copying text from a glossary card.

PASS = abbreviation, expansion, aliases/notes and Found in text are selectable.

## 7. Native right-click glossary lookup
Open any cockpit containing `GCS` (Core Acute-Care is convenient).

1. Select only `GCS` in the cockpit text.
2. Right-click.

PASS = the normal Edge/WebView2 context menu is still present **and** it has a **Pathfinder Glossary** submenu.

Open that submenu.

PASS = it immediately shows `GCS — Glasgow Coma Scale` plus an option to open the full glossary entry.

Repeat with an ambiguous abbreviation such as `GBS` or `PE` if convenient.

PASS = all curated exact meanings are shown; Pathfinder does not pretend to choose the correct one from context.

## 8. ? Guide
Open **? Guide**.

PASS = it now includes:
- Search all cockpits;
- exact/token highlighting and normalization;
- Medical abbreviation glossary;
- right-click glossary lookup;
- Windows spelling/proofing / no fuzzy search;
- one consolidated **Keyboard, mouse & touch shortcuts** section.

## 9. Closed-tab recovery regression
1. Open Pulmonary, scroll to an obvious position, and close the tab.
2. Press `Ctrl+Shift+T`.

PASS = it reopens near the exact position.

Close several tabs at different positions and press `Ctrl+Shift+T` repeatedly.

PASS = it walks backward through the recent closed-tab stack newest-first. My Study → Recently closed tabs still works too.

## 10. Final regression spot-check
Confirm:
- pinned tabs still resist accidental closing;
- Close other tabs / Close tabs to the right still work;
- backup/restore controls still open normally;
- themes and title/tab/scroll chrome still repaint correctly;
- fullscreen still puts tabs at the top;
- native WebView2 scrolling, pinch-zoom and pan remain normal;
- no medical content looks altered.

## Acceptance rule
If all sections pass, **Build 4 can be accepted as the final development build for v1.1**. The next artifact should be the Pathfinder **v1.1 release cut**, not another feature build. The separate development-continuity ZIP should be refreshed only after Build 4 acceptance so it records the accepted state.

Build 5 remains reserved for the future accessibility/compatibility gate.
