# W2D R1 Shell / Settings / Reset Notes

## Sidebar root-cause posture
The exact W2C late-library failure mechanism was not proven from screenshots alone. The pattern expanded from 19–22 to Clinical Recall and UWorld, making late-list/group-boundary shell virtualization/measurement a stronger explanation than HTML structure alone.

W2D therefore removes the relevant virtualization/selection ownership rather than patching individual cockpit HTMLs. This is both bounded and aligned with the approved native shell redesign. If the defect persists after this replacement, treat that new real-Windows evidence as the next root-cause input rather than rewriting frozen medical HTML by assumption.

## App surfaces
The native app-surface host deliberately hides the study/tool `TabView` while Settings/My Study/Guide is active and remembers the prior selected tab. It does not create a fake tab record for the app surface.

## Reset safety
Reset is intentionally stricter than a confirmation checkbox. A user cannot reach destructive confirmation without creating and verifying a fresh canonical backup first. The verified file path is shown at final confirmation.

Current Study/progress reset truthfully covers the manual subject-progress provider available before W3. W3 is responsible for registering meaningful cockpit-runtime state providers so future reset/backup scopes can cover them explicitly rather than pretending they already exist.
