# W1 — Extremely Easy Windows Test

This is a **source candidate**. It has not been compiled on this non-Windows environment. Real Windows compile/device evidence is still required before acceptance.

## 0. Protect your current data once
Close Pathfinder. In File Explorer paste this into the address bar:

`%LOCALAPPDATA%\NivareQ\Step2Pathfinder`

Copy that folder somewhere safe. This is only a beta-test safety copy; W1 does **not** move Pathfinder to portable data.

## 1. Build and launch
Double-click `TEST-W1-x64.cmd`.

W1 R3 automatically copies the candidate source to a short temporary build path under `%TEMP%\NQPF-W1-Build`, compiles/publishes there, verifies the payload, then copies the finished app back into `Built Apps`. **You do not need to rename or manually move the extracted FULL package to a shorter folder.**

Expected: medical-payload verification passes, the .NET 10 SDK gate passes, the console says it is preparing the short-path staging workspace, publish succeeds, the published payload passes verification, and the candidate launches. If compilation fails again, send the newest file from `Build Logs` rather than changing source yourself. The prior R1 `WMC9999` 265-character-path failure is specifically what R2 is designed to eliminate.

## 2. Normal-state smoke test
Confirm your existing theme, Favorites/My Study, progress, notes/bookmarks, open cockpits, touch/pinch/scroll and Aa accessibility options still behave normally.

## 3. Make a canonical W1 backup
In **My Study → Backup**, save a new JSON backup.

Expected: dialog says **Canonical Windows backup saved** only after the transacted file write commits, and truthfully notes that live cockpit review/quiz/mode extraction is scheduled for W3.

Optional sanity check: open the JSON in Notepad and confirm the top contains:
- `"BackupSchemaVersion": 2`
- `"FormatId": "nivareq.step2pathfinder.backup"`
- `"ContractAuthority": "windows-canonical"`

## 4. Restore your W1 backup
Change one harmless thing first (for example a favorite or theme), then restore the backup.

Expected:
- a preview/confirmation appears before anything is replaced;
- restore succeeds;
- you are told to restart once for the saved tab session;
- after restart the restored settings/My Study/session are back;
- a pre-restore cockpit cannot overwrite the restored reading position before that restart.

## 5. Legacy Windows fixture
Restore `docs\W1-fixtures\windows-v1.json`.

Expected: it is accepted as schema-v1 Windows/legacy state. It should restore its small test My Study/session state.

## 6. PWA B4A-shaped fixture
Before this test, set one Aa option on Windows so there is a visible Windows-only preference to preserve. Then restore `docs\W1-fixtures\pwa-b4a-v1.json`.

Expected preview notes:
- PWA-specific state is being preserved for later native gates;
- missing Windows-only Aa values preserve the current Windows values;
- the PWA UWorld Selector is not redirected to the legacy PDF.

After restore/restart, the PWA Search/Cardiology-compatible session pieces should translate. The fixture's `sage` theme may visually fall back until Windows gains Sage in W7; the restore preview should explicitly mention this, and the preference should remain retained in data.

## 7. Canonical strictness sanity test (optional)
Make a copy of the W1 canonical backup. In the copy, add a made-up top-level schema-v2 field such as `"FutureWindowsState": {}` and try to restore it.

Expected: Pathfinder rejects the modified canonical backup before mutation, explaining that the canonical field is unsupported rather than silently dropping it. Restore the untouched original afterward if desired.

## 8. Corrupt-startup recovery test (optional but valuable)
Close Pathfinder. Go to `%LOCALAPPDATA%\NivareQ\Step2Pathfinder`. Make sure you kept the safety copy from step 0. Replace the contents of `settings.json` with invalid text such as `{broken`, then launch the W1 candidate.

Expected: Pathfinder does not silently overwrite the only corrupt copy. It moves the unreadable file into `Recovery\Corrupt`, tries `.lastgood`, and shows a recovery notice.

## 9. What to report
For acceptance, tell me:
- compile: PASS/FAIL;
- launch: PASS/FAIL;
- normal state: PASS/FAIL;
- W1 backup + restore + restart: PASS/FAIL;
- Windows-v1 fixture: PASS/FAIL;
- PWA fixture: PASS/FAIL;
- canonical strictness (if tested): PASS/FAIL;
- corrupt recovery (if tested): PASS/FAIL;
- any unexpected dialog/text/state loss.

Do not test artificial full-disk/permission failures unless you want to. Those paths are source-designed and remain a dedicated failure-injection item if real-device evidence is needed after normal W1 smoke testing.
