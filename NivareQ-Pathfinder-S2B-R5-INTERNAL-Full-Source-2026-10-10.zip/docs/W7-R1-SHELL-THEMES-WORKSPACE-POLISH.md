# W7 R1 — Shell / Themes / Guide / Workspace Polish

W7 R1 is built from owner-accepted W6 R3. It is a shell/runtime/presentation candidate and does not revise frozen medical teaching bytes.

## Theme additions
All nine accepted themes are preserved. Four additive themes are introduced:

- **Sage Day** — soft sage daylight field, lower glare, restrained green accent.
- **Sunlit Apricot** — warm peach/cream daytime field with restrained orange accents.
- **Ember Glow** — brighter orange/terracotta evening environment; intentionally warmer and less gloomy than Amber without neon/high-glare styling.
- **Twilight Bloom** — violet/plum evening environment with lavender highlights for a cheerful low-light alternative.

Windows High Contrast remains authoritative while active. Theme changes remain shell/runtime CSS only; frozen cockpit HTML is unchanged.

## Home / My Study convenience
Home now includes a **Continue & study snapshot** card using existing local My Study state. It exposes the most recent cockpit when available plus compact favorite/progress counts and a direct My Study action. No new persistence schema is introduced.

## Workspace polish
- **Ctrl+Alt+S** opens/closes Split View.
- Double-click/tap the Split View divider to reset to **50/50**.
- Existing deliberate static-secondary ownership, Return to tabs and Swap behavior remain unchanged.

## Supplemental drill-feedback compatibility
The known cockpits 19–22 visual feedback issue had a clean runtime root cause: W3 host-side theme compatibility uses `!important` button styling, which could override those frozen cockpits' non-important `.opt.correct` / `.opt.wrong` backgrounds. W7 adds more-specific host-side feedback CSS so correct/wrong styling survives every Pathfinder theme and visibly labels **✓ Correct** and **✕ Your choice**. The frozen medical HTML remains byte-identical.

## Journal multi-block selection follow-up
W6 R3 was accepted with the remaining partial multi-block Journal capture issue deferred. W7 does not introduce rich text. Instead, the document bridge now keeps a short-lived plain-text selection snapshot at pointer-up/key-up/context-menu time; Journal/Search selection actions prefer that fresh cached DOM selection when it is more complete than the selection available after WebView2 opens its menu. The existing 12,000-character safety cap remains.

## Still deferred / watch-only
- Journal Pen Scratchpad Gate — CLOSED / owner decision required.
- Journal rich-text storage — DEFERRED.
- Late-library sidebar vertical-position jump — low-severity watch; no new claim of closure in W7 R1.
- Historical one-off BrowserProcessExited — watch-only unless reproduced.
