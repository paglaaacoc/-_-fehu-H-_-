# Build 4 R1 — Final Polish Candidate

This is a bounded refinement of the working Build 4 candidate, not a new feature build.

Changes:
- glossary card text is selectable/copyable;
- one-letter glossary input browses entries beginning with that letter; 2+ characters preserve the existing broad glossary search;
- bounded missing-abbreviation coverage sweep added 16 high-confidence omissions, including BiPAP/BPAP;
- ? Guide and Windows test instructions updated.

Explicitly unchanged:
- Universal Search ranking/matching architecture;
- no fuzzy search; Windows proofing remains the spelling-assistance layer;
- WebView2 native context menu behavior;
- Build 3 personal-study layer;
- frozen 132-file medical payload.

If this candidate passes real-Windows testing, the next step is the v1.1 release cut.
