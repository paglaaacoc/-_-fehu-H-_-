# NivareQ Step 2 Pathfinder — Build 1 R3 QC report

**Static/package QC: PASS — 20/20 checks passed.**

R2 already compiled successfully on real Windows for x64 and ARM64, and x64 launched. R3 changes are bounded shell/runtime repairs and still require a fresh Windows compile/run.

## Checks

- **PASS — XML App.xaml:** well-formed
- **PASS — XML MainWindow.xaml:** well-formed
- **PASS — XML NivareQ.Step2Pathfinder.csproj:** well-formed
- **PASS — XML app.manifest:** well-formed
- **PASS — JSON Brand/Themes/registry.json:** valid
- **PASS — JSON ShellData/study-times.json:** valid
- **PASS — Nine approved themes:** Light, Dark, OLED Black, Ocean, Forest, Amber, Aurora, Parchment, Glacier
- **PASS — Theme shell colors:** all #RRGGBB
- **PASS — XAML event handlers:** 19 handlers resolved
- **PASS — No ms-appx brand URI:** unpackaged-safe Home
- **PASS — No visual-tree reparent anti-pattern:** Home/Guide/Time keep one StackPanel
- **PASS — Guarded Time/Guide panel:** shell errors become tabs, not process crash
- **PASS — Study totals safe lookup:** no dictionary indexer dependency
- **PASS — No custom zoom/pan override:** native WebView2 touch zoom/pan preserved
- **PASS — MedicalPayload not WinUI Content:** plain copied runtime files
- **PASS — x64+ARM64 targets:** native targets retained
- **PASS — Frozen medical payload:** 132/132; mismatches/missing=0; extras=0
- **PASS — Authoritative R2 ZIP SHA-256:** 8fcde78900b3ecc5bb1616dff7ea3c8b05743c110bff149c12bc12c387734139
- **PASS — Pathfinder icon asset:** 256x256
- **PASS — Clean built-app folders:** runtime output separated from docs/logs

## R3 runtime repair scope

- Home: removes unpackaged `ms-appx` brand-image dependency and invalid control re-parenting.
- Time/Guide: fixes control re-parenting and adds guarded shell-panel creation.
- Themes: Light, Dark, OLED Black, Ocean, Forest, Amber, Aurora, Parchment, Glacier.
- Focus/theme: explicitly paints the SplitView background and retains native RequestedTheme behavior.
- PRI cleanup: MedicalPayload is copied as plain runtime files instead of WinUI resource-indexed Content.
- Medical HTML: unchanged; 132/132 byte-identical.

## Native runtime gate

This environment is Linux, so R3 itself has **not** been compiled or launched here. Run `BUILD-ON-WINDOWS.cmd`; the script verifies the medical payload before publish and inside each x64/ARM64 output.
