# W2C R2 — Bounded Search / Source Preview Repair

## Base
W2B R2 owner-accepted on real Windows. W2C R1 compiled/launched and proved the Source Preview / Go / Return architecture, but R1 was not accepted because the bounded defects documented in `W2C-R1-REAL-WINDOWS-FINDINGS.md` remained.

## R2 repairs
- **Occurrence-level exact search:** exact phrases now emit one result per bounded source occurrence rather than one result per cockpit. Search status reports distinct matching cockpits separately from exact source matches.
- **Source context binding:** each search result carries a bounded normalized context hint and occurrence identity. The WebView source resolver uses that context to distinguish multiple exact sources inside one verified cockpit.
- **Immutable Preview → Go target:** the preview's `Go to cockpit` forwards the original `UniversalSearchResult` to the exact same primary-cockpit path used by direct Search → Go. Preview scroll/layout state is never promoted into cockpit authority.
- **Larger adaptive preview:** Source Preview expands to the available window envelope (up to a desktop-friendly 1280 px width / 900 px content height) instead of inheriting the stock narrow dialog width.
- **Non-overlapping Return bar:** the native Source-jump InfoBar now owns an auto-height host row above WebView2; the cockpit content occupies the star row below it. Closed bars are collapsed.
- **19–22 direct navigation adapter:** source resolution no longer types into the internal filtering search box for resources 19–22. Direct Go captures the prior transient view, clears any existing cockpit filter, then reveal/scroll/highlights the target; Return can restore the prior filter/view.
- Failed source jumps still roll back the previous temporary view/location.

## Frozen-content boundary
No medical/teaching file was edited. Theme differences in 19–22 and GI empty `One step deeper` content are documented but deliberately not repaired by altering R2 medical bytes.

## Deferred mandatory gate
Before personal/friend release readiness is declared, run the documented **Medical Content Audit / Re-review Gate**. Any actual medical additions/corrections become a new medical-payload revision with its own bounded correctness audit, hashes and owner acceptance.
