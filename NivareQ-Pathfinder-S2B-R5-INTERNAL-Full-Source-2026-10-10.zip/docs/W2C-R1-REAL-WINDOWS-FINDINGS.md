# W2C R1 — Real-Windows Findings

W2C R1 compiled/launched and the core architecture worked on the owner's Windows machine, but it was **not accepted** because bounded defects were found during source-navigation testing.

## Confirmed working
- isolated read-only Source Preview opens and preserves the primary cockpit position;
- direct Search → Go to cockpit works and highlights the source;
- one-level Return to previous position works, including restoration of filtered/transient view state;
- one authoritative primary cockpit per resource remains intact.

## R1 defects carried into R2 repair
1. Source Preview dialog was too narrow for desktop cockpit layouts.
2. Preview → Go to cockpit recomputed from preview-derived location and could land differently from direct Search → Go.
3. Return InfoBar overlaid cockpit sticky navigation because it shared the same Grid layer as WebView2.
4. Resources 19–22 used their own cockpit search/filter as a navigation assist, hiding the rest of the cockpit instead of reveal/scroll/highlight.
5. Universal Search emitted at most one result per cockpit, so multiple exact occurrences in one cockpit were collapsed. Example: GI + Hepatobiliary contains both the learning-module title **Acute pancreatitis diagnosis** and the separate Core question **Acute pancreatitis diagnosis requires:**; R1 showed only one exact source result.
6. Separate finding: resources 19–22 do not participate consistently in host theme injection. Deferred to W3 unless a trivial host-only repair emerges.
7. Separate frozen-content finding: GI topic modules frequently render an empty `One step deeper` disclosure because the frozen source has empty `deeper` arrays (80/86 modules). This is documented for the mandatory release-readiness Medical Content Audit / Re-review gate; W2C does not invent or rewrite medical content.
