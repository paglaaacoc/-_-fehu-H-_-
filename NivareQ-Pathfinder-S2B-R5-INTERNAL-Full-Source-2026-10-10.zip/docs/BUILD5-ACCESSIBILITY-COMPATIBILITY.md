# Build 5 — Accessibility / Compatibility RC1

## Scope
This is the explicitly reserved post-v1.1.1 accessibility/compatibility gate. It is intentionally bounded to shell/runtime compatibility. The frozen medical payload is not edited.

## Optional user-controlled aids
All default OFF and persisted in normal shell settings / backup:
1. Stronger keyboard focus inside hosted study cockpits.
2. Reduced motion inside hosted study cockpits.
3. More spacious study text for reading-heavy paragraph/list/table content.

The new **Aa** top-bar command and **Ctrl+Shift+A** open the Accessibility & display page. A duplicate theme selector is present there so theme selection remains reachable even when narrow-window chrome hides the main top-bar theme selector.

## Always-on compatibility foundations
These are deliberately not user-disableable:
- normal keyboard focus/navigation and existing keyboard accelerators;
- explicit automation names/help text for important shell controls and the hosted study WebView surface;
- Windows High Contrast detection and live response;
- Windows/WinUI DPI scaling rather than a custom fake-DPI layer;
- responsive narrow-window behavior;
- native WebView2 touch/pinch/pan/zoom behavior with no custom gesture or zoom-factor override.

## High Contrast behavior
When Windows High Contrast is active, Pathfinder temporarily withholds the custom cockpit palette bridge and uses Windows system Background / Foreground / Accent colors for shell-owned surfaces. The selected Pathfinder theme is still remembered and returns when High Contrast is turned off.

The implementation uses Windows.UI.ViewManagement.AccessibilitySettings.HighContrast / HighContrastChanged and UISettings system colors. No startup/apartment architecture was changed.

## Reduced motion behavior
The shell adds no custom motion. Hosted cockpit animation/transition CSS is suppressed when either:
- Windows reports UI animations disabled, or
- the user manually enables Reduce motion in Pathfinder.

## Screen-reader/content boundary
Medical HTML is frozen. Pathfinder adds a runtime `lang="en"` only when a hosted HTML document lacks a language attribute; it does not rewrite the source file. Static audit of the current frozen HTML set found titles and H1s in all 46 HTML entry files and no empty/unlabelled `<button>` candidates. Four HTML files do not declare `lang`, which the runtime fallback covers.

## Narrow-window behavior
Below 650 DIP, Time and Guide top-bar commands collapse (both remain reachable from Home). Below 540 DIP, the top-bar theme selector also collapses; theme selection remains available from Accessibility & display. Essential navigation, Search, My Study, Accessibility, and Full Screen stay visible.

## Architecture preservation
`App.xaml.cs` is byte-identical to the accepted v1.1.1 source. The accepted normal WinUI-generated STA startup + named mutex / activation signal remains untouched. The rejected custom AppInstance Main path is not reintroduced.
