# W8 Medical Correction R1 — static/focused verification

Status: PASS. Candidate remains unaccepted pending owner Windows/device test.

## Results

- Medical-correction-specific static QC: **350 PASS / 0 FAIL**.
- Inherited Closure R1 static regression suite: **1081 PASS / 0 FAIL**.
- Frozen medical payload: **132/132** files represented by the medical integrity manifest and frozen-content map.
- Resource registry: **25/25** resources resolve to the corrected frozen payload.
- GI deeper layer: **23 populated / 63 intentionally empty** across 86 modules. This is the original 6 plus 17 approved additions (3 release-relevant + 14 optional). Astra MAX's rejected optional `acute-pancreatitis-dx` addition remains empty.
- Historical `MedicalPayload/R2/pkg/o`: **19/19 byte-identical** to owner-accepted Closure R1.
- `pkg/p`: no new package slots added; current packages 05, 07, 08, 12 and 14 refreshed to match corrected canonical live cockpits.
- Changed cockpit structural check: topic IDs preserved; parsed question IDs/answer indices preserved; pattern/rapid structures preserved.
- Changed HTML/JavaScript check: JavaScript syntax PASS; no duplicate IDs; no broken internal anchors on touched HTML surfaces.
- UWorld Selector corrected PDF: 4/4 pages rendered and visually inspected without clipping/overlap. SHA-256 `fff605e66f2391ea04ea6df7d0b29fa25392a5b355ec027d74127094fbd8145a`.
- Non-medical application source comparison vs Closure R1 (excluding the two intentionally refreshed content-integrity metadata files): **65/65 byte-identical**, 0 added, 0 removed, 0 changed.

## Corrected medical authority

`Pathfinder-Step2CK-2026-Medical-Payload-W8-Medical-Correction-R1.zip`

SHA-256: `035667ff06a7fc5bf7ca5072d2936a96dec512fec02e8efec8b6d06fa3348a1a`

The authority archive contains exactly 132 payload files beneath `R2/` and passed ZIP integrity testing.

## Compile status

No C#/XAML/project/runtime implementation changed from the owner-accepted Closure R1 source that already passed exact-source x64 and ARM64 GitHub compilation. This build therefore does not create a new executable-code delta to compile-prove. The supplied Windows build script still re-verifies the corrected 132-file payload and 25-resource registry before local publish; owner Windows/device testing remains required before acceptance.
