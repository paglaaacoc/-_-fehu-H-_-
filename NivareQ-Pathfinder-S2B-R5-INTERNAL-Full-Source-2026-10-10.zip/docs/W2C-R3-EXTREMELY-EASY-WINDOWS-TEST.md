# W2C R3 — Extremely Easy Windows Test

1. Extract `Pathfinder-W2C-R3-TEST.zip`.
2. Double-click `TEST-W2C-x64.cmd`.
3. Confirm the running app says **W2C R3 CANDIDATE**.
4. Re-check the W2C R2 functionality: occurrence-level exact search, Preview source, Preview → Go, Return bar, and 19–22 direct reveal/scroll behavior.
5. Specifically click resources **18, 19, 20, 21 and 22** from the study-library sidebar. The sidebar should remain full-width, must not horizontally shift/shrink, and should not jump to a strange position after the cockpit opens. Normal vertical scrolling is expected.
6. If all passes, report `W2C R3 PASS`. If not, send the console text/screenshot.

Do not edit or rename medical payload files.
