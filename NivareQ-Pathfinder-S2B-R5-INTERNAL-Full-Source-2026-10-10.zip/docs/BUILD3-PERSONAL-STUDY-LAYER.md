# NivareQ Step 2 Pathfinder — Build 3
## Personal Study Layer Development Candidate

Build 3 starts from the user-accepted Pathfinder v1.0 Friend Release / Full Continuity baseline.

This build is intentionally shell-only. The frozen 132-file medical payload is unchanged.

## Added in Build 3

### Exact cockpit resume position
- Pathfinder now records the active cockpit's document hash and scroll position.
- Position updates are sent from the hosted page to the native shell through the normal WebView2 message bridge.
- Reopening a subject restores its saved position.
- Last-session restore therefore returns not only to the same tabs, but also to each subject's saved reading position.
- No source HTML is edited.

### My Study
A new **My Study** surface is available from the top bar and Home.
It provides:
- Favorites
- Recently studied subjects
- Bookmarks
- Personal subject notes
- Recently closed study tabs
- Optional study progress
- Backup / restore

### Favorites
- Right-click a subject card → Add to favorites / Remove from favorites.
- Favorites receive a star and sort to the top of their existing library group.
- Favorites also appear in My Study.

### Bookmarks + personal notes
- Bookmark the exact current cockpit location from My Study or a study-tab context menu.
- A bookmark can have its own name and optional note.
- Each subject also has an independent personal note.
- Bookmarks and notes are Pathfinder-owned personal data; the medical source files remain immutable.

### Recently studied
- Pathfinder keeps a short local list of recently opened subjects.
- The list is available in My Study.

### Optional progress states
Progress tracking is OFF by default.
When enabled, the available states are:
- Not started
- Studying
- First pass done
- Review later

Turning progress OFF hides the state from the library but does not delete it.
Progress changes are manual; Pathfinder does not infer completion from opening a subject.

### Better tab/session ergonomics
Right-click a study tab for:
- Pin / unpin
- Bookmark this place
- Personal note
- Close other tabs
- Close tabs to the right
- Close tab

Pinned study tabs:
- cannot be closed accidentally by the close button or Ctrl+W;
- are preserved in session restore;
- are not replaced when a normal subject click would otherwise reuse the active study tab.

Ctrl+Shift+T still reopens the newest closed study tab, and My Study now exposes up to 10 recently closed study tabs from the current session.

### Backup / restore
My Study can export one JSON backup containing:
- Pathfinder theme/session settings
- open-tab session snapshot and pin state
- favorites
- recently studied subjects
- bookmarks
- personal notes
- progress states and whether progress is shown
- per-subject reading positions

Restore is explicit. After restore, restart Pathfinder once to reopen the backed-up tab session exactly as saved.

## Explicitly NOT part of Build 3
- Global cross-cockpit search — reserved for Build 4.
- Accessibility / keyboard / DPI-scaling / narrow-window / reduced-motion / touch hardening gate — reserved for a future Build 5.
- Any medical-content edits.

## Status
Static QC: PASS.
Native Windows compile / runtime validation: REQUIRED before Build 3 is accepted.
