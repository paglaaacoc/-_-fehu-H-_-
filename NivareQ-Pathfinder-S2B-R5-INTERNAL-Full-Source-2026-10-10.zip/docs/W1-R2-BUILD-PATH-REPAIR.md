# W1 R2 — Real-Windows WinUI Build-Path Repair

Date: 2026-09-29

## Trigger
The owner's first real-Windows W1 R1 x64 test passed the medical payload and .NET 10 SDK gates, then failed inside the WinUI XAML markup compiler with `WMC9999` while trying to create:

- `MainWindow\.g.i.cs`
- `MainWindow\.g.cs`

The reported generated-file path was 265 characters long. This crosses the classic 260-character Windows path boundary still encountered by parts of the WinUI XAML compiler toolchain.

## Diagnosis
This is a build-package/tooling path defect, not a demonstrated W1 C# compile defect. The compiler failed before the generated MainWindow C# files could be created. No medical payload mismatch or SDK deficiency was reported.

## R2 repair
`tools\build-windows.ps1` now:

1. verifies the authoritative medical payload in the actual candidate tree first;
2. copies only the candidate source into a deliberately short temporary workspace under `%TEMP%\NQPF-W1-Build` (excluding `bin`/`obj`);
3. performs WinUI/.NET publish from that short path;
4. verifies the published medical payload in the staged output;
5. copies the finished app back into the candidate's normal `Built Apps` folder;
6. verifies the copied published payload again;
7. deletes the staging tree after a successful build.

The authoritative source remains the FULL continuity candidate tree. The temporary staging copy is build machinery only and is not a new persistence/data architecture.

## Product/source scope
No Pathfinder runtime/product source was changed between W1 R1 and W1 R2. No medical HTML was changed. No persistence/backup behavior was changed. W1 R2 exists solely to make the already-approved real-Windows compile/test path resilient to long descriptive extraction folders.

## Status
Pending real-Windows compile and runtime testing. Windows v1.2 remains the accepted rollback baseline.
