# W1 R3 — Restore Journal Compile Repair

## Trigger
The owner's W1 R2 x64 build successfully passed medical integrity, .NET 10 SDK gating, restore, and the R2 short-path staging step. Compilation then stopped at `RestoreTransactionService.cs` with `CS0165: Use of unassigned local variable 'journalError'`.

## Root cause
The R2 recovery code combined a null test and validation call in one short-circuit expression:

```csharp
if (journal is null || !TryValidateJournal(journal, out var journalError))
```

The common failure body then referenced `journalError`. If `journal is null`, the validation call is skipped, so `journalError` is not definitely assigned. The C# compiler correctly rejects this path.

The later WinUI/XAML `WMC1509` / `WMC9999` messages occurred after the C# compiler error and are not treated as an independent XAML defect unless they recur after the C# error is removed.

## R3 repair
R3 separates the two failure branches:

1. null/deserialization failure reports a fixed parse message and returns;
2. validation failure calls `TryValidateJournal(... out var journalError)`, after which `journalError` is definitely assigned.

This is a narrow compile repair. It does not alter the W1 restore transaction semantics, canonical backup contract, accepted v1.2 rollback, startup architecture, or frozen medical payload.

## Verification performed here
- W1 static QC: **166 passed / 0 failed**.
- Frozen medical payload: **132/132 exact**.
- Added static regression check `restore-journal-definite-assignment`.
- No Windows compilation is claimed in this environment.

## Next
Run `TEST-W1-x64.cmd` on the owner's Windows machine. If compilation/launch succeeds, continue the existing W1 Backup/Restore smoke test. If another compile/runtime failure appears, repair W1 in place; do not restart W0 or alter v1.2.
