# W2B R2 — Unified Location v2 + Strict Source Identity

## Scope
W2B replaces filename/pixel-centric location assumptions with a single Windows `PathfinderLocation` contract bound to canonical resource identity and exact frozen source SHA-256.

### Added
- `PathfinderLocation` schema 2: resource ID, source version, purpose, semantic anchor/target/path/context, reveal state, offsets, hash/pixel fallback and timestamp.
- Semantic viewport capture from the byte-identical cockpit DOM.
- Strict source validation: same resource + same source SHA + durable semantic target required.
- Strict restoration refuses ambiguous/missing targets and never uses pixel fallback.
- Ordinary resume remains intentionally forgiving and may fall back to hash/pixels if old source bytes no longer match.
- Per-view monotonically increasing request IDs prevent stale location/search completions from winning.
- DOM bridge messages are bound to both content generation and source SHA.
- One authoritative primary interactive view per unique study resource under ordinary navigation.
- Source-version binding on Universal Search results and stale-result rejection.
- Reversible temporary cockpit-view snapshot primitives for W2C reveal/preview work.
- Canonical Windows backup schema 3 carries Location v2; schemas 1 and 2 remain import-compatible.
- Visible runtime build identifier: `W2B R2 CANDIDATE`.

## Preserved boundaries
- 132/132 frozen medical/teaching files remain byte-identical.
- No cockpit HTML/CSS/teaching content is edited.
- `%LOCALAPPDATA%\\NivareQ\\Step2Pathfinder` remains normal persistence root.
- Windows remains canonical backup/data authority.
- No Source Preview UI, Journal, native Selector, Settings migration, CockpitHost or Split View is pulled forward from later gates.

## Next gate after owner acceptance
W2C — Search + state-read-only Source Preview + Go-to-cockpit/Return Position.
