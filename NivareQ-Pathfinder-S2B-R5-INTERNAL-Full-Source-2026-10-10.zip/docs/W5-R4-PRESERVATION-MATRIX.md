# W5 R4 Preservation Matrix

- **Accepted fallback:** W4 R3.
- **Candidate:** W5 R4, unaccepted until real-Windows owner acceptance.
- **Medical payload:** 132/132 frozen files unchanged; 0 medical source changes.
- **Backup:** schema 6 retained; ProducerBuild advances to `W5-R4` only.
- **R4 runtime change:** only the Journal no-selection context-menu path plus candidate/build identity files.
- **Selected-text Journal capture:** preserved from R3.
- **Search:** W5 boundary-correct exact matching retained.
- **Split View:** W5 R2/R3 empty/static/hidden-secondary behavior retained unchanged; owner reported it perfect on real Windows.
- **Journal:** R3 inline editor, quick popup, tab Split participation, study-context resolution and Split-aware exact Open source retained.
- **Read-only source views:** remain excluded from fresh Journal capture.
- **Journal Pen Scratchpad:** CLOSED future gate; explicit owner decision required to open.
