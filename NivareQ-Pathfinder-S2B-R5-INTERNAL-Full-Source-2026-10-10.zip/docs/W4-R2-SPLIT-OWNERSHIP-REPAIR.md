# W4 R2 — Split View ownership / swap repair

W4 R1 real-Windows testing found a blocker: Swap panes and Show beside on the current primary could crash Pathfinder, and pane placeholders could become stale/inconsistent.

## Root cause
R1 could assign the current primary UIElement/WebView to `SecondaryWorkspaceContent` before WinUI had detached that element from the selected TabView ContentPresenter. XAML elements may have only one visual parent. SelectionChanged also attempted pane mutation while TabView was still completing selection.

## R2 repair
- pane swap is asynchronous and transactional;
- old secondary is detached/restored first;
- TabView selects the new primary and yields to the dispatcher;
- old primary detachment is verified before external hosting;
- clicking the secondary tab schedules the swap after SelectionChanged settles;
- swap/show-beside paths share the same safe transaction;
- swap failures are caught, both tab contents are restored, Split View closes safely, and Pathfinder remains running.

No frozen medical file was changed.
