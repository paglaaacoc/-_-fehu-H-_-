# W2B R2 — Extremely Easy Windows Test

W2A R1 is already accepted. This test is intentionally focused on the new W2B behavior.

## 1. Build + launch
Double-click:

`TEST-W2B-x64.cmd`

Expected pre-publish gates:
- medical payload: **132/132 PASS**;
- resource registry: **25 resources PASS**;
- .NET 10 SDK PASS;
- short staging path uses `%TEMP%\NQPF-W2B-Build`;
- x64 publish succeeds.

After launch, confirm the top bar visibly says:

**W2B R2 CANDIDATE**

The Windows title bar should also include **W2B R2 Candidate**.

If compilation fails, stop and send the console output/newest Build Logs file.

## 2. One-primary-resource rule
1. Open **Cardiology**.
2. Move somewhere obvious in Cardiology.
3. From the library, right-click Cardiology and choose **Open in new tab** (or middle-click/Ctrl+click Cardiology).

Expected: **no second Cardiology tab appears**. Pathfinder activates the already-open Cardiology primary tab.

Then open a different resource such as Renal/Pediatrics with Open in new tab.

Expected: different resources can coexist normally as separate tabs.

## 3. Rich resume/location sanity
1. In Cardiology, scroll to a distinctive section well away from the top.
2. Switch to another tab, then back.
3. Close Cardiology and reopen it.
4. If Restore last session is enabled, also close Pathfinder normally and reopen it once.

Expected: Cardiology returns to the same meaningful study area (or extremely close to it) and does not unexpectedly jump because of a late/stale request.

## 4. Bookmark sanity
At a recognizable Cardiology location, make a bookmark using the existing My Study bookmark action. Move elsewhere, then open that bookmark.

Expected: it returns to the intended location. Existing bookmark behavior must not regress.

## 5. Search ordering / source-binding sanity
Use Universal Search for a term with several results. Open one result, then quickly choose another result if practical.

Expected:
- the final action wins;
- there is no delayed snap-back to the earlier result;
- the result still lands in the correct cockpit/resource.

This is still the released Search UI. Search coverage + Source Preview are W2C.

## 6. Canonical backup now carries Location v2
After doing the location tests above, create a fresh canonical backup.

Open the JSON in Notepad and confirm near the top:

`"BackupSchemaVersion": 3`

and:

`"ProducerBuild": "W2B-R2"`

Inside at least one `PositionsBySlug` entry you should see fields such as:
- `"SchemaVersion": 2`
- `"ResourceId"`
- `"SourceVersion"` (a long 64-character SHA-256)
- `"Purpose": "resume"`
- `"Anchor"`, `"TargetId"`, `"TargetPath"`, `"Context"`
- `"ScrollX"`, `"ScrollY"`

Do **not** edit the backup for this test.

## 7. Backward backup compatibility
Restore the existing fixture:

`docs\W1-fixtures\canonical-w1-v2.json`

Expected: schema-2 Windows canonical backup is still accepted. Follow the normal restart instruction after restore.

Then launch W2B again and restore the fresh schema-3 backup you created in step 6.

Expected: schema-3 restore succeeds and the app restarts back into valid state.

## 8. Quick W2A regression check
Only a quick sanity pass is needed:
- open Geriatrics and Surgery;
- cockpit right-click/context menu works;
- native tab context menu works;
- selectable shell text menu remains readable in a light theme and a dark theme.

## 9. Report
A compact report is enough:

`Compile/launch + build ID PASS`  
`One-primary Cardiology PASS`  
`Different-resource tabs PASS`  
`Resume/restart location PASS`  
`Bookmark PASS`  
`Search ordering PASS`  
`Schema-3 backup PASS`  
`Schema-2 import PASS`  
`Schema-3 restore PASS`  
`W2A regression sanity PASS`

### Important W2B boundary
W2B contains the **strict source identity engine**, but Journal and the visible read-only Source Preview workflow do not exist yet. Those become visible in W2C, so there is no throwaway strict-source debug UI to test here.
