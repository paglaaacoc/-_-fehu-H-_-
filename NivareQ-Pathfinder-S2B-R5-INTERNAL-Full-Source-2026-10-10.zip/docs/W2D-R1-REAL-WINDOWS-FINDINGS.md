# W2D R1 — Real-Windows Findings (owner test)

W2D R1 compiled/launched on the owner's Windows machine and demonstrated that the major sidebar shell rewrite worked:

- **PASS:** the prior horizontal sidebar collapse/shrink rendering defect no longer occurs.
- **REMAINING:** clicking/tapping late resources (roughly beyond 16) can still shift the sidebar's vertical position; the effect self-corrects when the user scrolls/clicks elsewhere.
- **SEARCH INCONSISTENCY:** direct Search → Go to cockpit did not show Return to previous position on the first open of an otherwise closed cockpit, but did on the second/already-open attempt. Source inspection showed distinct first-open vs already-live paths.
- **PRODUCT CLEANUP:** the owner approved removing the low-frequency Study Time button from permanent top-bar chrome and moving the information into My Study.

W2D R1 was therefore not promoted. W2D R2 is the bounded closure candidate.
