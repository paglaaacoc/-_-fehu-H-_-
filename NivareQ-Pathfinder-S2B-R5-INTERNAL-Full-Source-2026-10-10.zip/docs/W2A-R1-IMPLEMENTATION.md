# W2A R1 — Canonical Resource Registry + Short-Path Migration

## Purpose
Make the frozen medical corpus a first-class Windows resource set without changing its medical/teaching bytes, and permanently remove legacy filesystem path length from product identity.

## Implemented
- Added `ShellData/resource-registry.json` as the canonical 25-resource registry: 23 study resources + Clinical Recall + the legacy UWorld PDF reference.
- Added stable `resourceId`, canonical physical path, legacy path/provenance, content type, role and authoritative SHA-256 per resource.
- Extended `SubjectEntry` with `ResourceId`, `LegacyMainPath` and `ExpectedSha256` while keeping `Slug == ResourceId` for v1.x persisted-state compatibility.
- `ContentCatalogService` now loads the registry rather than using the frozen historical `NAVIGATION-MANIFEST.json` as runtime identity.
- `ContentCatalogService.Resolve(...)` maps canonical IDs and legacy path aliases to the same resource, giving W2B/W2C a migration-safe identity layer.
- Session restoration and central slug opening now use the registry resolver.
- `RuntimeContentService` is keyed by canonical resource ID and verifies the bundled resource SHA-256 before creating its byte-exact runtime copy.
- Moved the 132 frozen payload files from the legacy long hierarchy into `MedicalPayload/R2` canonical short paths while preserving every file byte-for-byte.
- Primary study resources use compact paths such as `c/02-cardiology/main.html` and `c/16-geriatrics-prevention-ambulatory/main.html`.
- Historical/meta/source-support artifacts remain bundled under shorter `meta/`, `src/`, `pkg/`-style paths for continuity/integrity provenance.
- Added `ShellData/frozen-content-map.json` mapping every old physical path to its new canonical physical path and authoritative SHA-256.
- Build tooling now independently verifies the 132-file payload and the 25-resource registry both before publish and in the published app folder.

## Path-length result
The longest frozen-payload relative path in W1 was 214 characters. W2A reduces the longest path inside the canonical `R2` root to 49 characters (52 when counted relative to the `MedicalPayload` directory including `R2/`).

The specific legacy Geriatrics main path that triggered normal Windows Explorer path problems:

`cockpits/16-geriatrics-prevention-ambulatory/source/Step2CK-Geriatrics-Prevention-Ambulatory-Subject-Study-Fearless-Cockpit-R1-Package/Step2CK-Geriatrics-Prevention-Ambulatory-Subject-Study-Fearless-Cockpit-R1.html`

is now physically:

`c/16-geriatrics-prevention-ambulatory/main.html`

The old name remains only as provenance/alias metadata.

## Preflight maintenance repair carried from W1 testing
W1 device testing exposed a native WinUI selectable-TextBlock command flyout whose Copy/Select all text was unreadable under custom shell themes. Cockpit/WebView2 context menus and TabView context menus were healthy.

W2A replaces only the selectable-shell-text default command flyout with a native `MenuFlyout` containing Copy and Select all. It preserves text selection, clipboard copy, touch selection behavior, keyboard copy behavior, cockpit context menus and tab context menus. This does not touch medical HTML.

## Explicitly not in W2A
- no one-primary-cockpit enforcement yet (W2B);
- no Location v2 / J-1 strict source contract (W2B);
- no Search expansion/SourcePreview/Return Position (W2C);
- no Settings/shell-surface migration (W2D);
- no CockpitHost v1 (W3);
- no Split View (W4).

## Frozen-content statement
No medical/teaching payload byte was edited. W2A is a physical-path/resource-identity migration around the frozen corpus.
