# Build 1 architecture

```text
WinUI 3 native window
  ├─ fixed 58px top app bar
  │   ├─ Subjects / Back / Forward / Home
  │   ├─ global NivareQ theme selector
  │   ├─ Focus mode
  │   ├─ Time to study
  │   └─ Guide
  ├─ adaptive SplitView subject pane
  │   └─ native ListView with right-click/touch-hold/middle-click
  └─ native TabView (reorderable; native overflow scroll bumpers)
      ├─ Home (native shell UI)
      ├─ Guide / Study Time (native shell UI)
      └─ study tabs
          └─ one WebView2 per tab
              └─ READ-ONLY virtual-host mapping to immutable payload
```

## Content origin
`https://content.pathfinder.nivareq.local/` is mapped by WebView2 directly to the packaged read-only content folder. There is no HTTP listener/server.

## Storage
WebView2 profile data: `%LOCALAPPDATA%\NivareQ\Step2Pathfinder\WebView2`
Shell settings: `%LOCALAPPDATA%\NivareQ\Step2Pathfinder\settings.json`
The shell never writes into `MedicalPayload`.

## Native touch zoom
No custom pointer/pinch/double-tap/pan code is installed in the study surface. Edge/WebView2 defaults remain authoritative.

## Current version pins
- Microsoft.WindowsAppSDK 2.5.1
- Microsoft.Web.WebView2 1.0.4191.47
These were current stable packages when Build 1 source was assembled.
