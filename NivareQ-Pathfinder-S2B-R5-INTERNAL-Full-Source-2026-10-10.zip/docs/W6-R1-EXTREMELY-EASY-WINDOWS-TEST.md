# W6 R1 — Extremely Easy Real-Windows Test

## 1. Build and identity
1. Extract the whole W6 TEST ZIP.
2. Double-click **TEST-W6-x64.cmd**.
3. The build must complete and Pathfinder must visibly say **W6 R1 CANDIDATE**.
4. If compilation fails, stop and send the complete error text.

## 2. Find the Selector
1. In Study Library → Extras/Reference, find **Clinical Recall Library**.
2. **UWorld Selector** should appear directly below it.
3. Open UWorld Selector.
4. Confirm it is a normal closable workspace tab and shows the first-pass rule, summary, filters and recipe cards.

## 3. Unknown is not zero
1. Pick a recipe that is currently Unknown.
2. Enter `7` and press **Record**.
3. It should immediately show `7 unused` plus a local timestamp; the summary should change.
4. Change it to `0` and Record. It should now say `0 unused` — not Unknown.
5. Press **Clear → Unknown**. It must return to Unknown.
6. Try `-1`, letters, and `100001`; each must be rejected without changing the saved report.

## 4. Search and status filters
1. Search `cardio`; Cardiology should be easy to find.
2. Search `ophthalmology`; the supplemental ENT/Ophthalmology recipe should appear.
3. Clear search and try **Unknown**, **Unused remaining**, and **Verified 0 unused** filters after recording a few different values.

## 5. Open cockpit + Split View
1. From Cardiology recipe press **Open cockpit**. Cardiology should open normally; this must NOT change the Selector report.
2. Reopen Selector and use its tab context menu / Split controls to **Show beside**. Confirm the accepted W5 static Split behavior still works.
3. Ordinary main-tab/library navigation must not silently replace the parked Selector.

## 6. Residual six + final audit
1. Find **VERIFY Residual six-system coverage verification** and confirm it lists the six residual systems.
2. Find **FINAL Final 100% coverage audit**.
3. Expand the **All 22 UWorld systems** reference and confirm there are 22 numbered systems.
4. The final audit must say all five subjects / all systems / Unused ONLY and must remain Unknown until you report a count.

## 7. Existing printable PDF
Press **Open printable selector PDF**. The existing UWorld selector PDF should still open as the separate reference resource. Returning to the native Selector should show your recorded counts unchanged.

## 8. Journal integration
1. In a Selector recipe press **Add note to Journal…** and save a short note.
2. Open Journal and confirm the note owner is UWorld Selector.
3. Use **Open source** on that note. It should return to the exact Selector recipe; if Journal is main it should pair Selector beside when possible, and if Journal is already beside the Selector should open in main while Journal stays parked.

## 9. Global Search
1. In UWorld Selector, deliberately set a local search/status filter that hides a recipe you will target next.
2. Open universal Search and search for a distinctive Selector term such as `residual six` or `ophthalmology`.
3. A UWorld Selector section/result should appear.
4. **Go to Selector recipe** should clear any local Selector filter that would hide the destination and visibly reveal the targeted recipe.
5. Search `All Subjects All Systems`; it should resolve to the **FINAL** all-subject/all-system audit recipe.
6. Quick regression: search `ARDS`; embedded substrings such as `standards` must not return as exact ARDS hits.

## 10. Persistence + restart
1. Record at least two nonzero counts and one zero count.
2. Close Pathfinder normally and reopen it.
3. Reopen Selector. Counts and timestamps must remain; Unknown recipes must remain Unknown.

## 11. Backup schema 7 smoke
1. Create a canonical Pathfinder backup after recording Selector counts.
2. Change/clear one Selector value.
3. Restore the backup.
4. Selector values should return exactly to the backed-up reports.
5. Existing Journal, study state and W5 behavior must remain intact.

## 12. Important non-feature check
There should be **no** UWorld sign-in, account connection, web scraping, automatic count reading or claim that Pathfinder verified UWorld completion.

## Acceptance
If the important items above work on real Windows, explicitly tell the development chat **W6 R1 is accepted**. W5 R4 remains authoritative until that explicit acceptance.
