# W4 R3 — Extremely Easy Windows Test

Use `Pathfinder-W4-R3-TEST.zip` when possible.

1. Extract the ZIP to a normal folder.
2. Double-click **`TEST-W4-x64.cmd`**.
3. Confirm Pathfinder shows **W4 R3 CANDIDATE**.
4. The build script must first pass the frozen medical/resource integrity gates.

## A. Exact R2 stale-placeholder blocker retest — most important
Use two different Primary cockpits, preferably the pair that exposed the defect.

1. Open **Pulmonary** and **Cardiology** as normal Primary tabs.
2. Make **Pulmonary** the main/selected tab.
3. Put **Cardiology** beside it with Split View.
4. Click the **Cardiology tab header** in the main TabView.
   - Cardiology must become the main pane.
   - Pulmonary must move beside.
   - The main pane must show the **live Cardiology cockpit**, not the “shown in the other Split View pane” placeholder.
5. Click the **Pulmonary tab header**.
   - Pulmonary must become main.
   - Cardiology must move beside.
   - The main pane must show live Pulmonary immediately.
6. Alternate Cardiology ↔ Pulmonary at least **10 times**.
   - Exactly the tab currently hosted beside may show the placeholder when that tab is not selected.
   - The selected/main tab must never remain stuck on the placeholder.
   - The cockpit requested by the clicked tab must be the cockpit shown in main.
7. Open/select a **third unrelated cockpit** and then return to Pulmonary/Cardiology.
   - No stale placeholder may survive.
   - Pane ownership must remain understandable and deterministic.

**R3 fails if the old R2 “massacre” sequence appears even once.**

## B. R1 crash-path regression
1. With two different Primary cockpits split, press **Swap panes** repeatedly (10+ times).
2. Right-click the current main/Primary tab and choose **Show beside in Split View**.
3. Repeat from both sides.

Expected: no crash, no stale placeholder, no duplicated live XAML/WebView content.

## C. Quick-selection race check
1. With Pulmonary + Cardiology split, click the beside tab and then quickly click a third normal tab.
2. Repeat several times at human-fast speed.

Expected: an older deferred split swap must not override a newer tab choice. Pathfinder may settle on the latest valid selection, but must not leave a stale placeholder or mismatched pane assignment.

## D. Existing W4 contract glance
- Two **different** resources remain fully interactive Primary cockpits side-by-side.
- Same-resource second view remains **Read-only** and cannot write canonical study state.
- Search / Glossary can participate in Split View.
- Search → Preview source → **Show beside** remains read-only and does not steal Primary authority.
- Divider resize works with mouse/touch.
- Narrow-window fallback hides and later restores the second pane assignment.
- Closing/reopening with Split View restore enabled restores the workspace appropriately.

## E. Backup identity
Create a canonical backup and confirm:
- `"BackupSchemaVersion": 5`
- `"ProducerBuild": "W4-R3"`
- Split View workspace fields remain in `ShellSettings`.

## F. WebView2 recovery watch
During the repeated swap/tab test, watch for:

`The embedded study browser stopped unexpectedly (BrowserProcessExited).`

One such event occurred once during broken R2 stress testing and could not be reproduced. If it occurs in R3, report the exact sequence immediately. The existing **Reload cockpit safely** button should recover without changing frozen medical content.

## G. Regression glance
- W2C Search → Preview → Go → Return works.
- W2D Settings / My Study / Guide work.
- W3 Primary vs ReadOnlySecondary authority and cockpit-state persistence work.
- 132/132 frozen medical payload files pass the pre-build integrity gate.

Do not accept R3 based on static QC alone; owner real-Windows runtime testing is required.
