# W4 R2 — Extremely Easy Windows Test

Use the lightweight `Pathfinder-W4-R2-TEST.zip` when possible.

1. Extract it to any normal folder.
2. Double-click `TEST-W4-x64.cmd`.
3. Confirm the app says **W4 R2 CANDIDATE**.

## Core Split View test
1. Open **Cardiology** in one tab and **Renal** in another.
2. Select Cardiology and click **◫ Split**.
3. Confirm two panes appear and Cardiology + Renal are both usable/interactable.
4. Change something harmless in Cardiology, then something harmless in Renal. Both should behave as their own normal Primary cockpits.
5. Drag the divider with mouse or touch. Both panes should resize without disappearing.
6. Press **⇄ Swap**. The two workspaces should exchange sides without losing state.
7. Click the tab header of the view currently shown on the right. It should swap into the main/left pane rather than duplicate itself.

## Same-resource safety
1. Keep Cardiology open.
2. Use **Open in new tab** on Cardiology again.
3. Confirm the second tab says **Cardiology · Read-only**.
4. Put Primary Cardiology and Cardiology · Read-only side-by-side.
5. The read-only copy may scroll/zoom/select/copy, but must not change reviewed/quiz/study state.

## Search / source workflow
1. Open **Search** and search a known cockpit concept.
2. Choose **Preview source**.
3. In the preview dialog, click **Show beside**.
4. Search should remain available while a verified read-only source view appears beside it.
5. This action must not move the authoritative Primary cockpit.

## Adaptive/narrow test
1. With Split View open, narrow the Pathfinder window substantially (Surface portrait-like width).
2. Pathfinder should fall back to one visible pane without crashing or discarding the split assignment.
3. Widen the window again. The second pane should return.

## Session restore
1. Leave Split View open with two views and adjust the divider.
2. Close Pathfinder normally.
3. Reopen it.
4. If Settings → Workspace & Split View → restore is enabled, the split assignment and approximate divider ratio should return.

## Backup
Create a canonical backup. It should contain:
- `"BackupSchemaVersion": 5`
- `"ProducerBuild": "W4-R2"`
- Split View workspace fields in `ShellSettings`.

## Regression glance
- W2C Search → Preview → Go → Return still works.
- W2D Settings/My Study/Guide still work.
- W3 Primary vs ReadOnlySecondary authority still works.
- 132/132 medical payload integrity gate passes before build.

Report any compile error exactly as shown. Do not assume a WinUI/XAML follow-on error is independent if a C# error appears first.


## R2 blocker retest
1. Open two different primary cockpits in Split View and press **Swap panes** repeatedly. No crash.
2. Right-click the current main/primary tab and choose **Show beside in Split View**. It must swap safely, not crash.
3. Click the tab currently shown in the other pane; it should become the main pane and the previous main should move beside, with no stale placeholder.
4. Repeat with 3–4 unique cockpit tabs to verify the message “This view is currently shown in the other Split View pane” only appears for the tab actually hosted beside.
