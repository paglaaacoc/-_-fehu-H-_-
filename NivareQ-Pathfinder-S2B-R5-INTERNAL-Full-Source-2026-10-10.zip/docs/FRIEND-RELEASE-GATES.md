# Friend release gates after Build 2 RC1

Cut the friend release directly from the accepted Build 2 RC1 source if all native checks pass.

Required:
1. x64 publish succeeds and launches.
2. ARM64 publish succeeds (native ARM64 launch remains desirable when hardware is available).
3. 132/132 medical-integrity gate passes.
4. R6 cockpit visibility remains fixed.
5. R7 sidebar repaint / hover / accelerator-hint behavior remains fixed.
6. Pathfinder theme authority fixes Strategy and other cockpit secondary surfaces across multiple theme switches.
7. Last-session restore ON reopens the prior tabs and selected tab.
8. Restore OFF starts fresh.
9. Ctrl+Shift+T reopens the most recently closed study tab.
10. Home / Guide / Time contain user-facing copy rather than development explanations.

If all pass: make the friend release a packaging/release-identity cut only. Do not add another feature build.
