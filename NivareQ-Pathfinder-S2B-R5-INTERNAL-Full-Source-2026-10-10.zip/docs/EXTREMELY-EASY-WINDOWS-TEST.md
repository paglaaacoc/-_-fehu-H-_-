# Build 2 RC1 — extremely easy Windows test

This is the final pre-release candidate test. You do not need to inspect source code.

## 1. Build it
1. Extract the ZIP to a normal folder such as Documents.
2. Double-click `BUILD-ON-WINDOWS.cmd`.
3. Confirm the medical-integrity check says **132 / 132 PASS**.
4. Let x64 and ARM64 publish finish. (You only need to run x64 on your current PC.)
5. Open `Built Apps\NivareQ Step 2 Pathfinder - x64\NivareQ.Step2Pathfinder.exe`.

## 2. Quick regression check
Open **Cardiology → Pulmonary → Renal**.
- Every cockpit must remain visible after loading.
- Subject cards must remain outline-first with normal hover/selection feedback.
- Alt+Left must navigate Back without showing the old floating `Alt + Left` hint.

## 3. Main theme-authority test
1. Choose **Amber**.
2. Open **Strategy Cockpit**.
3. The large KPI/stat tiles near the top must use Amber-compatible secondary surfaces — they must NOT turn white/light-blue just because the cockpit previously remembered its own light/dark state.
4. The cockpit's own little light/dark theme-toggle button should no longer appear inside Pathfinder.
5. Switch **Amber → Parchment → OLED Black → Light → Amber** without restarting.
6. Cockpit background, cards, secondary cards/KPIs and primary-button text should follow Pathfinder immediately and remain readable.
7. Repeat one quick check in **Pulmonary** and **Cardiology**.

## 4. Last-session restore test
1. Keep at least three tabs open, for example **Strategy**, **Cardiology**, and **Pulmonary**.
2. Select **Cardiology** last.
3. Close Pathfinder with the normal Windows X.
4. Launch Pathfinder again.
5. The previous tabs should reopen and the previously selected tab should be selected again.

This feature is ON by default.

## 5. Restore OFF test
1. Open **Guide**.
2. Under **Continue where you left off**, uncheck **Reopen my last tabs when Pathfinder starts**.
3. Close Pathfinder.
4. Reopen it.
5. Pathfinder should start fresh on Home instead of reopening the prior tabs.
6. Turn the option back ON if you want the accidental-close protection.

## 6. Reopen-closed-tab shortcut
1. Open a subject in a tab.
2. Close that study tab.
3. Press **Ctrl+Shift+T**.
4. That most recently closed study subject should reopen.

## 7. Public-facing polish check
Look at **Home**, **Guide**, and **Time**.
- They should read like normal user-facing product pages.
- You should not see cards explaining internal payload immutability, runtime bridge implementation, build history, or other development notes.
- The normal independence / non-endorsement notice may remain.

## PASS / FAIL
If all sections above pass, Build 2 RC1 is suitable to freeze and cut into the friend release without another feature build.
If anything fails, send a screenshot plus `%LOCALAPPDATA%\NivareQ\Step2Pathfinder\study-view-events.log` when relevant.
