# W2B R2 — Real-Windows Compile Repair

## R1 result
The owner ran `TEST-W2B-x64.cmd` on real Windows. Medical integrity, resource registry, .NET SDK and short-path staging all passed. Compilation then failed in `MainWindow.Location.cs` with three `CS9007` errors. The later WinUI `WMC1509/WMC9999` messages occurred after the C# compile failure and are treated as downstream until proven otherwise.

## Root cause
W2B R1 embedded JavaScript in C# interpolated raw string literals using `$$"""`. JavaScript contains dense consecutive closing braces, which collided with C# raw-string interpolation delimiter parsing.

## R2 repair
The three affected JavaScript blocks now use ordinary non-interpolated C# raw string templates with explicit sentinel replacement for the few C# values that must be injected. No Location-v2, Search, persistence, source-fidelity, cockpit, resource-registry or medical-content behavior was intentionally changed.

## Scope
This is a bounded compile repair. W2A R1 remains the accepted development baseline until W2B is owner-accepted.
