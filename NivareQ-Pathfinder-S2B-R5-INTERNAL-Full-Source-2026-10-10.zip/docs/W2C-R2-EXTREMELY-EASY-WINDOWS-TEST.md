# W2C R2 — Extremely Easy Windows Test

1. Double-click **TEST-W2C-x64.cmd**.
2. Confirm the title/header says **W2C R2 CANDIDATE**.
3. **Occurrence search regression:** Search exactly `Acute pancreatitis diagnosis`. Confirm GI + Hepatobiliary now exposes **two distinct exact source matches** (learning module + Core question), with separate Preview/Go actions.
4. Open the GI learning-module exact result with **Preview source**. Confirm the preview is substantially wider/larger and the right side of the cockpit is not simply clipped by a narrow dialog.
5. From that preview click **Go to cockpit**. Confirm it lands on the **same learning module** and temporary highlight as direct Search → Go, not a different location.
6. Confirm the **Return to previous position** bar sits *above* the cockpit instead of covering its sticky cockpit navigation. Click Return and verify the prior study position/view returns.
7. Repeat direct Search → Go and Return once.
8. Test one resource from **19–22** (for example General Principles + Miscellaneous): Search a distinctive module, click Go to cockpit, and confirm the **full cockpit remains visible** while Pathfinder reveal/scroll/highlights the source. It must not leave the cockpit filtered down to only that card. Return should restore any prior view/filter.
9. Quick Preview regression: scroll/select/copy/pinch-zoom in Source Preview; study-changing controls remain non-authoritative.
10. Quick invariant: reopening an already-open cockpit still does not create a second interactive duplicate.
11. Quick context-menu regression: cockpit right-click menu, tab menu, and shell selectable-text menu remain usable.
12. Optional backup: schema remains 3 and producer is `W2C-R2`.

### Explicitly not part of this test
- Theme normalization for 19–22 (documented for W3 CockpitHost/theme compatibility).
- Filling empty medical teaching fields such as GI `One step deeper` (deferred to mandatory release-readiness medical audit/re-review).

If compilation fails, send the full console output. If runtime behavior differs, screenshot the exact source/result and say which numbered step failed.
