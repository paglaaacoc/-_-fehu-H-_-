# W2C R3 — Compile / TEST Packaging / Sidebar Stability Repair

## Why R3 exists
W2C R2 was not testable on the owner Windows machine for two independent handoff defects:

1. the lightweight TEST ZIP omitted `Integrity/MEDICAL_PAYLOAD_SHA256_MANIFEST.txt`, so its first integrity gate could not run;
2. `UniversalSearchService.cs` introduced occurrence-level search locals named `matchIndex` and `score` inside a nested branch while the enclosing scope later declared locals with the same names, producing real C# `CS0136` compiler errors.

The owner also reported a pre-existing/adjacent sidebar rendering/position-jump defect when opening later resources (18+).

## R3 repairs
- exact-occurrence branch locals are uniquely named `exactMatchIndex` and `exactScore`; search behavior is otherwise unchanged from R2;
- TEST package now carries the medical integrity manifest required by its own verifier;
- TEST packaging is independently checked before delivery;
- Study-library `ListView` no longer owns selection state (`SelectionMode=None`) because selection was never used as application state;
- horizontal scrolling is explicitly disabled in the study library, preventing long late-corpus titles from creating horizontal bring-into-view/layout offsets; vertical scrolling remains enabled.

## Boundaries
- no frozen medical/teaching bytes changed;
- no W2D Settings work;
- no medical-content enrichment;
- no change to W2C R2 occurrence-level search, Source Preview, Go/Return semantics beyond the compiler repair.

## Test status
Source/static checks only in the build environment. Real Windows compile/runtime acceptance remains owner-gated.
