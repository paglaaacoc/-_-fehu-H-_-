# W2D R1 — Extremely Easy Windows Test

Use the lightweight TEST ZIP if possible.

## 1. Build + launch
Double-click:

`TEST-W2D-x64.cmd`

Expected before publish:
- medical payload integrity PASS: 132/132
- source resource registry PASS: 25 resources / canonical+legacy aliases
- .NET 10 SDK gate PASS
- short-path staging under `%TEMP%\NQPF-W2D-Build`

When the app opens, confirm the title/top shell says:

**W2D R1 CANDIDATE**

If build fails, stop and send the complete console text/newest Build Logs file.

## 2. Mandatory sidebar blocker test
This is the most important W2D test.

Scroll the study library low enough to see the late resources. Open these repeatedly and in mixed order:
- 19 Allergy + Immunology
- 20 ENT + Ophthalmology
- 21 Poisoning + Environmental Exposure
- 22 General Principles + Miscellaneous
- Clinical Recall Library
- UWorld Checkbox Selector

Also jump back to earlier resources and then back late again.

**PASS:** sidebar stays full width, does not collapse/shrink horizontally, does not jump to a bizarre position merely because the cockpit opened, and ordinary vertical scrolling remains normal.

**FAIL:** take a screenshot immediately before manually scrolling/fixing it and report which resource triggered it.

## 3. Shell taxonomy
Confirm:
- opening a study subject creates/reuses a normal study tab;
- Search remains a tool tab;
- Glossary remains a tool tab;
- My Study opens as an app surface, not a new closable tab;
- Guide opens as an app surface, not a new closable tab;
- Settings opens as an app surface;
- `Return to study` returns to the prior study/tool tab;
- Home remains special/non-closable.

## 4. Settings
Open Settings and click through:
- General
- Appearance
- Accessibility & display
- Data, backup & reset
- Session & navigation
- Workspace & Split View
- About & integrity

Confirm Aa opens **Settings → Accessibility & display** directly.
Change theme once from Settings Appearance or the top quick selector and verify both represent the same state.

## 5. Study Time
Click **Time**.

PASS: a substantial flyout/panel opens; no Study Time tab is created.

## 6. W2C regression check
Quickly verify one Search result:
- Preview source
- Go to cockpit
- Return to previous position

The accepted W2C behavior must still work.

## 7. Canonical backup
Settings → Data, backup & reset → **Create canonical backup**.

PASS: backup saves and verifies normally.

## 8. Destructive reset safety test — optional but recommended
Safest beta test scope: **Session/view state only**.

1. Open a few tabs/locations you can recognize.
2. Settings → Data, backup & reset → Reset Pathfinder data…
3. Choose `Session/view state only`.
4. Continue.
5. **First test cancellation:** cancel the backup save picker. Reset must stop and report that no verified backup was created.
6. Repeat reset, this time save the required backup.
7. After backup verification, Pathfinder must ask a second explicit destructive confirmation.
8. Cancel there once if desired; nothing should reset.
9. To fully test, repeat and confirm reset. Restart Pathfinder when instructed.

Do **not** test Full canonical reset unless you deliberately want to exercise that destructive scope and are prepared to restore the required pre-reset backup.

## 9. Report
A compact report is enough:

- Build/launch: PASS/FAIL
- Late-library sidebar: PASS/FAIL
- App surfaces/tabs taxonomy: PASS/FAIL
- Settings sections/Aa: PASS/FAIL
- Study Time flyout: PASS/FAIL
- W2C Preview/Go/Return: PASS/FAIL
- Canonical backup: PASS/FAIL
- Reset backup-cancel gate: PASS/FAIL/not tested
- Session reset + restart: PASS/FAIL/not tested
- Any screenshots/odd behavior
