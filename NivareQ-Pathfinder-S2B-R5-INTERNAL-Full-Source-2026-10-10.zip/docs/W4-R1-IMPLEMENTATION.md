# W4 R1 — Native Split View & Multi-View Workspace

## Scope
W4 R1 builds the required native two-pane workspace on top of the accepted W3 CockpitHost/view-authority model. It does not modify frozen medical/teaching files.

## Implemented
- Native two-pane workspace with a top-bar `◫ Split` control.
- Two different Primary cockpits may remain fully interactive side-by-side (for example Cardiology + Renal).
- The same resource still has only one interactive Primary; additional same-resource cockpit views remain W3 `ReadOnlySecondary` views.
- Search and Glossary tool tabs can occupy the secondary pane.
- Search Source Preview adds `Show beside`, which creates a verified state-read-only source tab using the same immutable source target and hosts it in Split View without moving the primary cockpit.
- Secondary pane has local Back/Forward controls for cockpit/WebView navigation, plus Swap and Close.
- Clicking a tab currently hosted in the secondary pane swaps panes rather than creating duplicate ownership.
- Mouse/touch divider resize with bounded 28–72% ratio.
- Narrow-window/Surface portrait fallback temporarily shows a single pane while preserving the Split View assignment; the second pane returns when width is available.
- Workspace session persistence: enabled state, secondary view identity and divider ratio. Read-only secondary cockpit role is reconstructed safely on restart when configured.
- Canonical Windows backup advances to schema 5 and includes Split View workspace settings. Schemas 1–4 remain importable; older canonical backups start Split View closed.
- Settings → Workspace & Split View now exposes `Restore my Split View workspace when Pathfinder restarts`.

## Authority rule
Split View is layout, not data authority. Cockpit authority remains determined by W3 `CockpitViewRole`:
- Primary = interactive/canonical writer;
- ReadOnlySecondary = no canonical cockpit-state writes or resume ownership.

Therefore Cardiology + Renal may both write independently to their own canonical resource state, while Cardiology + Cardiology can only be Primary + ReadOnlySecondary.

## Deferred
- Journal workspace participation: W5.
- Native UWorld Selector workspace participation: W6.
- Final keyboard/workspace polish: W7.
- Known low-severity late-library sidebar vertical jump remains carried as opportunistic shell polish.
- Known 19–22 drill visual selected/correct/wrong feedback inconsistency remains later compatibility/polish.
