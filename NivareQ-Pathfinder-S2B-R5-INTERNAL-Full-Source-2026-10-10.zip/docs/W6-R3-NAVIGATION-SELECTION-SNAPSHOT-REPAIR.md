# W6 R3 — Navigation + Selection Snapshot Repair

W6 R3 is a bounded revision of the unaccepted W6 R2 candidate. The 26-recipe Selector contract, backup schema 7, context-menu layout and frozen medical payload remain unchanged.

## Context-selection timing repair
R2 correctly preferred DOM `window.getSelection().toString()` over WebView2 `SelectionText`, but requested that DOM value only after the custom context-menu command was clicked. Real-Windows testing showed the browser/context-menu interaction could already narrow the multi-block selection by then.

R3 starts one DOM-selection snapshot task immediately inside `ContextMenuRequested`, while the originating selection is still authoritative. Journal and Search selection commands await/reuse that snapshot only if invoked. WebView2 `SelectionText` remains fallback. Storage stays plain text with the existing 12,000-character safety cap.

## Search programmatic prefill
`OpenUniversalSearchFor` still writes the selected query into the existing Search TextBox, but R3 additionally calls the Search renderer directly. It no longer depends solely on WinUI `TextChanged` timing after a tab is created/selected, preventing a populated query from appearing with stale `Ready`/empty results.

## Selector cockpit navigation
R2 deliberately handled one mapped recipe by direct bring-into-view and multiple mapped recipes by slug filtering. That was logically valid but visually inconsistent. R3 uses one visible rule: every cockpit action populates the Selector search/filter with the stable cockpit slug. A single mapping additionally retains exact recipe bring-into-view; multi-mapped crossover cockpits show all recipes sharing the slug.

## Deferred scope
Journal rich text remains deferred. Journal Pen Scratchpad Gate remains closed and owner-controlled.
