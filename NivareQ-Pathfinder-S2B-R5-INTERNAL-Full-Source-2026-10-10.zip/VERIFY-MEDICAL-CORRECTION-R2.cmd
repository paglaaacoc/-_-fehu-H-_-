@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\verify-medical-payload.ps1"
if errorlevel 1 goto :fail
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\verify-resource-registry.ps1"
if errorlevel 1 goto :fail
where python >nul 2>&1
if errorlevel 1 (
  echo Python not found; payload/resource integrity passed. R2 developer QC is recorded in docs/Integrity.
  pause
  exit /b 0
)
python "%~dp0tools\medical-correction-r1-static-qc.py"
if errorlevel 1 goto :fail
python "%~dp0tools\closure-static-qc.py"
if errorlevel 1 goto :fail
python "%~dp0tools\medical-correction-r2-static-qc.py"
if errorlevel 1 goto :fail
echo.
echo W8 Medical Correction R2 verification PASS.
pause
exit /b 0
:fail
echo.
echo W8 Medical Correction R2 verification FAILED.
pause
exit /b 1
