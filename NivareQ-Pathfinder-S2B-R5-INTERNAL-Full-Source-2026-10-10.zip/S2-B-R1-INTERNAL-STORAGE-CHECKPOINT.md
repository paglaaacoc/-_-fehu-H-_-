# NivareQ Pathfinder — S2-B R1 Internal Storage Foundation (2026-10-09)

**NOT OWNER-TESTABLE. NO WINDOWS COMPILE OR CI EXECUTED. NOT AN ACCEPTED BASELINE.**

## Authority

- Derived byte-for-byte from embedded authenticated S2-A source checkpoint (`84ccd5b0017221a1f09eb55100be772e5fbbb302a847ae0b9df9167a6f52d0e9`).
- Accepted Windows rollback remains **v1.2.1 Stable**. Scratchpad S1 CI-Corrected R2 is an unaccepted TEST candidate.
- The S2-A theme/ruled-guide slice is carried forward without modification. Its Windows behavior is not yet verified.
- PWA, Public-Impact G0, all medical payloads, cockpit/Journal/My Study/Search flows are untouched.

## Implemented in this internal checkpoint

`Services/NotesStoreV1.cs` implements an isolated **INACTIVE staged-generation** Notes SQLite foundation. The accepted hierarchy is Notebook → Note → Page; Scratchpad remains an editor capability, not a second saved-document collection.

- Transactional SQLite schema for notebooks, notes, pages, text/ink writing spaces, source references (note-level), content-addressed attachment records and floating image objects.
- FTS5 indexed title and typed-body search; read limit. No OCR, HTML, cloud, or handwriting recognition.
- Independent per-page revision compare-and-swap; a stale pending page write fails atomically and cannot overwrite a newer acknowledged revision.
- SQLite `foreign_keys=ON`, `synchronous=FULL`, WAL and integrity/foreign-key verification.
- Staged attachment streaming to a temporary file; size cap 25 MB each; SHA-256 addressing and reference-safe (no garbage collection) storage. PNG chunk CRC/dimension checking and JPEG structural checks (not a complete decoding pipeline).
- Optional, **staged only**, S1 importer: preserves original source JSON in the inactive generation before import; creates a single `Imported Scratchpads` notebook with one Note per legacy pad and pages/cells/ink copied, including original S1 IDs as provenance. Counts/source SHA-256 are recorded; the S1 extension value is never changed or deleted. An invalid or interrupted import cannot activate itself.
- Explicit `SealStaging()` freezes a verified generation; sealed/reopened generations are read-only. No live-active writer and no pointer activation API is implemented here. Future S2-D must implement global snapshot/restore transactions and writer gating before live activation.
- Compatibility refusal: an invalid generation ID, missing database, unknown schema or invalid generation-state marker produces an error instead of an empty replacement database.
- Verified exact source flags cannot be accepted unless a trusted source-registry verifier callback approves the reference. General notes never claim an exact source location by default.

## Deliberately NOT done

- **Not wired to MainWindow, WebView2, or any live autosave or backup:** existing S1 JSON persistence is unchanged while new generation/backup wiring remains unproven. Thus this checkpoint does not remove the legacy 12 MB cap from the running app.
- No live data migration, S1 discard, test-note cleanup, `Backup VNext`, atomic restore generation pointer, page/trash/library UI, screenshot paste/Arrange, or lower-left Backups button implementation.
- No historical Journal notes migration (explicit owner waiver). Old Journal remains intact pending U1 parity.
- Does not guarantee malformed image rejection by complete raster decoding; S2-C must add a decoder/render-validation gate before displaying/acknowledging image insertion.
- No native Windows x64 or ARM64 compile or real Windows interaction tests. Do not label the ZIP a Windows release or installer.

## Design obligations before next checkpoint

1. **Compile and exercise the native cross-platform harness** (`dotnet run --project tests/NotesStoreHarness`) and then a Windows x64/ARM64 build from this full source. The available execution container has no `dotnet` binary or internet DNS. The Python `tools/s2b_contract_smoke.py` validates actual SQLite DDL/FTS/FK/CAS and safety invariants, but does not compile C#.
2. Add per-note/page collection operations, metadata sequencing, safe trash, and a bridge that sends targeted page data with monotonic page revisions. Verify edit/switch with in-flight ACKs and failure/retry. Do not fall back to replacing a whole library JSON.
3. Decide how owner values existing S1 test notes before activation: default **preserve and stage-migrate**, do not discard without express owner waiver. Existing non-S1 Windows study data is ALWAYS preserved.
4. Before activating any generation, implement and prove an atomic validated pointer in the bounded provider restore transaction, process/global writer gate, safe snapshot/rollback, and correct backup coverage. Until S2-D, all new generations remain inactive.
5. Reproduce each S1 page's text, ink strokes, guides, spacing and active identities in a sealed staged generation. Verify source hash/counts/relative per-page information and crash-mid-import retries in a new generation. Validate migrated data on Windows before any promotion.
6. Preserve user-selected final UI hierarchy and button arrangement: My Study / Search, Browse Notes / New Note, Settings / **Backups** (same Backup VNext engine as Settings).

## Minimal test suite

- `python tools/s2b_contract_smoke.py` — local actual-SQL smoke (passing in development environment).
- `dotnet run --project tests/NotesStoreHarness` — full native service smoke (written, **not run yet**).
- Future S2-B native tests must also include: S1 multi-pad/multi-page, page switch/inflight ACK race, crash before/after SQLite commit, invalid image, no disk space, WAL restart, incompatible DB refusal, S1 source preservation, corrupt attachment refusal, concurrent staging/sealing, and exact verified source resolver integration.

**Checkpoint verdict:** S2-B *foundation implemented, validation incomplete*. Do not begin S2-C as a supposedly accepted prior checkpoint. No GitHub default branch, live app data, or release has been modified by producing this working-source package.
