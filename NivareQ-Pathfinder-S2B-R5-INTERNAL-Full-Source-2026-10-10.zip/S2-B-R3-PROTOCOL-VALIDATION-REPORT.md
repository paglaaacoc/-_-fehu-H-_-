# S2-B R3 — Save/ACK boundary and test report

## Problem addressed

S2-B R2 had durable SQLite page CAS but no transport-side ACK ownership. A
renderer could inadvertently close/switch after an unacknowledged write, or
misinterpret an earlier ACK as confirming newer edits. S2-B R3 defines an
isolated, testable boundary **without activating the new store**.

## Protocol contract

`nivareq.notes.page-save.v1` request fields:
`sessionId`, `sequence`, `noteId`, `pageId`, `expectedRevision`, `page`.
A successful native ACK repeats all identities and provides `persistedRevision`
strictly equal to `expectedRevision + 1`. The JS coordinator moves its acknowledged
revision only after a fully matching ACK. The C# router acknowledges only after
`NotesStoreV1.SavePage` commits. A repeated identical sequence/payload returns the
cached ACK in the same process; an altered or old sequence fails closed. Two
simultaneous native writer sessions for the same page are refused.

A renderer mutation during a pending write stays dirty and receives a second
serialized write after the first ACK. Navigating to another page is a durability
fence and cannot clear the old draft if a write fails. The draft is retained in
RAM for retry and diagnostics; it is **not yet crash-durable without S2-D**.

If the database committed but a transport ACK was lost, the UI must NOT mark the
draft saved. It must block navigation and, after a stale-revision response, obtain
a verified current page revision and perform a user-safe reconcile. That recovery
workflow is a future UI/active-generation gate, not implemented here.

## Executed tests

| Test | Result | Limitation |
|---|---|---|
| JS simulated native transport | 27 PASS | Node, not actual WebView2 |
| SQLite schema smoke | 8 PASS | Python sqlite3, not .NET |
| R2 actual SQL + static contracts | 22 PASS | No managed runtime |
| Cross-language/isolation static guard | PASS | No .NET compile |
| Existing S1 Scratchpad JS syntax | PASS | Does not exercise native UI |
| Source/medical hashes and ZIP CRC | See manifest | Does not constitute app acceptance |
| C# staging router harness tests | AUTHORED; NOT RUN | No .NET SDK / GitHub branch source upload |

## Main remaining development blocker

The native app and C# harness still need actual Windows CI. No source is merged
to `main`; no GitHub Actions workflow was installed or launched; no current
owner-test package is produced. The existing v1.2.1 rollback and S1 live JSON
bridge are left unchanged.
