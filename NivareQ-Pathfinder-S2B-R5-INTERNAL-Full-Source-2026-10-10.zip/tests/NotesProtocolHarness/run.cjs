'use strict';
const assert = require('node:assert/strict');
const Coordinator = require('../../src/NivareQ.Step2Pathfinder/NotesProtocol/notes-draft-coordinator.js');
const p = (text='') => ({guide:'ruled',spacing:32,cells:[{text,strokes:[]}],images:[]});
const seed = (id='p1',rev=0)=>({sessionId:'session-'+id,noteId:'n1',pageId:id,persistedRevision:rev,page:p()});
function native() {
  const revisions = new Map([['p1',0],['p2',0]]), data=new Map(), writes=[];
  return {writes,revisions,data,
    probe: async ({protocol, sessionId, noteId, pageId})=>({protocol,sessionId,noteId,pageId,
      persistedRevision:revisions.get(pageId), page:data.get(pageId) || p()}),
    write: async packet => {
    writes.push(packet);
    if (packet.expectedRevision !== revisions.get(packet.pageId)) throw new Error('stale CAS');
    revisions.set(packet.pageId,packet.expectedRevision+1);
    data.set(packet.pageId,packet.page);
    return {protocol:Coordinator.protocol,sessionId:packet.sessionId,sequence:packet.sequence,
      noteId:packet.noteId,pageId:packet.pageId,persistedRevision:packet.expectedRevision+1};
  }};
}
async function main() {
  let checks=0;
  function ok(cond,msg){assert.ok(cond,msg);checks++;}
  const n=native();let status=[];
  const c=new Coordinator({write:n.write,onStatus:s=>status.push(s)});
  c.open(seed());
  ok(c.status.revision===0 && !c.status.pending,'open clean');
  let live=p('First clinical draft');c.edit(live);live.cells[0].text='MUTATED AFTER EDIT';
  ok(c.draft.cells[0].text==='First clinical draft','draft snapshots do not alias UI edits');
  await c.flush();
  ok(n.data.get('p1').cells[0].text==='First clinical draft' && c.status.revision===1,'ACK only after saved');
  const lost=native();lost.revisions.set('p1',1);
  let fail=true;
  const failing=new Coordinator({write:async packet => {if(fail)throw Error('disk full');return lost.write(packet)},probe:lost.probe,release:async()=>{}});
  failing.open(seed('p1',1));failing.edit(p('never silently discarded'));
  await assert.rejects(failing.flush(),/disk full/);checks++;
  ok(failing.status.pending && failing.status.error.includes('disk full'),'write failure is sticky');
  await assert.rejects(failing.switchTo(seed('p2')),/disk full/);checks++;
  ok(failing.draft.cells[0].text==='never silently discarded' && failing.status.pageId==='p1','failed switch preserves draft');
  await assert.rejects(failing.flush(),/disk full/);checks++;
  fail=false;await failing.flush({retry:true});
  ok(!failing.status.pending && !failing.status.error,'explicit retry recovers');
  await failing.switchTo(seed('p2'));
  ok(failing.status.pageId==='p2','switch after durable save');
  // Edits while a native save is unresolved must not be mislabeled as saved.
  const sequential=native();let release;
  const pending=new Promise(r=>{release=r});let calls=0;
  const racing=new Coordinator({write:async packet=>{calls++;if(calls===1)await pending;return sequential.write(packet)}});
  racing.open(seed());racing.edit(p('older draft'));
  const first=racing.flush();
  await Promise.resolve();await Promise.resolve();
  racing.edit(p('newer draft'));
  ok(racing.status.pending,'in-flight later edits stay dirty');
  release();await first;
  ok(sequential.writes.length===2 && sequential.writes[1].expectedRevision===1,'serial save after first ACK');
  ok(sequential.data.get('p1').cells[0].text==='newer draft' && !racing.status.pending,'latest data durably ACKed');
  const wrong=new Coordinator({write:async packet=>({...packet, protocol:Coordinator.protocol,persistedRevision:97})});
  wrong.open(seed());wrong.edit(p('must survive'));
  await assert.rejects(wrong.flush(),/acknowledgement/);checks++;
  ok(wrong.status.pending && wrong.draft.cells[0].text==='must survive','mismatched ACK blocks clean state');
  const duplicateNative=native();
  const concurrent=new Coordinator({write:duplicateNative.write});
  concurrent.open(seed());concurrent.edit(p('one request'));
  await Promise.all([concurrent.flush(),concurrent.flush()]);
  ok(duplicateNative.writes.length===1,'concurrent flush calls share in-flight request');
  await assert.rejects(Promise.resolve().then(()=>new Coordinator({write:native().write}).open(seed('p2',-1))),/Invalid native/);checks++;
  ok(status.length>0 && status.at(-1).error===null,'status updates emitted');
  // A committed write with its ACK lost must NOT report success or blindly
  // overwrite the persisted value on retry. Recovery needs a later read/merge gate.
  const committed=native();let lostAck=true;
  const uncertain=new Coordinator({probe:committed.probe,write:async packet=>{
    if(lostAck){await committed.write(packet);lostAck=false;throw Error('ACK channel broken');}
    return committed.write(packet);
  }});
  uncertain.open(seed());uncertain.edit(p('saved but unacknowledged'));
  await assert.rejects(uncertain.flush(),/ACK channel broken/);checks++;
  ok(committed.data.get('p1').cells[0].text==='saved but unacknowledged' && uncertain.status.pending,
    'lost ACK leaves draft pending although native committed');
  const beforeReconcileWrites=committed.writes.length;
  await uncertain.flush({retry:true});
  ok(uncertain.status.revision===1 && !uncertain.status.pending && !uncertain.status.needsReconciliation,
    'lost ACK reconciled only after native read+compare');
  ok(committed.writes.length===beforeReconcileWrites && uncertain.draft.cells[0].text==='saved but unacknowledged',
    'reconciliation did not issue a second save');
  // Wire DTO needs strokesJson (string) for C# NotesInkCell, never the S1
  // editor's in-memory strokes array. Guard a real representative ink stroke.
  const wireNative=native();
  const wire=new Coordinator({write:wireNative.write});
  wire.open(seed());
  wire.edit({guide:'ruled',spacing:32,cells:[{text:'Ink',strokes:[
    {color:'#142235',width:2,points:[[0.5,0.2],[0.7,0.8]]}]}],images:[]});
  await wire.flush();
  const serializedPacket=JSON.parse(JSON.stringify(wireNative.writes[0]));
  ok(typeof serializedPacket.page.cells[0].strokesJson==='string' &&
    Array.isArray(JSON.parse(serializedPacket.page.cells[0].strokesJson)) &&
    !('strokes' in serializedPacket.page.cells[0]),'native wire uses typed strokesJson');
  // Failed-but-not-committed can be verified and retried, including newer edits.
  const notCommitted=native();let rejectOnce=true;
  const verified=new Coordinator({write:async packet => {
    if(rejectOnce){rejectOnce=false;throw Error('connection lost before dispatch');}
    return notCommitted.write(packet);
  },probe:notCommitted.probe});
  verified.open(seed());verified.edit(p('older unsaved'));
  await assert.rejects(verified.flush(),/before dispatch/);checks++;
  verified.edit(p('newer unsaved'));
  await verified.flush({retry:true});
  ok(notCommitted.writes.length===1 && notCommitted.data.get('p1').cells[0].text==='newer unsaved',
    'confirmed noncommit retries latest draft');
  // A mismatched committed payload may never be acknowledged by comparing only
  // revision. Even an apparently valid page revision must match the saved body.
  const tampered=native();let dropOnce=true;
  const conflict=new Coordinator({write:async packet=>{
    if(dropOnce){dropOnce=false;await tampered.write(packet);throw Error('dropped ACK');}
    return tampered.write(packet);
  },probe:async req=>({...await tampered.probe(req),page:p('DIFFERENT REMOTE CONTENT')})});
  conflict.open(seed()); conflict.edit(p('must retain local draft'));
  await assert.rejects(conflict.flush(),/dropped ACK/);checks++;
  await assert.rejects(conflict.flush({retry:true}),/differs/);checks++;
  ok(conflict.status.pending && conflict.status.needsReconciliation &&
    conflict.draft.cells[0].text==='must retain local draft' && tampered.writes.length===1,
    'mismatched native read protects local draft and prevents overwrite');
  // No recovery reader is never permission to repeat an ambiguous save.
  const noProbeNative=native();
  const noProbe=new Coordinator({write:async packet=>{
    await noProbeNative.write(packet);throw Error('unknown result');
  }});
  noProbe.open(seed());noProbe.edit(p('no reader'));
  await assert.rejects(noProbe.flush(),/unknown result/);checks++;
  await assert.rejects(noProbe.flush({retry:true}),/verified native read/);checks++;
  ok(noProbeNative.writes.length===1 && noProbe.status.pending,
    'no probe refuses blind duplicate write');
  // Navigation while a save is pending cannot replace the old page until the
  // last newly edited revision has been acknowledged.
  let finishPending;const navigationGate=new Promise(resolve=>{finishPending=resolve});
  const navNative=native();let navCalls=0;
  const navigating=new Coordinator({release:async()=>{},write:async packet=>{
    if(++navCalls===1)await navigationGate;
    return navNative.write(packet);
  }});
  navigating.open(seed());navigating.edit(p('initial navigation draft'));
  const switching=navigating.switchTo(seed('p2'));
  await Promise.resolve();await Promise.resolve();
  navigating.edit(p('last-minute edit'));
  ok(navigating.status.pageId==='p1' && navigating.status.pending,'pending save prevents navigation');
  finishPending();await switching;
  ok(navNative.writes.length===2 && navNative.data.get('p1').cells[0].text==='last-minute edit',
    'last-minute edit committed before switching');
  ok(navigating.status.pageId==='p2' && !navigating.status.pending,'switch after final ACK');
  await assert.rejects(Promise.resolve().then(()=>navigating.open(seed('p1'))),/already open/);checks++;
  const noRelease=new Coordinator({write:native().write});
  noRelease.open(seed());
  await assert.rejects(noRelease.switchTo(seed('p2')),/session-release/);checks++;
  ok(noRelease.status.pageId==='p1','missing native release cannot silently abandon page');
  const closed=new Coordinator({write:native().write,release:async()=>{}});
  closed.open(seed());closed.edit(p('save before close'));
  await closed.close();
  ok(closed.status===null,'close requires durable save and native session release');
  // R5 regression: the old page must not accept edits after the last
  // flush while release awaits native ACK. That was a silent-loss window in R4.
  let releaseOldPage;
  const releasePending = new Promise(resolve => {releaseOldPage = resolve;});
  const guardedNative = native();
  const guarded = new Coordinator({write:guardedNative.write,release:async()=>releasePending});
  guarded.open(seed());guarded.edit(p('persisted before release'));
  const guardedSwitch = guarded.switchTo(seed('p2'));
  await new Promise(resolve=>setImmediate(resolve));
  ok(guarded.status.transitioning && guarded.status.pageId==='p1' && guarded.status.pending,
    'release barrier visible while native ACK pending');
  assert.throws(()=>guarded.edit(p('would be silently discarded')), /frozen during native session release/);checks++;
  await assert.rejects(guarded.flush(), /being released/);checks++;
  await assert.rejects(guarded.close(), /navigation is already in progress/);checks++;
  ok(guarded.draft.cells[0].text==='persisted before release' && guardedNative.data.get('p1').cells[0].text==='persisted before release',
    'edit after release barrier rejected without mutating persisted or in-memory content');
  releaseOldPage(); await guardedSwitch;
  ok(guarded.status.pageId==='p2' && !guarded.status.transitioning,
    'confirmed release changes page only after native ACK');
  // A failed release leaves the originating page and draft available, instead
  // of switching, clearing, or losing the last confirmed page contents.
  const rejectedNative=native();let failRelease=true;
  const rejected=new Coordinator({write:rejectedNative.write,release:async()=>{
    if(failRelease) throw Error('release failed');
  }});
  rejected.open(seed());rejected.edit(p('safe despite release failure'));
  await assert.rejects(rejected.switchTo(seed('p2')), /release failed/);checks++;
  ok(rejected.status.pageId==='p1' && !rejected.status.transitioning &&
     rejected.draft.cells[0].text==='safe despite release failure',
     'failed native release retains current page and draft');
  failRelease=false;
  await rejected.flush({retry:true});
  await rejected.switchTo(seed('p2'));
  ok(rejected.status.pageId==='p2' && rejectedNative.writes.length===1,
    'explicit recovery after a known release failure does not duplicate saved page');
  // Native bounds are narrower than renderer defaults for image IDs and z-index.
  const img = id => ({id,cellIndex:0,sha256:'a'.repeat(64),x:0.1,y:0.2,width:0.2,height:0.2,zIndex:0});
  const canonicalImages=new Coordinator({write:native().write});
  canonicalImages.open(seed());
  canonicalImages.edit({guide:'ruled',spacing:32,cells:[{text:'image',strokes:[]}],
    images:[img('a'),img('Z')]});
  ok(canonicalImages.draft.images.map(x=>x.id).join(',')==='Z,a',
    'image ties sort by binary ordinal to match SQLite rather than locale collation');
  assert.throws(()=>canonicalImages.edit({guide:'ruled',spacing:32,cells:[{text:'image',strokes:[]}],
    images:[img('x'.repeat(101))]}), /Invalid image reference/);checks++;
  assert.throws(()=>canonicalImages.edit({guide:'ruled',spacing:32,cells:[{text:'image',strokes:[]}],
    images:[{...img('valid'),zIndex:10001}]}), /Invalid image reference/);checks++;
  const previousDraft=navigating.draft;
  assert.throws(()=>navigating.edit({guide:'ruled',spacing:32,cells:[]}));checks++;
  ok(JSON.stringify(navigating.draft)===JSON.stringify(previousDraft),'invalid UI edit preserves draft');
  console.log(JSON.stringify({result:'PASS',suite:'isolated Notes JS ACK/draft contract (NOT native/WinUI)',checks},null,2));
}
main().catch(err=>{console.error(err);process.exitCode=1});
