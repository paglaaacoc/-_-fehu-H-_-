@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo.
echo ==========================================================
echo NivareQ Step 2 Pathfinder - Scratchpad S1 TEST CANDIDATE
echo Local x64 + ARM64 build only - NO GITHUB ACTIONS
 echo ==========================================================
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\build-scratchpad-s1-locally.ps1"
if errorlevel 1 (
  echo.
  echo BUILD FAILED - see error above and Build Logs. Existing stable files were not intentionally modified.
  pause
  exit /b 1
)
echo.
echo TEST BUILD COMPLETE. Check artifacts\installers for EXEs.
echo This is NOT an accepted release. Back up data before installing any candidate.
pause
exit /b 0
