@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "PROJECT=%CD%\src\NivareQ.Step2Pathfinder\NivareQ.Step2Pathfinder.csproj"
set "ART=%CD%\artifacts"
set "ISCC="

if exist "%ProgramFiles%\Inno Setup 7\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 7\ISCC.exe"
if not defined ISCC if exist "%ProgramFiles(x86)%\Inno Setup 7\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 7\ISCC.exe"

if not defined ISCC (
  echo Inno Setup was not found. Attempting a quiet install using winget...
  where winget >nul 2>nul
  if errorlevel 1 goto :NOINNO
  winget install --id JRSoftware.InnoSetup.7 -e --silent --accept-package-agreements --accept-source-agreements
  if errorlevel 1 goto :NOINNO
  if exist "%ProgramFiles%\Inno Setup 7\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 7\ISCC.exe"
  if not defined ISCC if exist "%ProgramFiles(x86)%\Inno Setup 7\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 7\ISCC.exe"
)
if not defined ISCC goto :NOINNO

if exist "%ART%" rmdir /s /q "%ART%"
mkdir "%ART%\publish-x64" || exit /b 1
mkdir "%ART%\publish-arm64" || exit /b 1
mkdir "%ART%\installers" || exit /b 1

echo.
echo [1/4] Publishing x64...
dotnet publish "%PROJECT%" -c Release -r win-x64 --self-contained true -o "%ART%\publish-x64"
if errorlevel 1 exit /b 1

echo.
echo [2/4] Publishing ARM64...
dotnet publish "%PROJECT%" -c Release -r win-arm64 --self-contained true -o "%ART%\publish-arm64"
if errorlevel 1 exit /b 1

echo.
echo [3/4] Compiling x64 installer...
"%ISCC%" "%CD%\installer\Pathfinder-x64.iss"
if errorlevel 1 exit /b 1

echo.
echo [4/4] Compiling ARM64 installer...
"%ISCC%" "%CD%\installer\Pathfinder-ARM64.iss"
if errorlevel 1 exit /b 1

echo.
echo === INSTALLER I1 BUILD COMPLETE ===
for %%F in ("%ART%\installers\*.exe") do certutil -hashfile "%%~fF" SHA256

echo.
echo Installers are in:
echo   %ART%\installers
exit /b 0

:NOINNO
echo.
echo ERROR: Inno Setup could not be found or installed automatically.
echo Install the current Inno Setup from jrsoftware.org, then run this file again.
exit /b 1
