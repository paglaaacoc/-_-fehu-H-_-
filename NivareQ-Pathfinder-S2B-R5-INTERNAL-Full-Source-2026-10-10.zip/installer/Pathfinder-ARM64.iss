#define PublishDir "..\artifacts\publish-arm64"
#define OutputBaseName "NivareQ-Step2-Pathfinder-v1.2.2-Scratchpad-S1-TEST-Setup-ARM64"
#define ArchitecturesAllowedValue "arm64"
#include "Pathfinder-Installer-Common.iss"
