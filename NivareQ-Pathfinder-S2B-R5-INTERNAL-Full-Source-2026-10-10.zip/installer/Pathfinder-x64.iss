#define PublishDir "..\artifacts\publish-x64"
#define OutputBaseName "NivareQ-Step2-Pathfinder-v1.2.2-Scratchpad-S1-TEST-Setup-x64"
#define ArchitecturesAllowedValue "x64compatible and not arm64"
#include "Pathfinder-Installer-Common.iss"
