#define MyAppName "NivareQ Step 2 Pathfinder"
#define MyAppVersion "1.2.2"
#define MyAppPublisher "NivareQ"
#define MyAppExeName "NivareQ.Step2Pathfinder.exe"
#define MyAppId "NivareQ.Step2Pathfinder"
#define MyDataRoot "{localappdata}\\NivareQ\\Step2Pathfinder"

[Setup]
AppId={#MyAppId}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
AppPublisher={#MyAppPublisher}
AppPublisherURL=https://nivareq.com
AppSupportURL=https://nivareq.com
AppUpdatesURL=https://nivareq.com
VersionInfoCompany={#MyAppPublisher}
VersionInfoDescription={#MyAppName}
VersionInfoProductName={#MyAppName}
VersionInfoProductVersion=1.2.2.0
VersionInfoVersion=1.2.2.0
DefaultDirName={autopf}\NivareQ\Step 2 Pathfinder
DefaultGroupName=NivareQ
DisableProgramGroupPage=yes
PrivilegesRequired=admin
PrivilegesRequiredOverridesAllowed=dialog
MinVersion=10.0.19041
ArchitecturesAllowed={#ArchitecturesAllowedValue}
ArchitecturesInstallIn64BitMode={#ArchitecturesAllowedValue}
OutputDir=..\artifacts\installers
OutputBaseFilename={#OutputBaseName}
SetupIconFile=..\src\NivareQ.Step2Pathfinder\Assets\Pathfinder.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
UninstallDisplayName={#MyAppName}
Uninstallable=yes
UninstallLogMode=append
WizardStyle=modern
Compression=lzma2/max
SolidCompression=yes
CloseApplications=yes
CloseApplicationsFilter={#MyAppExeName}
RestartApplications=no
AppMutex=Local\NivareQ.Step2Pathfinder.SingleInstance.v1
SetupMutex=NivareQ.Step2Pathfinder.Setup
UsePreviousAppDir=yes
UsePreviousGroup=yes
UsePreviousTasks=yes
UsePreviousLanguage=yes
UsePreviousPrivileges=yes
DisableReadyMemo=no
DisableFinishedPage=no

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Additional shortcuts:"; Flags: unchecked

[Files]
Source: "{#PublishDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\NivareQ Step 2 Pathfinder"; Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"; IconFilename: "{app}\Assets\Pathfinder.ico"
Name: "{group}\Uninstall NivareQ Step 2 Pathfinder"; Filename: "{uninstallexe}"
Name: "{autodesktop}\NivareQ Step 2 Pathfinder"; Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"; IconFilename: "{app}\Assets\Pathfinder.ico"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch NivareQ Step 2 Pathfinder"; Flags: nowait postinstall skipifsilent

[Code]
const
  RemoveDataPhrase = 'REMOVE MY PATHFINDER DATA';

var
  DeleteUserDataOnUninstall: Boolean;

function ConfirmPermanentDataRemoval: Boolean;
var
  Form: TSetupForm;
  WarningLabel: TNewStaticText;
  DetailLabel: TNewStaticText;
  PhraseLabel: TNewStaticText;
  Input: TNewEdit;
  ContinueButton: TNewButton;
  CancelButton: TNewButton;
  ModalResultCode: Integer;
begin
  Result := False;

  while True do
  begin
    Form := CreateCustomForm(ScaleX(560), ScaleY(330), True, True);
    try
      Form.Caption := 'Permanently remove Pathfinder data';
      Form.CenterOnShow := True;

      WarningLabel := TNewStaticText.Create(Form);
      WarningLabel.Parent := Form;
      WarningLabel.Left := ScaleX(24);
      WarningLabel.Top := ScaleY(22);
      WarningLabel.Width := ScaleX(512);
      WarningLabel.Height := ScaleY(52);
      WarningLabel.AutoSize := False;
      WarningLabel.WordWrap := True;
      WarningLabel.Font.Style := [fsBold];
      WarningLabel.Caption := 'WARNING: This permanently deletes all Pathfinder-owned local study data on this Windows account.';

      DetailLabel := TNewStaticText.Create(Form);
      DetailLabel.Parent := Form;
      DetailLabel.Left := ScaleX(24);
      DetailLabel.Top := ScaleY(82);
      DetailLabel.Width := ScaleX(512);
      DetailLabel.Height := ScaleY(84);
      DetailLabel.AutoSize := False;
      DetailLabel.WordWrap := True;
      DetailLabel.Caption := 'This includes study state, Journal data, cockpit state, preferences, recovery data, and the WebView2 profile under:' + #13#10 +
        ExpandConstant('{localappdata}\NivareQ\Step2Pathfinder') + #13#10#13#10 +
        'Backups that you manually exported somewhere else are not deleted.';

      PhraseLabel := TNewStaticText.Create(Form);
      PhraseLabel.Parent := Form;
      PhraseLabel.Left := ScaleX(24);
      PhraseLabel.Top := ScaleY(180);
      PhraseLabel.Width := ScaleX(512);
      PhraseLabel.Height := ScaleY(38);
      PhraseLabel.AutoSize := False;
      PhraseLabel.WordWrap := True;
      PhraseLabel.Caption := 'To enable permanent removal, type exactly:' + #13#10 + RemoveDataPhrase;

      Input := TNewEdit.Create(Form);
      Input.Parent := Form;
      Input.Left := ScaleX(24);
      Input.Top := ScaleY(225);
      Input.Width := ScaleX(512);
      Input.Text := '';

      ContinueButton := TNewButton.Create(Form);
      ContinueButton.Parent := Form;
      ContinueButton.Caption := 'Permanently remove data';
      ContinueButton.Left := ScaleX(312);
      ContinueButton.Top := ScaleY(276);
      ContinueButton.Width := ScaleX(224);
      ContinueButton.Height := ScaleY(30);
      ContinueButton.ModalResult := mrOk;

      CancelButton := TNewButton.Create(Form);
      CancelButton.Parent := Form;
      CancelButton.Caption := 'Back';
      CancelButton.Left := ScaleX(208);
      CancelButton.Top := ScaleY(276);
      CancelButton.Width := ScaleX(92);
      CancelButton.Height := ScaleY(30);
      CancelButton.ModalResult := mrCancel;

      Form.ActiveControl := Input;
      ModalResultCode := Form.ShowModal;

      if ModalResultCode <> mrOk then
      begin
        Result := False;
        Exit;
      end;

      if CompareText(Trim(Input.Text), RemoveDataPhrase) = 0 then
      begin
        Result := True;
        Exit;
      end;

      MsgBox('The confirmation text did not match. No Pathfinder data will be removed unless the phrase matches exactly.', mbError, MB_OK);
    finally
      Form.Free;
    end;
  end;
end;

function AskUninstallDataChoice: Boolean;
var
  Form: TSetupForm;
  Heading: TNewStaticText;
  Explanation: TNewStaticText;
  KeepRadio: TNewRadioButton;
  RemoveRadio: TNewRadioButton;
  ContinueButton: TNewButton;
  CancelButton: TNewButton;
  ModalResultCode: Integer;
begin
  Result := False;
  DeleteUserDataOnUninstall := False;

  Form := CreateCustomForm(ScaleX(560), ScaleY(310), True, True);
  try
    Form.Caption := 'Uninstall NivareQ Step 2 Pathfinder';
    Form.CenterOnShow := True;

    Heading := TNewStaticText.Create(Form);
    Heading.Parent := Form;
    Heading.Left := ScaleX(24);
    Heading.Top := ScaleY(22);
    Heading.Width := ScaleX(512);
    Heading.Height := ScaleY(34);
    Heading.AutoSize := False;
    Heading.Font.Style := [fsBold];
    Heading.Caption := 'Choose what happens to your Pathfinder data';

    Explanation := TNewStaticText.Create(Form);
    Explanation.Parent := Form;
    Explanation.Left := ScaleX(24);
    Explanation.Top := ScaleY(62);
    Explanation.Width := ScaleX(512);
    Explanation.Height := ScaleY(66);
    Explanation.AutoSize := False;
    Explanation.WordWrap := True;
    Explanation.Caption := 'Normal uninstall removes the application but keeps your local study data so a later reinstall can continue where you left off. Permanent data removal is optional and deliberately requires a second confirmation.';

    KeepRadio := TNewRadioButton.Create(Form);
    KeepRadio.Parent := Form;
    KeepRadio.Left := ScaleX(36);
    KeepRadio.Top := ScaleY(142);
    KeepRadio.Width := ScaleX(490);
    KeepRadio.Height := ScaleY(36);
    KeepRadio.Caption := 'Keep my Pathfinder study data (recommended)';
    KeepRadio.Checked := True;

    RemoveRadio := TNewRadioButton.Create(Form);
    RemoveRadio.Parent := Form;
    RemoveRadio.Left := ScaleX(36);
    RemoveRadio.Top := ScaleY(188);
    RemoveRadio.Width := ScaleX(490);
    RemoveRadio.Height := ScaleY(42);
    RemoveRadio.Caption := 'Permanently remove all Pathfinder-owned local data on this account';

    ContinueButton := TNewButton.Create(Form);
    ContinueButton.Parent := Form;
    ContinueButton.Caption := 'Continue';
    ContinueButton.Left := ScaleX(424);
    ContinueButton.Top := ScaleY(256);
    ContinueButton.Width := ScaleX(112);
    ContinueButton.Height := ScaleY(30);
    ContinueButton.ModalResult := mrOk;

    CancelButton := TNewButton.Create(Form);
    CancelButton.Parent := Form;
    CancelButton.Caption := 'Cancel';
    CancelButton.Left := ScaleX(304);
    CancelButton.Top := ScaleY(256);
    CancelButton.Width := ScaleX(108);
    CancelButton.Height := ScaleY(30);
    CancelButton.ModalResult := mrCancel;

    ModalResultCode := Form.ShowModal;
    if ModalResultCode <> mrOk then
      Exit;

    if RemoveRadio.Checked then
    begin
      if not ConfirmPermanentDataRemoval then
        Exit;
      DeleteUserDataOnUninstall := True;
    end;

    Result := True;
  finally
    Form.Free;
  end;
end;

function InitializeUninstall: Boolean;
begin
  DeleteUserDataOnUninstall := False;

  if UninstallSilent then
  begin
    { Silent uninstall is intentionally conservative: preserve personal data. }
    Result := True;
    Exit;
  end;

  Result := AskUninstallDataChoice;
end;

procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
var
  DataRoot: String;
  ParentRoot: String;
begin
  if (CurUninstallStep = usPostUninstall) and DeleteUserDataOnUninstall then
  begin
    DataRoot := ExpandConstant('{localappdata}\NivareQ\Step2Pathfinder');
    ParentRoot := ExpandConstant('{localappdata}\NivareQ');

    if DirExists(DataRoot) then
    begin
      if not DelTree(DataRoot, True, True, True) then
        MsgBox('Pathfinder was uninstalled, but Windows could not remove every item in the local data folder:' + #13#10 + DataRoot + #13#10#13#10 +
          'No data outside that Pathfinder-owned folder was targeted.', mbError, MB_OK);
    end;

    RemoveDir(ParentRoot);
  end;
end;
