$ErrorActionPreference='Stop'
$Root=Split-Path -Parent $PSScriptRoot
$Base=Join-Path $Root 'artifacts'
$InstallerOut=Join-Path $Base 'installers'
Write-Host 'Scratchpad S1 candidate local build; this script invokes no GitHub, CI or deploy services.' -ForegroundColor Cyan
if(-not (Get-Command dotnet -ErrorAction SilentlyContinue)){throw 'Install the .NET 10 SDK before building.'}
if(-not (@(& dotnet --list-sdks) | Where-Object { $_ -match '^10\.0\.' })){throw 'The .NET 10 SDK is required.'}
$Inno=@("$env:ProgramFiles\Inno Setup 7\ISCC.exe", "${env:ProgramFiles(x86)}\Inno Setup 7\ISCC.exe", "$env:ProgramFiles\Inno Setup 6\ISCC.exe", "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe") | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
if(-not $Inno){throw 'Install Inno Setup 7 locally before creating installers. This script never downloads dependencies.'}
if(-not (Test-Path (Join-Path $Root 'src\NivareQ.Step2Pathfinder\ScratchpadAssets\scratchpad.js'))){throw 'Scratchpad source is missing.'}
# The already-accepted shell tooling handles path-short staging for WinUI and validates
# the packaged medical resources before and after publishing.
& (Join-Path $PSScriptRoot 'build-windows.ps1') -Arch All
# Any failure in the called PowerShell publisher throws (robocopy may return 1 for success).
New-Item -ItemType Directory -Force -Path $Base, $InstallerOut | Out-Null
$Apps=Join-Path $Root 'Built Apps'
foreach($arch in @('x64','arm64')){
    $srcName=if($arch -eq 'x64'){'NivareQ Step 2 Pathfinder - x64'}else{'NivareQ Step 2 Pathfinder - ARM64'}
    $source=Join-Path $Apps $srcName
    $dest=Join-Path $Base "publish-$arch"
    if(-not (Test-Path (Join-Path $source 'NivareQ.Step2Pathfinder.exe'))){throw "Publish output missing for $arch"}
    if(Test-Path $dest){Remove-Item $dest -Force -Recurse}
    New-Item -ItemType Directory -Force -Path $dest | Out-Null
    & robocopy $source $dest /E /NFL /NDL /NJH /NJS /NP | Out-Null
    if($LASTEXITCODE -ge 8){throw "Failed to prepare installer payload for $arch"}
    foreach($asset in @('index.html','scratchpad.js','styles.css')){
      if(-not (Test-Path (Join-Path $dest "ScratchpadAssets\$asset"))){throw "Scratchpad asset missing from published $arch: $asset"}
    }
}
& $Inno (Join-Path $Root 'installer\Pathfinder-x64.iss')
if($LASTEXITCODE -ne 0){throw 'x64 installer compilation failed.'}
& $Inno (Join-Path $Root 'installer\Pathfinder-ARM64.iss')
if($LASTEXITCODE -ne 0){throw 'ARM64 installer compilation failed.'}
$files=Get-ChildItem -LiteralPath $InstallerOut -Filter '*Scratchpad-S1-TEST-Setup*.exe' -File
if($files.Count -lt 2){throw 'Expected two candidate installers.'}
$hashes=foreach($file in $files){Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256 | Select-Object @{N='File';E={$_.Path}},Hash}
$hashes | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $InstallerOut 'SCRATCHPAD-S1-TEST-INSTALLER-SHA256.json') -Encoding utf8
$hashes | Format-Table -AutoSize
Write-Host 'Candidate installers ready. This does NOT mean runtime testing or owner acceptance passed.' -ForegroundColor Yellow
