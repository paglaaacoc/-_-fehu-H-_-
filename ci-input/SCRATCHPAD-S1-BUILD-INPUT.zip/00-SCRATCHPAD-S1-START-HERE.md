# NivareQ Step 2 Pathfinder — Scratchpad S1 TEST candidate
Date: 2026-10-09

## Authority and status
- **Sole accepted Windows baseline**: v1.2.1 Stable, OWNER-ACCEPTED, unchanged.
- **This package**: bounded Scratchpad S1 IMPLEMENTATION CANDIDATE, NOT BUILT, NOT OWNER-TESTED, NOT ACCEPTED, NOT RELEASED.
- **Existing Public-Impact G0 and Four-Scope lines**: remain paused; this independent S1 feature gate does not open them.
- **GitHub**: not used. No Git branch, commit, Actions, CI, Store deployment, or Cloudflare operation was initiated.
- **Original accepted source**: `AUTHORITY/ACCEPTED-v1.2.1-STABLE-SOURCE-READ-ONLY.zip` (byte-identical to the source inside the supplied v1.2.1 master handoff).

## Your approved S1 scope
Scratchpad replaces **only the lower-left Guide shortcut**. The top-bar Guide remains intact. New tool tab is supported by Pathfinder's existing tabs / Split View. Type/edit/select/copy/paste plain text, and draw mouse/finger/stylus ink independently on top. One/two/four spaces per page, optional ruled or triple handwriting guides, adjustable spacing, multiple named pads and pages, ink erase/undo/redo, protected destructive actions, visible native autosave acknowledgement, canonical backup extension preservation.

## Build safely on Windows
1. On your usual v1.2.1 Stable installation, **export and verify a canonical backup** before experimenting.
2. Prefer a separate test Windows account or VM. Portable candidate apps use the same user-specific AppData as Stable, so simply launching a portable test build under your usual Windows login DOES interact with your real local profile.
3. Extract this ZIP to a new folder. Install local .NET **10 SDK**, Inno Setup **7**, Windows App SDK / NuGet prerequisites as needed. Internet may be needed once for normal NuGet restore; **GitHub Actions is never needed**.
4. Double-click `BUILD-SCRATCHPAD-S1-LOCALLY.cmd`. It invokes the inherited short-path Windows publisher, validates medical payload and registry, then locally compiles x64 and ARM64 EXE installers. The script itself does not install or deploy anything.
5. Check `artifacts/installers/` for TWO `v1.2.2-Scratchpad-S1-TEST-Setup-*.exe` and `SCRATCHPAD-S1-TEST-INSTALLER-SHA256.json`.
6. TEST on Windows and follow `SCRATCHPAD-S1-DOCS/OWNER-TEST-AND-ACCEPTANCE.md`. The local built app must compile and run correctly before any acceptance.

> Important: Test installers share the accepted application's installer identity and will upgrade it if installed over Stable. Use a test account/VM or preserve verified rollback backups and your Stable installer. Do NOT interpret 'builder completed' as 'S1 accepted'.

## Evidence and limits
- 504 inherited source files verified; EXACTLY 10 existing integration/build/version files changed and 494 byte-identical.
- 132 inherited `MedicalPayload` files byte-identical. No cockpit medical HTML or registry hash edited.
- Static source checks 14/14 PASS; actual Chromium UI smoke with simulated WebView2 storage bridge PASS.
- This authoring environment is Linux and lacks the Windows .NET 10 / WinUI compiler and Windows pen/touch devices. **Windows compilation, WebView2 integration, installer operation, real backup/restore, and stylus input remain UNVERIFIED.**
- Status must stay **UNACCEPTED** until explicit owner acceptance; a Windows build failure or owner-test failure requires repair, not promotion.

## Files
- `src/NivareQ.Step2Pathfinder/` = entire Windows candidate project, with 4 new S1 source/asset files
- `tools/` = inherited build/integrity tooling plus S1 local builder and read-only QC
- `AUTHORITY/` = exact accepted baseline source ZIP for offline comparison
- `SCRATCHPAD-S1-DOCS/` = implementation architecture, scope/risks, test matrix, diffs and handoff prompt
- `SCRATCHPAD-S1-QC-RESULTS.json` = static verification report
- `INTEGRITY-S1-MANIFEST.json` = file hashes for packaged candidate source

## Rollback
S1 is NOT an accepted replacement for v1.2.1. The embedded baseline source and the earlier accepted master handoff provide recovery; preserve the original v1.2.1 installer/backup. A simple uninstall may leave S1 user data in existing AppData, as required by accepted uninstall policy.
